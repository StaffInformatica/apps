prompt --application/shared_components/user_interface/lovs/lv_sup_funcionario
begin
--   Manifest
--     LV_SUP_FUNCIONARIO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>138
,p_default_id_offset=>286114887983410294
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(776624210360237402)
,p_lov_name=>'LV_SUP_FUNCIONARIO'
,p_lov_query=>'SELECT ID, NOME||'' ''||SOBRENOME||'' (''||USERNAME||'')'' AS FUNCIONARIO FROM ADM_USUARIO '
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'ID'
,p_display_column_name=>'FUNCIONARIO'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
