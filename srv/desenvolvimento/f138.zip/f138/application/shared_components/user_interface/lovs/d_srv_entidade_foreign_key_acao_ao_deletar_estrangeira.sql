prompt --application/shared_components/user_interface/lovs/d_srv_entidade_foreign_key_acao_ao_deletar_estrangeira
begin
--   Manifest
--     D_SRV_ENTIDADE_FOREIGN_KEY.ACAO_AO_DELETAR_ESTRANGEIRA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>138
,p_default_id_offset=>286114887983410294
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(463384825482518367)
,p_lov_name=>'D_SRV_ENTIDADE_FOREIGN_KEY.ACAO_AO_DELETAR_ESTRANGEIRA'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''srv_entidade_foreign_key'',''acao_ao_deletar_estrangeira'') order by d'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>44449961129305
);
wwv_flow_imp.component_end;
end;
/
