prompt --application/shared_components/user_interface/lovs/r_ng_despesa_descricao_despesa_minuta
begin
--   Manifest
--     R_NG_DESPESA.DESCRICAO_DESPESA_MINUTA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>138
,p_default_id_offset=>286114887983410294
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(547305254196941931)
,p_lov_name=>'R_NG_DESPESA.DESCRICAO_DESPESA_MINUTA'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    pkg_traducao.get_traducao(b.descricao_despesa) d,',
'    b.id r',
'from imp_processoimportacao_despesa a',
'join ng_despesa b on b.id = a.id_despesa',
'where a.id_processoimportacao = (',
'          select id_processoimportacao',
'            from imp_minutanotafiscal_entrada',
'           where id = :P9010_PARAMETRO',
'      )',
'  and a.ind_participa_nfe = ''N''',
'  and b.ind_participa_nfe = ''S''',
'order by d',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>50122976531143
);
wwv_flow_imp.component_end;
end;
/
