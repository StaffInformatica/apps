prompt --application/shared_components/user_interface/lovs/lv_situacao_convite
begin
--   Manifest
--     LV_SITUACAO_CONVITE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>138
,p_default_id_offset=>286114887983410294
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(685983274009328271)
,p_lov_name=>'LV_SITUACAO_CONVITE'
,p_lov_query=>'.'||wwv_flow_imp.id(685983274009328271)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(685983549089328271)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Convite pendente'
,p_lov_return_value=>'0'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(685983969084328273)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Convite enviado'
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(685984278492328274)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>unistr('Aguardando confirma\00E7\00E3o')
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(685984715562328274)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>unistr('Usu\00E1rio criado')
,p_lov_return_value=>'3'
);
wwv_flow_imp.component_end;
end;
/
