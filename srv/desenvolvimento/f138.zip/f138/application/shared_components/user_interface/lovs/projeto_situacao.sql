prompt --application/shared_components/user_interface/lovs/projeto_situacao
begin
--   Manifest
--     PROJETO_SITUACAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>138
,p_default_id_offset=>286114887983410294
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(700338637081733088)
,p_lov_name=>'PROJETO_SITUACAO'
,p_lov_query=>'.'||wwv_flow_imp.id(700338637081733088)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(700338881328733089)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Pendente'
,p_lov_return_value=>'P'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(700339333807733091)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Em progresso'
,p_lov_return_value=>'E'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(700339691724733091)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>unistr('Conclu\00EDdo')
,p_lov_return_value=>'C'
);
wwv_flow_imp.component_end;
end;
/
