prompt --application/shared_components/user_interface/lovs/d_tkt_ticket_status_ticket
begin
--   Manifest
--     D_TKT_TICKET.STATUS_TICKET
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>138
,p_default_id_offset=>286114887983410294
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(539914618775933973)
,p_lov_name=>'D_TKT_TICKET.STATUS_TICKET'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''tkt_ticket'',''status_ticket'') order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>50066959101355
);
wwv_flow_imp.component_end;
end;
/
