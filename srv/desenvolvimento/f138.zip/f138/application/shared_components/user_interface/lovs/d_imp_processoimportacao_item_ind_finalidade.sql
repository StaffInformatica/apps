prompt --application/shared_components/user_interface/lovs/d_imp_processoimportacao_item_ind_finalidade
begin
--   Manifest
--     D_IMP_PROCESSOIMPORTACAO_ITEM.IND_FINALIDADE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>138
,p_default_id_offset=>286114887983410294
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(517104960871931742)
,p_lov_name=>'D_IMP_PROCESSOIMPORTACAO_ITEM.IND_FINALIDADE'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''imp_processoimportacao_item'',''ind_finalidade'') order by 2'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>47367307113298
);
wwv_flow_imp.component_end;
end;
/
