prompt --application/shared_components/user_interface/lovs/d_ng_despesa_ind_despesa_base_calculo
begin
--   Manifest
--     D_NG_DESPESA.IND_DESPESA_BASE_CALCULO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>138
,p_default_id_offset=>286114887983410294
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(463738656175009062)
,p_lov_name=>'D_NG_DESPESA.IND_DESPESA_BASE_CALCULO'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''ng_despesa'',''ind_despesa_base_calculo'') order by case when r = ''10'' then 0 else 1 end, d'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>49942570507786
);
wwv_flow_imp.component_end;
end;
/
