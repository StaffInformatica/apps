prompt --application/shared_components/user_interface/lovs/d_imp_processoimportacao_ind_calculando_valores
begin
--   Manifest
--     D_IMP_PROCESSOIMPORTACAO.IND_CALCULANDO_VALORES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>138
,p_default_id_offset=>286114887983410294
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(441960713028336985)
,p_lov_name=>'D_IMP_PROCESSOIMPORTACAO.IND_CALCULANDO_VALORES'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''imp_processoimportacao'',''ind_calculando_valores'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>46843290310084
);
wwv_flow_imp.component_end;
end;
/
