prompt --application/shared_components/user_interface/lovs/d_ng_pessoa_agenciabancaria_ind_agencia_exterior
begin
--   Manifest
--     D_NG_PESSOA_AGENCIABANCARIA.IND_AGENCIA_EXTERIOR
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>138
,p_default_id_offset=>286114887983410294
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(480613425582140989)
,p_lov_name=>'D_NG_PESSOA_AGENCIABANCARIA.IND_AGENCIA_EXTERIOR'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''ng_pessoa_agenciabancaria'', ''ind_agencia_exterior'') order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>44724571949423
);
wwv_flow_imp.component_end;
end;
/
