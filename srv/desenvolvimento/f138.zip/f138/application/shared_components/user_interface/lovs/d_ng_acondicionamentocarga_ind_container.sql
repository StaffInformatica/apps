prompt --application/shared_components/user_interface/lovs/d_ng_acondicionamentocarga_ind_container
begin
--   Manifest
--     D_NG_ACONDICIONAMENTOCARGA.IND_CONTAINER
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>138
,p_default_id_offset=>286114887983410294
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(434218918895142296)
,p_lov_name=>'D_NG_ACONDICIONAMENTOCARGA.IND_CONTAINER'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''ng_acondicionamentocarga'',''ind_container'') order by d'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>44626819096805
);
wwv_flow_imp.component_end;
end;
/
