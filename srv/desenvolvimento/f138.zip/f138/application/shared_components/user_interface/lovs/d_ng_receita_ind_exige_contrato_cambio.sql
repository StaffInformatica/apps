prompt --application/shared_components/user_interface/lovs/d_ng_receita_ind_exige_contrato_cambio
begin
--   Manifest
--     D_NG_RECEITA.IND_EXIGE_CONTRATO_CAMBIO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>138
,p_default_id_offset=>286114887983410294
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(470516576256499340)
,p_lov_name=>'D_NG_RECEITA.IND_EXIGE_CONTRATO_CAMBIO'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''ng_receita'',''ind_exige_contrato_cambio'') order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>44682413143655
);
wwv_flow_imp.component_end;
end;
/
