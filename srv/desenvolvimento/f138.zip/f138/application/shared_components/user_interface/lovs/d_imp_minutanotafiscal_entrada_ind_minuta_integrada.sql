prompt --application/shared_components/user_interface/lovs/d_imp_minutanotafiscal_entrada_ind_minuta_integrada
begin
--   Manifest
--     D_IMP_MINUTANOTAFISCAL_ENTRADA.IND_MINUTA_INTEGRADA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>138
,p_default_id_offset=>286114887983410294
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(502516066745198839)
,p_lov_name=>'D_IMP_MINUTANOTAFISCAL_ENTRADA.IND_MINUTA_INTEGRADA'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Sim'' d, ''S'' r from dual',
'union all',
unistr('select ''N\00E3o'' d, ''N'' r from dual')))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>46565006062611
);
wwv_flow_imp.component_end;
end;
/
