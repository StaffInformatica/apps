prompt --application/shared_components/user_interface/lovs/lv_aparencia
begin
--   Manifest
--     LV_APARENCIA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>138
,p_default_id_offset=>286114887983410294
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(686752278889104302)
,p_lov_name=>'LV_APARENCIA'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_table=>'TUTORIAL_APARENCIA'
,p_query_where=>'ESTA_ATIVO = ''S'''
,p_return_column_name=>'ID'
,p_display_column_name=>'NM_APARENCIA'
,p_icon_column_name=>'ICONE'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'ID'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
