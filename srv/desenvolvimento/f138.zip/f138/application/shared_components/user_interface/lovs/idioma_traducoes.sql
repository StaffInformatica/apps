prompt --application/shared_components/user_interface/lovs/idioma_traducoes
begin
--   Manifest
--     IDIOMA_TRADUCOES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>138
,p_default_id_offset=>286114887983410294
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(485602862259072681)
,p_lov_name=>'IDIOMA_TRADUCOES'
,p_lov_query=>'select nome d, codigo r from srv_idioma'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'D'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>42150311974633
);
wwv_flow_imp.component_end;
end;
/
