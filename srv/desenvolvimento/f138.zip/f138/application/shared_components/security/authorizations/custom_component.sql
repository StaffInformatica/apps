prompt --application/shared_components/security/authorizations/custom_component
begin
--   Manifest
--     SECURITY SCHEME: Custom component
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>138
,p_default_id_offset=>286114887983410294
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(700315265924436578)
,p_name=>'Custom component'
,p_scheme_type=>'NATIVE_FUNCTION_BODY'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return true;',
''))
,p_error_message=>unistr('Voc\00EA n\00E3o tem permiss\00E3o para alterar a foto')
,p_version_scn=>1
,p_caching=>'BY_COMPONENT'
);
wwv_flow_imp.component_end;
end;
/
