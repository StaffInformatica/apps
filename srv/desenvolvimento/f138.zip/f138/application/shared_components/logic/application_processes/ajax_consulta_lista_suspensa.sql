prompt --application/shared_components/logic/application_processes/ajax_consulta_lista_suspensa
begin
--   Manifest
--     APPLICATION PROCESS: AJAX_CONSULTA_LISTA_SUSPENSA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>138
,p_default_id_offset=>286114887983410294
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(530068024301144087)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'AJAX_CONSULTA_LISTA_SUSPENSA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_codigo_artefato varchar2(100) := upper(apex_application.g_x01);',
'    l_campo           varchar2(200) := apex_application.g_x02;',
'',
'    l_package_name    varchar2(261);',
'    l_sql_lista       clob;',
'    l_sql_pkg         varchar2(32767);',
'',
'    l_cursor          integer;',
'    l_status          integer;',
'',
'    l_d               varchar2(4000);',
'    l_r               varchar2(4000);',
'begin',
'    /*',
'        Exemplo:',
'        l_codigo_artefato = TD439',
'        l_package_name    = UI_MPD_TD439',
'    */',
'',
'    if l_codigo_artefato is null then',
unistr('        raise_application_error(-20001, ''C\00F3digo do artefato n\00E3o informado.'');'),
'    end if;',
'',
'    if l_campo is null then',
unistr('        raise_application_error(-20002, ''Campo n\00E3o informado.'');'),
'    end if;',
'',
'    /*',
unistr('        Valida\00E7\00E3o para evitar SQL Injection no nome da package.'),
unistr('        Aceita apenas letras, n\00FAmeros e underline.'),
'    */',
'    if not regexp_like(l_codigo_artefato, ''^[A-Z0-9_]+$'') then',
unistr('        raise_application_error(-20003, ''C\00F3digo do artefato inv\00E1lido.'');'),
'    end if;',
'',
'    l_package_name := dbms_assert.simple_sql_name(''UI_MPD_'' || l_codigo_artefato);',
'',
'    /*',
'        Chama dinamicamente:',
'        begin :ret := UI_MPD_TD439.consulta_lista_suspensa(:campo); end;',
'    */',
'    l_sql_pkg :=',
'        ''begin :ret := '' || l_package_name || ''.consulta_lista_suspensa(:campo); end;'';',
'',
'    execute immediate l_sql_pkg',
'        using out l_sql_lista,',
'              in  l_campo;',
'',
'    if l_sql_lista is null then',
'        apex_json.open_array;',
'        apex_json.close_array;',
'        return;',
'    end if;',
'',
'    /*',
unistr('        A fun\00E7\00E3o consulta_lista_suspensa precisa retornar um SQL com duas colunas:'),
unistr('        d = descri\00E7\00E3o'),
'        r = valor',
'    */',
'',
'    l_cursor := dbms_sql.open_cursor;',
'',
'    dbms_sql.parse(',
'        c             => l_cursor,',
'        statement     => l_sql_lista,',
'        language_flag => dbms_sql.native',
'    );',
'',
'    dbms_sql.define_column(l_cursor, 1, l_d, 4000);',
'    dbms_sql.define_column(l_cursor, 2, l_r, 4000);',
'',
'    l_status := dbms_sql.execute(l_cursor);',
'',
'    apex_json.open_array;',
'',
'    while dbms_sql.fetch_rows(l_cursor) > 0 loop',
'        dbms_sql.column_value(l_cursor, 1, l_d);',
'        dbms_sql.column_value(l_cursor, 2, l_r);',
'',
'        apex_json.open_object;',
'        apex_json.write(''label'', l_d);',
'        apex_json.write(''value'', l_r);',
'        apex_json.close_object;',
'    end loop;',
'',
'    apex_json.close_array;',
'',
'    dbms_sql.close_cursor(l_cursor);',
'',
'exception',
'    when others then',
'        if dbms_sql.is_open(l_cursor) then',
'            dbms_sql.close_cursor(l_cursor);',
'        end if;',
'',
'        apex_json.open_object;',
'        apex_json.write(''success'', false);',
'        apex_json.write(''message'', sqlerrm);',
'        apex_json.close_object;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>49922633739784
);
wwv_flow_imp.component_end;
end;
/
