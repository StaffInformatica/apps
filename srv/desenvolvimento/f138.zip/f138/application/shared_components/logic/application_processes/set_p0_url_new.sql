prompt --application/shared_components/logic/application_processes/set_p0_url_new
begin
--   Manifest
--     APPLICATION PROCESS: SET_P0_URL_NEW
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>138
,p_default_id_offset=>286114887983410294
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(537770351084587566)
,p_process_sequence=>1
,p_process_point=>'AFTER_FOOTER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SET_P0_URL_NEW'
,p_process_sql_clob=>':P0_URL_NEW := null;'
,p_process_clob_language=>'PLSQL'
,p_version_scn=>45626526220078
);
wwv_flow_imp.component_end;
end;
/
