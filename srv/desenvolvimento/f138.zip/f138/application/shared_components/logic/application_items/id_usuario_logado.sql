prompt --application/shared_components/logic/application_items/id_usuario_logado
begin
--   Manifest
--     APPLICATION ITEM: ID_USUARIO_LOGADO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>138
,p_default_id_offset=>286114887983410294
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(690946444850526080)
,p_name=>'ID_USUARIO_LOGADO'
,p_protection_level=>'I'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
