prompt --application/shared_components/logic/application_items/idioma_logado
begin
--   Manifest
--     APPLICATION ITEM: IDIOMA_LOGADO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>138
,p_default_id_offset=>286114887983410294
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(755735938817961745)
,p_name=>'IDIOMA_LOGADO'
,p_protection_level=>'I'
,p_version_scn=>44278785487123
);
wwv_flow_imp.component_end;
end;
/
