prompt --application/shared_components/navigation/lists/wizard_incluir_idioma
begin
--   Manifest
--     LIST: Wizard incluir idioma
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>138
,p_default_id_offset=>286114887983410294
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(449483794741512627)
,p_name=>'Wizard incluir idioma'
,p_list_status=>'PUBLIC'
,p_version_scn=>44294736658949
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(449483941354512637)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>unistr('Descri\00E7\00E3o inicial')
,p_list_item_link_target=>'f?p=&APP_ID.:4:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(449484414238512641)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('Descri\00E7\00F5es adicionais')
,p_list_item_link_target=>'f?p=&APP_ID.:5:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
