prompt --application/shared_components/navigation/lists/perfil_de_usuário
begin
--   Manifest
--     LIST: Perfil de usuário
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>138
,p_default_id_offset=>286114887983410294
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(634613430153984749)
,p_name=>unistr('Perfil de usu\00E1rio')
,p_list_status=>'PUBLIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(634613674597984759)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Meu Perfil'
,p_list_item_link_target=>'f?p=&APP_ID.:133:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(634614088288984782)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Sair'
,p_list_item_link_target=>'&LOGOUT_URL.'
,p_list_item_current_for_pages=>'&LOGOUT_URL.'
);
wwv_flow_imp.component_end;
end;
/
