prompt --application/shared_components/navigation/lists/ação_mensagens_do_chat
begin
--   Manifest
--     LIST: Ação mensagens do chat
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>138
,p_default_id_offset=>286114887983410294
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(753568466453490347)
,p_name=>unistr('A\00E7\00E3o mensagens do chat')
,p_list_status=>'PUBLIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(753568664366490355)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Responder'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(753576128139641322)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('Op\00E7\00E3o 2')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(753576461075641323)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>unistr('Op\00E7\00E3o 3')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
