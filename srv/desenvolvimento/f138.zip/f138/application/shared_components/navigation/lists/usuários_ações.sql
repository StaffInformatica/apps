prompt --application/shared_components/navigation/lists/usuários_ações
begin
--   Manifest
--     LIST: Usuários Ações
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>138
,p_default_id_offset=>286114887983410294
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(687235245360085835)
,p_name=>unistr('Usu\00E1rios A\00E7\00F5es')
,p_list_status=>'PUBLIC'
,p_version_scn=>42176084410894
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(587218876324067659)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Excluir'
,p_list_item_link_target=>'f?p=&APP_ID.:108:&SESSION.::&DEBUG.:108:P108_ID:&P112_ID.:'
,p_list_item_icon=>'fa-trash'
,p_list_text_06=>'u-danger'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
