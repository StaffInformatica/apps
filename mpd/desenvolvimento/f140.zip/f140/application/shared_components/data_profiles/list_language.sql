prompt --application/shared_components/data_profiles/list_language
begin
--   Manifest
--     DATA PROFILE: list-language
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>286238045307748231
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_data_profile(
 p_id=>wwv_flow_imp.id(997881944514059726)
,p_name=>'list-language'
,p_format=>'JSON'
,p_row_selector=>'links'
,p_use_raw_json_selectors=>false
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(997882137754059729)
,p_data_profile_id=>wwv_flow_imp.id(997881944514059726)
,p_name=>'REL'
,p_sequence=>1
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>32767
,p_has_time_zone=>false
,p_selector=>'rel'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(997882493137059730)
,p_data_profile_id=>wwv_flow_imp.id(997881944514059726)
,p_name=>'HREF'
,p_sequence=>2
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>32767
,p_has_time_zone=>false
,p_selector=>'href'
);
wwv_flow_imp.component_end;
end;
/
