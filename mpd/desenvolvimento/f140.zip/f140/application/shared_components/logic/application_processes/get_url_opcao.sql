prompt --application/shared_components/logic/application_processes/get_url_opcao
begin
--   Manifest
--     APPLICATION PROCESS: GET_URL_OPCAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>297994634213220872
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(446071910046833817)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_URL_OPCAO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_url VARCHAR2(2000);',
'BEGIN',
unistr('    -- apex_application.g_x01 \00E9 como o APEX recebe o primeiro par\00E2metro via AJAX'),
'    l_url := APEX_PAGE.GET_URL (',
'        p_application => :APP_ID,',
unistr('        p_page        => 9000,  -- Altere para sua p\00E1gina de destino'),
'        p_session     => :APP_SESSION,',
unistr('        p_clear_cache => 9000,  -- Altere para sua p\00E1gina de destino'),
unistr('        p_items       => ''P9000_ID,P9000_PAGINA,P9000_PARAMETRO'', -- Altere para o item na p\00E1gina de destino'),
'        p_values      => apex_application.g_x02||'',''||apex_application.g_x01||'',''||apex_application.g_x03, -- O ID que recebemos do JavaScript',
'        p_triggering_element => ''apex.jQuery("#NEW")''',
'    );',
'',
'    -- Retornamos a URL em formato JSON',
'    -- grava_log2(''url:''|| l_url);',
'',
'    apex_json.open_object;',
'    apex_json.write(''url'', l_url);',
'    apex_json.close_object;',
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        -- Em caso de erro, retorne um status de erro',
'        htp.p(''{"error":"'' || SQLERRM || ''"}'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>46744901214843
);
wwv_flow_imp.component_end;
end;
/
