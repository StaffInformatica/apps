prompt --application/shared_components/navigation/lists/artefatos_opções
begin
--   Manifest
--     LIST: Artefatos Opções
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>297994634213220872
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(803733519662158004)
,p_name=>unistr('Artefatos Op\00E7\00F5es')
,p_list_status=>'PUBLIC'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
