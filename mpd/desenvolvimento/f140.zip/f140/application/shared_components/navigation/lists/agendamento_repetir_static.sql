prompt --application/shared_components/navigation/lists/agendamento_repetir_static
begin
--   Manifest
--     LIST: Agendamento repetir Static
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>286238045307748231
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(1074281785047968196)
,p_name=>'Agendamento repetir Static'
,p_list_status=>'PUBLIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1074282060488968198)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Nunca'
,p_list_text_03=>'data-id="1"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1074282499893968198)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Todos os Dias'
,p_list_text_03=>'data-id="2"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1074282820499968198)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'A Cada Semana'
,p_list_text_03=>'data-id="3"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1074283304695968199)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'A Cada 2 Semanas'
,p_list_text_03=>'data-id="4"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1074283716639968199)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>unistr('A Cada M\00EAs')
,p_list_text_03=>'data-id="5"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1074284020321968199)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'A Cada Ano'
,p_list_text_03=>'data-id="6"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
