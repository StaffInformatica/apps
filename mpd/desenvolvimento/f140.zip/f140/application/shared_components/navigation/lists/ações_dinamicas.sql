prompt --application/shared_components/navigation/lists/ações_dinamicas
begin
--   Manifest
--     LIST: Ações dinamicas
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>286238045307748231
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(896126928560359231)
,p_name=>unistr('A\00E7\00F5es dinamicas')
,p_list_type=>'FUNCTION_RETURNING_SQL_QUERY'
,p_list_language=>'PLSQL'
,p_list_query=>'return PKG_UI.buscar_acoes(:P9000_ID,:P9000_PAGINA,''W'',false,:P9000_PARAMETRO);'
,p_list_status=>'PUBLIC'
,p_version_scn=>42067731437598
);
wwv_flow_imp.component_end;
end;
/
