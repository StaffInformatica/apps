prompt --application/shared_components/navigation/lists/usuários_papel_opções
begin
--   Manifest
--     LIST: Usuários Papel Opções
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>297994634213220872
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(601495769783424474)
,p_name=>unistr('Usu\00E1rios Papel Op\00E7\00F5es')
,p_list_status=>'PUBLIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(601496021062424480)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Funcionalidades'
,p_list_item_link_target=>'f?p=&APP_ID.:273:&SESSION.::&DEBUG.:273:P273_ID:&P271_ID.:'
,p_list_item_icon=>'fa-tasks-alt'
,p_list_text_01=>'Permite atribuir, alterar ou excluir funcionalidades ao papel'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
