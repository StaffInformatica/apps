prompt --application/shared_components/navigation/lists/navigation_bar
begin
--   Manifest
--     LIST: Navigation Bar
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>297994634213220872
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(827740636737207960)
,p_name=>'Navigation Bar'
,p_list_status=>'PUBLIC'
,p_version_scn=>46526509561249
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(512162654305984600)
,p_list_item_display_sequence=>1
,p_list_item_link_text=>'Rastreamento Ativo'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-warning'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'   return pkg_log_execucao.rastreamento_habilitado;',
'end;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_text_02=>'mt-7'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(827750179369208007)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'&APP_USER.',
''))
,p_list_item_link_target=>'#'
,p_list_text_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<img style="width:25px;height:25px;border-radius:50%;" src="f?p=&APP_ID.:0:&APP_SESSION.:APPLICATION_PROCESS=GET_IMAGE_USER:::IMAGE_USER_ID:&APP_USER." alt=" "></img>',
''))
,p_list_text_02=>wwv_flow_string.join(wwv_flow_t_varchar2(
'has-username image_icon st',
''))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(827750628330208007)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'---'
,p_list_item_link_target=>'separator'
,p_list_item_disp_cond_type=>'NEVER'
,p_parent_list_item_id=>wwv_flow_imp.id(827750179369208007)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(646497034100853464)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Meu Perfil'
,p_list_item_link_target=>'f?p=&APP_ID.:133:&SESSION.::&DEBUG.:133:P133_ID:&ID_USUARIO_LOGADO.:'
,p_list_item_icon=>'fa-user'
,p_parent_list_item_id=>wwv_flow_imp.id(827750179369208007)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(542625507425670503)
,p_list_item_display_sequence=>45
,p_list_item_link_text=>'&P0_LABEL_SELECIONAR_IDIOMA.'
,p_list_item_link_target=>'javascript:openModal(''modal-selecionar-idioma'');'
,p_list_item_icon=>'fa-language'
,p_parent_list_item_id=>wwv_flow_imp.id(827750179369208007)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(488619694132332500)
,p_list_item_display_sequence=>47
,p_list_item_link_text=>'Politica de privacidade'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-user-lock'
,p_parent_list_item_id=>wwv_flow_imp.id(827750179369208007)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(512160179814031366)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Ativar/Desativar rastreamento'
,p_list_item_link_target=>'javascript:openModal(''modal-ativar-rastreamento'');'
,p_list_item_icon=>'fa-power-off'
,p_parent_list_item_id=>wwv_flow_imp.id(827750179369208007)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(512160618234020527)
,p_list_item_display_sequence=>51
,p_list_item_link_text=>'Ver rastreamento'
,p_list_item_link_target=>'f?p=&APP_ID.:9005:&SESSION.::&DEBUG.:9005:P9005_CODIGO_ARTEFATO,P0_CODIGO_ARTEFATO:TD1017,TD1017:'
,p_list_item_icon=>'fa-ai'
,p_parent_list_item_id=>wwv_flow_imp.id(827750179369208007)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(827751044303208007)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Sair'
,p_list_item_link_target=>'&LOGOUT_URL.'
,p_list_item_icon=>'fa-sign-out'
,p_parent_list_item_id=>wwv_flow_imp.id(827750179369208007)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
