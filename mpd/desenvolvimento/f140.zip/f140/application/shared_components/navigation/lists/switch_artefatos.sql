prompt --application/shared_components/navigation/lists/switch_artefatos
begin
--   Manifest
--     LIST: Switch artefatos
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>297994634213220872
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(697528728216285920)
,p_name=>'Switch artefatos'
,p_list_status=>'PUBLIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(697529041993285921)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Adicionar artefatos'
,p_list_item_icon=>'fa-hardware'
,p_list_text_03=>'data-id="1"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
