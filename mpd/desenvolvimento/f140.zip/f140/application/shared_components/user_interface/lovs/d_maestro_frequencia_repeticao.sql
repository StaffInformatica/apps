prompt --application/shared_components/user_interface/lovs/d_maestro_frequencia_repeticao
begin
--   Manifest
--     D_MAESTRO.FREQUENCIA_REPETICAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>297994634213220872
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(591039216209894972)
,p_lov_name=>'D_MAESTRO.FREQUENCIA_REPETICAO'
,p_lov_query=>'select * from PKG_UTIL.dominio_retorna_lista(5104)'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>50381308705975
);
wwv_flow_imp.component_end;
end;
/
