prompt --application/shared_components/user_interface/lovs/d_ng_documento_id_entidade
begin
--   Manifest
--     D_NG_DOCUMENTO.ID_ENTIDADE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>286238045307748231
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(756835152656813933)
,p_lov_name=>'D_NG_DOCUMENTO.ID_ENTIDADE'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    b.nome_leitura d,',
'    a.id           r',
'from srv_entidade_ng_permite_anexo a',
'join srv_entidade b',
'  on b.id = a.id_entidade',
'  order by d',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>45935341595358
);
wwv_flow_imp.component_end;
end;
/
