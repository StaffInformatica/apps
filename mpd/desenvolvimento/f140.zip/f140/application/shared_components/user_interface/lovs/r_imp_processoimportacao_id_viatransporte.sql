prompt --application/shared_components/user_interface/lovs/r_imp_processoimportacao_id_viatransporte
begin
--   Manifest
--     R_IMP_PROCESSOIMPORTACAO.ID_VIATRANSPORTE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>297994634213220872
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(475536431732717704)
,p_lov_name=>'R_IMP_PROCESSOIMPORTACAO.ID_VIATRANSPORTE'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    case ',
'        when regexp_like(a.descricao_viatransporte, ''^[0-9]+$'') ',
'            then t.d',
'        else t.d || '' (antigo)''',
'    end as d,',
'    a.descricao_viatransporte as r',
'from ng_viatransporte a',
'join table(pkg_util.dominio_retorna_lista(''ng_viatransporte'', ''descricao_viatransporte'')) t',
'    on t.r = a.codigo_siscomex',
'order by 1;'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>45868168220379
);
wwv_flow_imp.component_end;
end;
/
