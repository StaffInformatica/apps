prompt --application/shared_components/user_interface/lovs/r_imp_entrega_num_entrega
begin
--   Manifest
--     R_IMP_ENTREGA.NUM_ENTREGA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>286238045307748231
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(800050198051354621)
,p_lov_name=>'R_IMP_ENTREGA.NUM_ENTREGA'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Entrega '' || e.num_entrega',
unistr('       || '' \00B7 ID '' || e.id'),
'       || case when e.data_embarque_informada is not null',
unistr('               then '' \00B7 Emb. '' || to_char(e.data_embarque_informada, ''dd/mm/yyyy'')'),
'          end d,',
'       e.id r',
'  from imp_entrega e',
' where e.id_tenant = :P429_ID_TENANT',
'   and (:P429_ID_PEDIDOIMPORTACAO is null or e.id_pedidoimportacao = :P429_ID_PEDIDOIMPORTACAO)',
' order by e.num_entrega'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>47289060200905
);
wwv_flow_imp.component_end;
end;
/
