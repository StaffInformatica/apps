prompt --application/shared_components/user_interface/lovs/d_imp_minutanotafiscal_entrada_transporte_movimento_unico
begin
--   Manifest
--     D_IMP_MINUTANOTAFISCAL_ENTRADA_TRANSPORTE.MOVIMENTO_UNICO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>286238045307748231
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(836698658084292823)
,p_lov_name=>'D_IMP_MINUTANOTAFISCAL_ENTRADA_TRANSPORTE.MOVIMENTO_UNICO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select d, r from (',
'    select ''Sim'' d, ''S'' r, 1 ordem from dual',
'    union all',
unistr('    select ''N\00E3o'' d, ''N'' r, 2 ordem from dual'),
')',
'order by ordem',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>50138148822219
);
wwv_flow_imp.component_end;
end;
/
