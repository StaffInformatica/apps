prompt --application/shared_components/user_interface/lovs/lv_sup_solucao
begin
--   Manifest
--     LV_SUP_SOLUCAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>286238045307748231
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(1102253069402405565)
,p_lov_name=>'LV_SUP_SOLUCAO'
,p_lov_query=>'.'||wwv_flow_imp.id(1102253069402405565)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(1102253430238405565)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('Temos solu\00E7\00E3o de contorno para o problema reportado')
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(1102253846306405566)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('N\00E3o temos uma solu\00E7\00E3o de contorno para esse problema')
,p_lov_return_value=>'2'
);
wwv_flow_imp.component_end;
end;
/
