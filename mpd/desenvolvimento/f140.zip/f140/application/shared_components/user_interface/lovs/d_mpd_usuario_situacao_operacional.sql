prompt --application/shared_components/user_interface/lovs/d_mpd_usuario_situacao_operacional
begin
--   Manifest
--     D_MPD_USUARIO.SITUACAO_OPERACIONAL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>286238045307748231
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(901626573996162623)
,p_lov_name=>'D_MPD_USUARIO.SITUACAO_OPERACIONAL'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''mpd_usuario'',''SITUACAO_OPERACIONAL'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>41972578699632
);
wwv_flow_imp.component_end;
end;
/
