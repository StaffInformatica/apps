prompt --application/shared_components/user_interface/lovs/d_srv_artefato_eh_executavel_pelo_usuario
begin
--   Manifest
--     D_SRV_ARTEFATO.EH_EXECUTAVEL_PELO_USUARIO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>286238045307748231
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(765041019913033538)
,p_lov_name=>'D_SRV_ARTEFATO.EH_EXECUTAVEL_PELO_USUARIO'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''srv_artefato'',''eh_executavel_pelo_usuario'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>42100009238182
);
wwv_flow_imp.component_end;
end;
/
