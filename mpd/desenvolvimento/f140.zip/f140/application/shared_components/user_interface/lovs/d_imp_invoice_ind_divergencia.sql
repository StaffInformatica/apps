prompt --application/shared_components/user_interface/lovs/d_imp_invoice_ind_divergencia
begin
--   Manifest
--     D_IMP_INVOICE.IND_DIVERGENCIA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>286238045307748231
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(748480769758629898)
,p_lov_name=>'D_IMP_INVOICE.IND_DIVERGENCIA'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''imp_invoice'',''ind_divergencia'') order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>45858850497507
);
wwv_flow_imp.component_end;
end;
/
