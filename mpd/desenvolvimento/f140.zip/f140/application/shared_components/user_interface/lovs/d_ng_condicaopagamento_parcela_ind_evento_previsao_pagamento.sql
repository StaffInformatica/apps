prompt --application/shared_components/user_interface/lovs/d_ng_condicaopagamento_parcela_ind_evento_previsao_pagamento
begin
--   Manifest
--     D_NG_CONDICAOPAGAMENTO_PARCELA.IND_EVENTO_PREVISAO_PAGAMENTO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>286238045307748231
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(718471489617273014)
,p_lov_name=>'D_NG_CONDICAOPAGAMENTO_PARCELA.IND_EVENTO_PREVISAO_PAGAMENTO'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''ng_condicaopagamento_parcela'',''ind_evento_previsao_pagamento'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>44557246600940
);
wwv_flow_imp.component_end;
end;
/
