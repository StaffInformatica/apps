prompt --application/shared_components/user_interface/lovs/r_mpd_tenant_razao_social_autorizado
begin
--   Manifest
--     R_MPD_TENANT.RAZAO_SOCIAL(AUTORIZADO)
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>286238045307748231
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(919927016074147922)
,p_lov_name=>'R_MPD_TENANT.RAZAO_SOCIAL(AUTORIZADO)'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT a.razao_social, a.id',
'FROM mpd_tenant a',
'JOIN mpd_usuario_tenant b',
'ON a.id = b.id_tenant',
'AND b.id_usuario = :ID_USUARIO_LOGADO',
'AND (b.id_usuario <> :P127_ID_USUARIO_2 OR :ID_USUARIO_LOGADO = :P127_ID_USUARIO_2)',
'WHERE a.id NOT IN (',
'    SELECT CASE ',
'        WHEN id_tenant IN (',
'            SELECT id_tenant ',
'            FROM mpd_usuario_tenant ',
'            WHERE id = :P127_ID',
'        ) THEN NULL ',
'        ELSE id_tenant ',
'    END ',
'    FROM mpd_usuario_tenant ',
'    WHERE id_usuario = :P127_ID_USUARIO_2',
')',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'ID'
,p_display_column_name=>'RAZAO_SOCIAL'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'RAZAO_SOCIAL'
,p_default_sort_direction=>'ASC'
,p_version_scn=>41748641222113
);
wwv_flow_imp.component_end;
end;
/
