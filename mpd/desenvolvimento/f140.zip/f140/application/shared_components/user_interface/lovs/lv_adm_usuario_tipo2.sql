prompt --application/shared_components/user_interface/lovs/lv_adm_usuario_tipo2
begin
--   Manifest
--     LV_ADM_USUARIO_TIPO2
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>297994634213220872
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(697879194515156182)
,p_lov_name=>'LV_ADM_USUARIO_TIPO2'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select 1 as value, ''Administrador'' as Descricao, ''Acesso ilimitado aos recursos do sistema'' as Complemento from dual ',
'union ',
unistr('Select 2 as value, ''Usu\00E1rio final'' as Descricao, ''Considera as atribui\00E7\00F5es do controle de acesso'' as Complemento from dual')))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'VALUE'
,p_display_column_name=>'DESCRICAO'
,p_default_sort_column_name=>'DESCRICAO'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
