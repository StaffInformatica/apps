prompt --application/shared_components/user_interface/lovs/metadata_atribuito_nome
begin
--   Manifest
--     METADATA_ATRIBUITO.NOME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>286238045307748231
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(1002436291868871476)
,p_lov_name=>'METADATA_ATRIBUITO.NOME'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'METADATA_ATRIBUITO'
,p_return_column_name=>'ID'
,p_display_column_name=>'NOME'
,p_default_sort_column_name=>'NOME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
