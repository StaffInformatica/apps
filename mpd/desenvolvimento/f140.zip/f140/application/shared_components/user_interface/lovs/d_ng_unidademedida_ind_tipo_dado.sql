prompt --application/shared_components/user_interface/lovs/d_ng_unidademedida_ind_tipo_dado
begin
--   Manifest
--     D_NG_UNIDADEMEDIDA.IND_TIPO_DADO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>286238045307748231
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(718347428513573750)
,p_lov_name=>'D_NG_UNIDADEMEDIDA.IND_TIPO_DADO'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''ng_unidademedida'',''ind_tipo_dado'') order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>45533905423371
);
wwv_flow_imp.component_end;
end;
/
