prompt --application/shared_components/user_interface/lovs/lv_agendamento_frequencia
begin
--   Manifest
--     LV_AGENDAMENTO_FREQUENCIA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>297994634213220872
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(799971334747034859)
,p_lov_name=>'LV_AGENDAMENTO_FREQUENCIA'
,p_lov_query=>'.'||wwv_flow_imp.id(799971334747034859)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(799971760952034859)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Diariamente'
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(799972154470034859)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Semanalmente'
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(799972540918034860)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Mensalmente'
,p_lov_return_value=>'3'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(799972927309034860)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Anualmente'
,p_lov_return_value=>'4'
);
wwv_flow_imp.component_end;
end;
/
