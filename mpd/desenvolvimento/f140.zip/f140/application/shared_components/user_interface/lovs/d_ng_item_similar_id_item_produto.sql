prompt --application/shared_components/user_interface/lovs/d_ng_item_similar_id_item_produto
begin
--   Manifest
--     D_NG_ITEM_SIMILAR.ID_ITEM_PRODUTO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>297994634213220872
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(538548353245524363)
,p_lov_name=>'D_NG_ITEM_SIMILAR.ID_ITEM_PRODUTO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    b.codigo_item as d,  ',
'    b.id as r                       ',
'from  ng_item b ',
'where b.ind_tipo_item = ''P''',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>49877686289581
);
wwv_flow_imp.component_end;
end;
/
