prompt --application/shared_components/user_interface/lovs/d_imp_naturezaoperacao_tributo_ind_credito_pis_cofins
begin
--   Manifest
--     D_IMP_NATUREZAOPERACAO_TRIBUTO.IND_CREDITO_PIS_COFINS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>297994634213220872
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(458773448957237990)
,p_lov_name=>'D_IMP_NATUREZAOPERACAO_TRIBUTO.IND_CREDITO_PIS_COFINS'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''imp_naturezaoperacao_tributo'',''ind_credito_pis_cofins'') order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>45295261510254
);
wwv_flow_imp.component_end;
end;
/
