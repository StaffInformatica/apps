prompt --application/shared_components/user_interface/lovs/r_banco_dados
begin
--   Manifest
--     R_BANCO_DADOS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>297994634213220872
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(492948791447614688)
,p_lov_name=>'R_BANCO_DADOS'
,p_lov_query=>'select USERNAME AS ID, USERNAME AS DESCRICAO from all_users where username like ''WKSP_%'';'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'ID'
,p_display_column_name=>'DESCRICAO'
,p_default_sort_column_name=>'DESCRICAO'
,p_default_sort_direction=>'ASC'
,p_version_scn=>42124598457991
);
wwv_flow_imp.component_end;
end;
/
