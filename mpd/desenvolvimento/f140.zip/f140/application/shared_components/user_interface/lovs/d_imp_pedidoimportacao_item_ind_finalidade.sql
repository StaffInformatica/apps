prompt --application/shared_components/user_interface/lovs/d_imp_pedidoimportacao_item_ind_finalidade
begin
--   Manifest
--     D_IMP_PEDIDOIMPORTACAO_ITEM.IND_FINALIDADE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>286238045307748231
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(803130507313852338)
,p_lov_name=>'D_IMP_PEDIDOIMPORTACAO_ITEM.IND_FINALIDADE'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''imp_pedidoimportacao_item'',''ind_finalidade'') order by 2'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>47349602417040
);
wwv_flow_imp.component_end;
end;
/
