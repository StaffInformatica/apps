prompt --application/shared_components/user_interface/lovs/r_mpd_tenant_descricao_idioma
begin
--   Manifest
--     R_MPD_TENANT.DESCRICAO_IDIOMA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>286238045307748231
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(760312774682833211)
,p_lov_name=>'R_MPD_TENANT.DESCRICAO_IDIOMA'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    pkg_traducao.get_traducao(b.descricao_idioma) d,',
'    a.id r',
'from mpd_tenant a',
'left join srv_idioma b on b.id = a.id_idioma'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>46037555182733
);
wwv_flow_imp.component_end;
end;
/
