prompt --application/shared_components/user_interface/lovs/r_ng_atributoitem_descricao_atributoitem
begin
--   Manifest
--     R_NG_ATRIBUTOITEM.DESCRICAO_ATRIBUTOITEM
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>286238045307748231
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(762647184807671734)
,p_lov_name=>'R_NG_ATRIBUTOITEM.DESCRICAO_ATRIBUTOITEM'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select d, r from (',
'    select null d, null r, 0 ordem from dual',
'    union all',
'select ',
'    pkg_traducao.get_traducao(a.descricao_atributoitem), a.id, 1 ',
'from ng_atributoitem a ',
'where a.data_fim_vigencia is null ',
'or to_date(a.data_fim_vigencia) >= to_date(current_date))',
'order by ordem, d'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>46037565393060
);
wwv_flow_imp.component_end;
end;
/
