prompt --application/shared_components/user_interface/lovs/r_mpd_via_transporte
begin
--   Manifest
--     R_MPD_VIA_TRANSPORTE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>286238045307748231
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(743257089207942124)
,p_lov_name=>'R_MPD_VIA_TRANSPORTE'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select descricao d, a.id r from mpd_viatransporte a join mpd_descricao b on b.id_chave_tabela = a.id ',
'and b.id_tabela = (select id from mpd_entidade where lower(nome_entidade) = ''mpd_viatransporte'')',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>44365983030780
);
wwv_flow_imp.component_end;
end;
/
