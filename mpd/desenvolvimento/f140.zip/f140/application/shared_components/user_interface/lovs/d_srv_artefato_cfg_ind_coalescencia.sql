prompt --application/shared_components/user_interface/lovs/d_srv_artefato_cfg_ind_coalescencia
begin
--   Manifest
--     D_SRV_ARTEFATO_CFG.IND_COALESCENCIA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>286238045307748231
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(785357476890207432)
,p_lov_name=>'D_SRV_ARTEFATO_CFG.IND_COALESCENCIA'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''srv_artefato_cfg'',''ind_coalescencia'') order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>46488574769391
);
wwv_flow_imp.component_end;
end;
/
