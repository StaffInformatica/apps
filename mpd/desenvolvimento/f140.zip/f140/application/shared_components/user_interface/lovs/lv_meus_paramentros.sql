prompt --application/shared_components/user_interface/lovs/lv_meus_paramentros
begin
--   Manifest
--     LV_MEUS_PARAMENTROS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>286238045307748231
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(1075344312757180384)
,p_lov_name=>'LV_MEUS_PARAMENTROS'
,p_lov_query=>'Select ID, NOME FROM ADM_PROGRAMA WHERE PROGRAMA = :PROGRAMA AND USUARIO = RETORNA_ID_USUARIO_LOGADO AND NOME IS NOT NULL'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'ID'
,p_display_column_name=>'NOME'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
