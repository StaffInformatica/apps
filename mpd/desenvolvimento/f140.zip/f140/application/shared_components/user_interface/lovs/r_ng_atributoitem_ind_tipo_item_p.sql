prompt --application/shared_components/user_interface/lovs/r_ng_atributoitem_ind_tipo_item_p
begin
--   Manifest
--     R_NG_ATRIBUTOITEM.IND_TIPO_ITEM=P
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>286238045307748231
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(755828545770669583)
,p_lov_name=>'R_NG_ATRIBUTOITEM.IND_TIPO_ITEM=P'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    pkg_traducao.get_traducao(a.descricao_atributoitem)  D, a.id  R',
'from ng_atributoitem a ',
'where UPPER(ind_tipo_item) = ''P'' ',
'AND UPPER(ind_situacao) = ''D'' ',
'AND UPPER(ind_item_operacao) = ''I''',
'AND (a.data_fim_vigencia is null ',
'or to_date(a.data_fim_vigencia) >= to_date(current_date))',
'order by D'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>46037565834900
);
wwv_flow_imp.component_end;
end;
/
