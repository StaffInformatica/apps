prompt --application/shared_components/user_interface/lovs/lv_sup_simulado
begin
--   Manifest
--     LV_SUP_SIMULADO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>286238045307748231
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(1102251682058405564)
,p_lov_name=>'LV_SUP_SIMULADO'
,p_lov_query=>'.'||wwv_flow_imp.id(1102251682058405564)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(1102252071652405565)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Este problema pode ser reproduzido'
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(1102252445107405565)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('Este problema \00E9 aleat\00F3rio, n\00E3o consigo reproduzi-lo')
,p_lov_return_value=>'2'
);
wwv_flow_imp.component_end;
end;
/
