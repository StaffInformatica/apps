prompt --application/shared_components/user_interface/lovs/d_ng_pessoa_ind_perfil_transportador
begin
--   Manifest
--     D_NG_PESSOA.IND_PERFIL_TRANSPORTADOR
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>297994634213220872
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(451722443992722613)
,p_lov_name=>'D_NG_PESSOA.IND_PERFIL_TRANSPORTADOR'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.nome_fantasia || '' - '' ||a.razao_social as d,',
'    b.id as r',
'from ng_pessoa_juridica a ',
'join ng_pessoa b on b.id = a.id_pessoa',
'where '':'' || a.ind_perfil || '':'' like ''%:T:%''',
'order by 1'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>45667462049819
);
wwv_flow_imp.component_end;
end;
/
