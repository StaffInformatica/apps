prompt --application/shared_components/user_interface/lovs/d_srv_artefato_cfg_cb_ind_teste_em_andamento
begin
--   Manifest
--     D_SRV_ARTEFATO_CFG.CB_IND_TESTE_EM_ANDAMENTO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>297994634213220872
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(590039962630799704)
,p_lov_name=>'D_SRV_ARTEFATO_CFG.CB_IND_TESTE_EM_ANDAMENTO'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''srv_artefato_cfg'',''cb_ind_teste_em_andamento'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>50362773227358
);
wwv_flow_imp.component_end;
end;
/
