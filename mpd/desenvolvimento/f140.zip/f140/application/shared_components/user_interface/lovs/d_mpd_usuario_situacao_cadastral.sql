prompt --application/shared_components/user_interface/lovs/d_mpd_usuario_situacao_cadastral
begin
--   Manifest
--     D_MPD_USUARIO.SITUACAO_CADASTRAL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>286238045307748231
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(799957246483936999)
,p_lov_name=>'D_MPD_USUARIO.SITUACAO_CADASTRAL'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''mpd_usuario'',''SITUACAO_CADASTRAL'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>41972578495555
);
wwv_flow_imp.component_end;
end;
/
