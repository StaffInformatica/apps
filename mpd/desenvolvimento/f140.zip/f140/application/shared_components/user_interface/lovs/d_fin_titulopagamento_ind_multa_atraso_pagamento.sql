prompt --application/shared_components/user_interface/lovs/d_fin_titulopagamento_ind_multa_atraso_pagamento
begin
--   Manifest
--     D_FIN_TITULOPAGAMENTO.IND_MULTA_ATRASO_PAGAMENTO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>297994634213220872
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(480097778626274471)
,p_lov_name=>'D_FIN_TITULOPAGAMENTO.IND_MULTA_ATRASO_PAGAMENTO'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''fin_titulopagamento'',''ind_multa_atraso_pagamento'') order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>45909238566565
);
wwv_flow_imp.component_end;
end;
/
