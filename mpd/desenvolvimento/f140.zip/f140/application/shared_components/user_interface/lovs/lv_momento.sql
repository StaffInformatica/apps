prompt --application/shared_components/user_interface/lovs/lv_momento
begin
--   Manifest
--     LV_MOMENTO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>286238045307748231
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(1003322670031869666)
,p_lov_name=>'LV_MOMENTO'
,p_lov_query=>'.'||wwv_flow_imp.id(1003322670031869666)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(1003323001583869669)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Antes'
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(1003323364898869671)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Depois'
,p_lov_return_value=>'2'
);
wwv_flow_imp.component_end;
end;
/
