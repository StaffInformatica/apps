prompt --application/shared_components/user_interface/lovs/lv_sup_solicitante
begin
--   Manifest
--     LV_SUP_SOLICITANTE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>297994634213220872
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(818473222860745218)
,p_lov_name=>'LV_SUP_SOLICITANTE'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    ID_USUARIO,',
'    USUARIO, ',
'    ID_EMPRESA   ',
'FROM ADM_CHAMADO',
'WHERE ID_USUARIO IS NOT NULL AND USUARIO IS NOT NULL',
'GROUP BY ID_USUARIO, USUARIO, ID_EMPRESA'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'ID_USUARIO'
,p_display_column_name=>'USUARIO'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
