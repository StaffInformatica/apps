prompt --application/shared_components/user_interface/lovs/r_imp_entrega_item_codigo_item
begin
--   Manifest
--     R_IMP_ENTREGA_ITEM.CODIGO_ITEM
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>297994634213220872
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(525692134093423242)
,p_lov_name=>'R_IMP_ENTREGA_ITEM.CODIGO_ITEM'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select i.codigo_item',
unistr('       || '' \00B7 '' || substr(i.descricao_item, 1, 80)'),
unistr('       || '' \00B7 NCM '' || n.codigo_ncm'),
unistr('       || '' \00B7 EI '' || ei.id d,'),
'       ei.id r',
'  from imp_entrega_item ei',
'  join ng_item i',
'    on i.id_tenant = ei.id_tenant',
'   and i.id = ei.id_item',
'  join ng_ncm n',
'    on n.id_tenant = ei.id_tenant',
'   and n.id = ei.id_ncm',
' where ei.id_tenant = :P429_ID_TENANT',
'   and (:ID_ENTREGA is null or ei.id_entrega = :ID_ENTREGA)',
' order by i.codigo_item'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>47289062700525
);
wwv_flow_imp.component_end;
end;
/
