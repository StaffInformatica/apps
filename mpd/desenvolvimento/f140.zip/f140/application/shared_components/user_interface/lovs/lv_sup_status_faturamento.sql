prompt --application/shared_components/user_interface/lovs/lv_sup_status_faturamento
begin
--   Manifest
--     LV_SUP_STATUS_FATURAMENTO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>286238045307748231
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(1080192455050233962)
,p_lov_name=>'LV_SUP_STATUS_FATURAMENTO'
,p_lov_query=>'.'||wwv_flow_imp.id(1080192455050233962)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(1080192750891233982)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('Boleto n\00E3o emitido')
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(1080193161157233983)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Boleto emitido'
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(1080193526144233983)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Faturado'
,p_lov_return_value=>'3'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(1080193933673233984)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Atrasado'
,p_lov_return_value=>'4'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(1080194373440233984)
,p_lov_disp_sequence=>5
,p_lov_disp_value=>unistr('Em negocia\00E7\00E3o')
,p_lov_return_value=>'5'
);
wwv_flow_imp.component_end;
end;
/
