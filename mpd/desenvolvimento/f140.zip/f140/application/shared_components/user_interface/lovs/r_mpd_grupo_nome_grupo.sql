prompt --application/shared_components/user_interface/lovs/r_mpd_grupo_nome_grupo
begin
--   Manifest
--     R_MPD_GRUPO.NOME_GRUPO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>140
,p_default_id_offset=>286238045307748231
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(291268371334537282)
,p_lov_name=>'R_MPD_GRUPO.NOME_GRUPO'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'MPD_GRUPO'
,p_return_column_name=>'ID'
,p_display_column_name=>'NOME_GRUPO'
,p_default_sort_column_name=>'NOME_GRUPO'
,p_default_sort_direction=>'ASC'
,p_version_scn=>50352710742058
);
wwv_flow_imp.component_end;
end;
/
