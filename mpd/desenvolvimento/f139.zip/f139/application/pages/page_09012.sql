prompt --application/pages/page_09012
begin
--   Manifest
--     PAGE: 09012
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_page.create_page(
 p_id=>9012
,p_name=>'Template - Formulario Wizard'
,p_alias=>'TEMPLATE-FORMULARIO-WIZARD'
,p_page_mode=>'MODAL'
,p_step_title=>'Template - Formulario Wizard'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function copiarValor(origemId, destinoId) {',
'    var datePicker = document.getElementById(origemId);',
'    var valorOrigem = datePicker ? datePicker.value : ''''; ',
'    document.getElementById(destinoId).value = valorOrigem;',
'    console.log(document.getElementById(destinoId).value);',
'}',
'',
'function logValor(item){',
'    console.log(item);',
'    console.log(item.value);',
'    console.log(apex.item( "P9010_FILE1" ).getValue()); ',
'}',
'',
'',
'function checkInputAndToggleClass(inputElement) {',
unistr('    // Verificar se o campo de entrada est\00E1 preenchido'),
'    console.log(inputElement.value);',
'    if (inputElement.value.trim() !== "") {',
unistr('        // Localizar a div pai que cont\00E9m "CONTAINER" no ID'),
'        let parentDiv = inputElement.closest("div[id*=''CONTAINER'']");',
'        ',
'        // Se a div for encontrada, adicionar a classe js-show-label',
'        if (parentDiv) {',
'            parentDiv.classList.add("js-show-label");',
'        }',
'    } else {',
'        // Se o valor estiver vazio, remover a classe js-show-label',
'        let parentDiv = inputElement.closest("div[id*=''CONTAINER'']");',
'        ',
'        // Remover a classe js-show-label se ela existir',
'        if (parentDiv) {',
'            parentDiv.classList.remove("js-show-label");',
'        }',
'    }',
'}',
'',
'// function toggleFileUpload() {',
'//     // Seleciona o elemento <a-dynamic-content>',
'//     var dynamicContent = document.querySelector(''a-dynamic-content'');',
'//     console.log(dynamicContent);',
unistr('//     // Verifica se o elemento existe e se cont\00E9m a palavra "mostra_file"'),
'//     if (dynamicContent && dynamicContent.innerHTML.includes(''mostra_file'')) {',
'//         // Se encontrar, mostra o item de upload de arquivo',
'//         apex.item(''P9010_FILE1'').show();',
'//     } else {',
unistr('//         // Caso contr\00E1rio, oculta o item de upload de arquivo'),
'//         apex.item(''P9010_FILE1'').hide();',
'//     }',
'// }',
'',
'document.addEventListener("DOMContentLoaded", function() {',
'  //   toggleFileUpload();  ',
'  var windowWidth = 400;  // Largura da janela popup',
'  var windowHeight = 450;  // Altura da janela popup',
'',
'  // Calcula o centro da tela',
'  var left = (window.screen.width - windowWidth) / 2;',
'  var top = (window.screen.height - windowHeight) / 2;',
'',
unistr('  // Modifica os par\00E2metros de ''left'' e ''top'' no popup gerado'),
'  var originalOpen = window.open;',
'  window.open = function(url, name, specs) {',
unistr('    // Adiciona ou substitui os par\00E2metros ''left'' e ''top'''),
'    specs = specs.replace(/left=\d+/, ''left='' + left);',
'    specs = specs.replace(/top=\d+/, ''top='' + top);',
'',
unistr('    // Se ''left'' e ''top'' n\00E3o existirem, adiciona os par\00E2metros'),
'    if (!specs.includes(''left='')) specs += '',left='' + left;',
'    if (!specs.includes(''top='')) specs += '',top='' + top;',
'',
unistr('    // Chama a fun\00E7\00E3o window.open original com as modifica\00E7\00F5es'),
'    return originalOpen.call(window, url, name, specs);',
'  };',
'});'))
,p_javascript_code_onload=>'tituloTela($v("P9012_TELA_TITULO")+'' (''+$v("P9012_CODIGO_ARTEFATO")+'')'');'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.centro{',
'    display: grid;',
'    justify-items: center;',
'}',
'',
'.select option.selected {',
'    color: #888; /* Cor mais clara para parecer um placeholder */',
'    opacity: 0.5; /* Reduz a opacidade */',
'}',
'',
''))
,p_step_template=>wwv_flow_imp.id(489110489949697573)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_protection_level=>'C'
,p_page_component_map=>'27'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(321759841014005052)
,p_plug_name=>'Steps'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#:t-WizardSteps--displayLabels'
,p_plug_template=>wwv_flow_imp.id(489194609147697632)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_list_id=>wwv_flow_imp.id(167955282233907082)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(489271776772697681)
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    1',
'from srv_artefato_wizard a',
'join srv_artefato_versionado b on b.id = a.id_artefato_versionado',
'join srv_artefato c on c.id = b.id_artefato',
'join srv_artefato_versionado b1 on b1.id = a.id_artefato_versionado_base',
'join srv_artefato c1 on c1.id = b1.id_artefato',
'where c.codigo_artefato = nvl( apex_util.get_session_state(''P''||:APP_PAGE_ID||''_CODIGO_WIZARD''),:p0_codigo_artefato)'))
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(321760323446006699)
,p_plug_name=>'Footer'
,p_region_css_classes=>'u-margin-bottom-none'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(489149217063697608)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(329033600569543154)
,p_plug_name=>'Header'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(489149217063697608)
,p_plug_display_sequence=>10
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9012_CODIGO_ARTEFATO,''TD452'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_cabecalho(:param1,:param2); END;''',
'        USING OUT l_sql, IN nvl(:P9012_ID,:P9012_PARAMETRO),:P9012_PARAMETRO2;',
'',
'    return l_sql;       ',
'end;',
''))
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P9012_ID,P9012_PARAMETRO,P9010_PARAMETRO2'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from all_procedures',
'where upper(object_name) = upper(''ui_mpd_''||:p9012_codigo_artefato)',
'and upper(procedure_name) = upper(''sql_cabecalho'')',
'and upper(object_type) = upper(''package'');'))
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(475828099932183485)
,p_plug_name=>unistr('Formul\00E1rio')
,p_region_template_options=>'#DEFAULT#:t-Form--large'
,p_plug_template=>wwv_flow_imp.id(489146466586697607)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_html clob;        ',
'    l_codigo_artefato varchar2(128) := nvl(:P9012_CODIGO_ARTEFATO,100);',
'begin',
'    pkg_ui.gerar_formulario(l_codigo_artefato,nvl(:P9012_ID,:P9012_COPIA),:P9012_VISUALIZAR,l_html,:P9012_PARAMETRO,:P9012_PARAMETRO2); ',
'    return l_html;',
'end;'))
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P9012_CODIGO_ARTEFATO,P9012_ID,P9012_COPIA,P9012_PARAMETRO,P9012_PARAMETRO2,P9012_VISUALIZAR'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(633305142959006839)
,p_plug_name=>unistr('Opera\00E7\00F5es')
,p_parent_plug_id=>wwv_flow_imp.id(475828099932183485)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(489147839586697607)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return PKG_UI.buscar_acoes(:P9012_ID,:P9012_CODIGO_ARTEFATO,''E'',false,:P9012_PARAMETRO);',
''))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_BOT_ES_A__ES'
,p_ajax_items_to_submit=>'P9012_ID,P9012_PAGINA'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'PKG_UI.verifica_se_tem_linhas(PKG_UI.buscar_acoes(:P9012_ID,:P9012_CODIGO_ARTEFATO,''E'',false,:P9012_PARAMETRO)) = true'
,p_plug_display_when_cond2=>'PLSQL'
,p_required_patch=>wwv_flow_imp.id(489109181809697564)
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'ICON', 'ICON',
  'LABEL', 'LABEL',
  'LINK', 'LINK',
  'MY_SECOND_PLACEHOLDER', 'HELP')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(306364273234453368)
,p_name=>'SQL_VALIDACAO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SQL_VALIDACAO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(476753259684777161)
,p_name=>'LABEL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LABEL'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(476753324800777162)
,p_name=>'HELP'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'HELP'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(633501736217214708)
,p_name=>'LINK'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LINK'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(633501814785214709)
,p_name=>'ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(167921956528906893)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(321760323446006699)
,p_button_name=>'Create'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(489279883613697688)
,p_button_image_alt=>unistr('Pr\00F3ximo')
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P9012_ID is null and :P9012_URL_PROXIMO is not null'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-angle-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(167921537299906892)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(321760323446006699)
,p_button_name=>'Save'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(489279883613697688)
,p_button_image_alt=>unistr('Pr\00F3ximo')
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P9012_ID is not null and :P9012_URL_PROXIMO is not null'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-angle-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(167920310271906887)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(321760323446006699)
,p_button_name=>'DoneC'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(489279883613697688)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Concluir'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P9012_ID is null and :P9012_URL_PROXIMO is null'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-check-circle'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(167920771047906890)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(321760323446006699)
,p_button_name=>'DoneS'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(489279883613697688)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Concluir'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P9012_ID is not null and :P9012_URL_PROXIMO is null'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-check-circle'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(167921203913906891)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(321760323446006699)
,p_button_name=>'Voltar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(489279883613697688)
,p_button_image_alt=>'Voltar'
,p_button_position=>'PREVIOUS'
,p_button_condition=>'P9012_URL_ANTERIOR'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-angle-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(167954593990907071)
,p_branch_name=>'goto_anterior'
,p_branch_action=>'P9012_URL_ANTERIOR'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'BRANCH_TO_URL_IDENT_BY_ITEM'
,p_branch_when_button_id=>wwv_flow_imp.id(167921203913906891)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(167954994259907072)
,p_branch_name=>'goto_proximo'
,p_branch_action=>'P9012_URL_PROXIMO'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'BRANCH_TO_URL_IDENT_BY_ITEM'
,p_branch_sequence=>20
,p_branch_condition_type=>'REQUEST_IN_CONDITION'
,p_branch_condition=>'Create,Save'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(179619633221495184)
,p_name=>'P9012_CODIGO_WIZARD'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(221328977495065463)
,p_name=>'P9012_SELECTED_ITEM_ID'
,p_item_sequence=>200
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(221329074868065464)
,p_name=>'P9012_SELECTED_ITEM_TEXT'
,p_item_sequence=>210
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(246372862264147166)
,p_name=>'P9012_URL_PROXIMO'
,p_item_sequence=>170
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(246372959571147167)
,p_name=>'P9012_URL_ANTERIOR'
,p_item_sequence=>180
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(272783086042268759)
,p_name=>'P9012_ETAPA'
,p_item_sequence=>190
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(350995167120215644)
,p_name=>'P9012_ID'
,p_item_sequence=>140
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(395402035358389390)
,p_name=>'P9012_PARAMETRO'
,p_item_sequence=>120
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(395402130377389391)
,p_name=>'P9012_PARAMETRO2'
,p_item_sequence=>130
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(395402210459389392)
,p_name=>'P9012_TELA_TITULO'
,p_item_sequence=>150
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(395402280689389393)
,p_name=>'P9012_TELA_HELP'
,p_item_sequence=>160
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(475765468772017360)
,p_name=>'P9012_CODIGO_ARTEFATO'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(475846265769183644)
,p_name=>'P9012_SUCESSO'
,p_item_sequence=>100
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(475997432459180624)
,p_name=>'P9012_VISUALIZAR'
,p_item_sequence=>90
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(478248978981744143)
,p_name=>'P9012_COPIA'
,p_item_sequence=>110
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(167930610500906982)
,p_computation_sequence=>10
,p_computation_item=>'P9012_ID'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_id number;',
'    l_pagina varchar2(256) := nvl(:P9012_CODIGO_ARTEFATO,''TD452'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_id := UI_MPD_''||l_pagina||''.busca_id_etapa(:param1); END;''',
'        USING OUT l_id, IN :P9012_PARAMETRO;',
'',
'    return l_id;       ',
'end;',
''))
,p_compute_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from all_procedures',
'where upper(object_name) = upper(''ui_mpd_''||:p9012_codigo_artefato)',
'and upper(procedure_name) = upper(''BUSCA_ID_ETAPA'')',
'and upper(object_type) = upper(''package'');'))
,p_compute_when_type=>'EXISTS'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(167943100566907034)
,p_name=>'onChangeIdTenant'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#id_tenant'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(167943522377907038)
,p_event_id=>wwv_flow_imp.id(167943100566907034)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var value = apex.item("id_tenant").getValue();',
'apex.item("id_idioma_empresa").setValue(value)',
'',
'',
'var tenantValue = apex.item("id_tenant").getValue();',
'',
'apex.server.process(',
'    "SET_TENANT_GLOBAL",           // Nome do processo AJAX',
'    { x01: tenantValue },     // Passando o valor do item',
'    {',
'        success: function(pData) {',
unistr('            console.log("Sess\00E3o atualizada com sucesso:", tenantValue);'),
'        },',
'        error: function(err) {',
unistr('            console.error("Erro ao atualizar sess\00E3o:", err);'),
'        }',
'    }',
');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(167945789640907044)
,p_name=>'onClickjs-dlg-refresh'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.js-dlg-refresh'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#FORM'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(167946288697907045)
,p_event_id=>wwv_flow_imp.id(167945789640907044)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'window._lastDlgLink = this.triggeringElement;'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(167946633671907047)
,p_name=>'onClickjs-dlg-setvalue'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.js-dlg-setvalue'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(167947172141907048)
,p_event_id=>wwv_flow_imp.id(167946633671907047)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'window._lastDlgLinkZoom = $(this.triggeringElement)',
'    .closest(''span.lov'')   // sobe para o container',
'    .find(''input[coluna], textarea[coluna]'') // pega input OU textarea com atributo ''coluna''',
'    .attr(''coluna'');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(167947599663907049)
,p_name=>'onClosejs-dlg-refresh'
,p_event_sequence=>40
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'document'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'!!window._lastDlgLink'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(167948035717907052)
,p_event_id=>wwv_flow_imp.id(167947599663907049)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(475828099932183485)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(167948517678907053)
,p_event_id=>wwv_flow_imp.id(167947599663907049)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'window._lastDlgLink = null;'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(167948923182907054)
,p_name=>'onClosejs-dlg-setvalue'
,p_event_sequence=>50
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'document'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'!!window._lastDlgLinkZoom'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(167949467917907055)
,p_event_id=>wwv_flow_imp.id(167948923182907054)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9012_SELECTED_ITEM_ID'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P9004_SELECTED_ITEM_ID'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(167949996270907057)
,p_event_id=>wwv_flow_imp.id(167948923182907054)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9012_SELECTED_ITEM_TEXT'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P9004_SELECTED_ITEM_TEXT'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(167950417900907058)
,p_event_id=>wwv_flow_imp.id(167948923182907054)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'window._lastDlgLinkZoom = null;'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(167944000395907040)
,p_name=>'onChangeSelectItemId'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9012_SELECTED_ITEM_ID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(167944426035907041)
,p_event_id=>wwv_flow_imp.id(167944000395907040)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''input[coluna="'' + window._lastDlgLinkZoom + ''"], textarea[coluna="'' + window._lastDlgLinkZoom + ''"]'')',
'  .closest(''span.lov'')',
'  .find(''input[type=hidden]'');'))
,p_attribute_01=>'PLSQL_EXPRESSION'
,p_attribute_04=>':P9012_SELECTED_ITEM_ID'
,p_attribute_07=>'P9012_SELECTED_ITEM_ID'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P9012_SELECTED_ITEM_ID'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(167944827793907042)
,p_name=>'onChangeSelectItemText'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9012_SELECTED_ITEM_TEXT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(167945364809907043)
,p_event_id=>wwv_flow_imp.id(167944827793907042)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// $(''input[coluna="'' + window._lastDlgLinkZoom + ''"]'').closest(''span.lov'').find(''input[type=text]'')',
'$('':is(input, textarea)[coluna="'' + window._lastDlgLinkZoom + ''"]'')',
'  .closest(''span.lov'')',
'  .find('':is(input[type=text], textarea)'');'))
,p_attribute_01=>'PLSQL_EXPRESSION'
,p_attribute_04=>':P9012_SELECTED_ITEM_TEXT'
,p_attribute_07=>'P9012_SELECTED_ITEM_TEXT'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P9012_SELECTED_ITEM_TEXT'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(167950873547907059)
,p_name=>'onClickCreate'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(167921956528906893)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(167951349433907060)
,p_event_id=>wwv_flow_imp.id(167950873547907059)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.server.process(',
'    "VALIDAR",',
'    { x01: $v("P9012_ID") },',
'    {',
'        dataType: ''json'',',
'        success: function(pData) {',
'            if (pData.length > 0) {',
'',
unistr('                // Se houver sem valida\00E7\00E3o, segue direto'),
'                if (pData[0].hasOwnProperty(''semValidacao'')) {',
unistr('                    console.info("Sem valida\00E7\00E3o ao gravar");'),
'                    apex.submit({ request: "Create" });',
'                    return;',
'                }',
'',
unistr('                // Fun\00E7\00E3o recursiva para exibir mensagens em sequ\00EAncia'),
'                function exibirConfirmacoes(index) {',
'                    if (index >= pData.length) {',
unistr('                        // Terminou todas as confirma\00E7\00F5es, agora pode submeter'),
'                        apex.submit({ request: "Create" });',
'                        return;',
'                    }',
'',
'                    var msg = pData[index];',
'                    apex.message.confirm(',
'                        msg.mensagem,',
'                        function(okPressed) {',
'                            if (okPressed) {',
unistr('                                // Usu\00E1rio confirmou \2192 mostra a pr\00F3xima'),
'                                exibirConfirmacoes(index + 1);',
'                            } else {',
unistr('                                // Usu\00E1rio cancelou \2192 aborta'),
unistr('                                console.warn("Usu\00E1rio cancelou na etapa " + index);'),
'                                return;',
'                            }',
'                        },',
'                        {',
'                            title: msg.help,',
'                            style: "information",',
'                            dialogClasses: "minha-modal-customizada",',
'                            iconClasses: "fa fa-question-circle fa-2x text-warning",',
'                            confirmLabel: $v("P0_LABEL_SALVAR")',
'                        }',
'                    );',
'                }',
'',
'                // Inicia exibindo a primeira',
'                exibirConfirmacoes(0);',
'',
'            } else {',
unistr('                // Nenhuma mensagem \2192 segue normal'),
'                apex.submit({ request: "Create" });',
'            }',
'        }',
'    }',
');',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(167951736245907062)
,p_name=>'onClickSave'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(167921537299906892)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(167952241201907063)
,p_event_id=>wwv_flow_imp.id(167951736245907062)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.server.process(',
'    "VALIDAR",',
'    { x01: $v("P9012_ID") },',
'    {',
'        dataType: ''json'',',
'        success: function(pData) {',
'            if (pData.length > 0) {',
'',
unistr('                // Se houver sem valida\00E7\00E3o, segue direto'),
'                if (pData[0].hasOwnProperty(''semValidacao'')) {',
unistr('                    console.info("Sem valida\00E7\00E3o ao gravar");'),
'                    apex.submit({ request: "Save" });',
'                    return;',
'                }',
'',
unistr('                // Fun\00E7\00E3o recursiva para exibir mensagens em sequ\00EAncia'),
'                function exibirConfirmacoes(index) {',
'                    if (index >= pData.length) {',
unistr('                        // Terminou todas as confirma\00E7\00F5es, agora pode submeter'),
'                        apex.submit({ request: "Save" });',
'                        return;',
'                    }',
'',
'                    var msg = pData[index];',
'                    apex.message.confirm(',
'                        msg.mensagem,',
'                        function(okPressed) {',
'                            if (okPressed) {',
unistr('                                // Usu\00E1rio confirmou \2192 mostra a pr\00F3xima'),
'                                exibirConfirmacoes(index + 1);',
'                            } else {',
unistr('                                // Usu\00E1rio cancelou \2192 aborta'),
unistr('                                console.warn("Usu\00E1rio cancelou na etapa " + index);'),
'                                return;',
'                            }',
'                        },',
'                        {',
'                            title: msg.help,',
'                            style: "information",',
'                            dialogClasses: "minha-modal-customizada",',
'                            iconClasses: "fa fa-question-circle fa-2x text-warning",',
'                            confirmLabel: $v("P0_LABEL_SALVAR")',
'                        }',
'                    );',
'                }',
'',
'                // Inicia exibindo a primeira',
'                exibirConfirmacoes(0);',
'',
'            } else {',
unistr('                // Nenhuma mensagem \2192 segue normal'),
'                apex.submit({ request: "Save" });',
'            }',
'        }',
'    }',
');',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(167952623777907064)
,p_name=>'onClickDoneC'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(167920310271906887)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(167953198306907066)
,p_event_id=>wwv_flow_imp.id(167952623777907064)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.server.process(',
'    "VALIDAR",',
'    { x01: $v("P9012_ID") },',
'    {',
'        dataType: ''json'',',
'        success: function(pData) {',
'            if (pData.length > 0) {',
'',
unistr('                // Se houver sem valida\00E7\00E3o, segue direto'),
'                if (pData[0].hasOwnProperty(''semValidacao'')) {',
unistr('                    console.info("Sem valida\00E7\00E3o ao gravar");'),
'                    apex.submit({ request: "DoneC" });',
'                    return;',
'                }',
'',
unistr('                // Fun\00E7\00E3o recursiva para exibir mensagens em sequ\00EAncia'),
'                function exibirConfirmacoes(index) {',
'                    if (index >= pData.length) {',
unistr('                        // Terminou todas as confirma\00E7\00F5es, agora pode submeter'),
'                        apex.submit({ request: "DoneC" });',
'                        return;',
'                    }',
'',
'                    var msg = pData[index];',
'                    apex.message.confirm(',
'                        msg.mensagem,',
'                        function(okPressed) {',
'                            if (okPressed) {',
unistr('                                // Usu\00E1rio confirmou \2192 mostra a pr\00F3xima'),
'                                exibirConfirmacoes(index + 1);',
'                            } else {',
unistr('                                // Usu\00E1rio cancelou \2192 aborta'),
unistr('                                console.warn("Usu\00E1rio cancelou na etapa " + index);'),
'                                return;',
'                            }',
'                        },',
'                        {',
'                            title: msg.help,',
'                            style: "information",',
'                            dialogClasses: "minha-modal-customizada",',
'                            iconClasses: "fa fa-question-circle fa-2x text-warning",',
'                            confirmLabel: $v("P0_LABEL_SALVAR")',
'                        }',
'                    );',
'                }',
'',
'                // Inicia exibindo a primeira',
'                exibirConfirmacoes(0);',
'',
'            } else {',
unistr('                // Nenhuma mensagem \2192 segue normal'),
'                apex.submit({ request: "DoneC" });',
'            }',
'        }',
'    }',
');',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(167953568768907067)
,p_name=>'onClickDoneS'
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(167920771047906890)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(167954045504907068)
,p_event_id=>wwv_flow_imp.id(167953568768907067)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.server.process(',
'    "VALIDAR",',
'    { x01: $v("P9012_ID") },',
'    {',
'        dataType: ''json'',',
'        success: function(pData) {',
'            if (pData.length > 0) {',
'',
unistr('                // Se houver sem valida\00E7\00E3o, segue direto'),
'                if (pData[0].hasOwnProperty(''semValidacao'')) {',
unistr('                    console.info("Sem valida\00E7\00E3o ao gravar");'),
'                    apex.submit({ request: "DoneS" });',
'                    return;',
'                }',
'',
unistr('                // Fun\00E7\00E3o recursiva para exibir mensagens em sequ\00EAncia'),
'                function exibirConfirmacoes(index) {',
'                    if (index >= pData.length) {',
unistr('                        // Terminou todas as confirma\00E7\00F5es, agora pode submeter'),
'                        apex.submit({ request: "DoneS" });',
'                        return;',
'                    }',
'',
'                    var msg = pData[index];',
'                    apex.message.confirm(',
'                        msg.mensagem,',
'                        function(okPressed) {',
'                            if (okPressed) {',
unistr('                                // Usu\00E1rio confirmou \2192 mostra a pr\00F3xima'),
'                                exibirConfirmacoes(index + 1);',
'                            } else {',
unistr('                                // Usu\00E1rio cancelou \2192 aborta'),
unistr('                                console.warn("Usu\00E1rio cancelou na etapa " + index);'),
'                                return;',
'                            }',
'                        },',
'                        {',
'                            title: msg.help,',
'                            style: "information",',
'                            dialogClasses: "minha-modal-customizada",',
'                            iconClasses: "fa fa-question-circle fa-2x text-warning",',
'                            confirmLabel: $v("P0_LABEL_SALVAR")',
'                        }',
'                    );',
'                }',
'',
'                // Inicia exibindo a primeira',
'                exibirConfirmacoes(0);',
'',
'            } else {',
unistr('                // Nenhuma mensagem \2192 segue normal'),
'                apex.submit({ request: "DoneS" });',
'            }',
'        }',
'    }',
');',
''))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(167931803317906987)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Post-create'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_messages pkg_mensagem.message_record_table;',
'    l_pagina varchar2(256) := nvl(:P9012_CODIGO_ARTEFATO,325);',
'BEGIN',
'    v_messages := pkg_mensagem.message_record_table();',
'    EXECUTE IMMEDIATE',
'        ''BEGIN UI_MPD_''|| l_pagina ||''.post_create''||',
'        ''(p_id => :P9012_ID, p_sucesso => :P9012_SUCESSO, p_messages => :v_messages); END;''',
'        USING OUT :P9012_ID, OUT :P9012_SUCESSO, OUT v_messages;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'Create,DoneC'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_process_success_message=>'&P9012_SUCESSO.'
,p_internal_uid=>62667097304407877
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(167938392202907019)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Post-save'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_messages pkg_mensagem.message_record_table;',
'    l_pagina varchar2(256) := nvl(:P9012_CODIGO_ARTEFATO,325);',
'BEGIN',
'    v_messages := pkg_mensagem.message_record_table();',
'    EXECUTE IMMEDIATE',
'        ''BEGIN UI_MPD_''|| l_pagina ||''.post_save''||',
'        ''(p_id => :P9012_ID, p_sucesso => :P9012_SUCESSO, p_messages => :v_messages); END;''',
'        USING :P9012_ID, OUT :P9012_SUCESSO, OUT v_messages;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'Save,DoneS'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_process_success_message=>'&P9012_SUCESSO.'
,p_internal_uid=>62673686189407909
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(167938786071907020)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'url_wizard_post'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'URL_WIZARD'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'DoneC,DoneS'
,p_process_when_type=>'REQUEST_NOT_IN_CONDITION'
,p_internal_uid=>62674080058407910
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(167939293431907021)
,p_page_process_id=>wwv_flow_imp.id(167938786071907020)
,p_page_id=>9012
,p_name=>'p_codigo_artefato_base'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>20
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'case when :P9012_CODIGO_WIZARD is null then :P9012_CODIGO_ARTEFATO else :P9012_CODIGO_WIZARD end'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(167939754023907022)
,p_page_process_id=>wwv_flow_imp.id(167938786071907020)
,p_page_id=>9012
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P9012_CODIGO_ARTEFATO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(167940262637907025)
,p_page_process_id=>wwv_flow_imp.id(167938786071907020)
,p_page_id=>9012
,p_name=>'p_url_anterior'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P9012_URL_ANTERIOR'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(167940793840907027)
,p_page_process_id=>wwv_flow_imp.id(167938786071907020)
,p_page_id=>9012
,p_name=>'p_url_proximo'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>40
,p_value_type=>'ITEM'
,p_value=>'P9012_URL_PROXIMO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(167941298462907028)
,p_page_process_id=>wwv_flow_imp.id(167938786071907020)
,p_page_id=>9012
,p_name=>'p_param1'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>50
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'nvl(:P9012_PARAMETRO,:P9012_ID)'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(167941789827907030)
,p_page_process_id=>wwv_flow_imp.id(167938786071907020)
,p_page_id=>9012
,p_name=>'p_param2'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>60
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(167942221112907031)
,p_page_process_id=>wwv_flow_imp.id(167938786071907020)
,p_page_id=>9012
,p_name=>'p_etapa'
,p_direction=>'OUT'
,p_data_type=>'NUMBER'
,p_ignore_output=>true
,p_display_sequence=>70
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(167942705457907032)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'DoneC,DoneS'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>62677999444407922
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(167932603819906992)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'retorna_titulo_help'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'RETORNA_TITULO_TELA'
,p_internal_uid=>62667897806407882
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(167933051158907001)
,p_page_process_id=>wwv_flow_imp.id(167932603819906992)
,p_page_id=>9012
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'nvl(:P9012_CODIGO_ARTEFATO,:APP_PAGE_ID)'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(167933531452907004)
,p_page_process_id=>wwv_flow_imp.id(167932603819906992)
,p_page_id=>9012
,p_name=>'p_titulo'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P9012_TELA_TITULO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(167934050982907005)
,p_page_process_id=>wwv_flow_imp.id(167932603819906992)
,p_page_id=>9012
,p_name=>'p_help'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P9012_TELA_HELP'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(167934468121907006)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'url_wizard'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'URL_WIZARD'
,p_process_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    1',
'from srv_artefato_wizard a',
'join srv_artefato_versionado b on b.id = a.id_artefato_versionado',
'join srv_artefato c on c.id = b.id_artefato',
'join srv_artefato_versionado b1 on b1.id = a.id_artefato_versionado_base',
'join srv_artefato c1 on c1.id = b1.id_artefato',
'where c.codigo_artefato = nvl( apex_util.get_session_state(''P''||:APP_PAGE_ID||''_CODIGO_WIZARD''),:p0_codigo_artefato)'))
,p_process_when_type=>'EXISTS'
,p_internal_uid=>62669762108407896
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(167934962583907009)
,p_page_process_id=>wwv_flow_imp.id(167934468121907006)
,p_page_id=>9012
,p_name=>'p_codigo_artefato_base'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>20
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'case when :P9012_CODIGO_WIZARD is null then :P9012_CODIGO_ARTEFATO else :P9012_CODIGO_WIZARD end'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(167935446788907010)
,p_page_process_id=>wwv_flow_imp.id(167934468121907006)
,p_page_id=>9012
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P9012_CODIGO_ARTEFATO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(167935941759907012)
,p_page_process_id=>wwv_flow_imp.id(167934468121907006)
,p_page_id=>9012
,p_name=>'p_url_anterior'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P9012_URL_ANTERIOR'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(167936443256907013)
,p_page_process_id=>wwv_flow_imp.id(167934468121907006)
,p_page_id=>9012
,p_name=>'p_url_proximo'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>50
,p_value_type=>'ITEM'
,p_value=>'P9012_URL_PROXIMO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(167936982094907015)
,p_page_process_id=>wwv_flow_imp.id(167934468121907006)
,p_page_id=>9012
,p_name=>'p_param1'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>60
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(167937466233907016)
,p_page_process_id=>wwv_flow_imp.id(167934468121907006)
,p_page_id=>9012
,p_name=>'p_param2'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>70
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(167937957768907017)
,p_page_process_id=>wwv_flow_imp.id(167934468121907006)
,p_page_id=>9012
,p_name=>'p_etapa'
,p_direction=>'OUT'
,p_data_type=>'NUMBER'
,p_ignore_output=>false
,p_display_sequence=>80
,p_value_type=>'ITEM'
,p_value=>'P9012_ETAPA'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(167932109922906988)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'enviarParamentros'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    prc_enviar_parametros(',
'        apex_application.g_x01,',
'        apex_application.g_x02,',
'        apex_application.g_x03,',
'        apex_application.g_x04',
'    );',
'    if apex_application.g_x01 is not null then',
'        if upper(apex_application.g_x02) = upper(''id_tenant'') and :P9013_ID is null then',
'            :P0_TENANT_INFORMADO := apex_application.g_x03;',
'        end if;',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>62667403909407878
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(167930907143906983)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'atribuiValorAJAX'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_json CLOB;',
'BEGIN',
'    l_json := pkg_formulario_dinamico.executa_sql_parametrizado(',
'        p_param1 => apex_application.g_x01,',
'        p_sql    => apex_application.g_x02',
'    );',
'    sys.htp.init;   -- limpa buffer anterior',
'    owa_util.mime_header(''application/json'', FALSE);',
'    htp.p(''Cache-Control: no-cache'');',
'    owa_util.http_header_close;',
'    htp.prn(l_json); -- imprime exatamente o JSON',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>62666201130407873
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(167931396018906985)
,p_process_sequence=>30
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'VALIDAR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_clob clob;',
'    v_messages pkg_mensagem.message_record_table;',
'    l_pagina varchar2(256) := nvl(:p9012_codigo_artefato,''td452'');',
'begin',
'    execute immediate',
'        ''begin :v_messages := ui_mpd_''||l_pagina||''.valida(:p_id); end;''',
'        using out v_messages, in apex_application.g_x01;',
'',
'    -- Monta JSON de retorno',
'    apex_json.initialize_clob_output;',
'    apex_json.open_array;',
'',
'    if v_messages.count > 0 then',
'        for i in 1 .. v_messages.count loop',
'            apex_json.open_object;',
'            apex_json.write(''mensagem'',       v_messages(i).mensagem);',
'            apex_json.write(''instrucao'',      v_messages(i).instrucao);',
'            apex_json.write(''help'',           v_messages(i).help);',
'            apex_json.write(''local_exibicao'', v_messages(i).local_exibicao);',
'            apex_json.write(''nome_item'',      v_messages(i).nome_item);',
'            apex_json.write(''tipo'',           v_messages(i).tipo);',
'            apex_json.close_object;',
'        end loop;',
'    end if;',
'',
'    apex_json.close_array;',
'    l_clob := apex_json.get_clob_output;',
'    apex_json.free_output;    ',
'    sys.htp.prn(l_clob);     ',
'',
'    exception',
'        when others then',
'        -- Monta JSON de erro consistente',
'        apex_json.initialize_clob_output;',
'        apex_json.open_array;',
'        apex_json.open_object;',
'        apex_json.write(''semValidacao'', ''sim'');',
'        apex_json.close_object;',
'        apex_json.close_array;',
'',
'        l_clob := apex_json.get_clob_output;',
'        apex_json.free_output;    ',
'        sys.htp.prn(l_clob);     ',
'    ',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>62666690005407875
);
wwv_flow_imp.component_end;
end;
/
