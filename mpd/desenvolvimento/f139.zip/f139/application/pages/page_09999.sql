prompt --application/pages/page_09999
begin
--   Manifest
--     PAGE: 09999
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>9999
,p_name=>'Login'
,p_alias=>'LOGIN'
,p_step_title=>'Login'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(222376265577622135)
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Seleciona o campo de senha',
'var inputPassword = document.getElementById(''P9999_PASSWORD'');',
'',
unistr('// Cria o \00EDcone dentro do campo'),
'var eyeIcon = document.createElement(''i'');',
'eyeIcon.className = ''fa fa-eye icon-eye'';',
'eyeIcon.style.position = ''absolute'';',
'eyeIcon.style.right = ''10px'';',
'eyeIcon.style.top = ''50%'';',
'eyeIcon.style.transform = ''translateY(-50%)'';',
'eyeIcon.style.cursor = ''pointer'';',
'',
unistr('// Adiciona o \00EDcone no campo de senha'),
'inputPassword.parentNode.style.position = ''relative'';',
'inputPassword.parentNode.appendChild(eyeIcon);',
'',
unistr('// Fun\00E7\00E3o mostrar/ocultar senha'),
'eyeIcon.addEventListener(''click'', function() {',
'    if (inputPassword.type === ''password'') {',
'        inputPassword.type = ''text'';',
'        eyeIcon.classList.remove(''fa-eye'');',
'        eyeIcon.classList.add(''fa-eye-slash'');',
'    } else {',
'        inputPassword.type = ''password'';',
'        eyeIcon.classList.remove(''fa-eye-slash'');',
'        eyeIcon.classList.add(''fa-eye'');',
'    }',
'});',
'',
'// Permite fazer login ao clique ''Enter''',
'$(''#P9999_PASSWORD, #P9999_USERNAME'').on(''keydown'', function(event) {',
'  if (event.key === ''Enter'') {  ',
'    event.preventDefault();  ',
'    $(''#botao-login'').click();',
'  }',
'});',
''))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Alert{',
'    background-color: transparent;',
'    border: none;',
'    box-shadow: none;',
'}',
'',
'.t-Button{',
'    padding-left: 4px;',
'    padding-right: 4px;',
'}',
'',
'',
unistr('/* CSS para \00EDcone mostrar/ocultar senha */'),
'.icon-eye {',
'    position: absolute;',
'    right: 10px;',
'    transform: translateY(-50%);',
'    cursor: pointer;',
'    color: #888;',
'}',
''))
,p_step_template=>wwv_flow_imp.id(341000071649556215)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'12'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(441079189519113952)
,p_plug_name=>'MPD'
,p_region_template_options=>'#DEFAULT#:t-Login-region--headerHidden js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(341088492083556263)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<img src="#APP_FILES#logo.png" style="height: 30px;" alt="Minha Figura"></img>',
'<div class="st-titulo-app">&APP_NAME.</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(165193586230149563)
,p_plug_name=>'Login'
,p_parent_plug_id=>wwv_flow_imp.id(441079189519113952)
,p_icon_css_classes=>'fa-user-lock'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--customIcons:t-Alert--info:t-Alert--removeHeading js-removeLandmark:t-Form--slimPadding'
,p_plug_template=>wwv_flow_imp.id(341005634629556219)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(271359376212099464)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(165193586230149563)
,p_button_name=>'LOGIN-NORMAL'
,p_button_static_id=>'botao-login'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--stretch:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(341144157120556305)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P9999_LABEL_ACESSAR.'
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(271359803433099464)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(165193586230149563)
,p_button_name=>'LOGIN-MFA'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--stretch:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(341144157120556305)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Acessar'
,p_button_position=>'CLOSE'
,p_button_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(271358977409099464)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(165193586230149563)
,p_button_name=>'ESQUECEU'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--stretch:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(341144157120556305)
,p_button_image_alt=>'&P9999_LABEL_ESQUECEU_SENHA.'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:9998:&SESSION.::&DEBUG.:9998::'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(271369176255099470)
,p_branch_name=>'Go to 9997'
,p_branch_action=>'f?p=&APP_ID.:9997:&SESSION.::&DEBUG.:9997:P9997_USERNAME:&P9999_USERNAME.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(271359803433099464)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(271369646817099470)
,p_branch_name=>'Go to 9995'
,p_branch_action=>'f?p=&APP_ID.:9995:&SESSION.::&DEBUG.:9995:P9995_USERNAME,P9995_EMAIL:&P9999_USERNAME.,&P9999_EMAIL.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(271358977409099464)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(55992749312522554)
,p_name=>'P9999_IDIOMA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(441079189519113952)
,p_item_default=>'select id from mpd_idioma where codigo = ''pt-br'''
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'select nome d, id r from mpd_idioma'
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '4',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(55993071457522557)
,p_name=>'P9999_LABEL_USUARIO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(441079189519113952)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(55993830621522564)
,p_name=>'P9999_LABEL_SENHA'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(441079189519113952)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(55993910237522565)
,p_name=>'P9999_LABEL_LEMBRAR_USUARIO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(441079189519113952)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(55993995769522566)
,p_name=>'P9999_LABEL_ACESSAR'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(441079189519113952)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(55994056255522567)
,p_name=>'P9999_LABEL_ESQUECEU_SENHA'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(441079189519113952)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(55994319246522569)
,p_name=>'P9999_INSTRUCAO_USUARIO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(441079189519113952)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(55994380590522570)
,p_name=>'P9999_INSTRUCAO_SENHA'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(441079189519113952)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(165192428799149551)
,p_name=>'P9999_CONVITE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(441079189519113952)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(165193391927149561)
,p_name=>'P9999_SENHA_PROVISORIA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(441079189519113952)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(271360245016099465)
,p_name=>'P9999_USERNAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(165193586230149563)
,p_prompt=>'&P9999_LABEL_USUARIO.'
,p_placeholder=>'&P9999_INSTRUCAO_USUARIO.'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>40
,p_cMaxlength=>100
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'Y',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(271360636537099465)
,p_name=>'P9999_PASSWORD'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(165193586230149563)
,p_prompt=>'&P9999_LABEL_SENHA.'
,p_placeholder=>'&P9999_INSTRUCAO_SENHA.'
,p_post_element_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div>',
'    <i class="fa fa-eye icon-eye" style="cursor: pointer;"></i>',
'</div>'))
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>40
,p_cMaxlength=>100
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'submit_when_enter_pressed', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(271360967935099465)
,p_name=>'P9999_REMEMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(165193586230149563)
,p_prompt=>'&P9999_LABEL_LEMBRAR_USUARIO.'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_display_when=>'apex_authentication.persistent_cookies_enabled'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(341141341591556301)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(271361909839099466)
,p_validation_name=>'P9999_PASSWORD-Valid Username Password'
,p_validation_sequence=>10
,p_validation=>'return PKG_SEGURANCA.valid_username_and_password(:P9999_USERNAME,:P9999_PASSWORD);'
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_associated_item=>wwv_flow_imp.id(271360636537099465)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(65939993999188155)
,p_validation_name=>'P9999_PASSWORD-Valid Username Password_1'
,p_validation_sequence=>20
,p_validation=>'return PKG_API_SEGURANCA.valid_username_and_password(:P9999_USERNAME,:P9999_SENHA_PROVISORIA);'
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_validation_condition=>'P9999_CONVITE'
,p_validation_condition2=>'1'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_associated_item=>wwv_flow_imp.id(165193391927149561)
,p_error_display_location=>'INLINE_WITH_FIELD'
,p_required_patch=>wwv_flow_imp.id(340973604135556181)
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(271362687628099466)
,p_validation_name=>'P9999_USERNAME-Valid Username'
,p_validation_sequence=>30
,p_validation=>'return PKG_API_SEGURANCA.valid_username(:P9999_USERNAME);'
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_associated_item=>wwv_flow_imp.id(271360245016099465)
,p_error_display_location=>'INLINE_WITH_FIELD'
,p_required_patch=>wwv_flow_imp.id(340973604135556181)
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(271362298630099466)
,p_validation_name=>'P9999_USERNAME-Valid Not Null'
,p_validation_sequence=>40
,p_validation=>'P9999_USERNAME'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Usu\00E1rio deve ser informado')
,p_associated_item=>wwv_flow_imp.id(271360245016099465)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(159002091400639764)
,p_validation_name=>'P9999_PASSWORD-Valid Not Null'
,p_validation_sequence=>50
,p_validation=>'P9999_PASSWORD'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Senha deve ser informada'
,p_associated_item=>wwv_flow_imp.id(271360636537099465)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(55992940861522555)
,p_name=>'onChangeIdioma'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9999_IDIOMA'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(55992994076522556)
,p_event_id=>wwv_flow_imp.id(55992940861522555)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':IDIOMA_LOGADO := :P9999_IDIOMA;'
,p_attribute_02=>'P9999_IDIOMA'
,p_attribute_03=>'IDIOMA_LOGADO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(55993522941522561)
,p_event_id=>wwv_flow_imp.id(55992940861522555)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'location.reload();'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(271365391718099468)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Set Username Cookie'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'APEX_AUTHENTICATION'
,p_attribute_04=>'SEND_LOGIN_USERNAME_COOKIE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>62018725983111874
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(271365951512099468)
,p_page_process_id=>wwv_flow_imp.id(271365391718099468)
,p_page_id=>9999
,p_name=>'p_username'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>1
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'lower( :P9999_USERNAME )'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(271366457976099468)
,p_page_process_id=>wwv_flow_imp.id(271365391718099468)
,p_page_id=>9999
,p_name=>'p_consent'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>false
,p_display_sequence=>2
,p_value_type=>'ITEM'
,p_value=>'P9999_REMEMBER'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(271362970607099467)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Login'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_SEGURANCA'
,p_attribute_04=>'PROCESS_LOGIN'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(271359376212099464)
,p_internal_uid=>62016304872111873
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(187159704302976660)
,p_page_process_id=>wwv_flow_imp.id(271362970607099467)
,p_page_id=>9999
,p_name=>'p_user_name'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>1
,p_value_type=>'ITEM'
,p_value=>'P9999_USERNAME'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(187159784963976661)
,p_page_process_id=>wwv_flow_imp.id(271362970607099467)
,p_page_id=>9999
,p_name=>'p_app_id'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>32
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>':APP_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(187160176230976665)
,p_page_process_id=>wwv_flow_imp.id(271362970607099467)
,p_page_id=>9999
,p_name=>'p_auth_type'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>true
,p_display_sequence=>22
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(271365023528099468)
,p_page_process_id=>wwv_flow_imp.id(271362970607099467)
,p_page_id=>9999
,p_name=>'p_password'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>2
,p_value_type=>'ITEM'
,p_value=>'P9999_PASSWORD'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(57134089467830282)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Idioma logado'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_codigo varchar2(5);',
'begin',
'    select codigo into l_codigo from mpd_idioma where id = :P9999_IDIOMA;',
'    :FSP_LANGUAGE_PREFERENCE := l_codigo;',
'    :IDIOMA_LOGADO := :P9999_IDIOMA;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>21755547456732137
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14777456894926149)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carrega labels globais'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    select pkg_ui.retorna_label_tela(''filtrar-por''),',
'           pkg_ui.retorna_label_botao(''opcao''),',
'           pkg_ui.retorna_label_botao(''maisdetalhes''),',
'           pkg_ui.retorna_label_botao(''adicionar-favorito''),',
'           pkg_ui.retorna_label_botao(''remover-favorito''),',
'           pkg_ui.retorna_label_botao(''fixar-desfixar''),',
'           pkg_ui.retorna_label_botao(''visao-card''),',
'           pkg_ui.retorna_label_botao(''visao-lista''),',
'           pkg_ui.retorna_label_botao(''mostra-esconde-filtro''),',
'           pkg_ui.retorna_label_botao(''historico-exclusao''),',
'           pkg_ui.retorna_label_botao(''novo''),',
'           pkg_ui.retorna_label_botao(''voltar''),',
'           pkg_ui.retorna_label_botao(''configuracao-lista''),',
'           pkg_ui.retorna_label_botao(''gravar'')',
'    into :P0_LABEL_FILTRAR, :P0_LABEL_OPCAO, :P0_LABEL_MAIS_DETALHES,:P0_LABEL_ADICIONAR_FAV,:P0_LABEL_REMOVER_FAV,:P0_LABEL_FIXAR,:P0_LABEL_VISAO_CARD,',
'    :P0_LABEL_VISAO_LISTA,:P0_LABEL_ESCONDER_MOSTRAR_PESQUISA,:P0_LABEL_HISTORICO_EXCLUSAO,:P0_LABEL_NOVO,:P0_LABEL_VOLTAR, :P0_LABEL_CONFIGURACAO_LISTA,:P0_LABEL_SALVAR from dual;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>57648328555568422
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(271366858158099469)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Get Username Cookie'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P9999_USERNAME := apex_authentication.get_login_username_cookie;',
':P9999_REMEMBER := case when :P9999_USERNAME is not null then ''Y'' end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'P9999_CONVITE'
,p_process_when_type=>'ITEM_IS_NULL'
,p_internal_uid=>62020192423111875
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(165192834888149555)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Login convite'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_API_SEGURANCA'
,p_attribute_04=>'PROCESS_LOGIN'
,p_process_when=>'P9999_CONVITE'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'1'
,p_internal_uid=>129814292877051410
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(165192928262149556)
,p_page_process_id=>wwv_flow_imp.id(165192834888149555)
,p_page_id=>9999
,p_name=>'p_user_name'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P9999_USERNAME'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(165192982531149557)
,p_page_process_id=>wwv_flow_imp.id(165192834888149555)
,p_page_id=>9999
,p_name=>'p_password'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P9999_SENHA_PROVISORIA'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(165193129761149558)
,p_page_process_id=>wwv_flow_imp.id(165192834888149555)
,p_page_id=>9999
,p_name=>'p_auth_type'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>true
,p_display_sequence=>30
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(165193195522149559)
,p_page_process_id=>wwv_flow_imp.id(165192834888149555)
,p_page_id=>9999
,p_name=>'p_app_id'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>40
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>':APP_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(165193812140149565)
,p_page_process_id=>wwv_flow_imp.id(165192834888149555)
,p_page_id=>9999
,p_name=>'p_convite'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>true
,p_display_sequence=>50
,p_value_type=>'ITEM'
,p_value=>'P9999_CONVITE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(55994193995522568)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Labels'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    retorna_texto(''tela.usuario.l'',:P9999_IDIOMA),',
'    retorna_texto(''tela.usuario.i'',:P9999_IDIOMA),',
'    retorna_texto(''tela.senha.l'',:P9999_IDIOMA),',
'    retorna_texto(''tela.senha.i'',:P9999_IDIOMA),',
'    retorna_texto(''tela.lembrar-usuario.l'',:P9999_IDIOMA),',
'    retorna_texto(''botao.acessar.l'',:P9999_IDIOMA),',
'    retorna_texto(''botao.esqueceu-senha.l'',:P9999_IDIOMA)',
'    into ',
'    :P9999_LABEL_USUARIO,',
'    :P9999_INSTRUCAO_USUARIO,',
'    :P9999_LABEL_SENHA,',
'    :P9999_INSTRUCAO_SENHA,',
'    :P9999_LABEL_LEMBRAR_USUARIO,',
'    :P9999_LABEL_ACESSAR,',
'    :P9999_LABEL_ESQUECEU_SENHA',
'from dual;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>20615651984424423
);
wwv_flow_imp.component_end;
end;
/
