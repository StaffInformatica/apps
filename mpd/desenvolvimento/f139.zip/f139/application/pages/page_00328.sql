prompt --application/pages/page_00328
begin
--   Manifest
--     PAGE: 00328
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>328
,p_name=>unistr('Configura\00E7\00E3o')
,p_alias=>unistr('CONFIGURA\00C7\00C3O')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Configura\00E7\00E3o')
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function copiarValor(origemId, destinoId) {',
'    var datePicker = document.getElementById(origemId);',
'    var valorOrigem = datePicker ? datePicker.value : ''''; ',
'    document.getElementById(destinoId).value = valorOrigem;',
'    console.log(document.getElementById(destinoId).value);',
'}',
'',
'function logValor(item){',
'    console.log(item);',
'    console.log(item.value);',
'    console.log(apex.item( "P9010_FILE1" ).getValue()); ',
'}',
'',
'function enviarParametros(dynamicItem,extra) {',
'    if (dynamicItem) {',
'        var dynamicArtefato = apex.item(''P9012_CODIGO_ARTEFATO'').value;        ',
'        var dynamicValue = dynamicItem.value;',
'        var dynamicId = extra == null ? dynamicItem.id : extra;',
'        console.log(dynamicArtefato);',
'        console.log(dynamicValue);',
'        console.log(dynamicId);',
'    } else {',
unistr('        console.error("O elemento din\00E2mico n\00E3o foi encontrado.");'),
'    }',
'    apex.server.process(',
'    "enviarParamentros", // Nome do processo PL/SQL definido no APEX',
'    {',
unistr('      x01: dynamicArtefato, // Primeiro par\00E2metro'),
unistr('      x02: dynamicId, // Segundo par\00E2metro'),
unistr('      x03: dynamicValue  // Terceiro par\00E2metro'),
'    },',
'    {',
'      dataType: ''text'',',
'      success: function(pData) {',
'        console.log("Dados enviados com sucesso:", pData);',
'      }',
'    }',
'  );',
'}',
'',
'function checkInputAndToggleClass(inputElement) {',
unistr('    // Verificar se o campo de entrada est\00E1 preenchido'),
'    console.log(inputElement.value);',
'    if (inputElement.value.trim() !== "") {',
unistr('        // Localizar a div pai que cont\00E9m "CONTAINER" no ID'),
'        let parentDiv = inputElement.closest("div[id*=''CONTAINER'']");',
'        ',
'        // Se a div for encontrada, adicionar a classe js-show-label',
'        if (parentDiv) {',
'            parentDiv.classList.add("js-show-label");',
'        }',
'    } else {',
'        // Se o valor estiver vazio, remover a classe js-show-label',
'        let parentDiv = inputElement.closest("div[id*=''CONTAINER'']");',
'        ',
'        // Remover a classe js-show-label se ela existir',
'        if (parentDiv) {',
'            parentDiv.classList.remove("js-show-label");',
'        }',
'    }',
'}',
'',
'// function toggleFileUpload() {',
'//     // Seleciona o elemento <a-dynamic-content>',
'//     var dynamicContent = document.querySelector(''a-dynamic-content'');',
'//     console.log(dynamicContent);',
unistr('//     // Verifica se o elemento existe e se cont\00E9m a palavra "mostra_file"'),
'//     if (dynamicContent && dynamicContent.innerHTML.includes(''mostra_file'')) {',
'//         // Se encontrar, mostra o item de upload de arquivo',
'//         apex.item(''P9010_FILE1'').show();',
'//     } else {',
unistr('//         // Caso contr\00E1rio, oculta o item de upload de arquivo'),
'//         apex.item(''P9010_FILE1'').hide();',
'//     }',
'// }',
'',
'document.addEventListener("DOMContentLoaded", function() {',
'  //   toggleFileUpload();  ',
'  var windowWidth = 400;  // Largura da janela popup',
'  var windowHeight = 450;  // Altura da janela popup',
'',
'  // Calcula o centro da tela',
'  var left = (window.screen.width - windowWidth) / 2;',
'  var top = (window.screen.height - windowHeight) / 2;',
'',
unistr('  // Modifica os par\00E2metros de ''left'' e ''top'' no popup gerado'),
'  var originalOpen = window.open;',
'  window.open = function(url, name, specs) {',
unistr('    // Adiciona ou substitui os par\00E2metros ''left'' e ''top'''),
'    specs = specs.replace(/left=\d+/, ''left='' + left);',
'    specs = specs.replace(/top=\d+/, ''top='' + top);',
'',
unistr('    // Se ''left'' e ''top'' n\00E3o existirem, adiciona os par\00E2metros'),
'    if (!specs.includes(''left='')) specs += '',left='' + left;',
'    if (!specs.includes(''top='')) specs += '',top='' + top;',
'',
unistr('    // Chama a fun\00E7\00E3o window.open original com as modifica\00E7\00F5es'),
'    return originalOpen.call(window, url, name, specs);',
'  };',
'});',
'',
'function  disableRowSelector ( ) { ',
'  var records = $( ".a-GV" ). first (). find ( ".a-GV-w-scroll .a-GV-row" ); ',
'  for ( var i = 0 ; i < records. length ; i++) { ',
'    var isReadonly = records. eq (i)[ 0 ]. matches ( ''.is-readonly'' ); ',
'    if (isReadonly) { ',
'        var dataId = records. eq (i). attr ( "data-id" ); ',
unistr('        // Remove a caixa de sele\00E7\00E3o dessa linha'),
'         $( ".a-GV" ). first (). find ( ".a-GV-row[data-id=''" + dataId + "''] .u-selector" ). removeClass (); ',
'    } ',
'  } ',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'tituloTela($v("P328_TELA_TITULO")+'' (''+$v("P328_CODIGO_ARTEFATO")+'')'');',
'',
'// Intercepta o fechamento nativo do dialog',
'apex.jQuery(document).on("dialogclose", ".ui-dialog", function(event, ui){',
'    var dlg = $(this).closest(".ui-dialog-content");',
'    if(dlg.attr("id") === "PXX_MODAL_B") { // substitua PXX_MODAL_B pelo Static ID da Modal B',
'        event.stopImmediatePropagation(); // impede fechar todas as modais',
unistr('        apex.navigation.dialog.close(false); // fecha s\00F3 esta modal'),
'    }',
'});',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.centro{',
'    display: grid;',
'    justify-items: center;',
'}',
'',
'.select option.selected {',
'    color: #888; /* Cor mais clara para parecer um placeholder */',
'    opacity: 0.5; /* Reduz a opacidade */',
'}',
'',
'tr.linha-desabilitada {',
'    background-color: #f2f2f2;',
'    opacity: 0.6;',
'    cursor: not-allowed;',
'}',
'',
'.t-Region-title {    ',
'    word-break: break-word;',
'    -webkit-hyphens: auto;',
'    hyphens: auto;',
'    font-size: var(--a-cv-title-font-size, 16px);',
'    font-weight: var(--a-cv-title-font-weight, 700);',
'    line-height: var(--a-cv-title-line-height, 20px);',
'    color: var(--a-cv-title-text-color);',
'}',
'',
'.a-GV-footer {',
'    display: none;',
'}',
'',
'.a-GV-header.u-tS.is-required.is-readonly  {',
'    pointer-events: none !important;',
'}',
'',
'.a-GV-frozen--startLast{',
'    border-right-width: 1px !important;',
'}',
'',
'#ITENS_SALDO_ig col[data-idx="1"] {',
'  width: 20% !important;',
'}',
'',
'#ITENS_SALDO_ig col[data-idx="2"] {',
'  width: 80% !important;',
'}',
'',
'/* Garante que o texto da primeira coluna possa quebrar normalmente */',
'#ITENS_SALDO_ig td:nth-child(2),',
'#ITENS_SALDO_ig th:nth-child(2) {',
'  white-space: normal !important;',
'  word-break: break-word;',
'}',
'',
'.texto-cabecalho{    ',
'    font-size: var(--a-field-input-font-size, 0.75rem);    ',
'    font-weight: var(--a-field-input-font-weight, 400);',
'}',
'',
'.is-readonly.apex-item-wrapper--display-only.opacity_grupo_funcionalidade {',
'    opacity: 0.9; ',
'    color: #444 !important; /* muda a cor do texto */',
'}',
'.my-readonly-textarea .t-Form-inputContainer label {',
'    top: 0 !important;',
'    transform: none !important;',
'    position: relative !important;',
'}',
'',
'#P328_VALOR_STRING_CONTAINER .apex-item-group--textarea {',
'  border-radius: 15px;            /* arredonda os cantos */',
'}',
'',
'#P328_VALOR_STRING_CONTAINER textarea {',
'',
'  border-radius: 15px;            /* opcional: acompanha a borda externa */',
'}',
'.t-Form-label{',
'    padding-block-start: 5px!important;',
'}',
'',
'',
'',
'',
'.centro{',
'    display: grid;',
'    justify-items: center;',
'}',
'',
'.select option.selected {',
'    color: #888; /* Cor mais clara para parecer um placeholder */',
'    opacity: 0.5; /* Reduz a opacidade */',
'}',
'',
'tr.linha-desabilitada {',
'    background-color: #f2f2f2;',
'    opacity: 0.6;',
'    cursor: not-allowed;',
'}',
'',
'.t-Region-title {    ',
'    word-break: break-word;',
'    -webkit-hyphens: auto;',
'    hyphens: auto;',
'    font-size: var(--a-cv-title-font-size, 16px);',
'    font-weight: var(--a-cv-title-font-weight, 700);',
'    line-height: var(--a-cv-title-line-height, 20px);',
'    color: var(--a-cv-title-text-color);',
'}',
'',
'.a-GV-footer {',
'    display: none;',
'}',
'',
'.a-GV-header.u-tS.is-required.is-readonly  {',
'    pointer-events: none !important;',
'}',
'',
'.a-GV-frozen--startLast{',
'    border-right-width: 1px !important;',
'}',
'',
'#ITENS_SALDO_ig col[data-idx="1"] {',
'  width: 20% !important;',
'}',
'',
'#ITENS_SALDO_ig col[data-idx="2"] {',
'  width: 80% !important;',
'}',
'',
'/* Garante que o texto da primeira coluna possa quebrar normalmente */',
'#ITENS_SALDO_ig td:nth-child(2),',
'#ITENS_SALDO_ig th:nth-child(2) {',
'  white-space: normal !important;',
'  word-break: break-word;',
'}',
'',
'.texto-cabecalho{    ',
'    font-size: var(--a-field-input-font-size, 0.75rem);    ',
'    font-weight: var(--a-field-input-font-weight, 400);',
'}',
'',
'.is-readonly.apex-item-wrapper--display-only.opacity_grupo_funcionalidade {',
'    opacity: 0.9; ',
'    color: #444 !important; /* muda a cor do texto */',
'}',
'.my-readonly-textarea .t-Form-inputContainer label {',
'    top: 0 !important;',
'    transform: none !important;',
'    position: relative !important;',
'}',
'',
'#P328_VALOR_STRING_CONTAINER .apex-item-group--textarea {',
'  border-radius: 15px;            /* arredonda os cantos */',
'}',
'',
'#P328_VALOR_STRING_CONTAINER textarea {',
'',
'  border-radius: 15px;            /* opcional: acompanha a borda externa */',
'}',
'.t-Form-label{',
'    padding-block-start: 5px!important;',
'}',
''))
,p_step_template=>wwv_flow_imp.id(340974912275556190)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--lg'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(376396854076484067)
,p_plug_name=>'Alterar'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody:t-Form--large'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>70
,p_query_type=>'TABLE'
,p_query_table=>'NG_CONFIGURACAO'
,p_include_rowid_column=>true
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(126470188624221785)
,p_plug_name=>'teste'
,p_title=>'teste'
,p_parent_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_region_css_classes=>'is-readonly apex-item-wrapper--display-only'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(341044399187556241)
,p_plug_display_sequence=>290
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- DECLARE',
'--     l_sql VARCHAR2(4000);',
'--     l_colunas VARCHAR2(4000);',
'--     l_tabela  VARCHAR2(100);',
'-- BEGIN',
'--     -- Primeiro pega a tabela',
'--     SELECT B.NOME_ENTIDADE',
'--       INTO l_tabela',
'--       FROM SRV_ENTIDADE B',
'--      WHERE B.ID = :P328_ID_ENTIDADE;',
'',
'--     -- Pega as colunas que queremos concatenar',
'--     SELECT LISTAGG(A.NOME_COLUNA,'' || '''' - '''' ||'') WITHIN GROUP (ORDER BY A.NOME_COLUNA)',
'--       INTO l_colunas',
'--       FROM SRV_ENTIDADE_COLUNA A',
'--      WHERE A.ID_ENTIDADE = :P328_ID_ENTIDADE',
'--        AND A.REFERENCIA IS NOT NULL;',
'',
'--     -- Monta o SQL final',
'--     l_sql := ''SELECT '' || l_colunas || '' AS display_value FROM '' || l_tabela;',
'',
'--     RETURN l_sql;',
'',
'-- EXCEPTION',
'--     WHEN NO_DATA_FOUND THEN',
'--         RETURN ''SELECT ''''Nenhum registro'''' AS display_value FROM dual'';',
'--     WHEN OTHERS THEN',
unistr('--         RETURN ''SELECT ''''Erro ao gerar relat\00F3rio'''' AS display_value FROM dual'';'),
'-- END;',
'DECLARE',
'    l_sql VARCHAR2(4000);',
'    l_colunas VARCHAR2(4000);',
'    l_tabela  VARCHAR2(100);',
'BEGIN',
'    -- Pega a tabela da entidade',
'    SELECT B.NOME_ENTIDADE',
'      INTO l_tabela',
'      FROM SRV_ENTIDADE B',
'     WHERE B.ID = :P328_ID_ENTIDADE;',
'',
'    -- Pega as colunas que queremos concatenar',
'    SELECT LISTAGG(A.NOME_COLUNA,'' || '''' - '''' ||'') WITHIN GROUP (ORDER BY A.NOME_COLUNA)',
'      INTO l_colunas',
'      FROM SRV_ENTIDADE_COLUNA A',
'     WHERE A.ID_ENTIDADE = :P328_ID_ENTIDADE',
'       AND A.REFERENCIA IS NOT NULL;',
'',
'    -- Monta o SQL final filtrando pelos IDs do NG_CONFIGURACAO',
'    l_sql := ''',
'        SELECT '' || l_colunas || '' AS display_value',
'        FROM '' || l_tabela || '' T',
'        WHERE T.ID IN (',
'            SELECT TO_NUMBER(REGEXP_SUBSTR(NC.ID_REGISTRO, ''''[^:]+'''', 1, LEVEL))',
'            FROM NG_CONFIGURACAO NC',
'            WHERE NC.ID_ENTIDADE = :P328_ID_ENTIDADE',
'            CONNECT BY LEVEL <= REGEXP_COUNT(NC.ID_REGISTRO, '''':'''') + 1',
'            AND PRIOR NC.ID_REGISTRO = NC.ID_REGISTRO',
'            AND PRIOR SYS_GUID() IS NOT NULL',
'        )',
'        ORDER BY 1',
'    '';',
'',
'    RETURN l_sql;',
'',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'        RETURN ''SELECT ''''Nenhum registro'''' AS display_value FROM dual'';',
'    WHEN OTHERS THEN',
unistr('        RETURN ''SELECT ''''Erro ao gerar relat\00F3rio'''' AS display_value FROM dual'';'),
'END;',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P328_IND_TIPO_DADO'
,p_plug_display_when_cond2=>'IM'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'teste'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(126472476199221808)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'JONICLEI'
,p_internal_uid=>169343347859864081
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(129544681766994184)
,p_db_column_name=>'DISPLAY_VALUE'
,p_display_order=>10
,p_column_identifier=>'Z'
,p_column_label=>unistr('Identifica\00E7\00E3o')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(129571397631002468)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'748216'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(555901286912882737)
,p_plug_name=>'Steps'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#:t-WizardSteps--displayLabels'
,p_plug_template=>wwv_flow_imp.id(341059031473556249)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_list_id=>wwv_flow_imp.id(54805451114211345)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(341136199098556298)
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(555901769344884384)
,p_plug_name=>'Footer'
,p_region_css_classes=>'u-margin-bottom-none'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(341013639389556225)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(54750829925211554)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(555901769344884384)
,p_button_name=>'inclui_e_fecha'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(341144157120556305)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Gravar'
,p_button_position=>'NEXT'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(54751266439211553)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(555901769344884384)
,p_button_name=>'inclui_e_fecha_1'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(341144157120556305)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Gravar'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(54803747967211351)
,p_branch_name=>'goto_anterior'
,p_branch_action=>'P328_URL_ANTERIOR'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'BRANCH_TO_URL_IDENT_BY_ITEM'
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(54804201777211350)
,p_branch_name=>'goto_proximo'
,p_branch_action=>'P328_URL_PROXIMO'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'BRANCH_TO_URL_IDENT_BY_ITEM'
,p_branch_sequence=>30
,p_branch_condition_type=>'REQUEST_IN_CONDITION'
,p_branch_condition=>'PROXIMO'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(54804529865211349)
,p_branch_name=>'Grava'
,p_branch_action=>unistr('f?p=&APP_ID.:9000:&SESSION.::&DEBUG.:CR,9000:P9000_LABEL_TELA,P9000_PAGINA,P9000_ID:Op\00E7\00F5es,TD882,&P328_PARAMETRO.&success_msg=#SUCCESS_MSG#')
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>40
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(126472408108221775)
,p_name=>'P328_ENTIDADESS_1'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- -- -- select replace(',
'-- -- --          nvl(',
'-- -- --            (select id_registro',
'-- -- --               from ng_configuracao',
'-- -- --              where id = :P327_PARAMETRO),',
'-- -- --            ''''',
'-- -- --          ),',
'-- -- --          '':'',',
'-- -- --          chr(10)',
'-- -- --        ) as display_value',
'-- -- -- from dual',
'',
'-- -- -- Passo 1: separar os IDs usando apex_string.split',
'-- -- WITH ids AS (',
'-- --     SELECT trim(column_value) AS id_val',
'-- --     FROM table(',
'-- --         apex_string.split(''32:33:44'', '':'')  -- aqui pode ser :P327_PARAMETRO',
'-- --     )',
'-- -- )',
'-- -- -- Passo 2: usar os IDs em um select',
'-- -- aqui eu preciso pegar assim : ',
'',
'-- -- select ',
'',
'-- -- SELECT t.nome_coluna',
'-- -- FROM ids i',
'-- -- JOIN sua_tabela t ON t.id = i.id_val;',
'',
'',
'',
'-- declare',
'--     l_sql    varchar2(4000);',
'--     l_tabela varchar2(30);',
'--     l_coluna varchar2(30);',
'-- begin',
unistr('--     tenta buscar a tabela da configura\00E7\00E3o'),
'--     begin',
'--         select b.nome_entidade',
'--           into l_tabela',
'--           from ng_configuracao a',
'--           join srv_entidade b on b.id = a.id_entidade',
'--          where a.id = :P327_PARAMETRO;',
'--     exception',
'--         when no_data_found then',
unistr('--             l_tabela := null; -- n\00E3o achou nada'),
'--     end;',
'',
unistr('--     se n\00E3o encontrou a tabela, retorna SQL vazio'),
'--     if l_tabela is null then',
'--         return ''select null display_value, null return_value from dual where 1 = 0'';',
'--     end if;',
'',
unistr('--     tenta identificar uma coluna de nome ou descri\00E7\00E3o'),
'--     begin',
'--         select column_name',
'--           into l_coluna',
'--           from all_tab_columns',
'--          where table_name = upper(l_tabela)',
'--            and (column_name like ''%NOME%'' or column_name like ''%DESCRICAO%'')',
'--            and column_id = (',
'--                 select min(column_id)',
'--                   from all_tab_columns',
'--                  where table_name = upper(l_tabela)',
'--                    and (column_name like ''%NOME%'' or column_name like ''%DESCRICAO%'')',
'--            );',
'--     exception',
'--         when no_data_found then',
'--             l_coluna := ''ID''; -- fallback',
'--     end;',
'',
'--     monta SQL final',
'--     l_sql := ''select '' || l_coluna || '' as display_value, id as return_value from '' || l_tabela ;',
'',
'--     return l_sql;',
'-- end;',
'',
'',
'',
'declare',
'    l_sql    varchar2(4000);',
'    l_tabela varchar2(30);',
'    l_coluna varchar2(30);',
'begin',
unistr('    -- pega a tabela da configura\00E7\00E3o'),
'    begin',
'        select b.nome_entidade',
'          into l_tabela',
'          from ng_configuracao a',
'          join srv_entidade b on b.id = a.id_entidade',
'         where a.id = :P327_PARAMETRO;',
'    exception',
'        when no_data_found then',
'            return ''select null display_value, null return_value from dual where 1=0'';',
'    end;',
'',
'    -- pega coluna de nome ou descricao',
'    begin',
'        select column_name',
'          into l_coluna',
'          from all_tab_columns',
'         where table_name = upper(l_tabela)',
'           and (column_name like ''%NOME%'' or column_name like ''%DESCRICAO%'')',
'           and column_id = (',
'                select min(column_id)',
'                  from all_tab_columns',
'                 where table_name = upper(l_tabela)',
'                   and (column_name like ''%NOME%'' or column_name like ''%DESCRICAO%'')',
'           );',
'    exception',
'        when no_data_found then',
'            l_coluna := ''ID'';',
'    end;',
'',
'    -- monta SQL final usando apex_string.split',
'    l_sql := ''select t.'' || l_coluna || '' as display_value, t.id as return_value '' ||',
'             ''from '' || l_tabela || '' t '' ||',
'             ''join table(apex_string.split('' ||',
'             ''    nvl((select id_registro from ng_configuracao where id = :P327_PARAMETRO), ''''''''), '''':'''')'' ||',
'             '') s on to_number(trim(s.column_value)) = t.id'';',
'',
'    return l_sql;',
'end;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'PLUGIN_APEXUX.MPORAN.LISTCONTROL'
,p_display_when=>'P328_IND_TIPO_DADO'
,p_display_when2=>'IM'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'radio',
  'attribute_02', 'start',
  'attribute_03', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200420004725566491)
,p_name=>'P328_EMPRESA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_css_classes=>'is-readonly apex-item-wrapper--display-only '
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200420240675566493)
,p_name=>'P328_DESCRICAO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_prompt=>unistr('Descri\00E7\00E3o')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_css_classes=>'is-readonly apex-item-wrapper--display-only'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200498752748603191)
,p_name=>'P328_ROWID'
,p_source_data_type=>'ROWID'
,p_is_primary_key=>true
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_item_source_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_source=>'ROWID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200498954133603193)
,p_name=>'P328_CODIGO_CONFIGURACAO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_item_source_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_source=>'CODIGO_CONFIGURACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200580458563786645)
,p_name=>'P328_IND_TIPO_DADO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_item_source_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_source=>'IND_TIPO_DADO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200580604110786646)
,p_name=>'P328_VALOR_INTEIRO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_item_source_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_prompt=>'Valor Inteiro'
,p_source=>'VALOR_INTEIRO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_display_when=>'P328_IND_TIPO_DADO'
,p_display_when2=>'IN'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_css_classes=>'is-readonly apex-item-wrapper--display-only '
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200580692542786647)
,p_name=>'P328_VALOR_DECIMAL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_item_source_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_prompt=>'Valor Decimal'
,p_source=>'VALOR_DECIMAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_display_when=>'P328_IND_TIPO_DADO'
,p_display_when2=>'DE'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_css_classes=>'is-readonly apex-item-wrapper--display-only '
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200580778572786648)
,p_name=>'P328_QUANTIDADE_DECIMAL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_item_source_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_source=>'QUANTIDADE_DECIMAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when=>'P328_IND_TIPO_DADO'
,p_display_when2=>'DE'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200580918355786649)
,p_name=>'P328_VALOR_STRING'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_item_source_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_prompt=>'Valor String'
,p_source=>'VALOR_STRING'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>400
,p_cHeight=>3
,p_display_when=>'P328_IND_TIPO_DADO'
,p_display_when2=>'ST'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_css_classes=>'is-readonly apex-item-wrapper--display-only '
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200580962125786650)
,p_name=>'P328_VALOR_DATA'
,p_source_data_type=>'DATE'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_item_source_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_prompt=>'Valor Data'
,p_source=>'VALOR_DATA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_display_when=>'P328_IND_TIPO_DADO'
,p_display_when2=>'DT'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_css_classes=>'is-readonly apex-item-wrapper--display-only '
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200581081459786651)
,p_name=>'P328_VALOR_DATA_HORA'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_item_source_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_prompt=>'Valor Data Hora'
,p_source=>'VALOR_DATA_HORA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_display_when=>'P328_IND_TIPO_DADO'
,p_display_when2=>'DH'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_css_classes=>'is-readonly apex-item-wrapper--display-only '
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'Y',
  'use_defaults', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200581145079786652)
,p_name=>'P328_ID_ENTIDADE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_item_source_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_source=>'ID_ENTIDADE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200581303106786653)
,p_name=>'P328_ID_REGISTRO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_item_source_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_source=>'ID_REGISTRO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200581365797786654)
,p_name=>'P328_VALOR_DOMINIO'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_prompt=>'Valor Dominio'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- select id_registro',
'--   from ng_configuracao',
'--  where id = :P328_PARAMETRO',
unistr('--    and instr(id_registro, '':'') = 0 -- s\00F3 traz se n\00E3o tiver '':'''),
'',
'',
'--   select',
'--     b.descricao_dominio as display_value,',
'--     b.id ',
'-- from ng_configuracao a',
'-- join ng_configuracao_dominio b on b.id_configuracao = a.id',
'-- where a.id = :P328_PARAMETRO',
'-- order by b.descricao_dominio',
'',
'',
'select valor_dominio',
'  from ng_configuracao',
' where id = :P328_PARAMETRO'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    b.descricao_dominio as display_value,',
'    b.id as return_value',
'from ng_configuracao a',
'join ng_configuracao_dominio b on b.id_configuracao = a.id',
'where a.id = :P328_PARAMETRO',
'order by b.descricao_dominio',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when=>'P328_IND_TIPO_DADO'
,p_display_when2=>'DO'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_css_classes=>'is-readonly apex-item-wrapper--display-only '
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200581525411786655)
,p_name=>'P328_IND_SITUACAO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_item_source_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_source=>'IND_SITUACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200881446226619644)
,p_name=>'P328_ENTIDADESS'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_prompt=>unistr('Identifica\00E7\00E3o')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- -- -- select replace(',
'-- -- --          nvl(',
'-- -- --            (select id_registro',
'-- -- --               from ng_configuracao',
'-- -- --              where id = :P327_PARAMETRO),',
'-- -- --            ''''',
'-- -- --          ),',
'-- -- --          '':'',',
'-- -- --          chr(10)',
'-- -- --        ) as display_value',
'-- -- -- from dual',
'',
'-- -- -- Passo 1: separar os IDs usando apex_string.split',
'-- -- WITH ids AS (',
'-- --     SELECT trim(column_value) AS id_val',
'-- --     FROM table(',
'-- --         apex_string.split(''32:33:44'', '':'')  -- aqui pode ser :P327_PARAMETRO',
'-- --     )',
'-- -- )',
'-- -- -- Passo 2: usar os IDs em um select',
'-- -- aqui eu preciso pegar assim : ',
'',
'-- -- select ',
'',
'-- -- SELECT t.nome_coluna',
'-- -- FROM ids i',
'-- -- JOIN sua_tabela t ON t.id = i.id_val;',
'',
'',
'',
'-- declare',
'--     l_sql    varchar2(4000);',
'--     l_tabela varchar2(30);',
'--     l_coluna varchar2(30);',
'-- begin',
unistr('--     tenta buscar a tabela da configura\00E7\00E3o'),
'--     begin',
'--         select b.nome_entidade',
'--           into l_tabela',
'--           from ng_configuracao a',
'--           join srv_entidade b on b.id = a.id_entidade',
'--          where a.id = :P327_PARAMETRO;',
'--     exception',
'--         when no_data_found then',
unistr('--             l_tabela := null; -- n\00E3o achou nada'),
'--     end;',
'',
unistr('--     se n\00E3o encontrou a tabela, retorna SQL vazio'),
'--     if l_tabela is null then',
'--         return ''select null display_value, null return_value from dual where 1 = 0'';',
'--     end if;',
'',
unistr('--     tenta identificar uma coluna de nome ou descri\00E7\00E3o'),
'--     begin',
'--         select column_name',
'--           into l_coluna',
'--           from all_tab_columns',
'--          where table_name = upper(l_tabela)',
'--            and (column_name like ''%NOME%'' or column_name like ''%DESCRICAO%'')',
'--            and column_id = (',
'--                 select min(column_id)',
'--                   from all_tab_columns',
'--                  where table_name = upper(l_tabela)',
'--                    and (column_name like ''%NOME%'' or column_name like ''%DESCRICAO%'')',
'--            );',
'--     exception',
'--         when no_data_found then',
'--             l_coluna := ''ID''; -- fallback',
'--     end;',
'',
'--     monta SQL final',
'--     l_sql := ''select '' || l_coluna || '' as display_value, id as return_value from '' || l_tabela ;',
'',
'--     return l_sql;',
'-- end;',
'',
'',
'',
'declare',
'    l_sql    varchar2(4000);',
'    l_tabela varchar2(30);',
'    l_coluna varchar2(30);',
'begin',
unistr('    -- pega a tabela da configura\00E7\00E3o'),
'    begin',
'        select b.nome_entidade',
'          into l_tabela',
'          from ng_configuracao a',
'          join srv_entidade b on b.id = a.id_entidade',
'         where a.id = :P327_PARAMETRO;',
'    exception',
'        when no_data_found then',
'            return ''select null display_value, null return_value from dual where 1=0'';',
'    end;',
'',
'    -- pega coluna de nome ou descricao',
'    begin',
'        select column_name',
'          into l_coluna',
'          from all_tab_columns',
'         where table_name = upper(l_tabela)',
'           and (column_name like ''%NOME%'' or column_name like ''%DESCRICAO%'')',
'           and column_id = (',
'                select min(column_id)',
'                  from all_tab_columns',
'                 where table_name = upper(l_tabela)',
'                   and (column_name like ''%NOME%'' or column_name like ''%DESCRICAO%'')',
'           );',
'    exception',
'        when no_data_found then',
'            l_coluna := ''ID'';',
'    end;',
'',
'    -- monta SQL final usando apex_string.split',
'    l_sql := ''select t.'' || l_coluna || '' as display_value, t.id as return_value '' ||',
'             ''from '' || l_tabela || '' t '' ||',
'             ''join table(apex_string.split('' ||',
'             ''    nvl((select id_registro from ng_configuracao where id = :P327_PARAMETRO), ''''''''), '''':'''')'' ||',
'             '') s on to_number(trim(s.column_value)) = t.id'';',
'',
'    return l_sql;',
'end;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_display_when=>'P328_IND_TIPO_DADO'
,p_display_when2=>'IM'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(341141590422556302)
,p_item_css_classes=>'is-readonly apex-item-wrapper--display-only  my-readonly-textarea'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200881898878619648)
,p_name=>'P328_ENTIDADE'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_prompt=>unistr('Identifica\00E7\00E3o')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id_registro',
'  from ng_configuracao',
' where id = :P328_PARAMETRO',
unistr('   and instr(id_registro, '':'') = 0 -- s\00F3 traz se n\00E3o tiver '':''')))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql      varchar2(4000);',
'    l_tabela   varchar2(30);',
'    l_coluna   varchar2(30);',
'begin',
'    -- tenta buscar a tabela',
'    begin',
'        select b.nome_entidade ',
'          into l_tabela',
'        from ng_configuracao a',
'        join srv_entidade b on b.id = a.id_entidade',
'        where a.id = :P328_PARAMETRO;',
'    exception',
'        when no_data_found then',
'            l_tabela := null;',
'    end;',
'',
'    -- tenta buscar coluna',
'    if l_tabela is not null then',
'        begin',
'            select column_name',
'              into l_coluna',
'              from all_tab_columns',
'             where table_name = upper(l_tabela)',
'               and (column_name like ''%NOME%'' or column_name like ''%DESCRICAO%'')',
'               and column_id = (',
'                    select min(column_id)',
'                      from all_tab_columns',
'                     where table_name = upper(l_tabela)',
'                       and (column_name like ''%NOME%'' or column_name like ''%DESCRICAO%'')',
'               );',
'        exception',
'            when no_data_found then',
'                l_coluna := ''ID'';',
'        end;',
'',
'        l_sql := ''select ''||l_coluna||'' as display_value, id as return_value from '' || l_tabela;',
'    else',
unistr('        -- se n\00E3o achou nada, devolve query vazia'),
'        l_sql := ''select null as display_value, null as return_value from dual where 1=2'';',
'    end if;',
'',
'    return l_sql;',
'end;',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when=>'P328_IND_TIPO_DADO'
,p_display_when2=>'ID'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_css_classes=>'is-readonly apex-item-wrapper--display-only '
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200882016768619649)
,p_name=>'P328_VALOR_DOMINIOS1'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_prompt=>'DOMINIOS'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select trim(column_value)',
'  from table(',
'         apex_string.split(',
'             nvl(',
'                 (select valor_dominio',
'                    from ng_configuracao',
'                   where id = :P328_PARAMETRO),',
'                 ''''',
'             ),',
'             '':''',
'         )',
'       )',
' where trim(column_value) is not null'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql varchar2(4000);',
'begin',
'    if :P328_PARAMETRO is not null then',
'        l_sql :=',
'            ''select',
'                 b.descricao_dominio as display_value,',
'                 b.id as return_value',
'             from ng_configuracao a',
'             join ng_configuracao_dominio b on b.id_configuracao = a.id',
'             where a.id = '' || :P328_PARAMETRO || ''',
'             order by b.descricao_dominio'';',
'    else',
'        l_sql := ''select null as display_value, null as return_value from dual where 1=2'';',
'    end if;',
'',
'    return l_sql;',
'end;',
''))
,p_cHeight=>5
,p_display_when=>'P328_IND_TIPO_DADO'
,p_display_when2=>'DM'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'ALL')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200882517289619654)
,p_name=>'P328_VALOR_DOMINIOS'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_prompt=>'DOMINIOS'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select trim(column_value)',
'  from table(',
'         apex_string.split(',
'             nvl(',
'                 (select valor_dominio',
'                    from ng_configuracao',
'                   where id = :P328_PARAMETRO),',
'                 ''''',
'             ),',
'             '':''',
'         )',
'       )',
' where trim(column_value) is not null'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql varchar2(4000);',
'begin',
'    if :P328_PARAMETRO is not null then',
'        l_sql :=',
'            ''select',
'                 b.descricao_dominio as display_value,',
'                 b.id as return_value',
'             from ng_configuracao a',
'             join ng_configuracao_dominio b on b.id_configuracao = a.id',
'             where a.id = '' || :P328_PARAMETRO || ''',
'             order by b.descricao_dominio'';',
'    else',
'        l_sql := ''select null as display_value, null as return_value from dual where 1=2'';',
'    end if;',
'',
'    return l_sql;',
'end;',
''))
,p_display_when=>'P328_IND_TIPO_DADO'
,p_display_when2=>'DM'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_css_classes=>'is-readonly apex-item-wrapper--display-only '
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(376405097073484149)
,p_name=>'P328_ID_TENANT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_item_source_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_source=>'ID_TENANT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(376416449366580106)
,p_name=>'P328_GRUPO_FUNCIONALIDADE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_prompt=>'Grupo de funcionalidade'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.ind_grupo_funcionalidade',
'from ng_configuracao a',
'where a.id = :P328_PARAMETRO;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'D_NG_CONFIGURACAO.IND_GRUPO_FUNCIONALIDADE1'
,p_lov=>'select * from pkg_util.dominio_retorna_lista(''ng_configuracao'',''ind_grupo_funcionalidade'') order by 1'
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_css_classes=>'is-readonly apex-item-wrapper--display-only opacity_grupo_funcionalidade'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(376417541903580117)
,p_name=>'P328_ID_USUARIO_INCLUIU'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_item_source_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_source=>'ID_USUARIO_INCLUIU'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(376417684073580118)
,p_name=>'P328_DATA_INCLUSAO'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_item_source_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_source=>'DATA_INCLUSAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(376417746512580119)
,p_name=>'P328_ID_USUARIO_ALTEROU'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_item_source_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_prompt=>unistr('Usu\00E1rio que alterou o registro pela \00FAltima vez')
,p_source=>'ID_USUARIO_ALTEROU'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_css_classes=>'is-readonly apex-item-wrapper--display-only'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(376417880429580120)
,p_name=>'P328_DATA_ALTERACAO'
,p_source_data_type=>'DATE'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_item_source_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_prompt=>unistr('Data da \00FAltima altera\00E7\00E3o do registro')
,p_source=>'DATA_ALTERACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_css_classes=>'is-readonly apex-item-wrapper--display-only'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(376755756407906608)
,p_name=>'P328_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_item_source_plug_id=>wwv_flow_imp.id(376396854076484067)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(376845895244906912)
,p_name=>'P328_PARAMETRO'
,p_item_sequence=>100
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(380771995679991038)
,p_name=>'P328_INCREMENTA_ENTREGA_ATUAL_CONTADOR'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(380983692455274431)
,p_name=>'P328_REINICIAR_PAGAMENTOS'
,p_item_sequence=>210
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(413930969372373667)
,p_name=>'P328_CODIGO_WIZARD'
,p_item_sequence=>170
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480684198415025649)
,p_name=>'P328_URL_PROXIMO'
,p_item_sequence=>180
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(480684295722025650)
,p_name=>'P328_URL_ANTERIOR'
,p_item_sequence=>190
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(507094422193147242)
,p_name=>'P328_ETAPA'
,p_item_sequence=>200
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(629713466528267874)
,p_name=>'P328_PARAMETRO2'
,p_item_sequence=>110
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(629713546610267875)
,p_name=>'P328_TELA_TITULO'
,p_item_sequence=>150
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(629713616840267876)
,p_name=>'P328_TELA_HELP'
,p_item_sequence=>160
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(710076804922895843)
,p_name=>'P328_CODIGO_ARTEFATO'
,p_item_sequence=>90
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(710157601920062127)
,p_name=>'P328_SUCESSO'
,p_item_sequence=>140
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(710308768610059107)
,p_name=>'P328_VISUALIZAR'
,p_item_sequence=>130
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(712560315132622626)
,p_name=>'P328_COPIA'
,p_item_sequence=>120
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54771677273211452)
,p_computation_sequence=>130
,p_computation_item=>'P328_EMPRESA'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    b.nome_fantasia ',
'    from ng_configuracao a',
'    JOIN mpd_tenant      b on a.id_tenant = b.id',
'where a.id = :P328_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54772068132211451)
,p_computation_sequence=>140
,p_computation_item=>'P328_DESCRICAO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    to_char(chamar_webservice_traducao(',
'                    p_esquema           => ''wksp_teste'',',
'                    p_entidade          => ''ng_configuracao'',',
'                    p_campo             => ''descricao_configuracao'',',
'                    p_id_idioma_usuario => apex_util.get_session_state(''IDIOMA_LOGADO''),',
'                    p_id_registro       => a.id',
'                )) descricao',
'    from ng_configuracao a',
'    JOIN mpd_tenant      b on a.id_tenant = b.id',
'where a.id = :P328_PARAMETRO',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54772442497211450)
,p_computation_sequence=>150
,p_computation_item=>'P328_ID_TENANT'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>'select id_tenant from ng_configuracao a where a.id = :P328_PARAMETRO'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54772861981211449)
,p_computation_sequence=>160
,p_computation_item=>'P328_ID'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'ITEM_VALUE'
,p_computation=>'P328_PARAMETRO'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54773230722211448)
,p_computation_sequence=>170
,p_computation_item=>'P328_ID_USUARIO_INCLUIU'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.ID_USUARIO_INCLUIU',
'    from ng_configuracao a',
'where a.id = :P328_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54773713565211446)
,p_computation_sequence=>180
,p_computation_item=>'P328_DATA_INCLUSAO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.DATA_INCLUSAO',
'    from ng_configuracao a',
'where a.id = :P328_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54774046469211445)
,p_computation_sequence=>190
,p_computation_item=>'P328_ID_USUARIO_ALTEROU'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.nome',
'from MPD_USUARIO a',
'JOIN ng_configuracao b ON b.id_usuario_alterou = a.id',
'where b.id = :P328_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54774432032211444)
,p_computation_sequence=>210
,p_computation_item=>'P328_CODIGO_CONFIGURACAO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.CODIGO_CONFIGURACAO',
'    from ng_configuracao a',
'where a.id = :P328_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54774879968211442)
,p_computation_sequence=>230
,p_computation_item=>'P328_IND_TIPO_DADO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.IND_TIPO_DADO',
'    from ng_configuracao a',
'where a.id = :P328_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54775328223211441)
,p_computation_sequence=>240
,p_computation_item=>'P328_VALOR_INTEIRO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.VALOR_INTEIRO',
'    from ng_configuracao a',
'where a.id = :P328_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54775656148211440)
,p_computation_sequence=>250
,p_computation_item=>'P328_VALOR_DECIMAL'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.VALOR_DECIMAL',
'    from ng_configuracao a',
'where a.id = :P328_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54776077704211439)
,p_computation_sequence=>260
,p_computation_item=>'P328_QUANTIDADE_DECIMAL'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.QUANTIDADE_DECIMAL',
'    from ng_configuracao a ',
'where a.id = :P328_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54776489104211437)
,p_computation_sequence=>270
,p_computation_item=>'P328_VALOR_STRING'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.VALOR_STRING',
'    from ng_configuracao a ',
'where a.id = :P328_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54776831621211436)
,p_computation_sequence=>280
,p_computation_item=>'P328_VALOR_DATA'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.VALOR_DATA',
'    from ng_configuracao a ',
'where a.id = :P328_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54777264708211435)
,p_computation_sequence=>290
,p_computation_item=>'P328_VALOR_DATA_HORA'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.VALOR_DATA_HORA',
'    from ng_configuracao a ',
'where a.id = :P328_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54777694021211433)
,p_computation_sequence=>300
,p_computation_item=>'P328_ID_ENTIDADE'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.ID_ENTIDADE',
'    from ng_configuracao a ',
'where a.id = :P328_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54778087180211432)
,p_computation_sequence=>310
,p_computation_item=>'P328_ID_REGISTRO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.ID_REGISTRO',
'    from ng_configuracao a ',
'where a.id = :P328_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54778516310211431)
,p_computation_sequence=>330
,p_computation_item=>'P328_IND_SITUACAO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.IND_SITUACAO',
'    from ng_configuracao a ',
'where a.id = :P328_PARAMETRO',
'',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54778909732211430)
,p_computation_sequence=>340
,p_computation_item=>'P328_DATA_ALTERACAO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT TO_CHAR(B.DATA_ALTERACAO, ''DD/MM/YYYY HH24:MI:SS'')',
'FROM NG_CONFIGURACAO B',
'WHERE B.ID = :P328_PARAMETRO',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(54802271044211356)
,p_name=>'onChangeP328_IND_MULTA_ATRASO_PAGAMENTO'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P328_IND_MULTA_ATRASO_PAGAMENTO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54803320842211353)
,p_event_id=>wwv_flow_imp.id(54802271044211356)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P328_VALOR_MULTA,P328_PERCENTUAL_MULTA,P328_PERIODO_MULTA'
,p_client_condition_type=>'NOT_EQUALS'
,p_client_condition_element=>'P328_IND_MULTA_ATRASO_PAGAMENTO'
,p_client_condition_expression=>'S'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54802758642211354)
,p_event_id=>wwv_flow_imp.id(54802271044211356)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P328_VALOR_MULTA,P328_PERCENTUAL_MULTA,P328_PERIODO_MULTA'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P328_IND_MULTA_ATRASO_PAGAMENTO'
,p_client_condition_expression=>'S'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(54797043705211373)
,p_name=>'onChangeP328_IND_BASE_CALCULO'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P328_IND_BASE_CALCULO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54797585462211371)
,p_event_id=>wwv_flow_imp.id(54797043705211373)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_name=>'Hide P328_NUM_ENTREGA'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P328_NUM_ENTREGA'
,p_client_condition_type=>'NOT_EQUALS'
,p_client_condition_element=>'P328_IND_BASE_CALCULO'
,p_client_condition_expression=>'2'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54798086847211369)
,p_event_id=>wwv_flow_imp.id(54797043705211373)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Show P328_NUL_ENTREGA'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P328_NUM_ENTREGA'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P328_IND_BASE_CALCULO'
,p_client_condition_expression=>'2'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54799121176211366)
,p_event_id=>wwv_flow_imp.id(54797043705211373)
,p_event_result=>'TRUE'
,p_action_sequence=>90
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P328_ID_ENTREGA'
,p_client_condition_type=>'NOT_EQUALS'
,p_client_condition_element=>'P328_IND_BASE_CALCULO'
,p_client_condition_expression=>'2'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54800113881211363)
,p_event_id=>wwv_flow_imp.id(54797043705211373)
,p_event_result=>'TRUE'
,p_action_sequence=>100
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P328_NUM_ENTREGA'
,p_client_condition_type=>'NOT_EQUALS'
,p_client_condition_element=>'P328_IND_BASE_CALCULO'
,p_client_condition_expression=>'2'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54798603984211367)
,p_event_id=>wwv_flow_imp.id(54797043705211373)
,p_event_result=>'TRUE'
,p_action_sequence=>110
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P328_ID_ENTREGA'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    id    ',
'from imp_entrega',
'where id_pedidoimportacao = :P328_PARAMETRO',
'and id not in (',
'    select ',
'        id_entrega ',
'    from imp_pedidoimportacao_pagamento ',
'    where id_pedidoimportacao = :P328_PARAMETRO ',
'    and numero_parcela = :P328_PARCELA_ATUAL_CONTADOR',
') ',
'order by num_entrega',
'fetch first 1 row only;'))
,p_attribute_07=>'P328_PARAMETRO'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P328_IND_BASE_CALCULO'
,p_client_condition_expression=>'2'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54799559721211364)
,p_event_id=>wwv_flow_imp.id(54797043705211373)
,p_event_result=>'TRUE'
,p_action_sequence=>120
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P328_NUM_ENTREGA'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    num_entrega',
'from imp_entrega',
'where id_pedidoimportacao = :P328_PARAMETRO',
'and id not in (',
'    select ',
'        id_entrega ',
'    from imp_pedidoimportacao_pagamento ',
'    where id_pedidoimportacao = :P328_PARAMETRO ',
'    and numero_parcela = :P328_PARCELA_ATUAL_CONTADOR',
') ',
'order by num_entrega',
'fetch first 1 row only;'))
,p_attribute_07=>'P328_PARAMETRO'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P328_IND_BASE_CALCULO'
,p_client_condition_expression=>'2'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(54801421214211359)
,p_name=>'onPageLoad'
,p_event_sequence=>120
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54801910012211357)
,p_event_id=>wwv_flow_imp.id(54801421214211359)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ADD_CLASS'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P328_IND_BASE_CALCULO'
,p_attribute_01=>'is-readonly apex-item-wrapper--display-only'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P328_IND_BASE_CALCULO'
,p_client_condition_expression=>'2'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(54800505232211361)
,p_name=>'New'
,p_event_sequence=>130
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(54750829925211554)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54800971751211360)
,p_event_id=>wwv_flow_imp.id(54800505232211361)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.navigation.dialog.close(true);',
''))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(54785361521211412)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'altera_registro'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'BO_NG_CONFIGURACAO'
,p_attribute_04=>'ALTERA_REGISTRO'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(54750829925211554)
,p_process_success_message=>'&P328_SUCESSO.'
,p_internal_uid=>97656233181853685
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54785896722211409)
,p_page_process_id=>wwv_flow_imp.id(54785361521211412)
,p_page_id=>328
,p_name=>'p_id_tenant'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P328_ID_TENANT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54786423005211408)
,p_page_process_id=>wwv_flow_imp.id(54785361521211412)
,p_page_id=>328
,p_name=>'p_id'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>190
,p_value_type=>'ITEM'
,p_value=>'P328_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54786833312211406)
,p_page_process_id=>wwv_flow_imp.id(54785361521211412)
,p_page_id=>328
,p_name=>'p_pagina'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>true
,p_display_sequence=>200
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>':APP_PAGE_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54787301681211405)
,p_page_process_id=>wwv_flow_imp.id(54785361521211412)
,p_page_id=>328
,p_name=>'p_encadeado'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>210
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54787773260211403)
,p_page_process_id=>wwv_flow_imp.id(54785361521211412)
,p_page_id=>328
,p_name=>'p_sucesso'
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>false
,p_display_sequence=>220
,p_value_type=>'ITEM'
,p_value=>'P328_SUCESSO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54788251684211402)
,p_page_process_id=>wwv_flow_imp.id(54785361521211412)
,p_page_id=>328
,p_name=>'p_messages'
,p_direction=>'OUT'
,p_data_type=>'pkg_mensagem.message_record_table'
,p_display_sequence=>230
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54788753945211400)
,p_page_process_id=>wwv_flow_imp.id(54785361521211412)
,p_page_id=>328
,p_name=>'p_quantidade_decimal'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>240
,p_value_type=>'ITEM'
,p_value=>'P328_QUANTIDADE_DECIMAL'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54789239172211398)
,p_page_process_id=>wwv_flow_imp.id(54785361521211412)
,p_page_id=>328
,p_name=>'p_valor_string'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>250
,p_value_type=>'ITEM'
,p_value=>'P328_VALOR_STRING'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54789761166211397)
,p_page_process_id=>wwv_flow_imp.id(54785361521211412)
,p_page_id=>328
,p_name=>'p_valor_data'
,p_direction=>'IN'
,p_data_type=>'DATE'
,p_has_default=>false
,p_display_sequence=>260
,p_value_type=>'ITEM'
,p_value=>'P328_VALOR_DATA'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54790320518211396)
,p_page_process_id=>wwv_flow_imp.id(54785361521211412)
,p_page_id=>328
,p_name=>'p_valor_data_hora'
,p_direction=>'IN'
,p_data_type=>'TIMESTAMP'
,p_has_default=>false
,p_display_sequence=>270
,p_value_type=>'ITEM'
,p_value=>'P328_VALOR_DATA_HORA'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54790757607211394)
,p_page_process_id=>wwv_flow_imp.id(54785361521211412)
,p_page_id=>328
,p_name=>'p_id_entidade'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>280
,p_value_type=>'ITEM'
,p_value=>'P328_ID_ENTIDADE'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54791324818211392)
,p_page_process_id=>wwv_flow_imp.id(54785361521211412)
,p_page_id=>328
,p_name=>'p_id_registro'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>290
,p_value_type=>'FUNCTION_BODY'
,p_value_language=>'PLSQL'
,p_value=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'    l_valor  varchar2(4000);',
'begin',
'    -- Escolhe de qual item vem o valor, dependendo do tipo de dado',
'    if :P328_IND_TIPO_DADO = ''ID'' then',
'        l_valor := :P328_ENTIDADE;',
'    else',
'        l_valor := :P328_ENTIDADESS;',
'    end if;',
'',
'    return l_valor;',
'end;',
''))
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54791761332211391)
,p_page_process_id=>wwv_flow_imp.id(54785361521211412)
,p_page_id=>328
,p_name=>'p_valor_dominio'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>300
,p_value_type=>'FUNCTION_BODY'
,p_value_language=>'PLSQL'
,p_value=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'    l_valor  varchar2(4000);',
'begin',
'    -- Escolhe de qual item vem o valor, dependendo do tipo de dado',
'    if :P328_IND_TIPO_DADO = ''DO'' then',
'        l_valor := :P328_VALOR_DOMINIO;',
'    else',
'        l_valor := :P328_VALOR_DOMINIOS;',
'    end if;',
'',
'    return l_valor;',
'end;',
''))
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54792305480211389)
,p_page_process_id=>wwv_flow_imp.id(54785361521211412)
,p_page_id=>328
,p_name=>'p_ind_situacao'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>310
,p_value_type=>'ITEM'
,p_value=>'P328_IND_SITUACAO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54792767079211388)
,p_page_process_id=>wwv_flow_imp.id(54785361521211412)
,p_page_id=>328
,p_name=>'p_ind_grupo_funcionalidade'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>320
,p_value_type=>'ITEM'
,p_value=>'P328_GRUPO_FUNCIONALIDADE'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54793232787211386)
,p_page_process_id=>wwv_flow_imp.id(54785361521211412)
,p_page_id=>328
,p_name=>'p_codigo_configuracao'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>330
,p_value_type=>'ITEM'
,p_value=>'P328_CODIGO_CONFIGURACAO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54793789785211384)
,p_page_process_id=>wwv_flow_imp.id(54785361521211412)
,p_page_id=>328
,p_name=>'p_descricao_configuracao'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>340
,p_value_type=>'ITEM'
,p_value=>'P328_DESCRICAO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54794320854211383)
,p_page_process_id=>wwv_flow_imp.id(54785361521211412)
,p_page_id=>328
,p_name=>'p_ind_tipo_dado'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>350
,p_value_type=>'ITEM'
,p_value=>'P328_IND_TIPO_DADO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54794776173211381)
,p_page_process_id=>wwv_flow_imp.id(54785361521211412)
,p_page_id=>328
,p_name=>'p_valor_inteiro'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>360
,p_value_type=>'ITEM'
,p_value=>'P328_VALOR_INTEIRO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54795307188211379)
,p_page_process_id=>wwv_flow_imp.id(54785361521211412)
,p_page_id=>328
,p_name=>'p_valor_decimal'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>370
,p_value_type=>'ITEM'
,p_value=>'P328_VALOR_DECIMAL'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54795806869211378)
,p_page_process_id=>wwv_flow_imp.id(54785361521211412)
,p_page_id=>328
,p_name=>'p_data_alteracao'
,p_direction=>'IN'
,p_data_type=>'TIMESTAMP'
,p_has_default=>false
,p_display_sequence=>380
,p_value_type=>'ITEM'
,p_value=>'P328_DATA_ALTERACAO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(54779569755211428)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'retorna_titulo_help'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'RETORNA_TITULO_TELA'
,p_internal_uid=>97650441415853701
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54780056775211426)
,p_page_process_id=>wwv_flow_imp.id(54779569755211428)
,p_page_id=>328
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'nvl(:P328_CODIGO_ARTEFATO,:APP_PAGE_ID)'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54780554325211425)
,p_page_process_id=>wwv_flow_imp.id(54779569755211428)
,p_page_id=>328
,p_name=>'p_titulo'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P328_TELA_TITULO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54781105117211424)
,p_page_process_id=>wwv_flow_imp.id(54779569755211428)
,p_page_id=>328
,p_name=>'p_help'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P328_TELA_HELP'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(54781436268211423)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'url_wizard'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'URL_WIZARD'
,p_process_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    1',
'from srv_artefato_wizard a',
'join srv_artefato_versionado b on b.id = a.id_artefato_versionado',
'join srv_artefato c on c.id = b.id_artefato',
'join srv_artefato_versionado b1 on b1.id = a.id_artefato_versionado_base',
'join srv_artefato c1 on c1.id = b1.id_artefato',
'where c.codigo_artefato = nvl( apex_util.get_session_state(''P''||:APP_PAGE_ID||''_CODIGO_WIZARD''),:p0_codigo_artefato)'))
,p_process_when_type=>'EXISTS'
,p_internal_uid=>97652307928853696
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54782026082211421)
,p_page_process_id=>wwv_flow_imp.id(54781436268211423)
,p_page_id=>328
,p_name=>'p_codigo_artefato_base'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>20
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'case when :P328_CODIGO_WIZARD is null then :P328_CODIGO_ARTEFATO else :P328_CODIGO_WIZARD end'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54782457307211420)
,p_page_process_id=>wwv_flow_imp.id(54781436268211423)
,p_page_id=>328
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'nvl(:P328_CODIGO_ARTEFATO,:APP_PAGE_ID)'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54782993193211418)
,p_page_process_id=>wwv_flow_imp.id(54781436268211423)
,p_page_id=>328
,p_name=>'p_url_anterior'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P328_URL_ANTERIOR'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54783445950211417)
,p_page_process_id=>wwv_flow_imp.id(54781436268211423)
,p_page_id=>328
,p_name=>'p_url_proximo'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>50
,p_value_type=>'ITEM'
,p_value=>'P328_URL_PROXIMO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54783938046211416)
,p_page_process_id=>wwv_flow_imp.id(54781436268211423)
,p_page_id=>328
,p_name=>'p_param1'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>60
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54784527304211415)
,p_page_process_id=>wwv_flow_imp.id(54781436268211423)
,p_page_id=>328
,p_name=>'p_param2'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>70
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54784930333211413)
,p_page_process_id=>wwv_flow_imp.id(54781436268211423)
,p_page_id=>328
,p_name=>'p_etapa'
,p_direction=>'OUT'
,p_data_type=>'NUMBER'
,p_ignore_output=>false
,p_display_sequence=>80
,p_value_type=>'ITEM'
,p_value=>'P328_ETAPA'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(54765532718211495)
,p_process_sequence=>80
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(376396854076484067)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Gerar parceladas de pagamento'
,p_internal_uid=>97636404378853768
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(54796167482211376)
,p_process_sequence=>90
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'reinicia_pagamentos'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'BO_IMP_PEDIDOIMPORTACAO_PAGAMENTO'
,p_attribute_04=>'REINICIA_PAGAMENTOS'
,p_process_when=>'P328_REINICIAR_PAGAMENTOS'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_internal_uid=>97667039142853649
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54796689250211375)
,p_page_process_id=>wwv_flow_imp.id(54796167482211376)
,p_page_id=>328
,p_name=>'p_id_pedidoimportacao'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P328_PARAMETRO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(54779172023211429)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'enviarParamentros'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_param1 varchar2(100) := apex_application.g_x01||''_''||APEX_CUSTOM_AUTH.GET_SESSION_ID;',
'    v_param2 varchar2(100) := apex_application.g_x02;',
'    v_param3 varchar2(100) := apex_application.g_x03;',
'    v_existe number;',
'    v_id number;',
'begin',
unistr('    -- verifica se a cole\00E7\00E3o j\00E1 existe e a exclui para evitar duplica\00E7\00F5es'),
'    apex_debug.enable(apex_debug.c_log_level_info);',
'    apex_debug.info(''info enviarparamentros v_param1:%s'',v_param1); ',
'    apex_debug.info(''info enviarparamentros v_param2:%s'',v_param2); ',
'    apex_debug.info(''info enviarparamentros v_param3:%s'',v_param3); ',
'    apex_debug.info(''info enviarparamentros APEX_CUSTOM_AUTH.GET_SESSION_ID:%s'',APEX_CUSTOM_AUTH.GET_SESSION_ID); ',
'',
'    if not apex_collection.collection_exists(v_param1) then',
'        -- apex_collection.delete_collection(v_param1);',
'        apex_collection.create_collection(v_param1);',
'    end if;',
'',
'    select count(1) into v_existe ',
'    from apex_collections',
'    where collection_name = v_param1',
'      and c001 = v_param2;',
'    if v_existe > 0 then',
'        select seq_id into v_id ',
'        from apex_collections',
'        where collection_name = v_param1',
'          and c001 = v_param2;',
'',
'        apex_collection.update_member (',
'            p_collection_name => v_param1,',
'            p_seq => v_id,',
'            p_c001 => v_param2,',
'            p_c002 => v_param3);      ',
'    else',
'        apex_collection.add_member(',
'            p_collection_name => v_param1,',
'            p_c001 => v_param2,',
'            p_c002 => v_param3',
'        );',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>97650043683853702
);
wwv_flow_imp.component_end;
end;
/
