prompt --application/pages/page_00245
begin
--   Manifest
--     PAGE: 00245
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>245
,p_name=>'Artefato - Releases'
,p_alias=>'ARTEFATO-RELEASES'
,p_page_mode=>'MODAL'
,p_step_title=>'Artefato - Releases'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-actions{',
'    display: none;',
'}',
''))
,p_step_template=>wwv_flow_imp.id(340974912275556190)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--md'
,p_dialog_chained=>'N'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(203454463189716856)
,p_plug_name=>'Lista'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(341044399187556241)
,p_plug_display_sequence=>50
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.id,',
'    a.id_tenant,',
'    to_char(a.data_alteracao,''DD-MON-YYYY HH24:MI:SS'') as data_alteracao,',
'    b.nome des_analista,',
'    c.nome as des_desenvolvedor,',
'    dbms_lob.getlength(codigo_fonte) codigo_fonte',
'from srv_artefato_release a',
'left join mpd_usuario b on b.id = a.id_analista',
'left join mpd_usuario c on c.id = a.id_desenvolvedor',
'where a.ID_ARTEFATO_VERSIONADO = :P245_ID',
'order by a.data_alteracao desc'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P245_ID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Lista'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(126604412507019207)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'no_data_found_l'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'NTO'
,p_internal_uid=>169475284167661480
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(126604521390019208)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'coluna.srv_artefato_realease.id.l'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(126604589479019209)
,p_db_column_name=>'ID_TENANT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'coluna.srv_artefato_realease.id_tenant.l'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(126604696676019210)
,p_db_column_name=>'DATA_ALTERACAO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'coluna.srv_artefato_release.data_alteracao.l'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(126604993513019213)
,p_db_column_name=>'DES_ANALISTA'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'coluna.srv_artefato_release.id_analista.l'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(126605159500019214)
,p_db_column_name=>'DES_DESENVOLVEDOR'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'coluna.srv_artefato_release.id_desenvolvedor.l'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(126605263471019215)
,p_db_column_name=>'CODIGO_FONTE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'coluna.srv_artefato_release.codigo_fonte.l'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DOWNLOAD:SRV_ARTEFATO_RELEASE:CODIGO_FONTE:ID::CODIGO_FONTE_MIMETYPE:CODIGO_FONTE_FILENAME::CODIGO_FONTE_CHARSET:attachment:LAB_BAIXAR:'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(127164528897669941)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'775545'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:ID_TENANT:DATA_ALTERACAO:DES_ANALISTA:DES_DESENVOLVEDOR:CODIGO_FONTE'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(505917005065953143)
,p_plug_name=>'button bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI:margin-top-none'
,p_plug_template=>wwv_flow_imp.id(341013639389556225)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source=>'<div id="active_facets"></div>'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(156971933654205299)
,p_name=>'P245_CODIGO_ARTEFATO'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(202519699016261011)
,p_name=>'P245_ID_TENANT'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(345366558669852013)
,p_name=>'P245_ID'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(5950724817839628)
,p_name=>'onCloseCards'
,p_event_sequence=>70
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(203454463189716856)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5951210447839632)
,p_event_id=>wwv_flow_imp.id(5950724817839628)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(203454463189716856)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
