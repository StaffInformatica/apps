prompt --application/pages/page_09001
begin
--   Manifest
--     PAGE: 09001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>9001
,p_name=>unistr('Confirmar a\00E7\00E3o gen\00E9rica')
,p_alias=>unistr('CONFIRMAR-A\00C7\00C3O-GEN\00C9RICA')
,p_page_mode=>'MODAL'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'tituloTela($v("P9001_ACAO"));'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Cards--featured .t-Card-titleWrap {',
'    display: none !important;',
'}'))
,p_step_template=>wwv_flow_imp.id(340974912275556190)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--sm'
,p_protection_level=>'C'
,p_page_component_map=>'25'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5268595099045643)
,p_plug_name=>'Header'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(341013639389556225)
,p_plug_display_sequence=>10
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9001_CODIGO_ARTEFATO,''TD452'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_cabecalho(:param1,:param2); END;''',
'        USING OUT l_sql, IN nvl(:P9001_ID,:P9001_PARAMETRO),:P9001_PARAMETRO2;',
'',
'    return l_sql;       ',
'end;',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from all_procedures',
'where upper(object_name) = upper(''ui_mpd_''||:p9001_codigo_artefato)',
'and upper(procedure_name) = upper(''sql_cabecalho'')',
'and upper(object_type) = upper(''package'');'))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(59409312113426333)
,p_plug_name=>'Footer'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(341013639389556225)
,p_plug_display_sequence=>140
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(551788239004641514)
,p_plug_name=>unistr('Confirma\00E7\00E3o')
,p_region_name=>'button_bar'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>150
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_metodo_detalhe  varchar2(256) := nvl(:P9001_METODO_DETALHE, ''BO_SRV_MENU.detalhe_registro'');',
'    v_id              number := nvl(:P9001_ID,0);',
'    l_html clob;',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_html := ''||v_metodo_detalhe||''(p_id => ''||v_id||''); END;''',
'        USING OUT l_html;',
'',
'    return l_html;       ',
'end;',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P9001_ID,P9001_METODO_DETALHE'
,p_plug_display_condition_type=>'ITEM_IS_NOT_ZERO'
,p_plug_display_when_condition=>'P9001_ID'
,p_plug_header=>unistr('<!--<h4 style="text-align: center;">Voc\00EA deseja realmente executar esta a\00E7\00E3o?</h4>!-->')
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(135201324629772758)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(59409312113426333)
,p_button_name=>'Confirmar'
,p_button_static_id=>'BTN_CONFIRMAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(341144157120556305)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P9001_LABEL_CONFIRMAR.'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5268675982045644)
,p_name=>'P9001_PARAMETRO'
,p_item_sequence=>240
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5268787814045645)
,p_name=>'P9001_PARAMETRO2'
,p_item_sequence=>250
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(22059446879718654)
,p_name=>'P9001_FECHAR_MODAL'
,p_item_sequence=>260
,p_item_default=>'SIM'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(51436596312033461)
,p_name=>'P9001_CONFIRMACAO_SIMPLES'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(551788239004641514)
,p_prompt=>'&P9001_LABEL_CONFIRMAR_SIMPLES_L.'
,p_placeholder=>'&P9001_LABEL_CONFIRMAR_SIMPLES_I.'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when=>'P9001_TIPO_CONFIRMACAO'
,p_display_when2=>'2'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'&P9001_LABEL_CONFIRMAR_SIMPLES_H.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(51436713176033462)
,p_name=>'P9001_TIPO_CONFIRMACAO'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(51436761316033463)
,p_name=>'P9001_CONFIRMACAO_SENHA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(551788239004641514)
,p_prompt=>'&P9001_LABEL_CONFIRMAR_SENHA_L.'
,p_placeholder=>'&P9001_LABEL_CONFIRMAR_SENHA_I.'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_display_when=>'P9001_TIPO_CONFIRMACAO'
,p_display_when2=>'3'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'&P9001_LABEL_CONFIRMAR_SENHA_H.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'submit_when_enter_pressed', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(51437024140033465)
,p_name=>'P9001_LABEL_CONFIRMAR'
,p_item_sequence=>160
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(51437028632033466)
,p_name=>'P9001_LABEL_CONFIRMAR_SIMPLES_L'
,p_item_sequence=>180
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(51437212188033467)
,p_name=>'P9001_LABEL_CONFIRMAR_SIMPLES_I'
,p_item_sequence=>190
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(51437292582033468)
,p_name=>'P9001_LABEL_CONFIRMAR_SIMPLES_H'
,p_item_sequence=>200
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(51437402139033469)
,p_name=>'P9001_LABEL_CONFIRMAR_SENHA_L'
,p_item_sequence=>210
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(51437492942033470)
,p_name=>'P9001_LABEL_CONFIRMAR_SENHA_I'
,p_item_sequence=>220
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(51437626473033471)
,p_name=>'P9001_LABEL_CONFIRMAR_SENHA_H'
,p_item_sequence=>230
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(52686795131869535)
,p_name=>'P9001_LABEL_SENHA_INCORRETA'
,p_item_sequence=>170
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(160401475612960054)
,p_name=>'P9001_TELA_TITULO'
,p_item_sequence=>130
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(160401616479960055)
,p_name=>'P9001_TELA_HELP'
,p_item_sequence=>140
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(160401659678960056)
,p_name=>'P9001_CODIGO_ARTEFATO'
,p_item_sequence=>120
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213891895593270690)
,p_name=>'P9001_METODO_EXECUCAO'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213892002040270691)
,p_name=>'P9001_METODO_DETALHE'
,p_item_sequence=>90
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213892551883270696)
,p_name=>'P9001_ACAO'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(377821566206339326)
,p_name=>'P9001_SUCESSO'
,p_item_sequence=>110
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(551835774296641760)
,p_name=>'P9001_ID'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(51437646923033472)
,p_name=>'onChangeTipoConfirmacao'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9001_TIPO_CONFIRMACAO'
,p_condition_element=>'P9001_TIPO_CONFIRMACAO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(51437855478033474)
,p_event_id=>wwv_flow_imp.id(51437646923033472)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(135201324629772758)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(51437998856033475)
,p_event_id=>wwv_flow_imp.id(51437646923033472)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(135201324629772758)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(51438062219033476)
,p_name=>'onChangeConfirmacaoSimples'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9001_CONFIRMACAO_SIMPLES'
,p_condition_element=>'P9001_CONFIRMACAO_SIMPLES'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'CONFIRMAR'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(51438177311033477)
,p_event_id=>wwv_flow_imp.id(51438062219033476)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(135201324629772758)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(52686097884869528)
,p_event_id=>wwv_flow_imp.id(51438062219033476)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(135201324629772758)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(52686210188869529)
,p_name=>'onChangeConfirmacaoSenha'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9001_CONFIRMACAO_SENHA'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(52686478560869532)
,p_event_id=>wwv_flow_imp.id(52686210188869529)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('    var senha = $v("P9001_CONFIRMACAO_SENHA"); // Obt\00E9m o valor do item de senha'),
unistr('    var botaoId = "BTN_CONFIRMAR"; // ID do bot\00E3o que ser\00E1 habilitado/desabilitado'),
'    apex.server.process("VALIDAR_SENHA", {',
unistr('        x01: senha // Passa a senha como par\00E2metro'),
'    }, {',
'        success: function(data) {',
'            if (data.success === ''true'') {',
'                apex.message.clearErrors();',
unistr('                apex.item(botaoId).enable(); // Habilita o bot\00E3o'),
'            } else {',
unistr('                apex.item(botaoId).disable(); // Habilita o bot\00E3o'),
'                apex.message.clearErrors();',
'                apex.message.showErrors([{',
'                    type: "error",',
'                    location: ["inline"],',
'                    pageItem: "P9001_CONFIRMACAO_SENHA",',
'                    message: $v("P9001_LABEL_SENHA_INCORRETA"),',
'                    unsafe: false',
'                }]);',
'            }',
'        },',
'        error: function() {',
unistr('            console.error("Erro na requisi\00E7\00E3o AJAX");'),
unistr('            apex.item(botaoId).disable(); // Habilita o bot\00E3o'),
'        }',
'    });',
'',
'',
''))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(65449354739861845)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Backgound'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'IGNORE'
,p_attribute_09=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_required_patch=>wwv_flow_imp.id(340973604135556181)
,p_internal_uid=>108320226400504118
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(135206931173772777)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'executar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_messages pkg_mensagem.message_record_table;',
'BEGIN',
'    v_messages := pkg_mensagem.message_record_table();',
'    EXECUTE IMMEDIATE',
'        ''BEGIN ''|| :P9001_METODO_EXECUCAO ||',
'        ''(p_id => :P9001_ID, p_sucesso => :P9001_SUCESSO, p_messages => :v_messages); END;''',
'        USING :P9001_ID, OUT :P9001_SUCESSO, OUT v_messages;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(135201324629772758)
,p_process_success_message=>'&P9001_SUCESSO.'
,p_internal_uid=>99828389162674632
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(135207286362772778)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'closed'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(135201324629772758)
,p_internal_uid=>99828744351674633
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(160401138933960050)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'retorna_titulo_help'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'RETORNA_TITULO_TELA'
,p_internal_uid=>125022596922861905
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(160401150312960051)
,p_page_process_id=>wwv_flow_imp.id(160401138933960050)
,p_page_id=>9001
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'nvl(:P9001_CODIGO_ARTEFATO,:APP_PAGE_ID)'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(160401337000960052)
,p_page_process_id=>wwv_flow_imp.id(160401138933960050)
,p_page_id=>9001
,p_name=>'p_titulo'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P9001_TELA_TITULO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(160401347168960053)
,p_page_process_id=>wwv_flow_imp.id(160401138933960050)
,p_page_id=>9001
,p_name=>'p_help'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P9001_TELA_HELP'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(51436876137033464)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_prefixo_itens varchar2(32);',
'    l_label_confirmar varchar2(2000);',
'    l_label_senha_incorreta varchar2(2000);',
'    l_label_confirmar_simples_l varchar2(2000);',
'    l_label_confirmar_simples_i varchar2(2000);',
'    l_label_confirmar_simples_h varchar2(2000);',
'    l_label_confirmar_senha_l varchar2(2000);',
'    l_label_confirmar_senha_i varchar2(2000);',
'    l_label_confirmar_senha_h varchar2(2000);',
'begin',
'    l_prefixo_itens := ''P'' || :app_page_id  ;',
'    select pkg_ui.retorna_label_botao(''confirma''), pkg_ui.retorna_label_botao(''senha-incorreta'') into l_label_confirmar, l_label_senha_incorreta from dual;',
'    ',
'    apex_util.set_session_state(l_prefixo_itens || ''_LABEL_CONFIRMAR'', l_label_confirmar);',
'    apex_util.set_session_state(l_prefixo_itens || ''_LABEL_SENHA_INCORRETA'', l_label_senha_incorreta);',
'',
'    pkg_ui.retorna_label_tela(''confirmar-simples'',l_label_confirmar_simples_l,l_label_confirmar_simples_i,l_label_confirmar_simples_h);',
'    apex_util.set_session_state(l_prefixo_itens || ''_LABEL_CONFIRMAR_SIMPLES_L'', l_label_confirmar_simples_l);',
'    apex_util.set_session_state(l_prefixo_itens || ''_LABEL_CONFIRMAR_SIMPLES_I'', l_label_confirmar_simples_i);',
'    apex_util.set_session_state(l_prefixo_itens || ''_LABEL_CONFIRMAR_SIMPLES_H'', l_label_confirmar_simples_h);',
'',
'    pkg_ui.retorna_label_tela(''confirmar-senha'',l_label_confirmar_senha_l,l_label_confirmar_senha_i,l_label_confirmar_senha_h);',
'    apex_util.set_session_state(l_prefixo_itens || ''_LABEL_CONFIRMAR_SENHA_L'', l_label_confirmar_senha_l);',
'    apex_util.set_session_state(l_prefixo_itens || ''_LABEL_CONFIRMAR_SENHA_I'', l_label_confirmar_senha_i);',
'    apex_util.set_session_state(l_prefixo_itens || ''_LABEL_CONFIRMAR_SENHA_H'', l_label_confirmar_senha_h);',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>94307747797675737
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(52686609482869533)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'VALIDAR_SENHA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_result BOOLEAN;',
'BEGIN',
'    v_result := PKG_SEGURANCA.auth(apex_custom_auth.get_username, apex_application.g_x01);',
'    -- Retorna o resultado como JSON',
'    APEX_JSON.OPEN_OBJECT;',
'    APEX_JSON.WRITE(''success'', CASE WHEN v_result THEN ''true'' ELSE ''false'' END);',
'    APEX_JSON.CLOSE_OBJECT;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>95557481143511806
);
wwv_flow_imp.component_end;
end;
/
