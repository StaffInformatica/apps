prompt --application/pages/page_09000
begin
--   Manifest
--     PAGE: 09000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_page.create_page(
 p_id=>9000
,p_name=>unistr('A\00E7\00F5es gen\00E9rica')
,p_alias=>unistr('A\00C7\00D5ES-GEN\00C9RICA')
,p_page_mode=>'MODAL'
,p_step_title=>'&P9000_LABEL_TELA.'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'tituloTela($v("P9000_LABEL_TELA"));',
'',
'const $container = $(window.frameElement.parentElement.parentElement).find(".ui-dialog-titlebar");',
'',
unistr('// 1. Remove o \00EDcone que j\00E1 estava no topo (a vers\00E3o da execu\00E7\00E3o anterior)'),
'$container.find("#iconehome").remove();',
'',
unistr('// 2. Move o "novo" \00EDcone original para o topo'),
'// O comando .prependTo() retira ele do lugar original e coloca no destino',
'$("#iconehome").prependTo($container);'))
,p_step_template=>wwv_flow_imp.id(489110489949697573)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'27'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(166311763680903237)
,p_plug_name=>'Atualizar'
,p_region_name=>'ATUALIZAR'
,p_region_css_classes=>'u-hidden'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>130
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(201574659875918457)
,p_plug_name=>'Icone home'
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<a id="iconehome"',
'   href="javascript:void(0)"',
'   class="t-Header-logo-link"',
unistr('   title="P\00E1gina inicial"'),
'   onclick="window.open(''f?p=&APP_ID.:HOME:&SESSION.'',''_blank'');">',
'    <img src="r/teste/124/files/static/v1282/icons/app-icon-256-rounded.png"',
'         alt=""',
'         class="apex-logo-img">',
'</a>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(205266691618971635)
,p_plug_name=>'&P9000_LABEL_NAVEGACAO.'
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody:margin-left-md:margin-right-md'
,p_component_template_options=>'#DEFAULT#:u-colors'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>110
,p_location=>null
,p_list_id=>wwv_flow_imp.id(205324859061159097)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(258027369324965166)
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P9000_ID is not null and  PKG_UI.verifica_se_tem_linhas(PKG_UI.buscar_acoes(:P9000_ID,:P9000_PAGINA,''N'')) = true'
,p_plug_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(361818018985201307)
,p_plug_name=>'&P9000_LABEL_ACAO.'
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody:margin-left-md:margin-right-md'
,p_component_template_options=>'#DEFAULT#:u-colors'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>90
,p_location=>null
,p_list_id=>wwv_flow_imp.id(283332300053911334)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(258027369324965166)
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'PKG_UI.verifica_se_tem_linhas(PKG_UI.buscar_acoes(:P9000_ID,:P9000_PAGINA,''W'')) = true'
,p_plug_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(361818996648201317)
,p_plug_name=>unistr('Opera\00E7\00F5es')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(489147839586697607)
,p_plug_display_sequence=>120
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return PKG_UI.buscar_acoes(:P9000_ID,:P9000_PAGINA,''E'',false,:P9000_PARAMETRO);',
''))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_BOT_ES_A__ES'
,p_ajax_items_to_submit=>'P9000_ID,P9000_PAGINA'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_plug_query_no_data_found=>unistr('Nenhuma opera\00E7\00E3o dispon\00EDvel')
,p_no_data_found_icon_classes=>'fa-robot'
,p_show_total_row_count=>false
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P9000_ID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'ICON', 'ICON',
  'LABEL', 'LABEL',
  'LINK', 'LINK',
  'MY_SECOND_PLACEHOLDER', 'HELP')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(205267113373971639)
,p_name=>'LABEL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LABEL'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(205267178489971640)
,p_name=>'HELP'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'HELP'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(362015589906409186)
,p_name=>'LINK'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LINK'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(362015668474409187)
,p_name=>'ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(148985544436705112)
,p_name=>'P9000_PARAMETRO'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(160114996254777013)
,p_name=>'P9000_LABEL_ACAO'
,p_item_sequence=>20
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pkg_ui.retorna_label_tela(''acao'') from dual;',
''))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(160115067841777014)
,p_name=>'P9000_LABEL_NAVEGACAO'
,p_item_sequence=>30
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pkg_ui.retorna_label_tela(''navegacao'') from dual;',
''))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(160115190708777015)
,p_name=>'P9000_LABEL_TELA'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(170194647351860033)
,p_name=>'P9000_FECHAR_MODAL'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200685491226450122)
,p_name=>'P9000_PARAMETRO2'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(429648077421125159)
,p_name=>'P9000_PAGINA'
,p_item_sequence=>100
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(524928322095271342)
,p_name=>'P9000_ID'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(160115217602777016)
,p_computation_sequence=>10
,p_computation_item=>'P9000_LABEL_TELA'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pkg_ui.retorna_titulo_tela(''9000'') from dual;',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(166311863665903238)
,p_name=>'onClosedAtualizar'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(166311763680903237)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(170194952808860036)
,p_event_id=>wwv_flow_imp.id(166311863665903238)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9000_FECHAR_MODAL'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P9001_FECHAR_MODAL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(166311975423903239)
,p_event_id=>wwv_flow_imp.id(166311863665903238)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'location.reload();'
,p_client_condition_type=>'NULL'
,p_client_condition_element=>'P9000_FECHAR_MODAL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(170194796899860034)
,p_name=>'onChangeFechaModal'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9000_FECHAR_MODAL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(170194835113860035)
,p_event_id=>wwv_flow_imp.id(170194796899860034)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P9000_FECHAR_MODAL'
,p_client_condition_expression=>'SIM'
);
wwv_flow_imp.component_end;
end;
/
