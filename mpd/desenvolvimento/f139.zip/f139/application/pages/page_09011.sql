prompt --application/pages/page_09011
begin
--   Manifest
--     PAGE: 09011
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>9011
,p_name=>'Template - Formulario File '
,p_alias=>'TEMPLATE-FORMULARIO-FILE'
,p_page_mode=>'MODAL'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function copiarValor(origemId, destinoId) {',
'    var datePicker = document.getElementById(origemId);',
'    var valorOrigem = datePicker ? datePicker.value : ''''; ',
'    document.getElementById(destinoId).value = valorOrigem;',
'    console.log(document.getElementById(destinoId).value);',
'}',
'',
'function toggleFileUpload() {',
'    // Seleciona o elemento <a-dynamic-content>',
'    var dynamicContent = document.querySelector(''a-dynamic-content'');',
'    console.log(''toggleFileUpload'');',
unistr('    // Verifica se o elemento existe e se cont\00E9m a palavra "mostra_file"'),
'    if (dynamicContent && dynamicContent.innerHTML.includes(''mostra_file1'')) {',
'        // Se encontrar, mostra o item de upload de arquivo',
'        apex.item(''P9011_FILE1'').show();',
'        apex.item(''P9011_FILE2'').hide();',
'    }',
'    else if ( dynamicContent && dynamicContent.innerHTML.includes(''mostra_file2'') ){',
'        apex.item(''P9011_FILE2'').show();',
'        apex.item(''P9011_FILE1'').hide();',
'    }',
'    else {',
'        apex.item(''P9011_FILE2'').hide();',
'        apex.item(''P9011_FILE1'').hide();',
'    }',
'}',
'',
'function checkInputAndToggleClass(inputElement) {',
unistr('    // Verificar se o campo de entrada est\00E1 preenchido'),
'    console.log(inputElement.value);',
'    if (inputElement.value.trim() !== "") {',
unistr('        // Localizar a div pai que cont\00E9m "CONTAINER" no ID'),
'        let parentDiv = inputElement.closest("div[id*=''CONTAINER'']");',
'        ',
'        // Se a div for encontrada, adicionar a classe js-show-label',
'        if (parentDiv) {',
'            parentDiv.classList.add("js-show-label");',
'        }',
'    } else {',
'        // Se o valor estiver vazio, remover a classe js-show-label',
'        let parentDiv = inputElement.closest("div[id*=''CONTAINER'']");',
'        ',
'        // Remover a classe js-show-label se ela existir',
'        if (parentDiv) {',
'            parentDiv.classList.remove("js-show-label");',
'        }',
'    }',
'}',
'',
'document.addEventListener("DOMContentLoaded", function() {',
'  toggleFileUpload();',
'  var windowWidth = 400;  // Largura da janela popup',
'  var windowHeight = 450;  // Altura da janela popup',
'',
'  // Calcula o centro da tela',
'  var left = (window.screen.width - windowWidth) / 2;',
'  var top = (window.screen.height - windowHeight) / 2;',
'',
unistr('  // Modifica os par\00E2metros de ''left'' e ''top'' no popup gerado'),
'  var originalOpen = window.open;',
'  window.open = function(url, name, specs) {',
unistr('    // Adiciona ou substitui os par\00E2metros ''left'' e ''top'''),
'    specs = specs.replace(/left=\d+/, ''left='' + left);',
'    specs = specs.replace(/top=\d+/, ''top='' + top);',
'',
unistr('    // Se ''left'' e ''top'' n\00E3o existirem, adiciona os par\00E2metros'),
'    if (!specs.includes(''left='')) specs += '',left='' + left;',
'    if (!specs.includes(''top='')) specs += '',top='' + top;',
'',
unistr('    // Chama a fun\00E7\00E3o window.open original com as modifica\00E7\00F5es'),
'    return originalOpen.call(window, url, name, specs);',
'  };',
'});'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'tituloTela($v("P9011_TELA_TITULO")+'' (''+$v("P9011_CODIGO_ARTEFATO")+'')'');',
'',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.centro{',
'    display: grid;',
'    justify-items: center;',
'}',
'',
'.select option.selected {',
'    color: #888; /* Cor mais clara para parecer um placeholder */',
'    opacity: 0.5; /* Reduz a opacidade */',
'}'))
,p_step_template=>wwv_flow_imp.id(340974912275556190)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_protection_level=>'C'
,p_page_component_map=>'25'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1723755446390030)
,p_plug_name=>'New asd a'
,p_title=>'a sd asd '
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(341013639389556225)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(46433469374286992)
,p_plug_name=>'Form'
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9011_CODIGO_ARTEFATO,''TD152'');',
'BEGIN',
'    begin',
'        execute immediate',
'            ''begin :sql := UI_MPD_''|| l_pagina ||''.sql_file; end;'' ',
'            USING out l_sql;',
'            exception',
'                when others then',
'                    l_sql := ''select null id, empty_blob() file1, null file1_name from dual'';',
'    end;',
'    return l_sql;',
'END;',
'',
'return q''~',
'',
'~'';'))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_ajax_items_to_submit=>'P9011_CODIGO_ARTEFATO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(171276470498255047)
,p_plug_name=>unistr('Formul\00E1rio')
,p_region_template_options=>'#DEFAULT#:t-Form--large'
,p_plug_template=>wwv_flow_imp.id(341010888912556224)
,p_plug_display_sequence=>80
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_html clob;        ',
'    l_codigo_artefato varchar2(128) := nvl(:P9011_CODIGO_ARTEFATO,100);',
'begin',
'    pkg_ui.gerar_formulario(l_codigo_artefato,nvl(:P9011_ID,:P9011_COPIA),:P9011_VISUALIZAR,l_html,:P9011_PARAMETRO,:P9011_PARAMETRO2); ',
'    return l_html;',
'end;'))
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P9011_CODIGO_ARTEFATO,P9011_COPIA,P9011_PARAMETRO,P9011_PARAMETRO2,P9011_VISUALIZAR'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1792501499759668)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1723755446390030)
,p_button_name=>'inclui'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(341144305939556305)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Salvar'
,p_button_position=>'CREATE'
,p_button_condition=>'P9011_VISUALIZAR'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1772091375885049)
,p_name=>'P9011_FILE1'
,p_source_data_type=>'BLOB'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(171276470498255047)
,p_item_source_plug_id=>wwv_flow_imp.id(46433469374286992)
,p_prompt=>'&P9011_FILE1_NOME.'
,p_source=>'FILE1'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_cattributes_element=>'style="padding:8px;"'
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'&P9011_FILE1_HELP.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'content_disposition', 'attachment',
  'display_as', 'DROPZONE_BLOCK',
  'display_download_link', 'Y',
  'filename_column', 'FILE1_NAME',
  'storage_type', 'DB_COLUMN')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1772128825885050)
,p_name=>'P9011_FILE1_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(46433469374286992)
,p_item_source_plug_id=>wwv_flow_imp.id(46433469374286992)
,p_source=>'FILE1_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1772307045885051)
,p_name=>'P9011_FILE1_NOME'
,p_item_sequence=>180
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1772338894885052)
,p_name=>'P9011_FILE1_INSTRUCAO'
,p_item_sequence=>190
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1772495374885053)
,p_name=>'P9011_FILE1_HELP'
,p_item_sequence=>200
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17160727554247028)
,p_name=>'P9011_FILE2'
,p_source_data_type=>'BLOB'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(171276470498255047)
,p_item_source_plug_id=>wwv_flow_imp.id(46433469374286992)
,p_prompt=>'&P9011_FILE1_NOME.'
,p_source=>'FILE1'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_cattributes_element=>'style="padding:8px;"'
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'&P9011_FILE1_HELP.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_multiple_files', 'N',
  'display_as', 'DROPZONE_BLOCK',
  'purge_file_at', 'SESSION',
  'storage_type', 'APEX_APPLICATION_TEMP_FILES')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46437710953286971)
,p_name=>'P9011_ID_1'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(46433469374286992)
,p_item_source_plug_id=>wwv_flow_imp.id(46433469374286992)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46439316913286950)
,p_name=>'P9011_ID'
,p_item_sequence=>150
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(90846185151460696)
,p_name=>'P9011_PARAMETRO'
,p_item_sequence=>130
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(90846280170460697)
,p_name=>'P9011_PARAMETRO2'
,p_item_sequence=>140
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(90846360252460698)
,p_name=>'P9011_TELA_TITULO'
,p_item_sequence=>160
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(90846430482460699)
,p_name=>'P9011_TELA_HELP'
,p_item_sequence=>170
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(171209618565088666)
,p_name=>'P9011_CODIGO_ARTEFATO'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(171290415562254950)
,p_name=>'P9011_SUCESSO'
,p_item_sequence=>110
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(171441582252251930)
,p_name=>'P9011_VISUALIZAR'
,p_item_sequence=>100
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(173693128774815449)
,p_name=>'P9011_COPIA'
,p_item_sequence=>120
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1800546678759625)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Post'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_messages pkg_mensagem.message_record_table;',
'    l_pagina varchar2(256) := nvl(:P9011_CODIGO_ARTEFATO,266);',
'BEGIN',
'    v_messages := pkg_mensagem.message_record_table();',
'    EXECUTE IMMEDIATE',
'        ''BEGIN UI_MPD_''|| l_pagina ||''.post''||',
'        ''(p_id => :P9011_ID, p_sucesso => :P9011_SUCESSO, p_messages => :v_messages); END;''',
'        USING :P9011_ID, OUT :P9011_SUCESSO, OUT v_messages;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1792501499759668)
,p_process_success_message=>'&P9011_SUCESSO.'
,p_internal_uid=>44671418339401898
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1800983450759624)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'ClosedDialog'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>44671855111401897
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1803631607759617)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Seta id do Form'
,p_process_sql_clob=>':P9011_ID_1 := :P9011_ID;'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>44674503268401890
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1772578971885054)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Seta o Label do campo File'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_messages pkg_mensagem.message_record_table;',
'    l_pagina varchar2(256) := nvl(:P9011_CODIGO_ARTEFATO,''TD152'');',
'BEGIN',
'    v_messages := pkg_mensagem.message_record_table();',
'    EXECUTE IMMEDIATE',
'        ''BEGIN UI_MPD_''|| l_pagina ||''.label_coluna''||',
'        ''(campo => 1, p_label => :label, p_instrucao => :instrucao, p_help => :help ); END;''',
'        USING OUT :P9011_FILE1_NOME, OUT :P9011_FILE1_INSTRUCAO, OUT :P9011_FILE1_HELP;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>44643450632527327
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1801759731759622)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'retorna_titulo_help'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'RETORNA_TITULO_TELA'
,p_internal_uid=>44672631392401895
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(1802304261759621)
,p_page_process_id=>wwv_flow_imp.id(1801759731759622)
,p_page_id=>9011
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'nvl(:P9011_CODIGO_ARTEFATO,:APP_PAGE_ID)'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(1802814307759619)
,p_page_process_id=>wwv_flow_imp.id(1801759731759622)
,p_page_id=>9011
,p_name=>'p_titulo'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P9011_TELA_TITULO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(1803288071759618)
,p_page_process_id=>wwv_flow_imp.id(1801759731759622)
,p_page_id=>9011
,p_name=>'p_help'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P9011_TELA_HELP'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1797034439759644)
,p_process_sequence=>40
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(46433469374286992)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Template'
,p_internal_uid=>44667906100401917
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1801339681759623)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'enviarParamentros'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    prc_enviar_parametros(',
'        apex_application.g_x01,',
'        apex_application.g_x02,',
'        apex_application.g_x03,',
'        apex_application.g_x04',
'    );',
'    if apex_application.g_x01 is not null then',
'        if upper(apex_application.g_x02) = upper(''id_tenant'') and :P9013_ID is null then',
'            :P0_TENANT_INFORMADO := apex_application.g_x03;',
'        end if;',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>44672211342401896
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(20811804634260049)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'atribuiValorAJAX'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_json CLOB;',
'BEGIN',
'    l_json := pkg_formulario_dinamico.executa_sql_parametrizado(',
'        p_param1 => apex_application.g_x01,',
'        p_sql    => apex_application.g_x02',
'    );',
'    htp.p(l_json); -- resposta para o JavaScript',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>22059067026382224
);
wwv_flow_imp.component_end;
end;
/
