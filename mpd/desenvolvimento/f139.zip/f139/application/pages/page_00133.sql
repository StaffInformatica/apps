prompt --application/pages/page_00133
begin
--   Manifest
--     PAGE: 00133
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>133
,p_name=>unistr('Usu\00E1rio - Mais detalhes do usu\00E1rio')
,p_alias=>unistr('USU\00C1RIO-MAIS-DETALHES-DO-USU\00C1RIO')
,p_step_title=>unistr('Usu\00E1rio - Mais detalhes do usu\00E1rio')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Body-side{',
'    width: auto;',
'    box-shadow: none;',
'    max-width: 450px;',
'}',
'',
'.t-Region-title{',
'    padding-left: 16px;',
'}',
'',
'.st-card-title {',
'    font-weight: bold;',
'    font-size: larger;',
'    padding: 16px;',
'}',
'',
'.overflow_line {',
'    white-space: normal;',
'    overflow: hidden;',
'    word-wrap: break-word;',
'    hyphens: auto;',
'}'))
,p_step_template=>wwv_flow_imp.id(340985230573556208)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(168483854473422626)
,p_plug_name=>'form'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(341044399187556241)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_04'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.id,',
'       a.nome,',
'       email,',
'       telefone,',
'       login,',
'       pkg_util.dominio_retorna_tag(''mpd_usuario'',''situacao_cadastral'',situacao_cadastral) as situacao_cadastral,',
'       pkg_util.dominio_retorna_tag(''mpd_usuario'',''situacao_operacional'',situacao_operacional) as situacao_operacional,',
'       --b.nome as id_idioma,',
'       fuso_horario,',
'       pkg_util.dominio_retorna_tag(''mpd_usuario'',''usuario_eh_administrador'',usuario_eh_administrador) as usuario_eh_administrador,',
'       pkg_util.dominio_retorna_tag(''mpd_usuario'',''usuario_eh_administrador'',usuario_eh_master) as usuario_eh_master,',
'       foto,',
'       foto_name,',
'       foto_mimetype,',
'       foto_charset       ',
'from mpd_usuario a',
'left join srv_idioma b',
'on b.id = a.id_idioma',
'where a.id = :P133_ID',
'/*select id,',
'       nome_entidade,',
'       descricao_entidade,',
'       pkg_util.dominio_retorna_tag(''srv_entidade'',''compartilhamento'',compartilhamento) as compartilhamento,',
'       pkg_util.dominio_retorna_tag(''srv_entidade'',''carga_inicial'',carga_inicial) as carga_inicial,',
'       pkg_util.dominio_retorna_tag(''srv_entidade'',''atualizacao'',atualizacao) as atualizacao',
'from srv_entidade*/'))
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_ajax_items_to_submit=>'P133_ID'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(271987688118472955)
,p_plug_name=>'Painel esquerdo'
,p_region_css_classes=>'a-CardView'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(155419389020698771)
,p_plug_name=>'tela.seguranca.l'
,p_parent_plug_id=>wwv_flow_imp.id(271987688118472955)
,p_region_template_options=>'#DEFAULT#:i-h240:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_etapa varchar2(256);',
'Begin       ',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''MPD_USUARIO.LOGIN'',''fa-sign-in'',:P133_LOGIN,p_color=>''1''));',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''MPD_USUARIO.SITUACAO_CADASTRAL'',''fa-list-ul'',:P133_SITUACAO_CADASTRAL,p_color=>''2''));',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''MPD_USUARIO.SITUACAO_OPERACIONAL'',''fa-briefcase'',:P133_SITUACAO_OPERACIONAL,p_color=>''3'',p_ultimo=>''s''));    ',
'End;'))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(155419471172698772)
,p_plug_name=>'tela.preferencia.l'
,p_parent_plug_id=>wwv_flow_imp.id(271987688118472955)
,p_region_template_options=>'#DEFAULT#:i-h240:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_etapa varchar2(256);',
'Begin   ',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''SRV_IDIOMA.NOME'',''fa-globe'',:P133_ID_IDIOMA,p_color=>''1''));',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''MPD_USUARIO.FUSO_HORARIO'',''fa-clock-o'',:P133_FUSO_HORARIO,p_color=>''2'',p_ultimo=>''s''));',
'End;'))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(155419594586698773)
,p_plug_name=>'tela.privilegio.l'
,p_parent_plug_id=>wwv_flow_imp.id(271987688118472955)
,p_region_template_options=>'#DEFAULT#:i-h240:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_etapa varchar2(256);',
'Begin       ',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''MPD_USUARIO.USUARIO_EH_ADMINISTRADOR'',''fa-user-wrench'',:P133_USUARIO_EH_ADMINISTRADOR,p_color=>''1''));',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''MPD_USUARIO.USUARIO_EH_MASTER'',''fa-user-chart'',:P133_USUARIO_EH_MASTER,p_color=>''2'',p_ultimo=>''s''));    ',
'End;'))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(157513114263620090)
,p_plug_name=>'tela.papel-atribuido.l'
,p_parent_plug_id=>wwv_flow_imp.id(271987688118472955)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>70
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select     ',
'       A.ID,',
'       A.ID_USUARIO,',
'       A.ID_PAPEL_USUARIO,',
'       B.NOME_PAPEL AS PAPEL,',
'       C.RAZAO_SOCIAL AS RAZAO_SOCIAL',
'  from MPD_USUARIO_PAPEL A',
'  join MPD_PAPEL B',
'  on B.ID = A.ID_PAPEL_USUARIO',
'  join MPD_TENANT C',
'  on C.ID = B.ID_TENANT',
'  where A.ID_USUARIO = :P133_ID'))
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_ajax_items_to_submit=>'P133_ID'
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'text_column', 'PAPEL')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(157513341247620092)
,p_plug_name=>'tela.tenant-autorizado.l'
,p_parent_plug_id=>wwv_flow_imp.id(271987688118472955)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>80
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    b.id,',
'    razao_social,',
'    inscricao_federal,',
'    autenticacao_mfa_ativa,',
'    forma_autenticacao,',
'    numero_licenca_uso,',
'    qtd_maxima_tentativa_login,',
'    situacao_tenant',
'from mpd_tenant a',
'join mpd_usuario_tenant b ',
'on b.id_tenant = a.id',
'where id_usuario = :P133_ID',
''))
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_ajax_items_to_submit=>'P133_ID'
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'text_column', 'RAZAO_SOCIAL')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(157513507066620094)
,p_plug_name=>'tela.funcionalidade-autorizada.l'
,p_parent_plug_id=>wwv_flow_imp.id(271987688118472955)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(341019905956556228)
,p_plug_display_sequence=>100
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(159215168566752846)
,p_plug_name=>unistr('\00C1rvore')
,p_parent_plug_id=>wwv_flow_imp.id(157513507066620094)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from bo_mpd_funcionalidade.select_arvore_funcionalidade(:P133_ID)   ',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_JSTREE'
,p_ajax_items_to_submit=>'P133_ID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'activate_node_link_with', 'D',
  'default_icon_css_class', 'icon-tree-folder',
  'icon_css_class_column', 'ICON',
  'icon_type_css_class', 'a-Icon',
  'node_id_column', 'ID',
  'node_label_column', 'NAME',
  'node_value_column', 'ID',
  'order_siblings_by', 'NAME',
  'parent_key_column', 'PARENT',
  'start_tree_with', 'NULL',
  'tree_hierarchy', 'SQL',
  'tree_tooltip', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(159215297289752847)
,p_plug_name=>'Cards'
,p_parent_plug_id=>wwv_flow_imp.id(157513507066620094)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(341017957619556227)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH split_id_funcionalidade AS (',
'        SELECT t1.ID,',
'               REGEXP_SUBSTR(',
'                   DBMS_LOB.SUBSTR(t1.ID_FUNCIONALIDADE, 4000, 1),',
'                   ''[^:]+'',',
'                   1,',
'                   LEVEL',
'               ) AS id_funcionalidade',
'          FROM MPD_PAPEL t1',
'        CONNECT BY REGEXP_SUBSTR(',
'                      DBMS_LOB.SUBSTR(t1.ID_FUNCIONALIDADE, 4000, 1),',
'                      ''[^:]+'',',
'                      1,',
'                      LEVEL',
'                  ) IS NOT NULL',
'           AND PRIOR t1.ID = t1.ID',
'           AND PRIOR SYS_GUID() IS NOT NULL',
'        )',
'        SELECT a.id as id, ',
'               a.nome_papel as nome_papel,',
'               d.razao_social as razao_social,',
'               pkg_componentes.html_card_colunas(''mpd_funcionalidade.descricao_l'', LISTAGG(b.descricao, '', '') WITHIN GROUP (ORDER BY sfa.id_funcionalidade)) AS ATRIBUTO1',
'          FROM MPD_PAPEL a',
'          left JOIN split_id_funcionalidade sfa ON a.ID = sfa.ID',
'          left JOIN MPD_FUNCIONALIDADE b ON b.id = sfa.id_funcionalidade',
'          left JOIN MPD_USUARIO_PAPEL c ON c.id_papel_usuario = a.id ',
'          left JOIN MPD_TENANT d on d.id = a.id_tenant',
'         where c.id_usuario = :P133_ID',
'         GROUP BY a.id, a.nome_papel, d.razao_social'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P133_ID'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_required_patch=>wwv_flow_imp.id(340973604135556181)
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(159215362582752848)
,p_region_id=>wwv_flow_imp.id(159215297289752847)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>false
,p_title_column_name=>'NOME_PAPEL'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'RAZAO_SOCIAL'
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="row" style="display: flex; flex-wrap: wrap; justify-content: space-between;" >',
'    &ATRIBUTO1!RAW.',
'</div>'))
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
,p_pk2_column_name=>'ID'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(167547584735969136)
,p_plug_name=>'tela.dados-pessoais.l'
,p_parent_plug_id=>wwv_flow_imp.id(271987688118472955)
,p_region_template_options=>'#DEFAULT#:i-h240:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_etapa varchar2(256);',
'Begin   ',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''mpd_usuario.nome'',''fa-user'',:P133_NOME,p_color=>''1'',p_link_foto=>:P133_LINK_FOTO));',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''mpd_usuario.email'',''fa-envelope-o'',:P133_EMAIL,p_color=>''2''));',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''mpd_usuario.telefone'',''fa-phone'',:P133_TELEFONE,p_color=>''3'',p_ultimo=>''s''));',
'End;'))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(159219292293752887)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(157513507066620094)
,p_button_name=>'Retrair'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(341144305939556305)
,p_button_image_alt=>'retrair_l'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-minus-square-o'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(159219342686752888)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(157513507066620094)
,p_button_name=>'Expandir'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(341144305939556305)
,p_button_image_alt=>'expandir_l'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-plus-square-o'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(157512342517620083)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(167547584735969136)
,p_button_name=>'Opcoes_dados_pessoais'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'artefato.109.l'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:9010:&SESSION.::&DEBUG.:9010:P9010_CODIGO_ARTEFATO,P9010_ID:TD152,&P133_ID.'
,p_icon_css_classes=>'fa-edit'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(157512791112620087)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(155419389020698771)
,p_button_name=>unistr('Opcoes_seguran\00E7a')
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'artefato.110.l'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:9010:&SESSION.::&DEBUG.:9010:P9010_CODIGO_ARTEFATO,P9010_ID:TD153,&P133_ID.'
,p_icon_css_classes=>'fa-edit'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(157512941384620088)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(155419471172698772)
,p_button_name=>'Opcoes_preferencias'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'artefato.111.l'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:9010:&SESSION.::&DEBUG.:9010:P9010_CODIGO_ARTEFATO,P9010_ID:TD154,&P133_ID.'
,p_icon_css_classes=>'fa-edit'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(157513038615620089)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(155419594586698773)
,p_button_name=>'Opcoes_privilegios'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'artefato.124.l'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:9010:&SESSION.::&DEBUG.:9010:P9010_CODIGO_ARTEFATO,P9010_ID:TD155,&P133_ID.'
,p_icon_css_classes=>'fa-edit'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(62931381006506156)
,p_name=>'P133_TELA_HELP'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(155417031314698747)
,p_name=>'P133_NOME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(168483854473422626)
,p_item_source_plug_id=>wwv_flow_imp.id(168483854473422626)
,p_source=>'NOME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(155417302497698750)
,p_name=>'P133_EMAIL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(168483854473422626)
,p_item_source_plug_id=>wwv_flow_imp.id(168483854473422626)
,p_source=>'EMAIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(155417429447698751)
,p_name=>'P133_TELEFONE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(168483854473422626)
,p_item_source_plug_id=>wwv_flow_imp.id(168483854473422626)
,p_source=>'TELEFONE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(155417484675698752)
,p_name=>'P133_LOGIN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(168483854473422626)
,p_item_source_plug_id=>wwv_flow_imp.id(168483854473422626)
,p_source=>'LOGIN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(155417714879698754)
,p_name=>'P133_SITUACAO_CADASTRAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(168483854473422626)
,p_item_source_plug_id=>wwv_flow_imp.id(168483854473422626)
,p_source=>'SITUACAO_CADASTRAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(155417775471698755)
,p_name=>'P133_SITUACAO_OPERACIONAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(168483854473422626)
,p_item_source_plug_id=>wwv_flow_imp.id(168483854473422626)
,p_source=>'SITUACAO_OPERACIONAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(155417945805698757)
,p_name=>'P133_FUSO_HORARIO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(168483854473422626)
,p_item_source_plug_id=>wwv_flow_imp.id(168483854473422626)
,p_source=>'FUSO_HORARIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(155418853024698766)
,p_name=>'P133_USUARIO_EH_ADMINISTRADOR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(168483854473422626)
,p_item_source_plug_id=>wwv_flow_imp.id(168483854473422626)
,p_source=>'USUARIO_EH_ADMINISTRADOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(155418999451698767)
,p_name=>'P133_USUARIO_EH_MASTER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(168483854473422626)
,p_item_source_plug_id=>wwv_flow_imp.id(168483854473422626)
,p_source=>'USUARIO_EH_MASTER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(155564574416971451)
,p_name=>'P133_FOTO'
,p_source_data_type=>'BLOB'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(168483854473422626)
,p_item_source_plug_id=>wwv_flow_imp.id(168483854473422626)
,p_source=>'FOTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_tag_css_classes=>'foto-perfil-usuario'
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'DB_COLUMN',
  'filename_column', 'FOTO_NAME',
  'mime_type_column', 'FOTO_MIMETYPE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(155564726253971452)
,p_name=>'P133_FOTO_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(168483854473422626)
,p_item_source_plug_id=>wwv_flow_imp.id(168483854473422626)
,p_source=>'FOTO_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(155564785285971453)
,p_name=>'P133_FOTO_MIMETYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(168483854473422626)
,p_item_source_plug_id=>wwv_flow_imp.id(168483854473422626)
,p_source=>'FOTO_MIMETYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(155564852723971454)
,p_name=>'P133_FOTO_CHARSET'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(168483854473422626)
,p_item_source_plug_id=>wwv_flow_imp.id(168483854473422626)
,p_source=>'FOTO_CHARSET'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(155565142930971457)
,p_name=>'P133_LINK_FOTO'
,p_item_sequence=>10
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_foto blob;',
'begin',
'    select foto into v_foto from mpd_usuario where id = :P133_ID;',
'    if v_foto is null then',
'        return ''n'';',
'    else',
'        return ''f?p=&APP_ID.:0:&APP_SESSION.:APPLICATION_PROCESS=GET_IMAGE_USER:::IMAGE_USER_ID:''||:P133_LOGIN;',
'    end if;',
'end;'))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(160403063098960070)
,p_name=>'P133_VISUALIZAR'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(160403203509960071)
,p_name=>'P133_CODIGO_ARTEFATO'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(160403256798960072)
,p_name=>'P133_TELA_TITULO'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(168485853618422642)
,p_name=>'P133_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(168483854473422626)
,p_item_source_plug_id=>wwv_flow_imp.id(168483854473422626)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(155710547527109968)
,p_name=>'onPageLoad'
,p_event_sequence=>70
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(155710709798109969)
,p_event_id=>wwv_flow_imp.id(155710547527109968)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_TREE_EXPAND'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(159215168566752846)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(159219470826752889)
,p_name=>'onClickRetrair'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(159219292293752887)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(159219620837752890)
,p_event_id=>wwv_flow_imp.id(159219470826752889)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_COLLAPSE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(159215168566752846)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(159219675248752891)
,p_event_id=>wwv_flow_imp.id(159219470826752889)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(159219292293752887)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(159219785087752892)
,p_event_id=>wwv_flow_imp.id(159219470826752889)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(159219342686752888)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(159219846969752893)
,p_name=>'onClickExpandir'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(159219342686752888)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(159220017037752894)
,p_event_id=>wwv_flow_imp.id(159219846969752893)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_EXPAND'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(159215168566752846)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(159220052377752895)
,p_event_id=>wwv_flow_imp.id(159219846969752893)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(159219342686752888)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(160400703619960046)
,p_event_id=>wwv_flow_imp.id(159219846969752893)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(159219292293752887)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(62931508396506157)
,p_name=>'onMouseEnter'
,p_event_sequence=>110
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'$("#icon_info")'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'mouseenter'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(62931583100506158)
,p_event_id=>wwv_flow_imp.id(62931508396506157)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'PLUGIN_COM.FOS.TOOLTIP'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'$("#icon_info")'
,p_attribute_01=>'static'
,p_attribute_05=>'&P133_TELA_HELP.'
,p_attribute_08=>'#007BFE'
,p_attribute_09=>'#FFFFFF'
,p_attribute_10=>'scale'
,p_attribute_11=>'500'
,p_attribute_12=>'hover'
,p_attribute_13=>'top'
,p_attribute_14=>'cache-result,escape-html'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(896163294325842)
,p_name=>'onOpcoes_privilegios'
,p_event_sequence=>120
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(157513038615620089)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(896293764325843)
,p_event_id=>wwv_flow_imp.id(896163294325842)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'location.reload();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(896529679325846)
,p_name=>'New'
,p_event_sequence=>130
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(157512791112620087)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(896715751325847)
,p_event_id=>wwv_flow_imp.id(896529679325846)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'location.reload();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(896762711325848)
,p_name=>'New_1'
,p_event_sequence=>140
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(157512342517620083)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(896860267325849)
,p_event_id=>wwv_flow_imp.id(896762711325848)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'location.reload();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(897007025325850)
,p_name=>'New_2'
,p_event_sequence=>150
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(157512941384620088)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(897051182325851)
,p_event_id=>wwv_flow_imp.id(897007025325850)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'location.reload();'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(155496203837128334)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(168483854473422626)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form '
,p_internal_uid=>120117661826030189
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(62930973258506152)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'retorna_titulo_tela'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'RETORNA_TITULO_TELA'
,p_internal_uid=>27552431247408007
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(62931043345506153)
,p_page_process_id=>wwv_flow_imp.id(62930973258506152)
,p_page_id=>133
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'nvl(:P133_CODIGO_ARTEFATO,:app_page_id)'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(62931156239506154)
,p_page_process_id=>wwv_flow_imp.id(62930973258506152)
,p_page_id=>133
,p_name=>'p_titulo'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P133_TELA_TITULO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(62931243836506155)
,p_page_process_id=>wwv_flow_imp.id(62930973258506152)
,p_page_id=>133
,p_name=>'p_help'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P133_TELA_HELP'
);
wwv_flow_imp.component_end;
end;
/
