prompt --application/pages/page_00133
begin
--   Manifest
--     PAGE: 00133
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_page.create_page(
 p_id=>133
,p_name=>unistr('Usu\00E1rio - Mais detalhes do usu\00E1rio')
,p_alias=>unistr('USU\00C1RIO-MAIS-DETALHES-DO-USU\00C1RIO')
,p_step_title=>unistr('Usu\00E1rio - Mais detalhes do usu\00E1rio')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Body-side{',
'    width: auto;',
'    box-shadow: none;',
'    max-width: 450px;',
'}',
'',
'.t-Region-title{',
'    padding-left: 16px;',
'}',
'',
'.st-card-title {',
'    font-weight: bold;',
'    font-size: larger;',
'    padding: 16px;',
'}',
'',
'.overflow_line {',
'    white-space: normal;',
'    overflow: hidden;',
'    word-wrap: break-word;',
'    hyphens: auto;',
'}'))
,p_step_template=>wwv_flow_imp.id(489120808247697591)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(316619432147564009)
,p_plug_name=>'form'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(489179976861697624)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_04'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.id,',
'       a.nome,',
'       email,',
'       telefone,',
'       login,',
'       pkg_util.dominio_retorna_tag(''mpd_usuario'',''situacao_cadastral'',situacao_cadastral) as situacao_cadastral,',
'       pkg_util.dominio_retorna_tag(''mpd_usuario'',''situacao_operacional'',situacao_operacional) as situacao_operacional,',
'       --b.nome as id_idioma,',
'       fuso_horario,',
'       pkg_util.dominio_retorna_tag(''mpd_usuario'',''usuario_eh_administrador'',usuario_eh_administrador) as usuario_eh_administrador,',
'       pkg_util.dominio_retorna_tag(''mpd_usuario'',''usuario_eh_administrador'',usuario_eh_master) as usuario_eh_master,',
'       foto,',
'       foto_name,',
'       foto_mimetype,',
'       foto_charset       ',
'from mpd_usuario a',
'left join srv_idioma b',
'on b.id = a.id_idioma',
'where a.id = :P133_ID',
'/*select id,',
'       nome_entidade,',
'       descricao_entidade,',
'       pkg_util.dominio_retorna_tag(''srv_entidade'',''compartilhamento'',compartilhamento) as compartilhamento,',
'       pkg_util.dominio_retorna_tag(''srv_entidade'',''carga_inicial'',carga_inicial) as carga_inicial,',
'       pkg_util.dominio_retorna_tag(''srv_entidade'',''atualizacao'',atualizacao) as atualizacao',
'from srv_entidade*/'))
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_ajax_items_to_submit=>'P133_ID'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(420123265792614338)
,p_plug_name=>'Painel esquerdo'
,p_region_css_classes=>'a-CardView'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(303554966694840154)
,p_plug_name=>'tela.seguranca.l'
,p_parent_plug_id=>wwv_flow_imp.id(420123265792614338)
,p_region_template_options=>'#DEFAULT#:i-h240:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_etapa varchar2(256);',
'Begin       ',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''MPD_USUARIO.LOGIN'',''fa-sign-in'',:P133_LOGIN,p_color=>''1''));',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''MPD_USUARIO.SITUACAO_CADASTRAL'',''fa-list-ul'',:P133_SITUACAO_CADASTRAL,p_color=>''2''));',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''MPD_USUARIO.SITUACAO_OPERACIONAL'',''fa-briefcase'',:P133_SITUACAO_OPERACIONAL,p_color=>''3'',p_ultimo=>''s''));    ',
'End;'))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(303555048846840155)
,p_plug_name=>'tela.preferencia.l'
,p_parent_plug_id=>wwv_flow_imp.id(420123265792614338)
,p_region_template_options=>'#DEFAULT#:i-h240:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_etapa varchar2(256);',
'Begin   ',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''SRV_IDIOMA.NOME'',''fa-globe'',:P133_ID_IDIOMA,p_color=>''1''));',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''MPD_USUARIO.FUSO_HORARIO'',''fa-clock-o'',:P133_FUSO_HORARIO,p_color=>''2'',p_ultimo=>''s''));',
'End;'))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(303555172260840156)
,p_plug_name=>'tela.privilegio.l'
,p_parent_plug_id=>wwv_flow_imp.id(420123265792614338)
,p_region_template_options=>'#DEFAULT#:i-h240:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_etapa varchar2(256);',
'Begin       ',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''MPD_USUARIO.USUARIO_EH_ADMINISTRADOR'',''fa-user-wrench'',:P133_USUARIO_EH_ADMINISTRADOR,p_color=>''1''));',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''MPD_USUARIO.USUARIO_EH_MASTER'',''fa-user-chart'',:P133_USUARIO_EH_MASTER,p_color=>''2'',p_ultimo=>''s''));    ',
'End;'))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(305648691937761473)
,p_plug_name=>'tela.papel-atribuido.l'
,p_parent_plug_id=>wwv_flow_imp.id(420123265792614338)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>70
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select     ',
'       A.ID,',
'       A.ID_USUARIO,',
'       A.ID_PAPEL_USUARIO,',
'       B.NOME_PAPEL AS PAPEL,',
'       C.RAZAO_SOCIAL AS RAZAO_SOCIAL',
'  from MPD_USUARIO_PAPEL A',
'  join MPD_PAPEL B',
'  on B.ID = A.ID_PAPEL_USUARIO',
'  join MPD_TENANT C',
'  on C.ID = B.ID_TENANT',
'  where A.ID_USUARIO = :P133_ID'))
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_ajax_items_to_submit=>'P133_ID'
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'text_column', 'PAPEL')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(305648918921761475)
,p_plug_name=>'tela.tenant-autorizado.l'
,p_parent_plug_id=>wwv_flow_imp.id(420123265792614338)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>80
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    b.id,',
'    razao_social,',
'    inscricao_federal,',
'    autenticacao_mfa_ativa,',
'    forma_autenticacao,',
'    numero_licenca_uso,',
'    qtd_maxima_tentativa_login,',
'    situacao_tenant',
'from mpd_tenant a',
'join mpd_usuario_tenant b ',
'on b.id_tenant = a.id',
'where id_usuario = :P133_ID',
''))
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_ajax_items_to_submit=>'P133_ID'
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'text_column', 'RAZAO_SOCIAL')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(305649084740761477)
,p_plug_name=>'tela.funcionalidade-autorizada.l'
,p_parent_plug_id=>wwv_flow_imp.id(420123265792614338)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(489155483630697611)
,p_plug_display_sequence=>100
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(307350746240894229)
,p_plug_name=>unistr('\00C1rvore')
,p_parent_plug_id=>wwv_flow_imp.id(305649084740761477)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from bo_mpd_funcionalidade.select_arvore_funcionalidade(:P133_ID)   ',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_JSTREE'
,p_ajax_items_to_submit=>'P133_ID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'activate_node_link_with', 'D',
  'default_icon_css_class', 'icon-tree-folder',
  'icon_css_class_column', 'ICON',
  'icon_type_css_class', 'a-Icon',
  'node_id_column', 'ID',
  'node_label_column', 'NAME',
  'node_value_column', 'ID',
  'order_siblings_by', 'NAME',
  'parent_key_column', 'PARENT',
  'start_tree_with', 'NULL',
  'tree_hierarchy', 'SQL',
  'tree_tooltip', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(307350874963894230)
,p_plug_name=>'Cards'
,p_parent_plug_id=>wwv_flow_imp.id(305649084740761477)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(489153535293697610)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH split_id_funcionalidade AS (',
'        SELECT t1.ID,',
'               REGEXP_SUBSTR(',
'                   DBMS_LOB.SUBSTR(t1.ID_FUNCIONALIDADE, 4000, 1),',
'                   ''[^:]+'',',
'                   1,',
'                   LEVEL',
'               ) AS id_funcionalidade',
'          FROM MPD_PAPEL t1',
'        CONNECT BY REGEXP_SUBSTR(',
'                      DBMS_LOB.SUBSTR(t1.ID_FUNCIONALIDADE, 4000, 1),',
'                      ''[^:]+'',',
'                      1,',
'                      LEVEL',
'                  ) IS NOT NULL',
'           AND PRIOR t1.ID = t1.ID',
'           AND PRIOR SYS_GUID() IS NOT NULL',
'        )',
'        SELECT a.id as id, ',
'               a.nome_papel as nome_papel,',
'               d.razao_social as razao_social,',
'               pkg_componentes.html_card_colunas(''mpd_funcionalidade.descricao_l'', LISTAGG(b.descricao, '', '') WITHIN GROUP (ORDER BY sfa.id_funcionalidade)) AS ATRIBUTO1',
'          FROM MPD_PAPEL a',
'          left JOIN split_id_funcionalidade sfa ON a.ID = sfa.ID',
'          left JOIN MPD_FUNCIONALIDADE b ON b.id = sfa.id_funcionalidade',
'          left JOIN MPD_USUARIO_PAPEL c ON c.id_papel_usuario = a.id ',
'          left JOIN MPD_TENANT d on d.id = a.id_tenant',
'         where c.id_usuario = :P133_ID',
'         GROUP BY a.id, a.nome_papel, d.razao_social'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P133_ID'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_required_patch=>wwv_flow_imp.id(489109181809697564)
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(307350940256894231)
,p_region_id=>wwv_flow_imp.id(307350874963894230)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>false
,p_title_column_name=>'NOME_PAPEL'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'RAZAO_SOCIAL'
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="row" style="display: flex; flex-wrap: wrap; justify-content: space-between;" >',
'    &ATRIBUTO1!RAW.',
'</div>'))
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
,p_pk2_column_name=>'ID'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(315683162410110519)
,p_plug_name=>'tela.dados-pessoais.l'
,p_parent_plug_id=>wwv_flow_imp.id(420123265792614338)
,p_region_template_options=>'#DEFAULT#:i-h240:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_etapa varchar2(256);',
'Begin   ',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''mpd_usuario.nome'',''fa-user'',:P133_NOME,p_color=>''1'',p_link_foto=>:P133_LINK_FOTO));',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''mpd_usuario.email'',''fa-envelope-o'',:P133_EMAIL,p_color=>''2''));',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''mpd_usuario.telefone'',''fa-phone'',:P133_TELEFONE,p_color=>''3'',p_ultimo=>''s''));',
'End;'))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(307354869967894270)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(305649084740761477)
,p_button_name=>'Retrair'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(489279883613697688)
,p_button_image_alt=>'retrair_l'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-minus-square-o'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(307354920360894271)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(305649084740761477)
,p_button_name=>'Expandir'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(489279883613697688)
,p_button_image_alt=>'expandir_l'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-plus-square-o'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(305647920191761466)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(315683162410110519)
,p_button_name=>'Opcoes_dados_pessoais'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(489278989412697687)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'artefato.109.l'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:9010:&SESSION.::&DEBUG.:9010:P9010_CODIGO_ARTEFATO,P9010_ID:TD152,&P133_ID.'
,p_icon_css_classes=>'fa-edit'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(305648368786761470)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(303554966694840154)
,p_button_name=>unistr('Opcoes_seguran\00E7a')
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(489278989412697687)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'artefato.110.l'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:9010:&SESSION.::&DEBUG.:9010:P9010_CODIGO_ARTEFATO,P9010_ID:TD153,&P133_ID.'
,p_icon_css_classes=>'fa-edit'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(305648519058761471)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(303555048846840155)
,p_button_name=>'Opcoes_preferencias'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(489278989412697687)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'artefato.111.l'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:9010:&SESSION.::&DEBUG.:9010:P9010_CODIGO_ARTEFATO,P9010_ID:TD154,&P133_ID.'
,p_icon_css_classes=>'fa-edit'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(305648616289761472)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(303555172260840156)
,p_button_name=>'Opcoes_privilegios'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(489278989412697687)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'artefato.124.l'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:9010:&SESSION.::&DEBUG.:9010:P9010_CODIGO_ARTEFATO,P9010_ID:TD155,&P133_ID.'
,p_icon_css_classes=>'fa-edit'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(211066958680647539)
,p_name=>'P133_TELA_HELP'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303552608988840130)
,p_name=>'P133_NOME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(316619432147564009)
,p_item_source_plug_id=>wwv_flow_imp.id(316619432147564009)
,p_source=>'NOME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303552880171840133)
,p_name=>'P133_EMAIL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(316619432147564009)
,p_item_source_plug_id=>wwv_flow_imp.id(316619432147564009)
,p_source=>'EMAIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303553007121840134)
,p_name=>'P133_TELEFONE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(316619432147564009)
,p_item_source_plug_id=>wwv_flow_imp.id(316619432147564009)
,p_source=>'TELEFONE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303553062349840135)
,p_name=>'P133_LOGIN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(316619432147564009)
,p_item_source_plug_id=>wwv_flow_imp.id(316619432147564009)
,p_source=>'LOGIN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303553292553840137)
,p_name=>'P133_SITUACAO_CADASTRAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(316619432147564009)
,p_item_source_plug_id=>wwv_flow_imp.id(316619432147564009)
,p_source=>'SITUACAO_CADASTRAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303553353145840138)
,p_name=>'P133_SITUACAO_OPERACIONAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(316619432147564009)
,p_item_source_plug_id=>wwv_flow_imp.id(316619432147564009)
,p_source=>'SITUACAO_OPERACIONAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303553523479840140)
,p_name=>'P133_FUSO_HORARIO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(316619432147564009)
,p_item_source_plug_id=>wwv_flow_imp.id(316619432147564009)
,p_source=>'FUSO_HORARIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303554430698840149)
,p_name=>'P133_USUARIO_EH_ADMINISTRADOR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(316619432147564009)
,p_item_source_plug_id=>wwv_flow_imp.id(316619432147564009)
,p_source=>'USUARIO_EH_ADMINISTRADOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303554577125840150)
,p_name=>'P133_USUARIO_EH_MASTER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(316619432147564009)
,p_item_source_plug_id=>wwv_flow_imp.id(316619432147564009)
,p_source=>'USUARIO_EH_MASTER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303700152091112834)
,p_name=>'P133_FOTO'
,p_source_data_type=>'BLOB'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(316619432147564009)
,p_item_source_plug_id=>wwv_flow_imp.id(316619432147564009)
,p_source=>'FOTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_tag_css_classes=>'foto-perfil-usuario'
,p_field_template=>wwv_flow_imp.id(489277194088697685)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'DB_COLUMN',
  'filename_column', 'FOTO_NAME',
  'mime_type_column', 'FOTO_MIMETYPE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303700303928112835)
,p_name=>'P133_FOTO_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(316619432147564009)
,p_item_source_plug_id=>wwv_flow_imp.id(316619432147564009)
,p_source=>'FOTO_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303700362960112836)
,p_name=>'P133_FOTO_MIMETYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(316619432147564009)
,p_item_source_plug_id=>wwv_flow_imp.id(316619432147564009)
,p_source=>'FOTO_MIMETYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303700430398112837)
,p_name=>'P133_FOTO_CHARSET'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(316619432147564009)
,p_item_source_plug_id=>wwv_flow_imp.id(316619432147564009)
,p_source=>'FOTO_CHARSET'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303700720605112840)
,p_name=>'P133_LINK_FOTO'
,p_item_sequence=>10
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_foto blob;',
'begin',
'    select foto into v_foto from mpd_usuario where id = :P133_ID;',
'    if v_foto is null then',
'        return ''n'';',
'    else',
'        return ''f?p=&APP_ID.:0:&APP_SESSION.:APPLICATION_PROCESS=GET_IMAGE_USER:::IMAGE_USER_ID:''||:P133_LOGIN;',
'    end if;',
'end;'))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(308538640773101453)
,p_name=>'P133_VISUALIZAR'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(308538781184101454)
,p_name=>'P133_CODIGO_ARTEFATO'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(308538834473101455)
,p_name=>'P133_TELA_TITULO'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(316621431292564025)
,p_name=>'P133_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(316619432147564009)
,p_item_source_plug_id=>wwv_flow_imp.id(316619432147564009)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(303846125201251351)
,p_name=>'onPageLoad'
,p_event_sequence=>70
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(303846287472251352)
,p_event_id=>wwv_flow_imp.id(303846125201251351)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_TREE_EXPAND'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(307350746240894229)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(307355048500894272)
,p_name=>'onClickRetrair'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(307354869967894270)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(307355198511894273)
,p_event_id=>wwv_flow_imp.id(307355048500894272)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_COLLAPSE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(307350746240894229)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(307355252922894274)
,p_event_id=>wwv_flow_imp.id(307355048500894272)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(307354869967894270)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(307355362761894275)
,p_event_id=>wwv_flow_imp.id(307355048500894272)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(307354920360894271)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(307355424643894276)
,p_name=>'onClickExpandir'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(307354920360894271)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(307355594711894277)
,p_event_id=>wwv_flow_imp.id(307355424643894276)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_EXPAND'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(307350746240894229)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(307355630051894278)
,p_event_id=>wwv_flow_imp.id(307355424643894276)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(307354920360894271)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(308536281294101429)
,p_event_id=>wwv_flow_imp.id(307355424643894276)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(307354869967894270)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(211067086070647540)
,p_name=>'onMouseEnter'
,p_event_sequence=>110
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'$("#icon_info")'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'mouseenter'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(211067160774647541)
,p_event_id=>wwv_flow_imp.id(211067086070647540)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'PLUGIN_COM.FOS.TOOLTIP'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'$("#icon_info")'
,p_attribute_01=>'static'
,p_attribute_05=>'&P133_TELA_HELP.'
,p_attribute_08=>'#007BFE'
,p_attribute_09=>'#FFFFFF'
,p_attribute_10=>'scale'
,p_attribute_11=>'500'
,p_attribute_12=>'hover'
,p_attribute_13=>'top'
,p_attribute_14=>'cache-result,escape-html'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(149031740968467225)
,p_name=>'onOpcoes_privilegios'
,p_event_sequence=>120
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(305648616289761472)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(149031871438467226)
,p_event_id=>wwv_flow_imp.id(149031740968467225)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'location.reload();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(149032107353467229)
,p_name=>'New'
,p_event_sequence=>130
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(305648368786761470)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(149032293425467230)
,p_event_id=>wwv_flow_imp.id(149032107353467229)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'location.reload();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(149032340385467231)
,p_name=>'New_1'
,p_event_sequence=>140
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(305647920191761466)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(149032437941467232)
,p_event_id=>wwv_flow_imp.id(149032340385467231)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'location.reload();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(149032584699467233)
,p_name=>'New_2'
,p_event_sequence=>150
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(305648519058761471)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(149032628856467234)
,p_event_id=>wwv_flow_imp.id(149032584699467233)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'location.reload();'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(303631781511269717)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(316619432147564009)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form '
,p_internal_uid=>120117661826030189
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(211066550932647535)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'retorna_titulo_tela'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'RETORNA_TITULO_TELA'
,p_internal_uid=>27552431247408007
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(211066621019647536)
,p_page_process_id=>wwv_flow_imp.id(211066550932647535)
,p_page_id=>133
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'nvl(:P133_CODIGO_ARTEFATO,:app_page_id)'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(211066733913647537)
,p_page_process_id=>wwv_flow_imp.id(211066550932647535)
,p_page_id=>133
,p_name=>'p_titulo'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P133_TELA_TITULO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(211066821510647538)
,p_page_process_id=>wwv_flow_imp.id(211066550932647535)
,p_page_id=>133
,p_name=>'p_help'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P133_TELA_HELP'
);
wwv_flow_imp.component_end;
end;
/
