prompt --application/pages/page_09006
begin
--   Manifest
--     PAGE: 09006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>9006
,p_name=>'Template - Cards simples'
,p_alias=>'TEMPLATE-CARDS-SIMPLES'
,p_step_title=>'Template - Cards simples'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
' $(''.ui-dialog-title'').append($(''#BTN_DESFIXAR''));',
'',
'document.addEventListener("DOMContentLoaded", function () {',
'    setTimeout(function () {',
'        var reportTable = document.querySelector("table.a-IRR-table"); // Localiza a tabela do IR',
'        if (reportTable) {',
'            var rows = reportTable.querySelectorAll("tr");',
'            ',
'            rows.forEach(function (row) {',
'                var cells = row.children;',
'                if (cells.length > 2) { ',
unistr('                    row.insertBefore(cells[2], cells[0]); // Move a terceira coluna para a primeira posi\00E7\00E3o'),
'                }',
'            });',
'        }',
'        console.log(''UHLLL'');',
unistr('    }, 1000); // Aguarda o carregamento do relat\00F3rio'),
'});',
'',
unistr('//Esconder o rodape do CARD caso n\00E3o exista bot\00F5es de a\00E7\00E3o dentro'),
'document.querySelectorAll(".a-CardView").forEach(function(card) {',
'  const actions = card.querySelector(".a-CardView-actions");',
'  if (actions && actions.children.length === 0) {',
'    actions.style.display = "none";',
'  }',
'});'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* .a-IRR-button--actions{',
'    display: none;',
'} */',
'',
'.container-card {',
'    display: flex;',
'    justify-content: space-between;',
'    align-items: center;',
'}',
'',
'.left-element {',
'    flex-grow: 1;',
'}',
'',
'.right-element {',
unistr('    margin-left: 20px; /* Espa\00E7amento entre os elementos */'),
'    white-space: nowrap; /* Impede quebra de linha no segundo elemento */',
'}',
'',
'.ocultar{',
'    display: none;',
'}',
'',
'.a-CardView-opcao {',
'    grid-area: icon-end;',
'    padding-left: 15px;',
'    order: 4;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(225546868302211669)
,p_protection_level=>'C'
,p_page_component_map=>'22'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(136503986248583528)
,p_plug_name=>'Colunas'
,p_title=>'Colunas'
,p_region_name=>'COLUNAS'
,p_region_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--md'
,p_plug_template=>wwv_flow_imp.id(341039558490556238)
,p_plug_display_sequence=>180
,p_plug_display_point=>'REGION_POSITION_04'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(395059421357333524)
,p_plug_name=>'Header'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding'
,p_plug_template=>wwv_flow_imp.id(341013639389556225)
,p_plug_display_sequence=>20
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD367'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_cabecalho(:param1); END;''',
'        USING OUT l_sql, IN nvl(:P9006_PARAMETRO, 0);',
'',
'    return l_sql;        ',
'end;',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P9006_PARAMETRO'
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD367'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_cabecalho(:param1); END;''',
'        USING OUT l_sql, IN nvl(:P9006_PARAMETRO, 0);',
'        return true;',
'    exception',
'        when others then',
'            return false;',
'',
'end;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(435688233130590768)
,p_plug_name=>'Filtrar por Esquerda'
,p_title=>'&P0_LABEL_FILTRAR.'
,p_region_name=>'PAINEL_LEFT'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_02'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(385386461896522741)
,p_plug_name=>'Arvore'
,p_parent_plug_id=>wwv_flow_imp.id(435688233130590768)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody:margin-top-sm:margin-left-sm:margin-right-sm'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD150'');',
'begin',
'    begin',
'        EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_tree(:param1); END;''',
'        USING OUT l_sql, IN :P9006_PARAMETRO;',
'',
'        exception',
'            when others then',
'                return ''select null id, null titulo, null chave_pai from dual'';',
'    end;',
'    return l_sql;       ',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_JSTREE'
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD150'');',
'begin',
'    begin',
'        EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_tree(:param1); END;''',
'        USING OUT l_sql, IN :P9006_PARAMETRO;',
'',
'        exception',
'            when others then',
'                return false;',
'    end;',
'    return true;       ',
'end;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'activate_node_link_with', 'S',
  'default_icon_css_class', 'icon-tree-folder',
  'icon_type_css_class', 'a-Icon',
  'node_id_column', 'ID',
  'node_label_column', 'TITULO',
  'parent_key_column', 'CHAVE_PAI',
  'start_tree_with', 'NULL',
  'tree_hierarchy', 'SQL',
  'tree_tooltip', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(437760514369897168)
,p_plug_name=>'PesquisaCard'
,p_region_name=>'PESQUISA'
,p_parent_plug_id=>wwv_flow_imp.id(435688233130590768)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(487411440845978113)
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P9006_CARD_OU_LISTA'
,p_plug_display_when_cond2=>'CAR'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'batch_facet_search', 'N',
  'compact_numbers_threshold', '10000',
  'display_chart_for_top_n_values', '10',
  'show_charts', 'Y',
  'show_current_facets', 'N',
  'show_total_row_count', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(450697986669332966)
,p_plug_name=>'Pesquisa Lista'
,p_region_name=>'PESQUISA_LISTA'
,p_parent_plug_id=>wwv_flow_imp.id(435688233130590768)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(449372161480329917)
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P9006_CARD_OU_LISTA'
,p_plug_display_when_cond2=>'GRI'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'batch_facet_search', 'N',
  'compact_numbers_threshold', '10000',
  'display_chart_for_top_n_values', '10',
  'show_charts', 'Y',
  'show_current_facets', 'N',
  'show_total_row_count', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(435689158105590777)
,p_plug_name=>'Filtrar por Modal'
,p_title=>'&P0_LABEL_FILTRAR.'
,p_region_name=>'PAINEL_MODAL'
,p_region_template_options=>'#DEFAULT#:t-DialogRegion--noPadding:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--md'
,p_plug_template=>wwv_flow_imp.id(341039558490556238)
,p_plug_display_sequence=>120
,p_plug_display_point=>'REGION_POSITION_04'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(449372161480329917)
,p_name=>'Lista Oculta'
,p_region_name=>'LISTA_CR'
,p_template=>wwv_flow_imp.id(341010888912556224)
,p_display_sequence=>160
,p_region_css_classes=>'ocultar'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD778'');',
'begin',
'    if :P9006_CARD_OU_LISTA = ''GRI'' then',
'        EXECUTE IMMEDIATE',
'            ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_lista_oculta(:param1); END;''',
'            USING OUT l_sql, IN :P9006_PARAMETRO;',
'    else',
'        l_sql := q''~',
'            select ',
'                null              id,',
'                null              campo1,             ',
'                null              campo2,             ',
'                null              campo3,             ',
'                null              campo4,             ',
'                null              campo5,             ',
'                null              campo6,             ',
'                null              campo7,             ',
'                null              campo8,                                      ',
'                null              campo9,      ',
'                null              campo10,                                ',
'                null              filtro1,',
'                null              filtro2,',
'                null              filtro3,',
'                null              filtro4,',
'                null              filtro5,',
'                null              filtro_mult1,',
'                null              filtro_mult2,',
'                null              filtro_mult3,',
'                null              filtro_mult4,',
'                null              filtro_mult5,',
'                pkg_componentes.icone_opcao opcao',
'            from dual    ',
'        ~'';',
'    end if;',
'',
'    return l_sql;       ',
'end;'))
,p_display_when_condition=>'P9006_CARD_OU_LISTA'
,p_display_when_cond2=>'GRI'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P9006_PARAMETRO,P9006_CARD_OU_LISTA'
,p_lazy_loading=>true
,p_query_row_template=>wwv_flow_imp.id(341097593039556273)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47201513227920619)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'Id'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47201909320920620)
,p_query_column_id=>2
,p_column_alias=>'CAMPO1'
,p_column_display_sequence=>20
,p_column_heading=>'Campo1'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47202246611920622)
,p_query_column_id=>3
,p_column_alias=>'CAMPO2'
,p_column_display_sequence=>30
,p_column_heading=>'Campo2'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47202706081920623)
,p_query_column_id=>4
,p_column_alias=>'CAMPO3'
,p_column_display_sequence=>40
,p_column_heading=>'Campo3'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47203113903920625)
,p_query_column_id=>5
,p_column_alias=>'CAMPO4'
,p_column_display_sequence=>50
,p_column_heading=>'Campo4'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47203501798920626)
,p_query_column_id=>6
,p_column_alias=>'CAMPO5'
,p_column_display_sequence=>60
,p_column_heading=>'Campo5'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47203909323920628)
,p_query_column_id=>7
,p_column_alias=>'CAMPO6'
,p_column_display_sequence=>70
,p_column_heading=>'Campo6'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47204307318920630)
,p_query_column_id=>8
,p_column_alias=>'CAMPO7'
,p_column_display_sequence=>80
,p_column_heading=>'Campo7'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47204666662920631)
,p_query_column_id=>9
,p_column_alias=>'CAMPO8'
,p_column_display_sequence=>90
,p_column_heading=>'Campo8'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47205091005920633)
,p_query_column_id=>10
,p_column_alias=>'CAMPO9'
,p_column_display_sequence=>100
,p_column_heading=>'Campo9'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47205512979920634)
,p_query_column_id=>11
,p_column_alias=>'CAMPO10'
,p_column_display_sequence=>110
,p_column_heading=>'Campo10'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47197430877920603)
,p_query_column_id=>12
,p_column_alias=>'FILTRO1'
,p_column_display_sequence=>130
,p_column_heading=>'Filtro1'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47197896581920605)
,p_query_column_id=>13
,p_column_alias=>'FILTRO2'
,p_column_display_sequence=>140
,p_column_heading=>'Filtro2'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47198260919920606)
,p_query_column_id=>14
,p_column_alias=>'FILTRO3'
,p_column_display_sequence=>150
,p_column_heading=>'Filtro3'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47199503718920611)
,p_query_column_id=>15
,p_column_alias=>'FILTRO4'
,p_column_display_sequence=>180
,p_column_heading=>'Filtro4'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47199853639920613)
,p_query_column_id=>16
,p_column_alias=>'FILTRO5'
,p_column_display_sequence=>190
,p_column_heading=>'Filtro5'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47198684403920608)
,p_query_column_id=>17
,p_column_alias=>'FILTRO_MULT1'
,p_column_display_sequence=>200
,p_column_heading=>'Filtro Mult1'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47199126467920610)
,p_query_column_id=>18
,p_column_alias=>'FILTRO_MULT2'
,p_column_display_sequence=>210
,p_column_heading=>'Filtro Mult2'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47200291334920614)
,p_query_column_id=>19
,p_column_alias=>'FILTRO_MULT3'
,p_column_display_sequence=>220
,p_column_heading=>'Filtro Mult3'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47200650966920616)
,p_query_column_id=>20
,p_column_alias=>'FILTRO_MULT4'
,p_column_display_sequence=>230
,p_column_heading=>'Filtro Mult4'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47201054346920617)
,p_query_column_id=>21
,p_column_alias=>'FILTRO_MULT5'
,p_column_display_sequence=>240
,p_column_heading=>'Filtro Mult5'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(47205920357920635)
,p_query_column_id=>22
,p_column_alias=>'OPCAO'
,p_column_display_sequence=>120
,p_column_heading=>'Opcao'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(449383367943331559)
,p_plug_name=>'Lista'
,p_region_name=>'LISTA'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(341044399187556241)
,p_plug_display_sequence=>170
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD150'');',
'begin',
'    begin',
'        EXECUTE IMMEDIATE ',
'            ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_report; END;''',
'            -- ''BEGIN :l_sql := UI_MPD_100.sql_report; END;''',
'            USING OUT l_sql; ',
'        exception ',
'            when others then',
'                return ''select 1 from dual'';',
'    end;',
'    return l_sql;       ',
'end;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P9006_CARD_OU_LISTA'
,p_plug_display_when_cond2=>'GRI'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(449383462793331560)
,p_max_row_count=>'1000000'
,p_show_search_textbox=>'N'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'NONE'
,p_lazy_loading=>true
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'NTO'
,p_internal_uid=>492254334453973833
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(136502541794583513)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'AE'
,p_column_label=>'Id'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(421740107369990753)
,p_db_column_name=>'CAMPO1'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'&P9006_LABEL_COLUNA1.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_static_id=>'CAMPO1'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P9006_LABEL_COLUNA1 is not null and :P9006_MOSTRA_CAMPO1 = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(421740237000990754)
,p_db_column_name=>'CAMPO2'
,p_display_order=>30
,p_column_identifier=>'U'
,p_column_label=>'&P9006_LABEL_COLUNA2.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_static_id=>'CAMPO2'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P9006_LABEL_COLUNA2 is not null and :P9006_MOSTRA_CAMPO2 = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(421740266786990755)
,p_db_column_name=>'CAMPO3'
,p_display_order=>40
,p_column_identifier=>'V'
,p_column_label=>'&P9006_LABEL_COLUNA3.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_static_id=>'CAMPO3'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P9006_LABEL_COLUNA3 is not null and :P9006_MOSTRA_CAMPO3 = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(421740350312990756)
,p_db_column_name=>'CAMPO4'
,p_display_order=>50
,p_column_identifier=>'W'
,p_column_label=>'&P9006_LABEL_COLUNA4.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_static_id=>'CAMPO4'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P9006_LABEL_COLUNA4 is not null and :P9006_MOSTRA_CAMPO4 = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(421740439505990757)
,p_db_column_name=>'CAMPO5'
,p_display_order=>60
,p_column_identifier=>'X'
,p_column_label=>'&P9006_LABEL_COLUNA5.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_static_id=>'CAMPO5'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P9006_LABEL_COLUNA5 is not null and :P9006_MOSTRA_CAMPO5 = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(421740599678990758)
,p_db_column_name=>'CAMPO6'
,p_display_order=>70
,p_column_identifier=>'Y'
,p_column_label=>'&P9006_LABEL_COLUNA6.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_static_id=>'CAMPO6'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P9006_LABEL_COLUNA6 is not null and :P9006_MOSTRA_CAMPO6 = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(421740663013990759)
,p_db_column_name=>'CAMPO7'
,p_display_order=>80
,p_column_identifier=>'Z'
,p_column_label=>'&P9006_LABEL_COLUNA7.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_static_id=>'CAMPO7'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P9006_LABEL_COLUNA7 is not null and :P9006_MOSTRA_CAMPO7 = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(421740783725990760)
,p_db_column_name=>'CAMPO8'
,p_display_order=>90
,p_column_identifier=>'AA'
,p_column_label=>'&P9006_LABEL_COLUNA8.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_static_id=>'CAMPO8'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P9006_LABEL_COLUNA8 is not null and :P9006_MOSTRA_CAMPO8 = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(421740883401990761)
,p_db_column_name=>'CAMPO9'
,p_display_order=>100
,p_column_identifier=>'AB'
,p_column_label=>'&P9006_LABEL_COLUNA9.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_static_id=>'CAMPO9'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P9006_LABEL_COLUNA9 is not null and :P9006_MOSTRA_CAMPO9 = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(421740970485990762)
,p_db_column_name=>'CAMPO10'
,p_display_order=>110
,p_column_identifier=>'AC'
,p_column_label=>'&P9006_LABEL_COLUNA10.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_static_id=>'CAMPO10'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P9006_LABEL_COLUNA10 is not null and :P9006_MOSTRA_CAMPO10 = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(421741072927990763)
,p_db_column_name=>'OPCAO'
,p_display_order=>120
,p_column_identifier=>'AD'
,p_column_label=>'&P0_LABEL_OPCAO.'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div style="display: flex; align-items: center; justify-content: center; flex-grow: 1;">',
'    <span #OPCAO# style="cursor: pointer; color: var(--a-button-state-text-color, var(--a-button-type-text-color, var(--a-button-text-color, inherit)));" ',
'        class="fa fa-ellipsis-v js-dlg-refresh" title="&P0_LABEL_OPCAO!RAW.">',
'    </span>',
'</div>',
'    '))
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_static_id=>'OPCAO'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(449508853759785014)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'355331'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CAMPO1:CAMPO2:CAMPO3:CAMPO4:CAMPO5:CAMPO6:CAMPO7:CAMPO8:CAMPO9:OPCAO:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(453248850017455353)
,p_plug_name=>unistr('Defini\00E7\00F5es do relat\00F3rio')
,p_region_name=>'ACTION'
,p_region_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--sm'
,p_component_template_options=>'t-MediaList--showIcons:t-MediaList--showDesc:u-colors'
,p_plug_template=>wwv_flow_imp.id(341039558490556238)
,p_plug_display_sequence=>170
,p_plug_display_point=>'REGION_POSITION_04'
,p_location=>null
,p_list_id=>wwv_flow_imp.id(222272585216222758)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(341125559529556289)
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(487411440845978113)
,p_plug_name=>'Card simples'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(341017957619556227)
,p_plug_display_sequence=>30
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD150'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_card(:param1); END;''',
'        USING OUT l_sql, IN :P9006_PARAMETRO;',
'',
'    return l_sql;       ',
'end;',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P9006_CODIGO_ARTEFATO,P9006_PARAMETRO'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>true
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P9006_CARD_OU_LISTA'
,p_plug_display_when_cond2=>'CAR'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(47192281334920576)
,p_region_id=>wwv_flow_imp.id(487411440845978113)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>true
,p_title_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="container-card">',
'    <div class="left-element">',
'        <h3 class="a-CardView-title" title="&LABEL_TITULO!RAW.">&TITULO!RAW.</h3>',
'        <h4 class="a-CardView-subTitle" title="&LABEL_SUBTITULO!RAW.">&SUBTITULO!RAW.</h4>',
'    </div>',
'    <div class="right-element">',
'        <div class="a-CardView-badge &CLASS_DISTINTIVO!RAW." title="&LISTA_DISTINTIVO!RAW.">',
'        <span class="a-CardView-badgeValue" title="&LABEL_DISTINTIVO!RAW.">&DISTINTIVO!RAW.</span>',
'        </div>',
'    </div>',
'    <div class="right-element" style="cursor: pointer;">',
'        <div style="display: flex; align-items: center; justify-content: center; flex-grow: 1;">',
'            <span &OPCAO!RAW. style="cursor: pointer; color: var(--a-button-state-text-color, var(--a-button-type-text-color, var(--a-button-text-color, inherit)));" ',
'                class="fa fa-ellipsis-v js-dlg-refresh" title="&P0_LABEL_OPCAO!RAW.">',
'            </span>',
'        </div>',
'    </div>',
'</div>'))
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="a-CardView-actionsPrimary"> ',
'    <span class="a-CardView-button t-Button--link padding-none">',
'        <span class="a-CardView-buttonLabel" &URL_MAIS_DETALHES!RAW.>&P0_LABEL_MAIS_DETALHES!RAW.</span>',
'    </span>',
'</div>',
''))
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(47178020173920507)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(435689158105590777)
,p_button_name=>'desfixar'
,p_button_static_id=>'BTN_DESFIXAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_FIXAR.'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'u-pullRight'
,p_icon_css_classes=>'fa-thumb-tack'
,p_button_cattributes=>'style="margin-left: auto; "'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(47188137094920558)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(435688233130590768)
,p_button_name=>'fixar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_FIXAR.'
,p_button_position=>'COPY'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-thumb-tack'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(47210400932920666)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(136503986248583528)
,p_button_name=>'Save'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(341144157120556305)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_SALVAR.'
,p_button_position=>'CREATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(5126875648325962)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(17161532936247037)
,p_button_name=>'favNao'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_ADICIONAR_FAV.'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P9006_FAVORITO = 0 and :P9006_PARAMETRO is null'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-star-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4711636741686187)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(17161532936247037)
,p_button_name=>'favSim'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--warning:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_REMOVER_FAV.'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P9006_FAVORITO = 1 and :P9006_PARAMETRO is null'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-star'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(47214351962920686)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(17161532936247037)
,p_button_name=>'VisaoReport'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_VISAO_LISTA.'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P9006_CARD_OU_LISTA'
,p_button_condition2=>'CAR'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-columns'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(47214746185920688)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(17161532936247037)
,p_button_name=>'VisaoCard'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_VISAO_CARD.'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P9006_CARD_OU_LISTA'
,p_button_condition2=>'GRI'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-list-ul'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(47215132387920689)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(17161532936247037)
,p_button_name=>'filter'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_ESCONDER_MOSTRAR_PESQUISA.'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-filter'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15202586233808507)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(17161532936247037)
,p_button_name=>'log'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_HISTORICO_EXCLUSAO.'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:9010:&SESSION.::&DEBUG.:9010:P9010_CODIGO_ARTEFATO,P0_CODIGO_ARTEFATO,P9010_PARAMETRO,P9010_VISUALIZAR:TD833,TD833,&P9006_CODIGO_ARTEFATO.,1'
,p_icon_css_classes=>'fa-history fam-x fam-is-danger'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(47216023656920691)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(17161532936247037)
,p_button_name=>unistr('Op\00E7\00F5es')
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_OPCAO.'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:9000:&SESSION.::&DEBUG.:9000:P9000_PAGINA:&P9006_CODIGO_ARTEFATO.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PKG_UI.verifica_se_tem_linhas(PKG_UI.buscar_acoes(0,:P9006_CODIGO_ARTEFATO,''W'')) = true or',
'PKG_UI.verifica_se_tem_linhas(PKG_UI.buscar_acoes(0,:P9006_CODIGO_ARTEFATO,''N'')) = true'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-ellipsis-v-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(47215546084920690)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(17161532936247037)
,p_button_name=>'New'
,p_button_static_id=>'NEW'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_NOVO.'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'&P9006_URL_NEW.'
,p_button_css_classes=>'apex_disabled'
,p_icon_css_classes=>'fa-plus-circle'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(47183774946920537)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(449383367943331559)
,p_button_name=>'Opcoes'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_CONFIGURACAO_LISTA.'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-gear'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54065952970530)
,p_name=>'P9006_ATUALIZA_PAGINA'
,p_item_sequence=>60
,p_item_display_point=>'REGION_POSITION_01'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_retorno varchar2(10);',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD367'');',
'begin',
'    begin',
'        EXECUTE IMMEDIATE',
'            ''BEGIN :l_retorno := UI_MPD_''||l_pagina||''.atualizar_tela; END;''',
'            USING OUT l_retorno;',
'',
'        return l_retorno;       ',
'    exception',
'        when others then',
'        return ''false'';       ',
'    end;',
'end;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1603936901518262)
,p_name=>'P9006_URL'
,p_item_sequence=>70
,p_item_display_point=>'REGION_POSITION_01'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5126817428325961)
,p_name=>'P9006_FAVORITO'
,p_item_sequence=>50
,p_item_display_point=>'REGION_POSITION_01'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134425113681081431)
,p_name=>'P9006_FILTRO_CARD4'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(437760514369897168)
,p_prompt=>'&P9006_NOME_FILTRO4.'
,p_source=>'FILTRO4'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''4''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''4''''); END;''',
'        USING OUT l_true;',
'',
'    return l_true;       ',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134435959100081473)
,p_name=>'P9006_FILTRO_MULT_LISTA1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(450697986669332966)
,p_prompt=>'&P9006_NOME_FILTRO_MULT1.'
,p_source=>'FILTRO_MULT1'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''M1''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''M1''''); END;''',
'        USING OUT l_true;',
'',
'    return l_true;       ',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134436093461081474)
,p_name=>'P9006_FILTRO_MULT_LISTA2'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(450697986669332966)
,p_prompt=>'&P9006_NOME_FILTRO_MULT2.'
,p_source=>'FILTRO_MULT2'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''M2''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''M2''''); END;''',
'        USING OUT l_true;',
'',
'    return l_true;       ',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134437429850081487)
,p_name=>'P9006_FILTRO_LISTA4'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(450697986669332966)
,p_prompt=>'&P9006_NOME_FILTRO4.'
,p_source=>'FILTRO4'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''4''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''4''''); END;''',
'        USING OUT l_true;',
'',
'    return l_true;       ',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134437532699081488)
,p_name=>'P9006_FILTRO_LISTA5'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(450697986669332966)
,p_prompt=>'&P9006_NOME_FILTRO5.'
,p_source=>'FILTRO5'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''5''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''5''''); END;''',
'        USING OUT l_true;',
'',
'    return l_true;       ',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134437547826081489)
,p_name=>'P9006_FILTRO_MULT_LISTA3'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(450697986669332966)
,p_prompt=>'&P9006_NOME_FILTRO_MULT3.'
,p_source=>'FILTRO_MULT3'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''M3''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''M3''''); END;''',
'        USING OUT l_true;',
'',
'    return l_true;       ',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134437735670081490)
,p_name=>'P9006_FILTRO_MULT_LISTA4'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(450697986669332966)
,p_prompt=>'&P9006_NOME_FILTRO_MULT4.'
,p_source=>'FILTRO_MULT4'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''M4''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''M4''''); END;''',
'        USING OUT l_true;',
'',
'    return l_true;       ',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134437764831081491)
,p_name=>'P9006_FILTRO_MULT_LISTA5'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(450697986669332966)
,p_prompt=>'&P9006_NOME_FILTRO_MULT5.'
,p_source=>'FILTRO_MULT5'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''M5''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''M5''''); END;''',
'        USING OUT l_true;',
'',
'    return l_true;       ',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134445881801081525)
,p_name=>'P9006_ID'
,p_item_sequence=>100
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136513187537583564)
,p_name=>'P9006_NOME_FILTRO4'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(435688233130590768)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''F4''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136513358068583565)
,p_name=>'P9006_NOME_FILTRO5'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(435688233130590768)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''F5''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136513375712583566)
,p_name=>'P9006_NOME_FILTRO_MULT3'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(435688233130590768)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''M3''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136513493841583567)
,p_name=>'P9006_NOME_FILTRO_MULT4'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(435688233130590768)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''M4''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136513602851583568)
,p_name=>'P9006_NOME_FILTRO_MULT5'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(435688233130590768)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''M5''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136518126976583582)
,p_name=>'P9006_FILTRO_CARD5'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(437760514369897168)
,p_prompt=>'&P9006_NOME_FILTRO5.'
,p_source=>'FILTRO5'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''5''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''5''''); END;''',
'        USING OUT l_true;',
'',
'    return l_true;       ',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136518207679583583)
,p_name=>'P9006_FILTRO_MULT_CARD3'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(437760514369897168)
,p_prompt=>'&P9006_NOME_FILTRO_MULT3.'
,p_source=>'FILTRO_MULT3'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''M3''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''M3''''); END;''',
'        USING OUT l_true;',
'',
'    return l_true;       ',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136518285744583584)
,p_name=>'P9006_FILTRO_MULT_CARD4'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(437760514369897168)
,p_prompt=>'&P9006_NOME_FILTRO_MULT4.'
,p_source=>'FILTRO_MULT4'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''M4''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''M4''''); END;''',
'        USING OUT l_true;',
'',
'    return l_true;       ',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136518404642583585)
,p_name=>'P9006_FILTRO_MULT_CARD5'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(437760514369897168)
,p_prompt=>'&P9006_NOME_FILTRO_MULT5.'
,p_source=>'FILTRO_MULT5'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''M5''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''M5''''); END;''',
'        USING OUT l_true;',
'',
'    return l_true;       ',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136537547104583694)
,p_name=>'P9006_COLUNAS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(136503986248583528)
,p_prompt=>'Mova para a direita as colunas que deseja esconder'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH colunas AS (',
'    SELECT ''CAMPO1'' id_coluna, :P9006_LABEL_COLUNA1 label FROM dual UNION ALL',
'    SELECT ''CAMPO2'', :P9006_LABEL_COLUNA2 FROM dual UNION ALL',
'    SELECT ''CAMPO3'', :P9006_LABEL_COLUNA3 FROM dual UNION ALL',
'    SELECT ''CAMPO4'', :P9006_LABEL_COLUNA4 FROM dual UNION ALL',
'    SELECT ''CAMPO5'', :P9006_LABEL_COLUNA5 FROM dual UNION ALL',
'    SELECT ''CAMPO6'', :P9006_LABEL_COLUNA6 FROM dual UNION ALL',
'    SELECT ''CAMPO7'', :P9006_LABEL_COLUNA7 FROM dual UNION ALL',
'    SELECT ''CAMPO8'', :P9006_LABEL_COLUNA8 FROM dual UNION ALL',
'    SELECT ''CAMPO9'', :P9006_LABEL_COLUNA9 FROM dual UNION ALL',
'    SELECT ''CAMPO10'', :P9006_LABEL_COLUNA10 FROM dual',
')',
'SELECT c.label d, c.id_coluna r',
'FROM colunas c',
'LEFT JOIN MPD_USUARIO_GRID_OCULTA_COLUNA u',
'    ON u.id_usuario = :ID_USUARIO_LOGADO',
'    AND u.codigo_artefato = :P9006_CODIGO_ARTEFATO',
'    AND u.id_coluna LIKE ''%'' || c.id_coluna || ''%''',
'WHERE --u.id_coluna IS NULL and ',
'c.label is not null',
''))
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'MOVE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136539403749583713)
,p_name=>'P9006_MOSTRA_CAMPO1'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(136503986248583528)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136539505713583714)
,p_name=>'P9006_MOSTRA_CAMPO2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(136503986248583528)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136539661669583715)
,p_name=>'P9006_MOSTRA_CAMPO3'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(136503986248583528)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136539706358583716)
,p_name=>'P9006_MOSTRA_CAMPO4'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(136503986248583528)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136539832435583717)
,p_name=>'P9006_MOSTRA_CAMPO5'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(136503986248583528)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136539900814583718)
,p_name=>'P9006_MOSTRA_CAMPO6'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(136503986248583528)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(137135876472689169)
,p_name=>'P9006_MOSTRA_CAMPO7'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(136503986248583528)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(137135974933689170)
,p_name=>'P9006_MOSTRA_CAMPO8'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(136503986248583528)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(137136163484689171)
,p_name=>'P9006_MOSTRA_CAMPO9'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(136503986248583528)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(137136167657689172)
,p_name=>'P9006_MOSTRA_CAMPO10'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(136503986248583528)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(285152691984216134)
,p_name=>'P9006_PARAMETRO2'
,p_item_sequence=>150
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(311158219611404677)
,p_name=>'P9006_CARD_OU_LISTA'
,p_item_sequence=>110
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(312321974319487518)
,p_name=>'P9006_FILTRO_LIVRE_LISTA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(450697986669332966)
,p_prompt=>'Filtro Livre Lista'
,p_source=>'CAMPO1,CAMPO2,CAMPO3,CAMPO4'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'input_field', 'FACET',
  'search_type', 'ROW')).to_clob
,p_fc_show_chart=>false
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(328271259772722138)
,p_name=>'P9006_PARAMETRO'
,p_item_sequence=>140
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(402271526641209156)
,p_name=>'P9006_TELA_TITULO'
,p_item_sequence=>120
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(402271965393209161)
,p_name=>'P9006_TELA_HELP'
,p_item_sequence=>130
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(402492823926921815)
,p_name=>'P9006_NOME_FILTRO2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(435688233130590768)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''F2''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(402492990763921817)
,p_name=>'P9006_NOME_FILTRO3'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(435688233130590768)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''F3''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(402495130487921838)
,p_name=>'P9006_NOME_FILTRO_MULT1'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(435688233130590768)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''M1''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(402495201927921839)
,p_name=>'P9006_NOME_FILTRO_MULT2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(435688233130590768)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''M2''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(402497957715921836)
,p_name=>'P9006_FILTRO_CARD2'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(437760514369897168)
,p_prompt=>'&P9006_NOME_FILTRO2.'
,p_source=>'FILTRO2'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''2''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''2''''); END;''',
'        USING OUT l_true;',
'',
'    return l_true;       ',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(402498130529921838)
,p_name=>'P9006_FILTRO_CARD3'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(437760514369897168)
,p_prompt=>'&P9006_NOME_FILTRO3.'
,p_source=>'FILTRO3'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''3''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''3''''); END;''',
'        USING OUT l_true;',
'',
'    return l_true;       ',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(402500140649921858)
,p_name=>'P9006_FILTRO_MULT_CARD1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(437760514369897168)
,p_prompt=>'&P9006_NOME_FILTRO_MULT1.'
,p_source=>'FILTRO_MULT1'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''M1''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''M1''''); END;''',
'        USING OUT l_true;',
'',
'    return l_true;       ',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(402500202947921859)
,p_name=>'P9006_FILTRO_MULT_CARD2'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(437760514369897168)
,p_prompt=>'&P9006_NOME_FILTRO_MULT2.'
,p_source=>'FILTRO_MULT2'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''M2''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''M2''''); END;''',
'        USING OUT l_true;',
'',
'    return l_true;       ',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(417082288398942082)
,p_name=>'P9006_LABEL_COLUNA3'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(449383367943331559)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(417082470309942083)
,p_name=>'P9006_LABEL_COLUNA4'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(449383367943331559)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(417082537773942084)
,p_name=>'P9006_LABEL_COLUNA5'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(449383367943331559)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(417082668844942085)
,p_name=>'P9006_LABEL_COLUNA6'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(449383367943331559)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(417082774712942086)
,p_name=>'P9006_LABEL_COLUNA7'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(449383367943331559)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(417082784819942087)
,p_name=>'P9006_LABEL_COLUNA8'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(449383367943331559)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(417082949811942088)
,p_name=>'P9006_LABEL_COLUNA9'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(449383367943331559)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(417083076841942089)
,p_name=>'P9006_LABEL_COLUNA10'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(449383367943331559)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(423053739171631917)
,p_name=>'P9006_FILTRO_LISTA1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(450697986669332966)
,p_prompt=>'&P9006_NOME_FILTRO1.'
,p_source=>'FILTRO1'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD257'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''1''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD257'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''1''''); END;''',
'        USING OUT l_true;',
'',
'    return l_true;       ',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(435795490384591159)
,p_name=>'P9006_TIPO_PESQUISA'
,p_item_sequence=>70
,p_item_default=>'1'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(437756863316945423)
,p_name=>'P9006_CODIGO_ARTEFATO'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(437757785231945432)
,p_name=>'P9006_URL_NEW'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(437791056862897310)
,p_name=>'P9006_NOME_FILTRO1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(435688233130590768)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''F1''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(437796167791897330)
,p_name=>'P9006_FILTRO_LIVRE_CARD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(437760514369897168)
,p_prompt=>'Filtro Livre Card'
,p_source=>'DISTINTIVO,TITULO,SUBTITULO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'input_field', 'FACET',
  'search_type', 'ROW')).to_clob
,p_fc_show_chart=>false
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(437796207427897331)
,p_name=>'P9006_FILTRO_CARD1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(437760514369897168)
,p_prompt=>'&P9006_NOME_FILTRO1.'
,p_source=>'FILTRO1'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''1''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''1''''); END;''',
'        USING OUT l_true;',
'',
'    return l_true;       ',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(449784752328355722)
,p_name=>'P9006_LABEL_COLUNA1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(449383367943331559)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(449784904131355723)
,p_name=>'P9006_LABEL_COLUNA2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(449383367943331559)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(450838347166639692)
,p_name=>'P9006_FILTRO_LISTA2'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(450697986669332966)
,p_prompt=>'&P9006_NOME_FILTRO2.'
,p_source=>'FILTRO2'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD150'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''2''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,''TD150'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''2''''); END;''',
'        USING OUT l_true;',
'',
'    return l_true;       ',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(450839903816639708)
,p_name=>'P9006_FILTRO_LISTA3'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(450697986669332966)
,p_prompt=>'&P9006_NOME_FILTRO3.'
,p_source=>'FILTRO3'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''3''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''3''''); END;''',
'        USING OUT l_true;',
'',
'    return l_true;       ',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(47219245764920704)
,p_computation_sequence=>10
,p_computation_item=>'P9006_LABEL_COLUNA1'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''1''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(47219632877920705)
,p_computation_sequence=>20
,p_computation_item=>'P9006_LABEL_COLUNA2'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''2''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(47220063796920707)
,p_computation_sequence=>30
,p_computation_item=>'P9006_LABEL_COLUNA3'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''3''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(47220494711920707)
,p_computation_sequence=>40
,p_computation_item=>'P9006_LABEL_COLUNA4'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''4''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(47220869406920709)
,p_computation_sequence=>50
,p_computation_item=>'P9006_LABEL_COLUNA5'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''5''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(47221278620920710)
,p_computation_sequence=>60
,p_computation_item=>'P9006_LABEL_COLUNA6'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''6''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(47221651285920711)
,p_computation_sequence=>70
,p_computation_item=>'P9006_LABEL_COLUNA7'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''7''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(47222029148920712)
,p_computation_sequence=>80
,p_computation_item=>'P9006_LABEL_COLUNA8'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''8''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(47222482527920713)
,p_computation_sequence=>90
,p_computation_item=>'P9006_LABEL_COLUNA9'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''9''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(47222837699920714)
,p_computation_sequence=>100
,p_computation_item=>'P9006_LABEL_COLUNA10'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9006_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''10''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(47233040354920743)
,p_name=>'onClickFixar'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(47188137094920558)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47233592408920744)
,p_event_id=>wwv_flow_imp.id(47233040354920743)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (apex.item( "P9006_TIPO_PESQUISA" ).getValue() == 1){',
'    apex.item( "P9006_TIPO_PESQUISA" ).setValue( 2 );',
'} else {',
'    apex.item( "P9006_TIPO_PESQUISA" ).setValue( 1 );',
'}',
'    '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(47233989980920745)
,p_name=>'onChangeTipoPesquisa = Esquerda'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9006_TIPO_PESQUISA'
,p_condition_element=>'P9006_TIPO_PESQUISA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47234493441920746)
,p_event_id=>wwv_flow_imp.id(47233989980920745)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#PESQUISA'').appendTo(''#PAINEL_LEFT'');',
'$(''#PESQUISA_LISTA'').appendTo(''#PAINEL_LEFT'');',
'$(''#t_Body_side'').show();'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47234938140920747)
,p_event_id=>wwv_flow_imp.id(47233989980920745)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(435689158105590777)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(47235387171920749)
,p_name=>'onChangeTipoPesquisa = Modal'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9006_TIPO_PESQUISA'
,p_condition_element=>'P9006_TIPO_PESQUISA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47235833332920750)
,p_event_id=>wwv_flow_imp.id(47235387171920749)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#PESQUISA'').appendTo(''#PAINEL_MODAL .t-DrawerRegion-body'');    ',
'$(''#PESQUISA_LISTA'').appendTo(''#PAINEL_MODAL .t-DrawerRegion-body'');    ',
'$(''#t_Body_side'').hide();'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47236366605920751)
,p_event_id=>wwv_flow_imp.id(47235387171920749)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(435689158105590777)
,p_build_option_id=>wwv_flow_imp.id(340973604135556181)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(47236799351920752)
,p_name=>'onClickDesfixar'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(47178020173920507)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47237277748920753)
,p_event_id=>wwv_flow_imp.id(47236799351920752)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (apex.item( "P9006_TIPO_PESQUISA" ).getValue() == 1){',
'    apex.item( "P9006_TIPO_PESQUISA" ).setValue( 2 );',
'} else {',
'    apex.item( "P9006_TIPO_PESQUISA" ).setValue( 1 );',
'}',
'    '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(47238549339920757)
,p_name=>'onCloseNew'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(47215546084920690)
,p_condition_element=>'P9006_ATUALIZA_PAGINA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'true'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54145528970531)
,p_event_id=>wwv_flow_imp.id(47238549339920757)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'location.reload();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39965488809705543)
,p_event_id=>wwv_flow_imp.id(47238549339920757)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(487411440845978113)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39965568482705544)
,p_event_id=>wwv_flow_imp.id(47238549339920757)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(449383367943331559)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39968751263705576)
,p_event_id=>wwv_flow_imp.id(47238549339920757)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(437760514369897168)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39968884132705577)
,p_event_id=>wwv_flow_imp.id(47238549339920757)
,p_event_result=>'FALSE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(450697986669332966)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(47238990009920758)
,p_name=>'onClickFilter = Esquerda'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(47215132387920689)
,p_condition_element=>'P9006_TIPO_PESQUISA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47239434611920759)
,p_event_id=>wwv_flow_imp.id(47238990009920758)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#t_Body_side'').is('':visible'')) {',
'    $(''#t_Body_side'').hide();',
'} else {',
'    $(''#t_Body_side'').show();',
'}',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(47239840205920761)
,p_name=>'onClickFilter = Modal'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(47215132387920689)
,p_condition_element=>'P9006_TIPO_PESQUISA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47240380448920762)
,p_event_id=>wwv_flow_imp.id(47239840205920761)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(435689158105590777)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(47240762957920763)
,p_name=>'onPageLoad'
,p_event_sequence=>110
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47241267894920764)
,p_event_id=>wwv_flow_imp.id(47240762957920763)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(47215546084920690)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(47232204591920740)
,p_name=>'onClickOpcoes'
,p_event_sequence=>150
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(47183774946920537)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47232680063920742)
,p_event_id=>wwv_flow_imp.id(47232204591920740)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(453248850017455353)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(39966044793705549)
,p_name=>'onCloseCard'
,p_event_sequence=>160
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(487411440845978113)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39966150936705550)
,p_event_id=>wwv_flow_imp.id(39966044793705549)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(487411440845978113)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(49929951896101628)
,p_event_id=>wwv_flow_imp.id(39966044793705549)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(437760514369897168)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(39966308178705551)
,p_name=>'onCloseLista'
,p_event_sequence=>170
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(449383367943331559)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39966358779705552)
,p_event_id=>wwv_flow_imp.id(39966308178705551)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(449383367943331559)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(49930113344101629)
,p_event_id=>wwv_flow_imp.id(39966308178705551)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(450697986669332966)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(49930197930101630)
,p_name=>'onCloseMenu'
,p_event_sequence=>180
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(47216023656920691)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(49930263680101631)
,p_event_id=>wwv_flow_imp.id(49930197930101630)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(487411440845978113)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(49930340727101632)
,p_event_id=>wwv_flow_imp.id(49930197930101630)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(449383367943331559)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(49930514587101633)
,p_event_id=>wwv_flow_imp.id(49930197930101630)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(437760514369897168)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(49930545661101634)
,p_event_id=>wwv_flow_imp.id(49930197930101630)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(450697986669332966)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(61988135689719557)
,p_name=>'onAfterRefreshListaOculta'
,p_event_sequence=>190
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(449372161480329917)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(61988285253719558)
,p_event_id=>wwv_flow_imp.id(61988135689719557)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(449383367943331559)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(5707556238710534)
,p_name=>'onClickVisaoReport'
,p_event_sequence=>200
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(47214351962920686)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5707439002710533)
,p_event_id=>wwv_flow_imp.id(5707556238710534)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    p_sucesso clob;',
'    p_messages pkg_mensagem.message_record_table;',
'begin',
'    bo_mpd_usuario_artefato_formato.inclui_ou_altera_registro(',
'        p_codigo_artefato => :P9006_CODIGO_ARTEFATO,',
'        p_formato => ''GRI'',',
'        p_sucesso => p_sucesso,',
'        p_messages => p_messages',
'    );',
'    :P9006_URL := apex_page.get_url( ',
'        p_page => 9006,  ',
'        p_items => ''P9006_CODIGO_ARTEFATO,P9006_PARAMETRO,P9006_PARAMETRO2'', ',
'        p_values => :P9006_CODIGO_ARTEFATO||'',''||:P9006_PARAMETRO||'',''||:P9006_PARAMETRO2);       ',
'end;'))
,p_attribute_02=>'P9006_CODIGO_ARTEFATO'
,p_attribute_03=>'P9006_URL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1603824517518261)
,p_event_id=>wwv_flow_imp.id(5707556238710534)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v(''P9006_URL''))',
'    window.location.replace($v(''P9006_URL''));   '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(5707300142710532)
,p_name=>'onClickVisaoCard'
,p_event_sequence=>210
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(47214746185920688)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5707245133710531)
,p_event_id=>wwv_flow_imp.id(5707300142710532)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    p_sucesso clob;',
'    p_messages pkg_mensagem.message_record_table;',
'begin',
'    bo_mpd_usuario_artefato_formato.inclui_ou_altera_registro(',
'        p_codigo_artefato => :P9006_CODIGO_ARTEFATO,',
'        p_formato => ''CAR'',',
'        p_sucesso => p_sucesso,',
'        p_messages => p_messages',
'    );',
'    :P9006_URL := apex_page.get_url( ',
'        p_page => 9006,  ',
'        p_items => ''P9006_CODIGO_ARTEFATO,P9006_PARAMETRO,P9006_PARAMETRO2'', ',
'        p_values => :P9006_CODIGO_ARTEFATO||'',''||:P9006_PARAMETRO||'',''||:P9006_PARAMETRO2);       ',
'end;'))
,p_attribute_02=>'P9006_CODIGO_ARTEFATO'
,p_attribute_03=>'P9006_URL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1603759689518260)
,p_event_id=>wwv_flow_imp.id(5707300142710532)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v(''P9006_URL''))',
'    window.location.replace($v(''P9006_URL''));   '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(5126731708325960)
,p_name=>'onClickFavNao'
,p_event_sequence=>220
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(5126875648325962)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5126670521325959)
,p_event_id=>wwv_flow_imp.id(5126731708325960)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    p_sucesso clob;',
'    p_messages pkg_mensagem.message_record_table;',
'begin',
'    bo_mpd_usuario_artefato_favorito.inclui_ou_exclui_registro(',
'        p_codigo_artefato => :P9006_CODIGO_ARTEFATO,',
'        p_acao => 1, -- inclui favorito',
'        p_sucesso => p_sucesso,',
'        p_messages => p_messages',
'    );',
'    :P9006_URL := apex_page.get_url( ',
'        p_page => 9006,  ',
'        p_items => ''P9006_CODIGO_ARTEFATO,P9006_PARAMETRO,P9006_PARAMETRO2'', ',
'        p_values => :P9006_CODIGO_ARTEFATO||'',''||:P9006_PARAMETRO||'',''||:P9006_PARAMETRO2);       ',
'end;'))
,p_attribute_02=>'P9006_CODIGO_ARTEFATO'
,p_attribute_03=>'P9006_URL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1603029921518253)
,p_event_id=>wwv_flow_imp.id(5126731708325960)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v(''P9006_URL''))',
'    window.location.replace($v(''P9006_URL''));        '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(5126537270325958)
,p_name=>'onClickFavSim'
,p_event_sequence=>230
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(4711636741686187)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5126385267325957)
,p_event_id=>wwv_flow_imp.id(5126537270325958)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    p_sucesso clob;',
'    p_messages pkg_mensagem.message_record_table;',
'begin',
'    bo_mpd_usuario_artefato_favorito.inclui_ou_exclui_registro(',
'        p_codigo_artefato => :P9006_CODIGO_ARTEFATO,',
'        p_acao => 2, -- inclui favorito',
'        p_sucesso => p_sucesso,',
'        p_messages => p_messages',
'    );',
'    :P9006_URL := apex_page.get_url( ',
'        p_page => 9006,  ',
'        p_items => ''P9006_CODIGO_ARTEFATO,P9006_PARAMETRO,P9006_PARAMETRO2'', ',
'        p_values => :P9006_CODIGO_ARTEFATO||'',''||:P9006_PARAMETRO||'',''||:P9006_PARAMETRO2);       ',
'end;'))
,p_attribute_02=>'P9006_CODIGO_ARTEFATO'
,p_attribute_03=>'P9006_URL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1602922278518252)
,p_event_id=>wwv_flow_imp.id(5126537270325958)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v(''P9006_URL''))',
'    window.location.replace($v(''P9006_URL''));        '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(53438270228777066)
,p_name=>'onChangeUrlNew'
,p_event_sequence=>240
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9006_URL_NEW'
,p_condition_element=>'P9006_URL_NEW'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(53438381714777067)
,p_event_id=>wwv_flow_imp.id(53438270228777066)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(47215546084920690)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(53438542771777069)
,p_event_id=>wwv_flow_imp.id(53438270228777066)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(47215546084920690)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(47228260739920729)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>unistr('Salvar personaliza\00E7\00E3o das colunas')
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'BO_MPD_USUARIO_GRID_OCULTA_COLUNA'
,p_attribute_04=>'INCLUI_OU_ALTERA_REGISTRO'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(47210400932920666)
,p_internal_uid=>90099132400563002
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(47228780866920731)
,p_page_process_id=>wwv_flow_imp.id(47228260739920729)
,p_page_id=>9006
,p_name=>'p_id_coluna'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P9006_COLUNAS'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(47229260714920733)
,p_page_process_id=>wwv_flow_imp.id(47228260739920729)
,p_page_id=>9006
,p_name=>'p_id_usuario'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'ID_USUARIO_LOGADO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(47229810244920734)
,p_page_process_id=>wwv_flow_imp.id(47228260739920729)
,p_page_id=>9006
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P9006_CODIGO_ARTEFATO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(47230255500920735)
,p_page_process_id=>wwv_flow_imp.id(47228260739920729)
,p_page_id=>9006
,p_name=>'p_pagina'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>true
,p_display_sequence=>40
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(47230785363920737)
,p_page_process_id=>wwv_flow_imp.id(47228260739920729)
,p_page_id=>9006
,p_name=>'p_encadeado'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>50
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(47231310403920738)
,p_page_process_id=>wwv_flow_imp.id(47228260739920729)
,p_page_id=>9006
,p_name=>'p_sucesso'
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>true
,p_display_sequence=>60
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(47231772277920739)
,p_page_process_id=>wwv_flow_imp.id(47228260739920729)
,p_page_id=>9006
,p_name=>'p_messages'
,p_direction=>'OUT'
,p_data_type=>'pkg_mensagem.message_record_table'
,p_display_sequence=>70
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(47225454902920722)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'url_new'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'URL_NEW'
,p_internal_uid=>90096326563562995
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(47225997866920724)
,p_page_process_id=>wwv_flow_imp.id(47225454902920722)
,p_page_id=>9006
,p_name=>'p_param2'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>70
,p_value_type=>'ITEM'
,p_value=>'P9006_PARAMETRO2'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(47226445177920725)
,p_page_process_id=>wwv_flow_imp.id(47225454902920722)
,p_page_id=>9006
,p_name=>'p_param1'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>60
,p_value_type=>'ITEM'
,p_value=>'P9006_PARAMETRO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(47226946268920726)
,p_page_process_id=>wwv_flow_imp.id(47225454902920722)
,p_page_id=>9006
,p_name=>'p_url'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>40
,p_value_type=>'ITEM'
,p_value=>'P9006_URL_NEW'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(47227470377920727)
,p_page_process_id=>wwv_flow_imp.id(47225454902920722)
,p_page_id=>9006
,p_name=>'p_codigo_arfato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>50
,p_value_type=>'ITEM'
,p_value=>'P9006_CODIGO_ARTEFATO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(47223562177920716)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'retorna_titulo_tela'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'RETORNA_TITULO_TELA'
,p_internal_uid=>90094433838562989
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(47224056423920718)
,p_page_process_id=>wwv_flow_imp.id(47223562177920716)
,p_page_id=>9006
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P9006_CODIGO_ARTEFATO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(47224601349920719)
,p_page_process_id=>wwv_flow_imp.id(47223562177920716)
,p_page_id=>9006
,p_name=>'p_titulo'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P0_TITULO_TELA'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(47225058108920721)
,p_page_process_id=>wwv_flow_imp.id(47223562177920716)
,p_page_id=>9006
,p_name=>'p_help'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P0_HELP_TELA'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(47223185430920715)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_formato varchar2(3);',
'    l_id number;',
'    l_data_alteracao timestamp;',
'begin   ',
'    PKG_UI.prc_configurar_filtros(',
'        p_id_usuario => :ID_USUARIO_LOGADO ,',
'        p_codigo_artefato => :P9006_CODIGO_ARTEFATO,',
'        p_app_page_id => :app_page_id   ',
'    );',
'',
'    begin',
'        select formato into l_formato from mpd_usuario_artefato_formato ',
'        where upper(login) = upper(apex_custom_auth.get_username) ',
'        and upper(codigo_artefato) = upper(:P9006_CODIGO_ARTEFATO)',
'        and aplicacao = apex_application.g_flow_id;',
'        exception',
'            when no_data_found then',
'                l_formato := null;',
'    end;',
'',
'    :P9006_CARD_OU_LISTA := l_formato;    ',
'    if :P9006_CARD_OU_LISTA is null then',
'        :P9006_CARD_OU_LISTA := ''CAR'';',
'    end if;',
'',
'    bo_mpd_usuario_artefato_favorito.retorna_registro( ',
'        p_login => upper(apex_custom_auth.get_username),',
'        p_codigo_artefato => :P9006_CODIGO_ARTEFATO,',
'        p_aplicacao => apex_application.g_flow_id,',
'        p_id => l_id,',
'        p_data_alteracao => l_data_alteracao',
'    );    ',
'    if l_id is not null then',
'        :P9006_FAVORITO := 1;',
'    else',
'        :P9006_FAVORITO := 0;',
'    end if;    ',
'end;',
'',
'',
'    ',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>90094057091562988
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(47227894718920728)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GETIMAGE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    ',
'',
'    for c1 in (select *',
'               from   MPD_USUARIO',
'               where  id = :P9006_ID) loop',
'        sys.htp.init;',
'        sys.owa_util.Mime_header(c1.foto_mimetype, false);',
'        sys.htp.P(''Content-length: ''|| sys.dbms_lob.Getlength(c1.foto));',
'        sys.htp.P(''Content-Disposition: attachment; filename="''|| c1.foto_name|| ''"'');',
'        sys.htp.P(''Cache-Control: max-age=1'');',
'        sys.owa_util.http_header_close;',
'        sys.wpg_docload.Download_file(c1.foto);',
'        apex_application.stop_apex_engine;',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>90098766379563001
);
wwv_flow_imp.component_end;
end;
/
