prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'teste'
,p_alias=>'TESTE'
,p_step_title=>'teste'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(340977852296556203)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'22'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(82676607109388751)
,p_name=>'Search Results1'
,p_template=>wwv_flow_imp.id(341046435992556242)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P3_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    if :P3_CARD_OU_LISTA = ''GRI'' then',
'        EXECUTE IMMEDIATE',
'            ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_lista_oculta(:param1,:param2); END;''',
'            USING OUT l_sql, IN :P3_PARAMETRO, :P3_PARAMETRO2;',
'    else',
'        l_sql := q''~',
'            select ',
'                null              id,',
'                null              campo1,             ',
'                null              campo2,             ',
'                null              campo3,             ',
'                null              campo4,             ',
'                null              campo5,             ',
'                null              campo6,             ',
'                null              campo7,             ',
'                null              campo8,                                      ',
'                null              campo9,      ',
'                null              campo10,                                ',
'                null              filtro1,',
'                null              filtro2,',
'                null              filtro3,',
'                null              filtro4,',
'                null              filtro5,',
'                null              filtro6,',
'                null              filtro7,',
'                null              filtro8,',
'                null              filtro9,',
'                null              filtro10,',
'                null              filtro11,',
'                null              filtro12,',
'                null              filtro_mult1,',
'                null              filtro_mult2,',
'                null              filtro_mult3,',
'                null              filtro_mult4,',
'                null              filtro_mult5,',
'                null              filtro_data_range1,',
'                null              filtro_data_range2,',
'                pkg_componentes.icone_opcao opcao',
'            from dual    ',
'        ~'';',
'    end if;',
'',
'    return l_sql;       ',
'end;'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P3_CODIGO_ARTEFATO,P3_CARD_OU_LISTA,P3_PARAMETRO,P3_PARAMETRO2'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(341097593039556273)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>100000
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(82676711336388752)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(82677625068388762)
,p_query_column_id=>2
,p_column_alias=>'CAMPO1'
,p_column_display_sequence=>20
,p_column_heading=>'Campo1'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(82677780422388763)
,p_query_column_id=>3
,p_column_alias=>'CAMPO2'
,p_column_display_sequence=>30
,p_column_heading=>'Campo2'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(82677908862388764)
,p_query_column_id=>4
,p_column_alias=>'CAMPO3'
,p_column_display_sequence=>40
,p_column_heading=>'Campo3'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(82677953129388765)
,p_query_column_id=>5
,p_column_alias=>'CAMPO4'
,p_column_display_sequence=>50
,p_column_heading=>'Campo4'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(82678067942388766)
,p_query_column_id=>6
,p_column_alias=>'CAMPO5'
,p_column_display_sequence=>60
,p_column_heading=>'Campo5'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(82678206672388767)
,p_query_column_id=>7
,p_column_alias=>'CAMPO6'
,p_column_display_sequence=>70
,p_column_heading=>'Campo6'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89614417461199518)
,p_query_column_id=>8
,p_column_alias=>'CAMPO7'
,p_column_display_sequence=>80
,p_column_heading=>'Campo7'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89614491710199519)
,p_query_column_id=>9
,p_column_alias=>'CAMPO8'
,p_column_display_sequence=>90
,p_column_heading=>'Campo8'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89614577024199520)
,p_query_column_id=>10
,p_column_alias=>'CAMPO9'
,p_column_display_sequence=>100
,p_column_heading=>'Campo9'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89614709998199521)
,p_query_column_id=>11
,p_column_alias=>'CAMPO10'
,p_column_display_sequence=>110
,p_column_heading=>'Campo10'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89614734355199522)
,p_query_column_id=>12
,p_column_alias=>'FILTRO1'
,p_column_display_sequence=>120
,p_column_heading=>'Filtro1'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89614826602199523)
,p_query_column_id=>13
,p_column_alias=>'FILTRO2'
,p_column_display_sequence=>130
,p_column_heading=>'Filtro2'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89615000389199524)
,p_query_column_id=>14
,p_column_alias=>'FILTRO3'
,p_column_display_sequence=>140
,p_column_heading=>'Filtro3'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89615047989199525)
,p_query_column_id=>15
,p_column_alias=>'FILTRO4'
,p_column_display_sequence=>150
,p_column_heading=>'Filtro4'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89615158741199526)
,p_query_column_id=>16
,p_column_alias=>'FILTRO5'
,p_column_display_sequence=>160
,p_column_heading=>'Filtro5'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89615298273199527)
,p_query_column_id=>17
,p_column_alias=>'FILTRO6'
,p_column_display_sequence=>170
,p_column_heading=>'Filtro6'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89615400763199528)
,p_query_column_id=>18
,p_column_alias=>'FILTRO7'
,p_column_display_sequence=>180
,p_column_heading=>'Filtro7'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89615467066199529)
,p_query_column_id=>19
,p_column_alias=>'FILTRO8'
,p_column_display_sequence=>190
,p_column_heading=>'Filtro8'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89615593740199530)
,p_query_column_id=>20
,p_column_alias=>'FILTRO9'
,p_column_display_sequence=>200
,p_column_heading=>'Filtro9'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89615680992199531)
,p_query_column_id=>21
,p_column_alias=>'FILTRO10'
,p_column_display_sequence=>210
,p_column_heading=>'Filtro10'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89615811784199532)
,p_query_column_id=>22
,p_column_alias=>'FILTRO11'
,p_column_display_sequence=>220
,p_column_heading=>'Filtro11'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89615850382199533)
,p_query_column_id=>23
,p_column_alias=>'FILTRO12'
,p_column_display_sequence=>230
,p_column_heading=>'Filtro12'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89615998164199534)
,p_query_column_id=>24
,p_column_alias=>'FILTRO_MULT1'
,p_column_display_sequence=>240
,p_column_heading=>'Filtro Mult1'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89616038801199535)
,p_query_column_id=>25
,p_column_alias=>'FILTRO_MULT2'
,p_column_display_sequence=>250
,p_column_heading=>'Filtro Mult2'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89616167213199536)
,p_query_column_id=>26
,p_column_alias=>'FILTRO_MULT3'
,p_column_display_sequence=>260
,p_column_heading=>'Filtro Mult3'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89616245198199537)
,p_query_column_id=>27
,p_column_alias=>'FILTRO_MULT4'
,p_column_display_sequence=>270
,p_column_heading=>'Filtro Mult4'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89616356001199538)
,p_query_column_id=>28
,p_column_alias=>'FILTRO_MULT5'
,p_column_display_sequence=>280
,p_column_heading=>'Filtro Mult5'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89616432557199539)
,p_query_column_id=>29
,p_column_alias=>'FILTRO_DATA_RANGE1'
,p_column_display_sequence=>290
,p_column_heading=>'Filtro Data Range1'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89616528219199540)
,p_query_column_id=>30
,p_column_alias=>'FILTRO_DATA_RANGE2'
,p_column_display_sequence=>300
,p_column_heading=>'Filtro Data Range2'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89616623884199541)
,p_query_column_id=>31
,p_column_alias=>'OPCAO'
,p_column_display_sequence=>310
,p_column_heading=>'Opcao'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(89597547274004360)
,p_name=>'Search Results'
,p_template=>wwv_flow_imp.id(341046435992556242)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       ID_TENANT,',
'       CODIGO_MOEDA,',
'       DESCRICAO_MOEDA,',
'       SIMBOLO_ISO,',
'       DATA_FIM_VIGENCIA,',
'       ID_USUARIO_INCLUIU,',
'       DATA_INCLUSAO,',
'       ID_USUARIO_ALTEROU,',
'       DATA_ALTERACAO',
'  from NG_MOEDA'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(341097593039556273)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>100000
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89601487664004544)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>0
,p_column_heading=>'ID'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_hidden_column=>'Y'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89601785854004545)
,p_query_column_id=>2
,p_column_alias=>'ID_TENANT'
,p_column_display_sequence=>2
,p_column_heading=>'Id Tenant'
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(87170059361991689)
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89602138091004545)
,p_query_column_id=>3
,p_column_alias=>'CODIGO_MOEDA'
,p_column_display_sequence=>3
,p_column_heading=>'Codigo Moeda'
,p_column_format=>'999G999G999G999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89602614708004546)
,p_query_column_id=>4
,p_column_alias=>'DESCRICAO_MOEDA'
,p_column_display_sequence=>4
,p_column_heading=>'Descricao Moeda'
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89602945964004547)
,p_query_column_id=>5
,p_column_alias=>'SIMBOLO_ISO'
,p_column_display_sequence=>5
,p_column_heading=>'Simbolo Iso'
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89603339273004547)
,p_query_column_id=>6
,p_column_alias=>'DATA_FIM_VIGENCIA'
,p_column_display_sequence=>6
,p_column_heading=>'Data Fim Vigencia'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89603812748004548)
,p_query_column_id=>7
,p_column_alias=>'ID_USUARIO_INCLUIU'
,p_column_display_sequence=>7
,p_column_heading=>'Id Usuario Incluiu'
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(109899727192893955)
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89604126209004549)
,p_query_column_id=>8
,p_column_alias=>'DATA_INCLUSAO'
,p_column_display_sequence=>8
,p_column_heading=>'Data Inclusao'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89604575445004549)
,p_query_column_id=>9
,p_column_alias=>'ID_USUARIO_ALTEROU'
,p_column_display_sequence=>9
,p_column_heading=>'Id Usuario Alterou'
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(109899727192893955)
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(89604935280004550)
,p_query_column_id=>10
,p_column_alias=>'DATA_ALTERACAO'
,p_column_display_sequence=>10
,p_column_heading=>'Data Alteracao'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(89597640704004360)
,p_plug_name=>'Search'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_location=>null
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(89597547274004360)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'batch_facet_search', 'N',
  'compact_numbers_threshold', '10000',
  'current_facets_selector', '#active_facets',
  'display_chart_for_top_n_values', '10',
  'show_charts', 'Y',
  'show_current_facets', 'E',
  'show_total_row_count', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(89600504363004397)
,p_plug_name=>'Button Bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(341013639389556225)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>'<div id="active_facets"></div>'
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(89617134193199546)
,p_plug_name=>'Search1'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_02'
,p_location=>null
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(82676607109388751)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'batch_facet_search', 'N',
  'compact_numbers_threshold', '10000',
  'current_facets_selector', '#active_facets',
  'display_chart_for_top_n_values', '10',
  'show_charts', 'Y',
  'show_current_facets', 'E',
  'show_total_row_count', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(89600934270004402)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(89600504363004397)
,p_button_name=>'RESET'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(341144305939556305)
,p_button_image_alt=>'Reset'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:3:&APP_SESSION.::&DEBUG.:RR,3::'
,p_icon_css_classes=>'fa-undo'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(82676446670388750)
,p_name=>'P3_ID_USUARIO_INCLUIU_1'
,p_source_data_type=>'TIMESTAMP_TZ'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(89597640704004360)
,p_prompt=>'Data vigencia'
,p_source=>'DATA_FIM_VIGENCIA'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'manual_entry', 'N',
  'select_multiple', 'N')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(89598209897004374)
,p_name=>'P3_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(89597640704004360)
,p_prompt=>'Search'
,p_source=>'ID_TENANT,DESCRICAO_MOEDA,SIMBOLO_ISO,ID_USUARIO_INCLUIU,ID_USUARIO_ALTEROU'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'collapsed_search_field', 'N',
  'input_field', 'FACET',
  'search_type', 'ROW')).to_clob
,p_fc_collapsible=>false
,p_fc_initial_collapsed=>false
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(89616818042199542)
,p_name=>'P3_CODIGO_ARTEFATO'
,p_item_sequence=>50
,p_item_default=>'TD337'
,p_prompt=>'Codigo Artefato'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(89616844673199543)
,p_name=>'P3_PARAMETRO'
,p_item_sequence=>60
,p_prompt=>'Parametro'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(89617020823199544)
,p_name=>'P3_PARAMETRO2'
,p_item_sequence=>70
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(89617041241199545)
,p_name=>'P3_CARD_OU_LISTA'
,p_item_sequence=>80
,p_item_default=>'GRI'
,p_prompt=>'Card Ou Lista'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(89617232959199547)
,p_name=>'P3_SEARCH_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(89617134193199546)
,p_prompt=>'Search'
,p_source=>'FILTRO_DATA_RANGE1'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'input_field', 'FACET',
  'search_type', 'ROW')).to_clob
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(89617343525199548)
,p_name=>'P3_ID_USUARIO_INCLUIU_1_1'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(89617134193199546)
,p_prompt=>'Data vigencia'
,p_source=>'CAMPO6'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P3_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''R1''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql is not null;       ',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'manual_entry', 'N',
  'select_multiple', 'N')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(89618693514199561)
,p_name=>'P3_NOME_DATA_RANGE1'
,p_item_sequence=>90
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P3_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''R1''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Nome Data Range1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp.component_end;
end;
/
