prompt --application/pages/page_09998
begin
--   Manifest
--     PAGE: 09998
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>9998
,p_name=>'Esquceu a senha'
,p_alias=>'ESQUCEU-A-SENHA'
,p_step_title=>'Esquceu a senha'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(222376265577622135)
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function toogleCard(id) {',
'   // Get the card-item based on the id',
'   console.log(''toogleCard id:''+id);',
'   let card = apex.jQuery(".a-CardView-item[data-id="+ id + "]");',
'',
'   // Get the cardView that holds the selection class',
'   let cardView = card.find("div.a-CardView");',
'',
'   // Look for the selected class',
'   if (cardView.hasClass("selected")) {',
'      cardView.removeClass("selected");',
'   } else {',
'      cardView.addClass("selected");',
'   }',
'}'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Alert{',
'    background-color: transparent;',
'    border: none;',
'    box-shadow: none;',
'}',
'',
'.t-Button{',
'    padding-left: 4px;',
'    padding-right: 4px;',
'}',
'',
'/* Reduce the opacity of images for selected items */',
'div.a-CardView.selected img.a-CardView-mediaImg {',
'  opacity: 0.5 !important;',
'}',
'',
'/* Add the check mark */',
'div.a-CardView.selected > .a-CardView-media:after{',
'  content: "\f058";',
'  font-size: 2rem;',
'  font-family: ''Font APEX Large'' !important;',
'  color: #2e5afd;',
'  position: absolute;',
'  z-index: 2;',
'  top: 0.5rem;',
'  right: 0.5rem;',
'}',
'',
'/* Overwrite the link opacity on focus and the transition */',
'.a-CardView-media a:focus {',
'    opacity: 1;',
'}',
'.a-CardView-media a {',
'   transition: none;',
'}',
'',
'/* Add box-shadow and border to highlight selected cards */',
'div.a-CardView.selected {',
'  box-shadow: 0 0 rgb(0 0 0 / 0.1), 0 0, 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);',
'  border-color: #2e5afd;',
'}'))
,p_step_template=>wwv_flow_imp.id(341000071649556215)
,p_page_template_options=>'#DEFAULT#:t-DeferredRendering'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(452807213049437124)
,p_plug_name=>'MPD'
,p_region_template_options=>'#DEFAULT#:t-Login-region--headerHidden js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(341088492083556263)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<img src="#APP_FILES#logo.png" style="height: 30px;" alt="Minha Figura"></img>',
'<div class="st-titulo-app">&APP_NAME.</div>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(176921609760472735)
,p_plug_name=>unistr('Enviar c\00F3digo de verfica\00E7\00E3o')
,p_parent_plug_id=>wwv_flow_imp.id(452807213049437124)
,p_region_css_classes=>'color-text'
,p_icon_css_classes=>'fa-user-magnifying-glass'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--customIcons:t-Alert--warning:t-Alert--removeHeading js-removeLandmark:t-Form--slimPadding'
,p_plug_template=>wwv_flow_imp.id(341005634629556219)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="st-titulo-login">Redefinir Senha</div>',
unistr('<div class="st-detalhe-login">Por favor, insira seu usu\00E1rio ou e-mail para localizarmos seu cadastro e enviarmos um c\00F3digo de verifica\00E7\00E3o:</div>')))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(47109004505421343)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(176921609760472735)
,p_button_name=>'UmEnvia'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--warning:t-Button--simple'
,p_button_template_id=>wwv_flow_imp.id(341144157120556305)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Enviar c\00F3digo de verifica\00E7\00E3o')
,p_button_position=>'PREVIOUS'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(47167749898840194)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(176921609760472735)
,p_button_name=>'DoisOuMaisEnvia'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--warning:t-Button--simple'
,p_button_template_id=>wwv_flow_imp.id(341144157120556305)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Enviar c\00F3digo de verifica\00E7\00E3o')
,p_button_position=>'PREVIOUS'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(47166788759840184)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(176921609760472735)
,p_button_name=>'cancel'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(341144157120556305)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'PREVIOUS'
,p_button_redirect_url=>'f?p=&APP_ID.:9999:&SESSION.::&DEBUG.:9999::'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(47165604703840172)
,p_branch_name=>'Um usuario'
,p_branch_action=>'f?p=&APP_ID.:9995:&SESSION.::&DEBUG.:9995:P9995_USERNAME:&P9998_USERNAME.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(47109004505421343)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(47165718911840173)
,p_branch_name=>unistr('Dois ou mais usu\00E1rio')
,p_branch_action=>'f?p=&APP_ID.:9995:&SESSION.::&DEBUG.:9995:P9995_USERNAME:&P9998_SELECIONADO.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(47167749898840194)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47164253141840159)
,p_name=>'P9998_SELECIONADO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(176921609760472735)
,p_prompt=>unistr('Selecione o usu\00E1rio para redefinir a senha:')
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT d, r',
'FROM (',
'    SELECT ',
'        UPPER(login) AS d,',
'        UPPER(login) AS r,',
'        COUNT(*) OVER () AS total_count',
'    FROM MPD_USUARIO',
'    WHERE lower(login) = lower(:P9998_USERNAME) OR lower(email) = lower(:P9998_USERNAME)',
') sub',
'WHERE total_count > 1;'))
,p_lov_cascade_parent_items=>'P9998_USERNAME'
,p_ajax_items_to_submit=>'P9998_USERNAME'
,p_ajax_optimize_refresh=>'Y'
,p_field_template=>wwv_flow_imp.id(341141590422556302)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47164951282840166)
,p_name=>'P9998_RESULT'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(452807213049437124)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47167353276840190)
,p_name=>'P9998_CONTA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(176921609760472735)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(176921030336472735)
,p_name=>'P9998_CONVITE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(452807213049437124)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(283091078685422663)
,p_name=>'P9998_USERNAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(176921609760472735)
,p_placeholder=>unistr('Usu\00E1rio ou E-mail')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>40
,p_cMaxlength=>100
,p_field_template=>wwv_flow_imp.id(341141341591556301)
,p_item_icon_css_classes=>'fa-user-magnifying-glass'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_inline_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<div class="u-color-39-text" id="la-nao">Usuario ou e-mail n\00E3o encontrado</div>'),
'<div class="u-color-35-text" id="la-sim">Usuario ou e-mail encontrado</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(47165516498840171)
,p_validation_name=>'Valid-Selecionado'
,p_validation_sequence=>10
,p_validation=>'P9998_SELECIONADO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Selecione o usu\00E1rio')
,p_when_button_pressed=>wwv_flow_imp.id(47167749898840194)
,p_associated_item=>wwv_flow_imp.id(47164253141840159)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(48034096637689453)
,p_name=>'Conta=0'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9998_CONTA'
,p_condition_element=>'P9998_CONTA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'0'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48034391227689456)
,p_event_id=>wwv_flow_imp.id(48034096637689453)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(47109004505421343)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48035408711689466)
,p_event_id=>wwv_flow_imp.id(48034096637689453)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9998_SELECIONADO'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48036062717689473)
,p_event_id=>wwv_flow_imp.id(48034096637689453)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(47167749898840194)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48035740767689469)
,p_event_id=>wwv_flow_imp.id(48034096637689453)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("#la-nao").show();',
'$("#la-sim").hide();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(165195183452149579)
,p_name=>'onChangeUsername'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9998_USERNAME'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keyup'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47167608050840192)
,p_event_id=>wwv_flow_imp.id(165195183452149579)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9998_CONTA'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    SELECT ',
'        COUNT(1) ',
'    FROM MPD_USUARIO',
'    WHERE lower(login) = lower(:P9998_USERNAME) OR lower(email) = lower(:P9998_USERNAME)',
''))
,p_attribute_07=>'P9998_USERNAME'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47164360719840160)
,p_event_id=>wwv_flow_imp.id(165195183452149579)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9998_SELECIONADO,P9998_CONTA'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48036040350689472)
,p_event_id=>wwv_flow_imp.id(165195183452149579)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("#la-nao").hide();',
'$("#la-sim").hide();'))
,p_client_condition_type=>'NULL'
,p_client_condition_element=>'P9998_USERNAME'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(48034818800689460)
,p_name=>'Conta=1'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9998_CONTA'
,p_condition_element=>'P9998_CONTA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48034883976689461)
,p_event_id=>wwv_flow_imp.id(48034818800689460)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(47109004505421343)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48036160188689474)
,p_event_id=>wwv_flow_imp.id(48034818800689460)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(47109004505421343)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48035085930689463)
,p_event_id=>wwv_flow_imp.id(48034818800689460)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(47167749898840194)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48036272699689475)
,p_event_id=>wwv_flow_imp.id(48034818800689460)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(47167749898840194)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48035500058689467)
,p_event_id=>wwv_flow_imp.id(48034818800689460)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9998_SELECIONADO'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48035801766689470)
,p_event_id=>wwv_flow_imp.id(48034818800689460)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("#la-nao").hide();',
'$("#la-sim").show();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(48033419112689446)
,p_name=>'Conta>1'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9998_CONTA'
,p_condition_element=>'P9998_CONTA'
,p_triggering_condition_type=>'GREATER_THAN'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48033484733689447)
,p_event_id=>wwv_flow_imp.id(48033419112689446)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(47167749898840194)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48036428143689476)
,p_event_id=>wwv_flow_imp.id(48033419112689446)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(47167749898840194)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48033738942689449)
,p_event_id=>wwv_flow_imp.id(48033419112689446)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(47109004505421343)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48036518847689477)
,p_event_id=>wwv_flow_imp.id(48033419112689446)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(47109004505421343)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48035295965689465)
,p_event_id=>wwv_flow_imp.id(48033419112689446)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9998_SELECIONADO'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48035906757689471)
,p_event_id=>wwv_flow_imp.id(48033419112689446)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("#la-nao").hide();',
'$("#la-sim").show();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(48037097349689483)
,p_name=>'New'
,p_event_sequence=>40
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48037589982689488)
,p_event_id=>wwv_flow_imp.id(48037097349689483)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(47109004505421343)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48037249152689485)
,p_event_id=>wwv_flow_imp.id(48037097349689483)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(47167749898840194)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48037459051689487)
,p_event_id=>wwv_flow_imp.id(48037097349689483)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9998_SELECIONADO'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48037387230689486)
,p_event_id=>wwv_flow_imp.id(48037097349689483)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("#la-nao").hide();',
'$("#la-sim").hide();'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(47164573762840162)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Um usuario'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_API_SEGURANCA'
,p_attribute_04=>'SEND_OTP'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(47109004505421343)
,p_internal_uid=>11786031751742017
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(47164729471840163)
,p_page_process_id=>wwv_flow_imp.id(47164573762840162)
,p_page_id=>9998
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P9998_RESULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(47164775164840164)
,p_page_process_id=>wwv_flow_imp.id(47164573762840162)
,p_page_id=>9998
,p_name=>'p_user_name'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P9998_USERNAME'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(47165075948840167)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>unistr('Dois ou mais usu\00E1rio')
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_API_SEGURANCA'
,p_attribute_04=>'SEND_OTP'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(47167749898840194)
,p_internal_uid=>11786533937742022
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(47165154254840168)
,p_page_process_id=>wwv_flow_imp.id(47165075948840167)
,p_page_id=>9998
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P9998_RESULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(47165247492840169)
,p_page_process_id=>wwv_flow_imp.id(47165075948840167)
,p_page_id=>9998
,p_name=>'p_user_name'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P9998_SELECIONADO'
);
wwv_flow_imp.component_end;
end;
/
