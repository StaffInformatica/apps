prompt --application/pages/page_00134
begin
--   Manifest
--     PAGE: 00134
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>134
,p_name=>unistr('Tradu\00E7\00E3o - Visualizar')
,p_alias=>unistr('TRADU\00C7\00C3O-VISUALIZAR')
,p_step_title=>unistr('Tradu\00E7\00E3o - Visualizar')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'',
'',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Body-side{',
'    width: auto;',
'    box-shadow: none;',
'    max-width: 450px;',
'}',
'',
'.a-IRR-button--actions{',
'    display: none;',
'}'))
,p_step_template=>wwv_flow_imp.id(340977852296556203)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'24'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(172100890458747779)
,p_plug_name=>'Painel esquerdo'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(287696429240391964)
,p_plug_name=>'tela.dados_gerais.l'
,p_parent_plug_id=>wwv_flow_imp.id(172100890458747779)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Begin   ',
'    Htp.p(''<div class="a-CardView">'');',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''tela.134.nome_aplicacao.l'',''fa-hardware'',:P134_PRIMARY_APPLICATION_NAME,p_label_fixo => ''s'',p_color=>''1''));',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''tela.134.numero_aplicacao.l'',''fa-key'',:P134_ID,p_label_fixo => ''s'',p_color=>''2''));',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''tela.134.workspace.l'',''fa-code-fork'',:P134_WORKSPACE,P_ULTIMO=>''s'',p_label_fixo => ''s'',p_color=>''3''));',
'    Htp.p(''</div>'');',
'End;'))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(336643702346798046)
,p_plug_name=>unistr('A\00E7\00F5es')
,p_region_name=>'ACTION'
,p_region_template_options=>'#DEFAULT#:js-dialog-nosize'
,p_component_template_options=>'t-MediaList--showIcons:t-MediaList--showDesc:u-colors'
,p_plug_template=>wwv_flow_imp.id(216292148774982531)
,p_plug_display_sequence=>80
,p_plug_display_point=>'REGION_POSITION_04'
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(341125559529556289)
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(426083509198707164)
,p_plug_name=>'tela.textos.l'
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_08'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(126778169259337833)
,p_name=>'Lista CR'
,p_region_name=>'LISTA_CR'
,p_parent_plug_id=>wwv_flow_imp.id(426083509198707164)
,p_template=>wwv_flow_imp.id(341046435992556242)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select from_string, to_string, language_code, application_id, APPLICATION_PAGE_ID, ',
'case when dbms_lob.substr(from_string,32767) <> dbms_lob.substr(to_string,32767) then ''S'' else ''N'' end as traduzido ',
'from apex_application_trans_repos',
'where application_id = :P134_ID'))
,p_display_condition_type=>'NEVER'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(341097593039556273)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(11941280261454120)
,p_query_column_id=>1
,p_column_alias=>'FROM_STRING'
,p_column_display_sequence=>110
,p_column_heading=>'From String'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(11941720746454122)
,p_query_column_id=>2
,p_column_alias=>'TO_STRING'
,p_column_display_sequence=>120
,p_column_heading=>'To String'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(11942061646454123)
,p_query_column_id=>3
,p_column_alias=>'LANGUAGE_CODE'
,p_column_display_sequence=>140
,p_column_heading=>'Language Code'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(11942499619454124)
,p_query_column_id=>4
,p_column_alias=>'APPLICATION_ID'
,p_column_display_sequence=>40
,p_column_heading=>'Application Id'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(11942869628454125)
,p_query_column_id=>5
,p_column_alias=>'APPLICATION_PAGE_ID'
,p_column_display_sequence=>160
,p_column_heading=>'Application Page Id'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(11943255340454126)
,p_query_column_id=>6
,p_column_alias=>'TRADUZIDO'
,p_column_display_sequence=>150
,p_column_heading=>'Traduzido'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(126780713911337858)
,p_plug_name=>'Pesquisa'
,p_parent_plug_id=>wwv_flow_imp.id(426083509198707164)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source_type=>'NATIVE_SMART_FILTERS'
,p_filtered_region_id=>wwv_flow_imp.id(126778169259337833)
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'compact_numbers_threshold', '10000',
  'more_filters_suggestion_chip', 'N',
  'show_total_row_count', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(53927795095231352481)
,p_plug_name=>'Lista'
,p_region_name=>'LISTA'
,p_parent_plug_id=>wwv_flow_imp.id(426083509198707164)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(341044399187556241)
,p_plug_display_sequence=>30
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql varchar(2000);',
'begin',
'    l_sql := q''~',
'        select ',
'            to_char(a.from_string) from_string,',
'            to_char(a.to_string) to_string,',
'            pkg_util.retorna_descricao_idioma_logado(b.id),',
'            a.application_id,',
'            a.id,',
'            APPLICATION_PAGE_ID,',
'            language_code,',
'            ''opcao'' as opcao',
'        from apex_application_trans_repos a',
'        left join srv_idioma b on lower(b.codigo) = lower(a.language_code)',
'        where a.application_id = :P134_ID        ',
'        -- and internal_attribute_name	in (',
'        --         ''APEX_PAGE_BUTTONS.BUTTON_IMAGE_ALT'',',
'        --         ''APEX_CARD_ACTIONS.LABEL'',',
'        --         ''APEX_PAGE_REGIONS.PLUG_NAME'',',
'        --         ''APEX_PAGE_ITEMS.PROMPT'',',
'        --         ''APEX_PAGE_ITEMS.PLACEHOLDER'',',
'        --         ''APEX_PAGE_ITEM_HELP.HELP_TEXT''',
'        --     )',
'        and (to_char(a.from_string) like ''%''||:P134_SEARCH||''%'' or to_char(a.to_string) like ''%''||:P134_SEARCH||''%'')',
'        and lower(a.language_code) = lower(nvl(:P134_IDIOMA,a.language_code))',
'        ~'';',
'    if :P134_TRADUZIDO = ''S'' then',
'        l_sql := l_sql || '' and dbms_lob.substr(from_string,32767) <> dbms_lob.substr(to_string,32767)'';',
'    else    ',
'        l_sql := l_sql || '' and dbms_lob.substr(from_string,32767) = dbms_lob.substr(to_string,32767)'';',
'    end if;    ',
'',
'    return l_sql;',
'end;',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P134_SEARCH,P134_IDIOMA,P134_TRADUZIDO'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Rela\00E7\00E3o dos assuntos a serem apresentados no tutorial')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(470924859296037747)
,p_max_row_count=>'1000000'
,p_show_search_textbox=>'N'
,p_report_list_mode=>'NONE'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'NORTHONN'
,p_internal_uid=>513795730956680020
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(126925958283210730)
,p_db_column_name=>'OPCAO'
,p_display_order=>40
,p_column_identifier=>'T'
,p_column_label=>'botao.opcoes.l'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'TMPL_BOT_O_LISTAGEM'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(126926155837210732)
,p_db_column_name=>'APPLICATION_ID'
,p_display_order=>50
,p_column_identifier=>'U'
,p_column_label=>'Application Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(126926294167210733)
,p_db_column_name=>'ID'
,p_display_order=>60
,p_column_identifier=>'V'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(126926521039210735)
,p_db_column_name=>'LANGUAGE_CODE'
,p_display_order=>70
,p_column_identifier=>'W'
,p_column_label=>'Language Code'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(126926566649210736)
,p_db_column_name=>'FROM_STRING'
,p_display_order=>80
,p_column_identifier=>'X'
,p_column_label=>'tela.134.texto_original.l'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(126926667397210737)
,p_db_column_name=>'TO_STRING'
,p_display_order=>90
,p_column_identifier=>'Y'
,p_column_label=>'tela.134.texto_traduzido.l'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(185419418100454553)
,p_db_column_name=>'APPLICATION_PAGE_ID'
,p_display_order=>100
,p_column_identifier=>'Z'
,p_column_label=>'tela.134.application_page_id.l'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39964991904705538)
,p_db_column_name=>'PKG_UTIL.RETORNA_DESCRICAO_IDIOMA_LOGADO(B.ID)'
,p_display_order=>110
,p_column_identifier=>'AA'
,p_column_label=>'Pkg Util.retorna Descricao Idioma Logado(b.id)'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(470998973702608311)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'448217'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'OPCAO:FROM_STRING:TO_STRING'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(53849122611670137326)
,p_plug_name=>'Form'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(341044399187556241)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    distinct WORKSPACE, ',
'    PRIMARY_APPLICATION_ID id, ',
'    PRIMARY_APPLICATION_NAME,',
'    pkg_traducao.lista_traducao(PRIMARY_APPLICATION_ID) as lista_aplicacao',
'from apex_application_trans_map '))
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11949892395454176)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(287696429240391964)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--danger:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_image_alt=>'botao.excluir.l'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:238:&SESSION.::&DEBUG.:238:P238_ID_APLICACAO:&P134_PRIMARY_APPLICATION_ID.'
,p_icon_css_classes=>'fa ico-trash-sm'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11948672088454170)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(53927795095231352481)
,p_button_name=>'gear'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_image_alt=>'Gear'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'t-Button--link  color-text'
,p_icon_css_classes=>'fa-gear'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1996787360262125)
,p_name=>'P134_LISTA_APLICACAO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(53849122611670137326)
,p_item_source_plug_id=>wwv_flow_imp.id(53849122611670137326)
,p_source=>'LISTA_APLICACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1996876186262126)
,p_name=>'P134_WORKSPACE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(53849122611670137326)
,p_item_source_plug_id=>wwv_flow_imp.id(53849122611670137326)
,p_source=>'WORKSPACE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11979787555635634)
,p_name=>'P134_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(53849122611670137326)
,p_item_source_plug_id=>wwv_flow_imp.id(53849122611670137326)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(93224272884897280)
,p_name=>'P134_CODIGO_ARTEFATO'
,p_item_sequence=>90
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(93224447772897281)
,p_name=>'P134_TELA_TITULO'
,p_item_sequence=>110
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(93224462594897282)
,p_name=>'P134_TELA_HELP'
,p_item_sequence=>120
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(125982863925950081)
,p_name=>'P134_PRIMARY_APPLICATION_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(53849122611670137326)
,p_item_source_plug_id=>wwv_flow_imp.id(53849122611670137326)
,p_source=>'PRIMARY_APPLICATION_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(126784996864337913)
,p_name=>'P134_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(126780713911337858)
,p_prompt=>'Search'
,p_placeholder=>'tela.buscar-por.l'
,p_source=>'FROM_STRING,TO_STRING'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'collapsed_search_field', 'N',
  'search_type', 'ROW')).to_clob
,p_fc_show_chart=>false
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(126785392584337917)
,p_name=>'P134_TRADUZIDO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(126780713911337858)
,p_prompt=>'tela.134.texto_traduzido.l'
,p_source=>'TRADUZIDO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov_sort_direction=>'ASC'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_compute_counts=>false
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
,p_ai_enabled=>false
,p_suggestions_type=>'STATIC'
,p_suggestions_source=>'S'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(126786048012337923)
,p_name=>'P134_IDIOMA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(126780713911337858)
,p_prompt=>'tela.134.idioma.l'
,p_source=>'LANGUAGE_CODE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'select pkg_util.retorna_descricao_idioma_logado(id) d, codigo r from srv_idioma'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_compute_counts=>false
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>false
,p_fc_display_as=>'INLINE'
,p_ai_enabled=>false
,p_suggestions_type=>'DYNAMIC'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11956480288454226)
,p_name=>'onClosedDelete'
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(11949892395454176)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11956990508454230)
,p_event_id=>wwv_flow_imp.id(11956480288454226)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'history.back()'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11957427336454231)
,p_name=>unistr('onClickAc\00F5es')
,p_event_sequence=>130
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(336643702346798046)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11957864737454234)
,p_event_id=>wwv_flow_imp.id(11957427336454231)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(336643702346798046)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11958165448454234)
,p_name=>'onChangePesquisa'
,p_event_sequence=>140
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(126780713911337858)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11958690677454236)
,p_event_id=>wwv_flow_imp.id(11958165448454234)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const milissegundos = 1 * 1000;',
'setTimeout(function() {',
'    apex.region("LISTA").refresh();',
'}, milissegundos);',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11959090752454237)
,p_name=>'onClickGear'
,p_event_sequence=>150
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(11948672088454170)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11959565611454238)
,p_event_id=>wwv_flow_imp.id(11959090752454237)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(336643702346798046)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1996764136262124)
,p_name=>'onMouseEnterTooltip'
,p_event_sequence=>160
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'$("#icon_info")'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'mouseenter'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1996645296262123)
,p_event_id=>wwv_flow_imp.id(1996764136262124)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'PLUGIN_COM.FOS.TOOLTIP'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'$("#icon_info")'
,p_attribute_01=>'static'
,p_attribute_05=>'&P134_TELA_HELP. (&P134_CODIGO_ARTEFATO.)'
,p_attribute_08=>'#007BFE'
,p_attribute_09=>'#FFFFFF'
,p_attribute_10=>'scale'
,p_attribute_11=>'500'
,p_attribute_12=>'hover'
,p_attribute_13=>'top'
,p_attribute_14=>'cache-result,escape-html'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(11953132429454188)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(53849122611670137326)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Mais detalhes do tutorial'
,p_internal_uid=>54824004090096461
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(11954589997454214)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'retorna_titulo_tela'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'RETORNA_TITULO_TELA'
,p_internal_uid=>54825461658096487
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(11955061409454221)
,p_page_process_id=>wwv_flow_imp.id(11954589997454214)
,p_page_id=>134
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P134_CODIGO_ARTEFATO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(11955540920454223)
,p_page_process_id=>wwv_flow_imp.id(11954589997454214)
,p_page_id=>134
,p_name=>'p_titulo'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P134_TELA_TITULO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(11956112501454224)
,p_page_process_id=>wwv_flow_imp.id(11954589997454214)
,p_page_id=>134
,p_name=>'p_help'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P134_TELA_HELP'
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(172736367486150835)
,p_ir_column_id=>wwv_flow_imp.id(126925958283210730)
,p_position_id=>wwv_flow_imp.id(159580458767641889)
,p_display_sequence=>10
,p_label=>'opcao_l'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:9000:&SESSION.::&DEBUG.:9000:P9000_ID,P9000_PAGINA:#ID#,134'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-ellipsis-v-o'
,p_action_css_classes=>'color-text'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp.component_end;
end;
/
