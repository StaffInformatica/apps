prompt --application/pages/page_00327
begin
--   Manifest
--     PAGE: 00327
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>327
,p_name=>unistr('Alterar configura\00E7\00E3o para a aplica\00E7\00E3o NG')
,p_alias=>unistr('ALTERAR-CONFIGURA\00C7\00C3O-PARA-A-APLICA\00C7\00C3O-NG1')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Alterar configura\00E7\00E3o para a aplica\00E7\00E3o NG')
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function copiarValor(origemId, destinoId) {',
'    var datePicker = document.getElementById(origemId);',
'    var valorOrigem = datePicker ? datePicker.value : ''''; ',
'    document.getElementById(destinoId).value = valorOrigem;',
'    console.log(document.getElementById(destinoId).value);',
'}',
'',
'function logValor(item){',
'    console.log(item);',
'    console.log(item.value);',
'    console.log(apex.item( "P9010_FILE1" ).getValue()); ',
'}',
'',
'function enviarParametros(dynamicItem,extra) {',
'    if (dynamicItem) {',
'        var dynamicArtefato = apex.item(''P9012_CODIGO_ARTEFATO'').value;        ',
'        var dynamicValue = dynamicItem.value;',
'        var dynamicId = extra == null ? dynamicItem.id : extra;',
'        console.log(dynamicArtefato);',
'        console.log(dynamicValue);',
'        console.log(dynamicId);',
'    } else {',
unistr('        console.error("O elemento din\00E2mico n\00E3o foi encontrado.");'),
'    }',
'    apex.server.process(',
'    "enviarParamentros", // Nome do processo PL/SQL definido no APEX',
'    {',
unistr('      x01: dynamicArtefato, // Primeiro par\00E2metro'),
unistr('      x02: dynamicId, // Segundo par\00E2metro'),
unistr('      x03: dynamicValue  // Terceiro par\00E2metro'),
'    },',
'    {',
'      dataType: ''text'',',
'      success: function(pData) {',
'        console.log("Dados enviados com sucesso:", pData);',
'      }',
'    }',
'  );',
'}',
'',
'function checkInputAndToggleClass(inputElement) {',
unistr('    // Verificar se o campo de entrada est\00E1 preenchido'),
'    console.log(inputElement.value);',
'    if (inputElement.value.trim() !== "") {',
unistr('        // Localizar a div pai que cont\00E9m "CONTAINER" no ID'),
'        let parentDiv = inputElement.closest("div[id*=''CONTAINER'']");',
'        ',
'        // Se a div for encontrada, adicionar a classe js-show-label',
'        if (parentDiv) {',
'            parentDiv.classList.add("js-show-label");',
'        }',
'    } else {',
'        // Se o valor estiver vazio, remover a classe js-show-label',
'        let parentDiv = inputElement.closest("div[id*=''CONTAINER'']");',
'        ',
'        // Remover a classe js-show-label se ela existir',
'        if (parentDiv) {',
'            parentDiv.classList.remove("js-show-label");',
'        }',
'    }',
'}',
'',
'// function toggleFileUpload() {',
'//     // Seleciona o elemento <a-dynamic-content>',
'//     var dynamicContent = document.querySelector(''a-dynamic-content'');',
'//     console.log(dynamicContent);',
unistr('//     // Verifica se o elemento existe e se cont\00E9m a palavra "mostra_file"'),
'//     if (dynamicContent && dynamicContent.innerHTML.includes(''mostra_file'')) {',
'//         // Se encontrar, mostra o item de upload de arquivo',
'//         apex.item(''P9010_FILE1'').show();',
'//     } else {',
unistr('//         // Caso contr\00E1rio, oculta o item de upload de arquivo'),
'//         apex.item(''P9010_FILE1'').hide();',
'//     }',
'// }',
'',
'document.addEventListener("DOMContentLoaded", function() {',
'  //   toggleFileUpload();  ',
'  var windowWidth = 400;  // Largura da janela popup',
'  var windowHeight = 450;  // Altura da janela popup',
'',
'  // Calcula o centro da tela',
'  var left = (window.screen.width - windowWidth) / 2;',
'  var top = (window.screen.height - windowHeight) / 2;',
'',
unistr('  // Modifica os par\00E2metros de ''left'' e ''top'' no popup gerado'),
'  var originalOpen = window.open;',
'  window.open = function(url, name, specs) {',
unistr('    // Adiciona ou substitui os par\00E2metros ''left'' e ''top'''),
'    specs = specs.replace(/left=\d+/, ''left='' + left);',
'    specs = specs.replace(/top=\d+/, ''top='' + top);',
'',
unistr('    // Se ''left'' e ''top'' n\00E3o existirem, adiciona os par\00E2metros'),
'    if (!specs.includes(''left='')) specs += '',left='' + left;',
'    if (!specs.includes(''top='')) specs += '',top='' + top;',
'',
unistr('    // Chama a fun\00E7\00E3o window.open original com as modifica\00E7\00F5es'),
'    return originalOpen.call(window, url, name, specs);',
'  };',
'});',
'',
'function  disableRowSelector ( ) { ',
'  var records = $( ".a-GV" ). first (). find ( ".a-GV-w-scroll .a-GV-row" ); ',
'  for ( var i = 0 ; i < records. length ; i++) { ',
'    var isReadonly = records. eq (i)[ 0 ]. matches ( ''.is-readonly'' ); ',
'    if (isReadonly) { ',
'        var dataId = records. eq (i). attr ( "data-id" ); ',
unistr('        // Remove a caixa de sele\00E7\00E3o dessa linha'),
'         $( ".a-GV" ). first (). find ( ".a-GV-row[data-id=''" + dataId + "''] .u-selector" ). removeClass (); ',
'    } ',
'  } ',
'}',
'',
'// Aumenta largura e altura do a-select moderno',
'document.addEventListener("DOMContentLoaded", function() {',
'    const item = document.querySelector("#P327_ENTIDADE");',
'    if(item) {',
'        // faz o a-select ocupar toda a coluna',
'        item.style.width = "100%";',
'',
'        // ajusta input interno',
'        const input = item.querySelector("input.apex-item-text");',
'        if(input) {',
'            input.style.height = "36px";',
'            input.style.lineHeight = "36px";',
'            input.style.padding = "0 10px";',
'            input.style.fontSize = "14px";',
'        }',
'',
unistr('        // ajusta bot\00E3o do dropdown'),
'        const btn = item.querySelector("button.a-Button");',
'        if(btn) btn.style.height = "36px";',
'    }',
'});',
''))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'tituloTela($v("P327_TELA_TITULO")+'' (''+$v("P327_CODIGO_ARTEFATO")+'')'');',
'',
'// Intercepta o fechamento nativo do dialog',
'apex.jQuery(document).on("dialogclose", ".ui-dialog", function(event, ui){',
'    var dlg = $(this).closest(".ui-dialog-content");',
'    if(dlg.attr("id") === "PXX_MODAL_B") { // substitua PXX_MODAL_B pelo Static ID da Modal B',
'        event.stopImmediatePropagation(); // impede fechar todas as modais',
unistr('        apex.navigation.dialog.close(false); // fecha s\00F3 esta modal'),
'    }',
'});',
'',
unistr('// Quando a p\00E1gina carregar'),
'$(document).ready(function() {',
'    // Aplica estilo ao input',
'    $(''#P327_ENTIDADE'').closest(''.t-Form-inputContainer'').find(''input'').css({',
'        ''height'': ''40px'',',
'        ''border-radius'': ''8px'',',
'        ''padding'': ''0 10px'',',
'        ''font-size'': ''14px''',
'    });',
'',
'    // Estilo do dropdown do Select One (jQuery UI autocomplete)',
'    $(''#P327_ENTIDADE'').on(''apexafterrefresh'', function() {',
'        $(''.ui-autocomplete'').css({',
'            ''max-height'': ''200px'',',
'            ''overflow-y'': ''auto'',',
'            ''border-radius'': ''8px'',',
'            ''font-size'': ''14px''',
'        });',
'    });',
'});',
'',
'// $(document).ready(function() {',
'//     $(''#P327_ENTIDADE'').closest(''.t-Form-inputContainer'')',
'//         .css(''width'', ''100%'') // garante que o container ocupe toda a coluna',
'//         .find(''input[type="text"]'')',
'//         .css({',
'//             ''width'': ''100%'',       // ocupa toda a coluna',
'//             ''height'': ''38px'',      // igual aos Text Items',
'//             ''line-height'': ''38px'', // alinhamento vertical',
'//             ''padding'': ''0 10px'',',
'//             ''font-size'': ''14px'',',
'//             ''border-radius'': ''4px''',
'//         });',
'// });',
'',
unistr('// Quando a p\00E1gina carregar'),
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Form-label{',
'    padding-block-start: 5px!important;',
'}',
'',
'.centro{',
'    display: grid;',
'    justify-items: center;',
'}',
'',
'.select option.selected {',
'    color: #888; /* Cor mais clara para parecer um placeholder */',
'    opacity: 0.5; /* Reduz a opacidade */',
'}',
'',
'tr.linha-desabilitada {',
'    background-color: #f2f2f2;',
'    opacity: 0.6;',
'    cursor: not-allowed;',
'}',
'',
'.t-Region-title {    ',
'    word-break: break-word;',
'    -webkit-hyphens: auto;',
'    hyphens: auto;',
'    font-size: var(--a-cv-title-font-size, 16px);',
'    font-weight: var(--a-cv-title-font-weight, 700);',
'    line-height: var(--a-cv-title-line-height, 20px);',
'    color: var(--a-cv-title-text-color);',
'}',
'',
'.a-GV-footer {',
'    display: none;',
'}',
'',
'.a-GV-header.u-tS.is-required.is-readonly  {',
'    pointer-events: none !important;',
'}',
'',
'.a-GV-frozen--startLast{',
'    border-right-width: 1px !important;',
'}',
'',
'#ITENS_SALDO_ig col[data-idx="1"] {',
'  width: 20% !important;',
'}',
'',
'#ITENS_SALDO_ig col[data-idx="2"] {',
'  width: 80% !important;',
'}',
'',
'/* Garante que o texto da primeira coluna possa quebrar normalmente */',
'#ITENS_SALDO_ig td:nth-child(2),',
'#ITENS_SALDO_ig th:nth-child(2) {',
'  white-space: normal !important;',
'  word-break: break-word;',
'}',
'',
'.texto-cabecalho{    ',
'    font-size: var(--a-field-input-font-size, 0.75rem);    ',
'    font-weight: var(--a-field-input-font-weight, 400);',
'}',
'',
'.is-readonly.apex-item-wrapper--display-only.opacity_grupo_funcionalidade {',
'    opacity: 0.9; ',
'    color: #444 !important; /* muda a cor do texto */',
'}',
'',
'/* Aumenta a largura do input do Popup LOV */',
'.wide-input .a-InputText,',
'.wide-input input[type="text"] {',
'    width: 100% !important; /* ocupa toda a coluna */',
unistr('    min-width: 300px;        /* largura m\00EDnima */'),
'    font-size: 14px;         /* opcional: aumenta fonte */',
'    height: 36px;            /* opcional: aumenta altura */',
'    box-sizing: border-box;  /* padding incluso na largura */',
'}',
'',
unistr('/* For\00E7a o input do Popup LOV a ocupar toda a coluna */'),
'#P327_ENTIDADE .apex-item-comboselect input[type="text"] {',
'    width: 100% !important;   /* ocupa 100% da coluna */',
unistr('    min-width: 300px;          /* largura m\00EDnima */'),
unistr('    max-width: 100%;           /* n\00E3o ultrapassa a coluna */'),
'    height: 36px;              /* altura maior, opcional */',
'    font-size: 14px;           /* opcional */',
'    box-sizing: border-box;    /* padding incluso na largura */',
'}',
'',
'.teste {',
'        border-radius: 20px;',
'}',
'',
'',
'',
'',
'#P327_VALOR_STRING_CONTAINER .apex-item-group--textarea {',
'  border-radius: 15px;            /* arredonda os cantos */',
'}',
'',
'#P327_VALOR_STRING_CONTAINER textarea {',
'',
'  border-radius: 15px;            /* opcional: acompanha a borda externa */',
'}',
''))
,p_step_template=>wwv_flow_imp.id(340974912275556190)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--lg'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(301852268270101126)
,p_plug_name=>'Alterar'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody:t-Form--large'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>60
,p_query_type=>'TABLE'
,p_query_table=>'NG_CONFIGURACAO'
,p_include_rowid_column=>true
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(481356701106499796)
,p_plug_name=>'Steps'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#:t-WizardSteps--displayLabels'
,p_plug_template=>wwv_flow_imp.id(341059031473556249)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_list_id=>wwv_flow_imp.id(54671805757226236)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(341136199098556298)
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(481357183538501443)
,p_plug_name=>'Footer'
,p_region_css_classes=>'u-margin-bottom-none'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(341013639389556225)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(54615566387226461)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(481357183538501443)
,p_button_name=>'inclui_e_fecha'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(341144157120556305)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Gravar'
,p_button_position=>'NEXT'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(54616008649226459)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(481357183538501443)
,p_button_name=>'inclui_e_fecha_1'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(341144157120556305)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Gravar'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(54670093858226258)
,p_branch_name=>'goto_anterior'
,p_branch_action=>'P327_URL_ANTERIOR'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'BRANCH_TO_URL_IDENT_BY_ITEM'
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(54670464104226257)
,p_branch_name=>'goto_proximo'
,p_branch_action=>'P327_URL_PROXIMO'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'BRANCH_TO_URL_IDENT_BY_ITEM'
,p_branch_sequence=>30
,p_branch_condition_type=>'REQUEST_IN_CONDITION'
,p_branch_condition=>'PROXIMO'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(54670861548226256)
,p_branch_name=>'Grava'
,p_branch_action=>unistr('f?p=&APP_ID.:9000:&SESSION.::&DEBUG.:CR,9000:P9000_LABEL_TELA,P9000_PAGINA,P9000_ID:Op\00E7\00F5es,TD882,&P327_PARAMETRO.&success_msg=#SUCCESS_MSG#')
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>40
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(125873162502183504)
,p_name=>'P327_EMPRESA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_css_classes=>'is-readonly apex-item-wrapper--display-only '
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(125873398452183506)
,p_name=>'P327_DESCRICAO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_prompt=>unistr('Descri\00E7\00E3o')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_css_classes=>'is-readonly apex-item-wrapper--display-only'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(125951910525220204)
,p_name=>'P327_ROWID'
,p_source_data_type=>'ROWID'
,p_is_primary_key=>true
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_item_source_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_source=>'ROWID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(125952111910220206)
,p_name=>'P327_CODIGO_CONFIGURACAO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_item_source_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_source=>'CODIGO_CONFIGURACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(126033616340403658)
,p_name=>'P327_IND_TIPO_DADO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_item_source_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_source=>'IND_TIPO_DADO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(126033761887403659)
,p_name=>'P327_VALOR_INTEIRO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_item_source_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_prompt=>'Valor Inteiro'
,p_format_mask=>'9999999'
,p_source=>'VALOR_INTEIRO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_display_when=>'P327_IND_TIPO_DADO'
,p_display_when2=>'IN'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(126033850319403660)
,p_name=>'P327_VALOR_DECIMAL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_item_source_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_prompt=>'Valor Decimal'
,p_source=>'VALOR_DECIMAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_display_when=>'P327_IND_TIPO_DADO'
,p_display_when2=>'DE'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_css_classes=>'is-readonly '
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(126033936349403661)
,p_name=>'P327_QUANTIDADE_DECIMAL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_item_source_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_source=>'QUANTIDADE_DECIMAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when=>'P327_IND_TIPO_DADO'
,p_display_when2=>'DE'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(126034076132403662)
,p_name=>'P327_VALOR_STRING'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_item_source_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_prompt=>'Valor String'
,p_source=>'VALOR_STRING'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>400
,p_cHeight=>5
,p_display_when=>'P327_IND_TIPO_DADO'
,p_display_when2=>'ST'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_css_classes=>'teste'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(126034119902403663)
,p_name=>'P327_VALOR_DATA'
,p_source_data_type=>'DATE'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_item_source_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_prompt=>'Valor Data'
,p_source=>'VALOR_DATA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_display_when=>'P327_IND_TIPO_DADO'
,p_display_when2=>'DT'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(126034239236403664)
,p_name=>'P327_VALOR_DATA_HORA'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_item_source_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_prompt=>'Valor Data Hora'
,p_source=>'VALOR_DATA_HORA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_display_when=>'P327_IND_TIPO_DADO'
,p_display_when2=>'DH'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'Y',
  'use_defaults', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(126034302856403665)
,p_name=>'P327_ID_ENTIDADE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_item_source_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_source=>'ID_ENTIDADE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(126034460883403666)
,p_name=>'P327_ID_REGISTRO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_item_source_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_source=>'ID_REGISTRO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(126034523574403667)
,p_name=>'P327_VALOR_DOMINIO'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_prompt=>'Valor Dominio'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- select id_registro',
'--   from ng_configuracao',
'--  where id = :P327_PARAMETRO',
unistr('--    and instr(id_registro, '':'') = 0 -- s\00F3 traz se n\00E3o tiver '':'''),
'',
'',
'--   select',
'--     b.descricao_dominio as display_value,',
'--     b.id ',
'-- from ng_configuracao a',
'-- join ng_configuracao_dominio b on b.id_configuracao = a.id',
'-- where a.id = :P327_PARAMETRO',
'-- order by b.descricao_dominio',
'',
'',
'select valor_dominio',
'  from ng_configuracao',
' where id = :P327_PARAMETRO'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    b.descricao_dominio as display_value,',
'    b.id as return_value',
'from ng_configuracao a',
'join ng_configuracao_dominio b on b.id_configuracao = a.id',
'where a.id = :P327_PARAMETRO',
'order by b.descricao_dominio',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when=>'P327_IND_TIPO_DADO'
,p_display_when2=>'DO'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(126034683188403668)
,p_name=>'P327_IND_SITUACAO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_item_source_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_source=>'IND_SITUACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(126334604003236657)
,p_name=>'P327_ENTIDADESSWE'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_prompt=>unistr('Identifica\00E7\00E3o')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select replace(',
'         nvl(',
'           (select id_registro',
'              from ng_configuracao',
'             where id = :P327_PARAMETRO),',
'           ''''',
'         ),',
'         '':'',',
'         chr(10)',
'       ) as display_value',
'from dual'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_display_when=>'P327_IND_TIPO_DADO'
,p_display_when2=>'IM'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(126335056655236661)
,p_name=>'P327_ENTIDADE-2'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_prompt=>unistr('Identifica\00E7\00E3o')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id_registro',
'  from ng_configuracao',
' where id = :P327_PARAMETRO',
unistr('   and instr(id_registro, '':'') = 0 -- s\00F3 traz se n\00E3o tiver '':''')))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  l_colunas VARCHAR2(4000);',
'  l_tabela  VARCHAR2(4000);',
'BEGIN',
'  SELECT LISTAGG(A.NOME_COLUNA,''||''''-''''||'') WITHIN GROUP (ORDER BY A.NOME_COLUNA),',
'         B.NOME_ENTIDADE',
'    INTO l_colunas, l_tabela',
'    FROM SRV_ENTIDADE_COLUNA A',
'    JOIN SRV_ENTIDADE B ON B.ID = A.ID_ENTIDADE',
'   WHERE ID_ENTIDADE = :P327_ID_ENTIDADE',
'     AND REFERENCIA IS NOT NULL',
'   GROUP BY B.NOME_ENTIDADE;',
'',
'  IF l_colunas IS NOT NULL AND l_tabela IS NOT NULL THEN',
'    RETURN ''SELECT ''||l_colunas||'' AS display_value, ID AS return_value FROM ''|| l_tabela;',
'  ELSE',
'    RETURN ''SELECT 1 AS display_value, 1 AS return_value FROM dual'';',
'  END IF;',
'',
'EXCEPTION',
'  WHEN OTHERS THEN',
'    RETURN ''SELECT 1 AS display_value, 1 AS return_value FROM dual'';',
'END;',
'',
'',
'',
'-- declare',
'--     l_sql      varchar2(4000);',
'--     l_tabela   varchar2(30);',
'--     l_coluna   varchar2(30);',
'-- begin',
'--     -- tenta buscar a tabela',
'--     begin',
'--         select b.nome_entidade ',
'--           into l_tabela',
'--         from ng_configuracao a',
'--         join srv_entidade b on b.id = a.id_entidade',
'--         where a.id = :P327_PARAMETRO;',
'--     exception',
'--         when no_data_found then',
'--             l_tabela := null;',
'--     end;',
'',
'--     -- tenta buscar coluna',
'--     if l_tabela is not null then',
'--         begin',
'--             select column_name',
'--               into l_coluna',
'--               from all_tab_columns',
'--              where table_name = upper(l_tabela)',
'--                and (column_name like ''%NOME%'' or column_name like ''%DESCRICAO%'')',
'--                and column_id = (',
'--                     select min(column_id)',
'--                       from all_tab_columns',
'--                      where table_name = upper(l_tabela)',
'--                        and (column_name like ''%NOME%'' or column_name like ''%DESCRICAO%'')',
'--                );',
'--         exception',
'--             when no_data_found then',
'--                 l_coluna := ''ID'';',
'--         end;',
'',
'--         l_sql := ''select ''||l_coluna||'' as display_value, id as return_value from '' || l_tabela;',
'--     else',
unistr('--         -- se n\00E3o achou nada, devolve query vazia'),
'--         l_sql := ''select null as display_value, null as return_value from dual where 1=2'';',
'--     end if;',
'',
'--     return l_sql;',
'-- end;',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when=>'P327_IND_TIPO_DADO'
,p_display_when2=>'ID'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(126335174545236662)
,p_name=>'P327_VALOR_DOMINIOS1'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_prompt=>'DOMINIOS'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select trim(column_value)',
'  from table(',
'         apex_string.split(',
'             nvl(',
'                 (select valor_dominio',
'                    from ng_configuracao',
'                   where id = :P327_PARAMETRO),',
'                 ''''',
'             ),',
'             '':''',
'         )',
'       )',
' where trim(column_value) is not null'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql varchar2(4000);',
'begin',
'    if :P327_PARAMETRO is not null then',
'        l_sql :=',
'            ''select',
'                 b.descricao_dominio as display_value,',
'                 b.id as return_value',
'             from ng_configuracao a',
'             join ng_configuracao_dominio b on b.id_configuracao = a.id',
'             where a.id = '' || :P327_PARAMETRO || ''',
'             order by b.descricao_dominio'';',
'    else',
'        l_sql := ''select null as display_value, null as return_value from dual where 1=2'';',
'    end if;',
'',
'    return l_sql;',
'end;',
''))
,p_cHeight=>5
,p_display_when=>'P327_IND_TIPO_DADO'
,p_display_when2=>'DM'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'ALL')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(126335675066236667)
,p_name=>'P327_VALOR_DOMINIOS'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_prompt=>'DOMINIOS'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select trim(column_value)',
'  from table(',
'         apex_string.split(',
'             nvl(',
'                 (select valor_dominio',
'                    from ng_configuracao',
'                   where id = :P327_PARAMETRO),',
'                 ''''',
'             ),',
'             '':''',
'         )',
'       )',
' where trim(column_value) is not null'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql varchar2(4000);',
'begin',
'    if :P327_PARAMETRO is not null then',
'        l_sql :=',
'            ''select',
'                 b.descricao_dominio as display_value,',
'                 b.id as return_value',
'             from ng_configuracao a',
'             join ng_configuracao_dominio b on b.id_configuracao = a.id',
'             where a.id = '' || :P327_PARAMETRO || ''',
'             order by b.descricao_dominio'';',
'    else',
'        l_sql := ''select null as display_value, null as return_value from dual where 1=2'';',
'    end if;',
'',
'    return l_sql;',
'end;',
''))
,p_display_when=>'P327_IND_TIPO_DADO'
,p_display_when2=>'DM'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(126336011958236671)
,p_name=>'P327_ENTIDADE'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_prompt=>unistr('Identifica\00E7\00E3o')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id_registro',
'  from ng_configuracao',
' where id = :P327_PARAMETRO',
unistr('   and instr(id_registro, '':'') = 0 -- s\00F3 traz se n\00E3o tiver '':''')))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  l_colunas VARCHAR2(4000);',
'  l_tabela  VARCHAR2(4000);',
'  l_id_entidade number;',
'BEGIN',
'  select id_entidade into l_id_entidade from ng_configuracao where id = :P327_PARAMETRO;',
'  SELECT LISTAGG(A.NOME_COLUNA,''||''''-''''||'') WITHIN GROUP (ORDER BY A.NOME_COLUNA),',
'         B.NOME_ENTIDADE',
'    INTO l_colunas, l_tabela',
'    FROM SRV_ENTIDADE_COLUNA A',
'    JOIN SRV_ENTIDADE B ON B.ID = A.ID_ENTIDADE',
'   WHERE ID_ENTIDADE = l_id_entidade',
'     AND REFERENCIA IS NOT NULL',
'   GROUP BY B.NOME_ENTIDADE;',
'',
'  IF l_colunas IS NOT NULL AND l_tabela IS NOT NULL THEN',
'    RETURN ''SELECT ''||l_colunas||'' AS display_value, ID AS return_value FROM ''|| l_tabela;',
'  ELSE',
'    RETURN ''SELECT 2 AS display_value, 1 AS return_value FROM dual'';',
'  END IF;',
'',
'EXCEPTION',
'  WHEN OTHERS THEN',
'    RETURN ''SELECT 1 AS display_value, 1 AS return_value FROM dual'';',
'END;',
'',
'',
'-- declare',
'--     l_sql      varchar2(4000);',
'--     l_tabela   varchar2(30);',
'--     l_coluna   varchar2(30);',
'-- begin',
'--     -- tenta buscar a tabela',
'--     begin',
'--         select b.nome_entidade ',
'--           into l_tabela',
'--         from ng_configuracao a',
'--         join srv_entidade b on b.id = a.id_entidade',
'--         where a.id = :P327_PARAMETRO;',
'--     exception',
'--         when no_data_found then',
'--             l_tabela := null;',
'--     end;',
'',
'--     -- tenta buscar coluna',
'--     if l_tabela is not null then',
'--         begin',
'--             select column_name',
'--               into l_coluna',
'--               from all_tab_columns',
'--              where table_name = upper(l_tabela)',
'--                and (column_name like ''%NOME%'' or column_name like ''%DESCRICAO%'')',
'--                and column_id = (',
'--                     select min(column_id)',
'--                       from all_tab_columns',
'--                      where table_name = upper(l_tabela)',
'--                        and (column_name like ''%NOME%'' or column_name like ''%DESCRICAO%'')',
'--                );',
'--         exception',
'--             when no_data_found then',
'--                 l_coluna := ''ID'';',
'--         end;',
'',
'--         l_sql := ''select ''||l_coluna||'' as display_value, id as return_value from '' || l_tabela;',
'--     else',
unistr('--         -- se n\00E3o achou nada, devolve query vazia'),
'--         l_sql := ''select null as display_value, null as return_value from dual where 1=2'';',
'--     end if;',
'',
'--     return l_sql;',
'-- end;',
''))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P327_ID,P327_PARAMETRO'
,p_ajax_items_to_submit=>'P327_ENTIDADE'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>100
,p_tag_css_classes=>'wide-input'
,p_colspan=>12
,p_display_when=>'P327_IND_TIPO_DADO'
,p_display_when2=>'ID'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(341141590422556302)
,p_item_css_classes=>'wide-input'
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0',
  'width', '1500')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(126336130334236672)
,p_name=>'P327_ENTIDADE3'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_prompt=>'Entidade3'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id_registro',
'  from ng_configuracao',
' where id = :P327_PARAMETRO',
unistr('   and instr(id_registro, '':'') = 0 -- s\00F3 traz se n\00E3o tiver '':''')))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_SELECT_ONE'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  l_colunas VARCHAR2(4000);',
'  l_tabela  VARCHAR2(4000);',
'BEGIN',
'  SELECT LISTAGG(A.NOME_COLUNA,''||''''-''''||'') WITHIN GROUP (ORDER BY A.NOME_COLUNA),',
'         B.NOME_ENTIDADE',
'    INTO l_colunas, l_tabela',
'    FROM SRV_ENTIDADE_COLUNA A',
'    JOIN SRV_ENTIDADE B ON B.ID = A.ID_ENTIDADE',
'   WHERE ID_ENTIDADE = :P327_ID_ENTIDADE',
'     AND REFERENCIA IS NOT NULL',
'   GROUP BY B.NOME_ENTIDADE;',
'',
'  IF l_colunas IS NOT NULL AND l_tabela IS NOT NULL THEN',
'    RETURN ''SELECT ''||l_colunas||'' AS display_value, ID AS return_value FROM ''|| l_tabela;',
'  ELSE',
'    RETURN ''SELECT 1 AS display_value, 1 AS return_value FROM dual'';',
'  END IF;',
'',
'EXCEPTION',
'  WHEN OTHERS THEN',
'    RETURN ''SELECT 1 AS display_value, 1 AS return_value FROM dual'';',
'END;',
'',
'',
'',
'-- declare',
'--     l_sql      varchar2(4000);',
'--     l_tabela   varchar2(30);',
'--     l_coluna   varchar2(30);',
'-- begin',
'--     -- tenta buscar a tabela',
'--     begin',
'--         select b.nome_entidade ',
'--           into l_tabela',
'--         from ng_configuracao a',
'--         join srv_entidade b on b.id = a.id_entidade',
'--         where a.id = :P327_PARAMETRO;',
'--     exception',
'--         when no_data_found then',
'--             l_tabela := null;',
'--     end;',
'',
'--     -- tenta buscar coluna',
'--     if l_tabela is not null then',
'--         begin',
'--             select column_name',
'--               into l_coluna',
'--               from all_tab_columns',
'--              where table_name = upper(l_tabela)',
'--                and (column_name like ''%NOME%'' or column_name like ''%DESCRICAO%'')',
'--                and column_id = (',
'--                     select min(column_id)',
'--                       from all_tab_columns',
'--                      where table_name = upper(l_tabela)',
'--                        and (column_name like ''%NOME%'' or column_name like ''%DESCRICAO%'')',
'--                );',
'--         exception',
'--             when no_data_found then',
'--                 l_coluna := ''ID'';',
'--         end;',
'',
'--         l_sql := ''select ''||l_coluna||'' as display_value, id as return_value from '' || l_tabela;',
'--     else',
unistr('--         -- se n\00E3o achou nada, devolve query vazia'),
'--         l_sql := ''select null as display_value, null as return_value from dual where 1=2'';',
'--     end if;',
'',
'--     return l_sql;',
'-- end;',
''))
,p_tag_css_classes=>'big-select'
,p_grid_row_css_classes=>'big-select'
,p_colspan=>12
,p_display_when=>'P327_IND_TIPO_DADO'
,p_display_when2=>'ID'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(341141590422556302)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'fetch_on_search', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129094083825803564)
,p_name=>'P327_ENTIDADESS'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_prompt=>unistr('Identifica\00E7\00E3o')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select trim(column_value)',
'  from table(',
'         apex_string.split(',
'             nvl(',
'                 (select id_registro',
'                    from ng_configuracao',
'                   where id = :P327_PARAMETRO),',
'                 ''''',
'             ),',
'             '':''',
'         )',
'       )',
' where trim(column_value) is not null'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_sql VARCHAR2(4000);',
'BEGIN',
'    IF :P327_ID_ENTIDADE IS NULL THEN',
'        RETURN ''SELECT 1 AS display_value, 1 AS return_value FROM dual'';',
'    END IF;',
'',
'    SELECT ''SELECT '' ||',
'           LISTAGG(A.NOME_COLUNA, '' || '''' - '''' || '') WITHIN GROUP (ORDER BY A.NOME_COLUNA) ||',
'           '' AS display_value, ID AS return_value FROM '' || B.NOME_ENTIDADE',
'      INTO l_sql',
'      FROM SRV_ENTIDADE_COLUNA A',
'      JOIN SRV_ENTIDADE B ON B.ID = A.ID_ENTIDADE',
'     WHERE A.ID_ENTIDADE = :P327_ID_ENTIDADE',
'       AND A.REFERENCIA IS NOT NULL',
'     GROUP BY B.NOME_ENTIDADE;',
'',
'    RETURN l_sql;',
'',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'        RETURN ''SELECT 1 AS display_value, 1 AS return_value FROM dual'';',
'    WHEN OTHERS THEN',
'        RETURN ''SELECT 1 AS display_value, 1 AS return_value FROM dual'';',
'END;',
''))
,p_lov_cascade_parent_items=>'P327_ID_ENTIDADE'
,p_ajax_items_to_submit=>'P327_ID_ENTIDADE'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>5
,p_display_when=>'P327_IND_TIPO_DADO'
,p_display_when2=>'IM'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(341141590422556302)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'ALL')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(301858254850101162)
,p_name=>'P327_ID_TENANT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_item_source_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_source=>'ID_TENANT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(301869607143197119)
,p_name=>'P327_GRUPO_FUNCIONALIDADE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_prompt=>'Grupo de funcionalidade'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.ind_grupo_funcionalidade',
'from ng_configuracao a',
'where a.id = :P327_PARAMETRO;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'D_NG_CONFIGURACAO.IND_GRUPO_FUNCIONALIDADE'
,p_lov=>'select * from pkg_util.dominio_retorna_lista(''ng_configuracao'',''ind_grupo_funcionalidade'') order by 1'
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_css_classes=>'is-readonly apex-item-wrapper--display-only opacity_grupo_funcionalidade'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(301870699680197130)
,p_name=>'P327_ID_USUARIO_INCLUIU'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_item_source_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_source=>'ID_USUARIO_INCLUIU'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(301870841850197131)
,p_name=>'P327_DATA_INCLUSAO'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_item_source_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_source=>'DATA_INCLUSAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(301870904289197132)
,p_name=>'P327_ID_USUARIO_ALTEROU'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_item_source_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_source=>'ID_USUARIO_ALTEROU'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(301871038206197133)
,p_name=>'P327_DATA_ALTERACAO'
,p_source_data_type=>'DATE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_item_source_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_source=>'DATA_ALTERACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(302208914184523621)
,p_name=>'P327_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_item_source_plug_id=>wwv_flow_imp.id(301852268270101126)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(302284723780523849)
,p_name=>'P327_PARAMETRO'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(306210824215607975)
,p_name=>'P327_INCREMENTA_ENTREGA_ATUAL_CONTADOR'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(306422520990891368)
,p_name=>'P327_REINICIAR_PAGAMENTOS'
,p_item_sequence=>190
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(339369797907990604)
,p_name=>'P327_CODIGO_WIZARD'
,p_item_sequence=>150
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(406123026950642586)
,p_name=>'P327_URL_PROXIMO'
,p_item_sequence=>160
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(406123124257642587)
,p_name=>'P327_URL_ANTERIOR'
,p_item_sequence=>170
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(432533250728764179)
,p_name=>'P327_ETAPA'
,p_item_sequence=>180
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(555152295063884811)
,p_name=>'P327_PARAMETRO2'
,p_item_sequence=>90
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(555152375145884812)
,p_name=>'P327_TELA_TITULO'
,p_item_sequence=>130
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(555152445375884813)
,p_name=>'P327_TELA_HELP'
,p_item_sequence=>140
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(635515633458512780)
,p_name=>'P327_CODIGO_ARTEFATO'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(635596430455679064)
,p_name=>'P327_SUCESSO'
,p_item_sequence=>120
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(635747597145676044)
,p_name=>'P327_VISUALIZAR'
,p_item_sequence=>110
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(637999143668239563)
,p_name=>'P327_COPIA'
,p_item_sequence=>100
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54635660234226355)
,p_computation_sequence=>130
,p_computation_item=>'P327_EMPRESA'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    b.nome_fantasia ',
'    from ng_configuracao a',
'    JOIN mpd_tenant      b on a.id_tenant = b.id',
'where a.id = :P327_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54636108825226354)
,p_computation_sequence=>140
,p_computation_item=>'P327_DESCRICAO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    to_char(chamar_webservice_traducao(',
'                    p_esquema           => ''wksp_teste'',',
'                    p_entidade          => ''ng_configuracao'',',
'                    p_campo             => ''descricao_configuracao'',',
'                    p_id_idioma_usuario => apex_util.get_session_state(''IDIOMA_LOGADO''),',
'                    p_id_registro       => a.id',
'                )) descricao',
'    from ng_configuracao a',
'    JOIN mpd_tenant      b on a.id_tenant = b.id',
'where a.id = :P327_PARAMETRO',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54636472768226352)
,p_computation_sequence=>150
,p_computation_item=>'P327_ID_TENANT'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>'select id_tenant from ng_configuracao a where a.id = :P327_PARAMETRO'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54636853915226351)
,p_computation_sequence=>160
,p_computation_item=>'P327_ID'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'ITEM_VALUE'
,p_computation=>'P327_PARAMETRO'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54637298857226350)
,p_computation_sequence=>170
,p_computation_item=>'P327_ID_USUARIO_INCLUIU'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.ID_USUARIO_INCLUIU',
'    from ng_configuracao a',
'where a.id = :P327_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54637631136226349)
,p_computation_sequence=>180
,p_computation_item=>'P327_DATA_INCLUSAO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.DATA_INCLUSAO',
'    from ng_configuracao a',
'where a.id = :P327_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54638089536226347)
,p_computation_sequence=>190
,p_computation_item=>'P327_ID_USUARIO_ALTEROU'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation=>'pkg_util.retorna_id_usuario_logado'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54638522337226346)
,p_computation_sequence=>210
,p_computation_item=>'P327_CODIGO_CONFIGURACAO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.CODIGO_CONFIGURACAO',
'    from ng_configuracao a',
'where a.id = :P327_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54638918625226345)
,p_computation_sequence=>230
,p_computation_item=>'P327_IND_TIPO_DADO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.IND_TIPO_DADO',
'    from ng_configuracao a',
'where a.id = :P327_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54639230727226344)
,p_computation_sequence=>240
,p_computation_item=>'P327_VALOR_INTEIRO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.VALOR_INTEIRO',
'    from ng_configuracao a',
'where a.id = :P327_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54639653544226342)
,p_computation_sequence=>250
,p_computation_item=>'P327_VALOR_DECIMAL'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.VALOR_DECIMAL',
'    from ng_configuracao a',
'where a.id = :P327_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54640044560226341)
,p_computation_sequence=>260
,p_computation_item=>'P327_QUANTIDADE_DECIMAL'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.QUANTIDADE_DECIMAL',
'    from ng_configuracao a ',
'where a.id = :P327_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54640478052226340)
,p_computation_sequence=>270
,p_computation_item=>'P327_VALOR_STRING'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.VALOR_STRING',
'    from ng_configuracao a ',
'where a.id = :P327_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54640883033226339)
,p_computation_sequence=>280
,p_computation_item=>'P327_VALOR_DATA'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.VALOR_DATA',
'    from ng_configuracao a ',
'where a.id = :P327_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54641261930226337)
,p_computation_sequence=>290
,p_computation_item=>'P327_VALOR_DATA_HORA'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.VALOR_DATA_HORA',
'    from ng_configuracao a ',
'where a.id = :P327_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54641654176226336)
,p_computation_sequence=>300
,p_computation_item=>'P327_ID_ENTIDADE'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.ID_ENTIDADE',
'    from ng_configuracao a ',
'where a.id = :P327_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54642074518226335)
,p_computation_sequence=>310
,p_computation_item=>'P327_ID_REGISTRO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.ID_REGISTRO',
'    from ng_configuracao a ',
'where a.id = :P327_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54642437310226334)
,p_computation_sequence=>330
,p_computation_item=>'P327_IND_SITUACAO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.IND_SITUACAO',
'    from ng_configuracao a ',
'where a.id = :P327_PARAMETRO'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(54664295468226274)
,p_name=>'onChangeP327_IND_MULTA_ATRASO_PAGAMENTO'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P327_IND_MULTA_ATRASO_PAGAMENTO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54665236964226270)
,p_event_id=>wwv_flow_imp.id(54664295468226274)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P327_VALOR_MULTA,P327_PERCENTUAL_MULTA,P327_PERIODO_MULTA'
,p_client_condition_type=>'NOT_EQUALS'
,p_client_condition_element=>'P327_IND_MULTA_ATRASO_PAGAMENTO'
,p_client_condition_expression=>'S'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54664786233226272)
,p_event_id=>wwv_flow_imp.id(54664295468226274)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P327_VALOR_MULTA,P327_PERCENTUAL_MULTA,P327_PERIODO_MULTA'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P327_IND_MULTA_ATRASO_PAGAMENTO'
,p_client_condition_expression=>'S'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(54665665454226270)
,p_name=>'onChangeP327_IND_BASE_CALCULO'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P327_IND_BASE_CALCULO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54666140542226268)
,p_event_id=>wwv_flow_imp.id(54665665454226270)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_name=>'Hide P327_NUM_ENTREGA'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P327_NUM_ENTREGA'
,p_client_condition_type=>'NOT_EQUALS'
,p_client_condition_element=>'P327_IND_BASE_CALCULO'
,p_client_condition_expression=>'2'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54666717116226267)
,p_event_id=>wwv_flow_imp.id(54665665454226270)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Show P327_NUL_ENTREGA'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P327_NUM_ENTREGA'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P327_IND_BASE_CALCULO'
,p_client_condition_expression=>'2'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54667677019226264)
,p_event_id=>wwv_flow_imp.id(54665665454226270)
,p_event_result=>'TRUE'
,p_action_sequence=>90
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P327_ID_ENTREGA'
,p_client_condition_type=>'NOT_EQUALS'
,p_client_condition_element=>'P327_IND_BASE_CALCULO'
,p_client_condition_expression=>'2'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54668721680226262)
,p_event_id=>wwv_flow_imp.id(54665665454226270)
,p_event_result=>'TRUE'
,p_action_sequence=>100
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P327_NUM_ENTREGA'
,p_client_condition_type=>'NOT_EQUALS'
,p_client_condition_element=>'P327_IND_BASE_CALCULO'
,p_client_condition_expression=>'2'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54667204976226265)
,p_event_id=>wwv_flow_imp.id(54665665454226270)
,p_event_result=>'TRUE'
,p_action_sequence=>110
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P327_ID_ENTREGA'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    id    ',
'from imp_entrega',
'where id_pedidoimportacao = :P327_PARAMETRO',
'and id not in (',
'    select ',
'        id_entrega ',
'    from imp_pedidoimportacao_pagamento ',
'    where id_pedidoimportacao = :P327_PARAMETRO ',
'    and numero_parcela = :P327_PARCELA_ATUAL_CONTADOR',
') ',
'order by num_entrega',
'fetch first 1 row only;'))
,p_attribute_07=>'P327_PARAMETRO'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P327_IND_BASE_CALCULO'
,p_client_condition_expression=>'2'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54668136430226263)
,p_event_id=>wwv_flow_imp.id(54665665454226270)
,p_event_result=>'TRUE'
,p_action_sequence=>120
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P327_NUM_ENTREGA'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    num_entrega',
'from imp_entrega',
'where id_pedidoimportacao = :P327_PARAMETRO',
'and id not in (',
'    select ',
'        id_entrega ',
'    from imp_pedidoimportacao_pagamento ',
'    where id_pedidoimportacao = :P327_PARAMETRO ',
'    and numero_parcela = :P327_PARCELA_ATUAL_CONTADOR',
') ',
'order by num_entrega',
'fetch first 1 row only;'))
,p_attribute_07=>'P327_PARAMETRO'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P327_IND_BASE_CALCULO'
,p_client_condition_expression=>'2'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(54663345594226276)
,p_name=>'onPageLoad'
,p_event_sequence=>120
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54663847305226275)
,p_event_id=>wwv_flow_imp.id(54663345594226276)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ADD_CLASS'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P327_IND_BASE_CALCULO'
,p_attribute_01=>'is-readonly apex-item-wrapper--display-only'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P327_IND_BASE_CALCULO'
,p_client_condition_expression=>'2'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(54669057601226261)
,p_name=>'New'
,p_event_sequence=>130
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(54615566387226461)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54669618751226259)
,p_event_id=>wwv_flow_imp.id(54669057601226261)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.navigation.dialog.close(true);',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(54661549124226281)
,p_name=>'onChange'
,p_event_sequence=>140
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P327_ENTIDADESS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54662100372226280)
,p_event_id=>wwv_flow_imp.id(54661549124226281)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'PLUGIN_CB.DEV.SHUTTLE.SORTING.FILTER'
,p_attribute_01=>'P327_ENTIDADESS'
,p_attribute_02=>'0'
,p_attribute_03=>'0'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(54662435887226279)
,p_name=>'Decimais'
,p_event_sequence=>150
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54662964951226277)
,p_event_id=>wwv_flow_imp.id(54662435887226279)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// var item = $("#P327_VALOR_DECIMAL");',
'',
unistr('// // Remove qualquer valor inv\00E1lido ao digitar'),
'// item.on("input", function() {',
'//     var valor = this.value;',
'',
unistr('//     // Substitui ponto por v\00EDrgula'),
'//     valor = valor.replace(".", ",");',
'',
unistr('//     // Regex para limitar at\00E9 2 casas decimais'),
'//     var regex = /^(\d+)(,\d{0,2})?$/;',
'//     var match = valor.match(regex);',
'',
'//     if(match){',
'//         this.value = match[0];',
'//     } else {',
unistr('//         // Se n\00E3o bater com o padr\00E3o, remove o \00FAltimo caractere'),
'//         this.value = valor.slice(0, -1);',
'//     }',
'// });',
'',
'var item = $("#P327_VALOR_DECIMAL");',
'',
unistr('// Pega o n\00FAmero de casas decimais do item oculto'),
'var decimais = parseInt($v("P327_QUANTIDADE_DECIMAL")) || 2; // default 2',
'',
unistr('// Cria regex din\00E2mica para limitar casas decimais'),
'var regex = new RegExp("^(\\d+)(,\\d{0," + decimais + "})?$");',
'',
unistr('// Remove qualquer valor inv\00E1lido ao digitar'),
'item.on("input", function() {',
'    var valor = this.value;',
'',
unistr('    // Substitui ponto por v\00EDrgula'),
'    valor = valor.replace(".", ",");',
'',
'    var match = valor.match(regex);',
'',
'    if(match){',
'        this.value = match[0];',
'    } else {',
unistr('        // Se n\00E3o bater com o padr\00E3o, remove o \00FAltimo caractere'),
'        this.value = valor.slice(0, -1);',
'    }',
'});',
'',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(54660678977226284)
,p_name=>'Inteiro'
,p_event_sequence=>160
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54661175055226282)
,p_event_id=>wwv_flow_imp.id(54660678977226284)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var item = $("#P327_VALOR_INTEIRO");',
'',
unistr('// Remove qualquer caractere que n\00E3o seja n\00FAmero'),
'item.on("input", function() {',
'    this.value = this.value.replace(/\D/g, '''');',
'});',
''))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(54648979355226313)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'altera_registro'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'BO_NG_CONFIGURACAO'
,p_attribute_04=>'ALTERA_REGISTRO'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(54615566387226461)
,p_process_success_message=>'&P327_SUCESSO.'
,p_internal_uid=>97519851015868586
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54649449889226311)
,p_page_process_id=>wwv_flow_imp.id(54648979355226313)
,p_page_id=>327
,p_name=>'p_id_tenant'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P327_ID_TENANT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54649948256226310)
,p_page_process_id=>wwv_flow_imp.id(54648979355226313)
,p_page_id=>327
,p_name=>'p_id'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>190
,p_value_type=>'ITEM'
,p_value=>'P327_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54650466765226309)
,p_page_process_id=>wwv_flow_imp.id(54648979355226313)
,p_page_id=>327
,p_name=>'p_pagina'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>true
,p_display_sequence=>200
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>':APP_PAGE_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54651012643226308)
,p_page_process_id=>wwv_flow_imp.id(54648979355226313)
,p_page_id=>327
,p_name=>'p_encadeado'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>210
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54651470535226306)
,p_page_process_id=>wwv_flow_imp.id(54648979355226313)
,p_page_id=>327
,p_name=>'p_sucesso'
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>false
,p_display_sequence=>220
,p_value_type=>'ITEM'
,p_value=>'P327_SUCESSO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54651904290226305)
,p_page_process_id=>wwv_flow_imp.id(54648979355226313)
,p_page_id=>327
,p_name=>'p_messages'
,p_direction=>'OUT'
,p_data_type=>'pkg_mensagem.message_record_table'
,p_display_sequence=>230
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54652353842226304)
,p_page_process_id=>wwv_flow_imp.id(54648979355226313)
,p_page_id=>327
,p_name=>'p_quantidade_decimal'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>240
,p_value_type=>'ITEM'
,p_value=>'P327_QUANTIDADE_DECIMAL'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54652927452226303)
,p_page_process_id=>wwv_flow_imp.id(54648979355226313)
,p_page_id=>327
,p_name=>'p_valor_string'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>250
,p_value_type=>'ITEM'
,p_value=>'P327_VALOR_STRING'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54653415730226301)
,p_page_process_id=>wwv_flow_imp.id(54648979355226313)
,p_page_id=>327
,p_name=>'p_valor_data'
,p_direction=>'IN'
,p_data_type=>'DATE'
,p_has_default=>false
,p_display_sequence=>260
,p_value_type=>'ITEM'
,p_value=>'P327_VALOR_DATA'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54653829062226300)
,p_page_process_id=>wwv_flow_imp.id(54648979355226313)
,p_page_id=>327
,p_name=>'p_valor_data_hora'
,p_direction=>'IN'
,p_data_type=>'TIMESTAMP'
,p_has_default=>false
,p_display_sequence=>270
,p_value_type=>'ITEM'
,p_value=>'P327_VALOR_DATA_HORA'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54654415163226299)
,p_page_process_id=>wwv_flow_imp.id(54648979355226313)
,p_page_id=>327
,p_name=>'p_id_entidade'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>280
,p_value_type=>'ITEM'
,p_value=>'P327_ID_ENTIDADE'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54654831636226297)
,p_page_process_id=>wwv_flow_imp.id(54648979355226313)
,p_page_id=>327
,p_name=>'p_id_registro'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>290
,p_value_type=>'FUNCTION_BODY'
,p_value_language=>'PLSQL'
,p_value=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'    l_valor  varchar2(4000);',
'begin',
'    -- Escolhe de qual item vem o valor, dependendo do tipo de dado',
'    if :P327_IND_TIPO_DADO = ''ID'' then',
'        l_valor := :P327_ENTIDADE;',
'    else',
'        l_valor := :P327_ENTIDADESS;',
'    end if;',
'',
'    return l_valor;',
'end;',
''))
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54655341693226296)
,p_page_process_id=>wwv_flow_imp.id(54648979355226313)
,p_page_id=>327
,p_name=>'p_valor_dominio'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>300
,p_value_type=>'FUNCTION_BODY'
,p_value_language=>'PLSQL'
,p_value=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'    l_valor  varchar2(4000);',
'begin',
'    -- Escolhe de qual item vem o valor, dependendo do tipo de dado',
'    if :P327_IND_TIPO_DADO = ''DO'' then',
'        l_valor := :P327_VALOR_DOMINIO;',
'    else',
'        l_valor := :P327_VALOR_DOMINIOS;',
'    end if;',
'',
'    return l_valor;',
'end;',
''))
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54655893303226295)
,p_page_process_id=>wwv_flow_imp.id(54648979355226313)
,p_page_id=>327
,p_name=>'p_ind_situacao'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>310
,p_value_type=>'ITEM'
,p_value=>'P327_IND_SITUACAO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54656342862226294)
,p_page_process_id=>wwv_flow_imp.id(54648979355226313)
,p_page_id=>327
,p_name=>'p_ind_grupo_funcionalidade'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>320
,p_value_type=>'ITEM'
,p_value=>'P327_GRUPO_FUNCIONALIDADE'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54656885506226293)
,p_page_process_id=>wwv_flow_imp.id(54648979355226313)
,p_page_id=>327
,p_name=>'p_codigo_configuracao'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>330
,p_value_type=>'ITEM'
,p_value=>'P327_CODIGO_CONFIGURACAO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54657335380226292)
,p_page_process_id=>wwv_flow_imp.id(54648979355226313)
,p_page_id=>327
,p_name=>'p_descricao_configuracao'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>340
,p_value_type=>'ITEM'
,p_value=>'P327_DESCRICAO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54657835333226291)
,p_page_process_id=>wwv_flow_imp.id(54648979355226313)
,p_page_id=>327
,p_name=>'p_ind_tipo_dado'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>350
,p_value_type=>'ITEM'
,p_value=>'P327_IND_TIPO_DADO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54658385795226290)
,p_page_process_id=>wwv_flow_imp.id(54648979355226313)
,p_page_id=>327
,p_name=>'p_valor_inteiro'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>360
,p_value_type=>'ITEM'
,p_value=>'P327_VALOR_INTEIRO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54658852139226288)
,p_page_process_id=>wwv_flow_imp.id(54648979355226313)
,p_page_id=>327
,p_name=>'p_valor_decimal'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>370
,p_value_type=>'ITEM'
,p_value=>'P327_VALOR_DECIMAL'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54659368472226287)
,p_page_process_id=>wwv_flow_imp.id(54648979355226313)
,p_page_id=>327
,p_name=>'p_data_alteracao'
,p_direction=>'IN'
,p_data_type=>'TIMESTAMP'
,p_has_default=>false
,p_display_sequence=>380
,p_value_type=>'ITEM'
,p_value=>'P327_DATA_ALTERACAO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(54643177994226331)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'retorna_titulo_help'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'RETORNA_TITULO_TELA'
,p_internal_uid=>97514049654868604
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54643692964226329)
,p_page_process_id=>wwv_flow_imp.id(54643177994226331)
,p_page_id=>327
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'nvl(:P327_CODIGO_ARTEFATO,:APP_PAGE_ID)'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54644135510226326)
,p_page_process_id=>wwv_flow_imp.id(54643177994226331)
,p_page_id=>327
,p_name=>'p_titulo'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P327_TELA_TITULO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54644658585226325)
,p_page_process_id=>wwv_flow_imp.id(54643177994226331)
,p_page_id=>327
,p_name=>'p_help'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P327_TELA_HELP'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(54645066259226323)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'url_wizard'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'URL_WIZARD'
,p_process_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    1',
'from srv_artefato_wizard a',
'join srv_artefato_versionado b on b.id = a.id_artefato_versionado',
'join srv_artefato c on c.id = b.id_artefato',
'join srv_artefato_versionado b1 on b1.id = a.id_artefato_versionado_base',
'join srv_artefato c1 on c1.id = b1.id_artefato',
'where c.codigo_artefato = nvl( apex_util.get_session_state(''P''||:APP_PAGE_ID||''_CODIGO_WIZARD''),:p0_codigo_artefato)'))
,p_process_when_type=>'EXISTS'
,p_internal_uid=>97515937919868596
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54645620376226322)
,p_page_process_id=>wwv_flow_imp.id(54645066259226323)
,p_page_id=>327
,p_name=>'p_codigo_artefato_base'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>20
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'case when :P327_CODIGO_WIZARD is null then :P327_CODIGO_ARTEFATO else :P327_CODIGO_WIZARD end'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54646060266226321)
,p_page_process_id=>wwv_flow_imp.id(54645066259226323)
,p_page_id=>327
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'nvl(:P327_CODIGO_ARTEFATO,:APP_PAGE_ID)'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54646531024226320)
,p_page_process_id=>wwv_flow_imp.id(54645066259226323)
,p_page_id=>327
,p_name=>'p_url_anterior'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P327_URL_ANTERIOR'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54647077736226318)
,p_page_process_id=>wwv_flow_imp.id(54645066259226323)
,p_page_id=>327
,p_name=>'p_url_proximo'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>50
,p_value_type=>'ITEM'
,p_value=>'P327_URL_PROXIMO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54647529948226317)
,p_page_process_id=>wwv_flow_imp.id(54645066259226323)
,p_page_id=>327
,p_name=>'p_param1'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>60
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54648097542226315)
,p_page_process_id=>wwv_flow_imp.id(54645066259226323)
,p_page_id=>327
,p_name=>'p_param2'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>70
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54648627806226314)
,p_page_process_id=>wwv_flow_imp.id(54645066259226323)
,p_page_id=>327
,p_name=>'p_etapa'
,p_direction=>'OUT'
,p_data_type=>'NUMBER'
,p_ignore_output=>false
,p_display_sequence=>80
,p_value_type=>'ITEM'
,p_value=>'P327_ETAPA'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(54630849141226384)
,p_process_sequence=>80
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(301852268270101126)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Gerar parceladas de pagamento'
,p_internal_uid=>97501720801868657
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(54659821590226286)
,p_process_sequence=>90
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'reinicia_pagamentos'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'BO_IMP_PEDIDOIMPORTACAO_PAGAMENTO'
,p_attribute_04=>'REINICIA_PAGAMENTOS'
,p_process_when=>'P327_REINICIAR_PAGAMENTOS'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_internal_uid=>97530693250868559
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(54660323994226285)
,p_page_process_id=>wwv_flow_imp.id(54659821590226286)
,p_page_id=>327
,p_name=>'p_id_pedidoimportacao'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P327_PARAMETRO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(54642821377226333)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'enviarParamentros'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_param1 varchar2(100) := apex_application.g_x01||''_''||APEX_CUSTOM_AUTH.GET_SESSION_ID;',
'    v_param2 varchar2(100) := apex_application.g_x02;',
'    v_param3 varchar2(100) := apex_application.g_x03;',
'    v_existe number;',
'    v_id number;',
'begin',
unistr('    -- verifica se a cole\00E7\00E3o j\00E1 existe e a exclui para evitar duplica\00E7\00F5es'),
'    apex_debug.enable(apex_debug.c_log_level_info);',
'    apex_debug.info(''info enviarparamentros v_param1:%s'',v_param1); ',
'    apex_debug.info(''info enviarparamentros v_param2:%s'',v_param2); ',
'    apex_debug.info(''info enviarparamentros v_param3:%s'',v_param3); ',
'    apex_debug.info(''info enviarparamentros APEX_CUSTOM_AUTH.GET_SESSION_ID:%s'',APEX_CUSTOM_AUTH.GET_SESSION_ID); ',
'',
'    if not apex_collection.collection_exists(v_param1) then',
'        -- apex_collection.delete_collection(v_param1);',
'        apex_collection.create_collection(v_param1);',
'    end if;',
'',
'    select count(1) into v_existe ',
'    from apex_collections',
'    where collection_name = v_param1',
'      and c001 = v_param2;',
'    if v_existe > 0 then',
'        select seq_id into v_id ',
'        from apex_collections',
'        where collection_name = v_param1',
'          and c001 = v_param2;',
'',
'        apex_collection.update_member (',
'            p_collection_name => v_param1,',
'            p_seq => v_id,',
'            p_c001 => v_param2,',
'            p_c002 => v_param3);      ',
'    else',
'        apex_collection.add_member(',
'            p_collection_name => v_param1,',
'            p_c001 => v_param2,',
'            p_c002 => v_param3',
'        );',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>97513693037868606
);
wwv_flow_imp.component_end;
end;
/
