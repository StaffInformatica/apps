prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_page.create_page(
 p_id=>6
,p_name=>'Policita de privacidade'
,p_alias=>'POLICITA-DE-PRIVACIDADE'
,p_page_mode=>'MODAL'
,p_step_title=>'Policita de privacidade'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(489110489949697573)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(194647310066155055)
,p_plug_name=>'Lista'
,p_region_name=>'static-id'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH policy_check AS (',
'    SELECT object_name',
'    FROM all_policies',
'    WHERE object_owner = SYS_CONTEXT(''USERENV'', ''CURRENT_SCHEMA'')',
'      AND UPPER(policy_name) = UPPER(''tenant'')',
')',
'SELECT ',
'    distinct',
'    lower(table_name) nome_entidade,',
'    CASE ',
'        WHEN pc.object_name IS NOT NULL THEN ''Y''',
'        ELSE ''N''',
'    END AS situacao,',
'    CASE ',
'        WHEN pc.object_name IS NOT NULL THEN ''sim''',
'        ELSE ''nao''',
'    END AS status,',
'    CASE ',
'        WHEN pc.object_name IS NOT NULL THEN ''Ativada''',
'        ELSE ''Desativada''',
'    END AS des_status,',
'    descricao_entidade',
'FROM ',
'    all_tab_columns e',
'LEFT JOIN ',
'    policy_check pc ON UPPER(pc.object_name) = UPPER(e.table_name)',
'LEFT JOIN ',
'    srv_entidade c ON UPPER(e.table_name) = UPPER(c.nome_entidade)',
'where (lower(e.column_name) = ''id_tenant'' or lower(e.table_name) = ''mpd_tenant'')',
'order by 2 desc,1    '))
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'counter_column', 'DES_STATUS',
  'link_target', 'javascript:$s(''P6_TABELA_ATUAL'',''&NOME_ENTIDADE.''); $s(''P6_TABELA_ATUAL_S'',''&SITUACAO.'');',
  'list_attributes', 'span class="click-linha"',
  'list_entry_attributes', 'data-status="&STATUS."',
  'list_view_features', 'ADVANCED_FORMATTING:SEARCH',
  'search_column', 'NOME_ENTIDADE',
  'search_type', 'SERVER_EXACT_IGNORE',
  'supplemental_info_formatting', '&DESCRICAO_ENTIDADE.',
  'text_formatting', '&NOME_ENTIDADE.')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(150155211395308617)
,p_name=>'P6_TABELA_ATUAL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(194647310066155055)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(150155400874308618)
,p_name=>'P6_TABELA_ATUAL_S'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(194647310066155055)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(150181174688824476)
,p_name=>'onClick-linha'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'ul.click-linha > li:not(.apex-load-more)'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(150181557254824472)
,p_event_id=>wwv_flow_imp.id(150181174688824476)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Deseja alterar a policita de privacidade?'
,p_attribute_03=>'information'
,p_attribute_06=>'Sim, alterar'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(150182053479824470)
,p_event_id=>wwv_flow_imp.id(150181174688824476)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_esquema varchar2(256);',
'    l_funcao varchar2(256);',
'begin',
'    SELECT sys_context(''userenv'', ''current_schema'') into l_esquema FROM dual;',
'    if :P6_TABELA_ATUAL_S = ''N'' then',
'        if lower(:P6_TABELA_ATUAL) = ''mpd_tenant'' then',
'            l_funcao := ''where_tenant_simples'';',
'        else',
'            l_funcao := ''where_tenant'';',
'        end if;',
'        dbms_rls.add_policy(',
'            object_schema => l_esquema, ',
'            object_name => lower(:P6_TABELA_ATUAL), ',
'            policy_name => ''tenant'', ',
'            function_schema => l_esquema, ',
'            policy_function => l_funcao,',
'            update_check => true, ',
'            enable => true);',
'    else',
'        dbms_rls.drop_policy(',
'            object_schema => l_esquema, ',
'            object_name => lower(:P6_TABELA_ATUAL), ',
'            policy_name => ''tenant''); ',
'    end if;',
'end;',
'            '))
,p_attribute_02=>'P6_TABELA_ATUAL,P6_TABELA_ATUAL_S'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(150155426712308619)
,p_event_id=>wwv_flow_imp.id(150181174688824476)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(194647310066155055)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
