prompt --application/pages/page_09996
begin
--   Manifest
--     PAGE: 09996
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>9996
,p_name=>'Verifica Token'
,p_alias=>'VERIFICA-TOKEN'
,p_step_title=>'Verifica Token'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(222376265577622135)
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'document.addEventListener("paste", function(e) {',
'  // if the target is a text input',
'  ',
'  if (e.target.type === "text") {',
'   var data = e.clipboardData.getData(''Text'');',
'   // split clipboard text into single characters',
'   apex.item( "P9996_TOKEN" ).setValue( data );',
'   data = data.split('''');',
'   ',
'   // find all other text inputs',
'   [].forEach.call(document.querySelectorAll("input[type=text]"), (node, index) => {',
'      // And set input value to the relative character',
'      if (node.id != ''P9996_TOKEN'')',
'        node.value = data[index];',
'      ',
'      ',
'    });',
'  }',
'});',
'',
'function moveToNext(event, nextInputId) {',
'  //alert(''moveToNext'');  ',
'  var token = $("#digito1").val() + $("#digito2").val() + $("#digito3").val() + $("#digito4").val();',
' ',
'  apex.item( "P9996_TOKEN" ).setValue( token );  ',
unistr('  // Verifica se a tecla pressionada \00E9 num\00E9rica (0-9)'),
'  if ((event.keyCode >= 48 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105)) {',
unistr('    // Move o foco para o pr\00F3ximo campo de entrada'),
'    document.getElementById(nextInputId).focus();',
'    document.getElementById(nextInputId).select();',
'    ',
'  }',
'}',
'',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Alert{',
'    background-color: transparent;',
'    border: none;',
'    box-shadow: none;',
'}',
'',
'.t-Button{',
'    padding-left: 4px;',
'    padding-right: 4px;',
'}',
'',
'.st-font-size-40{',
'    font-size: 30px;',
'    padding: 10px;',
'}',
'',
'#form {',
'    margin: 20px auto 20px;',
'}',
'',
'input {',
'    margin: 0 5px;',
'    text-align: center;',
'    line-height: 80px;',
'    font-size: 50px;',
'    border: solid 1px #ccc;',
'    box-shadow: 0 0 5px #ccc inset;',
'    outline: none;',
'    transition: all .2s ease-in-out;',
'    border-radius: 3px;',
'    width: 20%;',
'}    ',
'',
'input:focus {',
'    border-color: rgb(63, 146, 255);',
'    box-shadow: 0 0 5px rgb(63, 146, 255) inset;',
'}',
'',
'input::selection {',
'    background: transparent;',
'}',
'     ',
'      ',
'     '))
,p_step_template=>wwv_flow_imp.id(341000071649556215)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(499215307400101301)
,p_plug_name=>'MBP'
,p_region_template_options=>'#DEFAULT#:t-Login-region--headerHidden js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(341088492083556263)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(454996123165947268)
,p_plug_name=>'Logo'
,p_parent_plug_id=>wwv_flow_imp.id(499215307400101301)
,p_icon_css_classes=>'fa-mobile'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<img src="#APP_FILES#logo.png" style="height: 30px;" alt="Minha Figura"></img>',
'<div class="st-titulo-app">&APP_NAME.</div>',
'<div style="font-size: 18px;">&P9997_USERNAME.</div>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(452109215670001924)
,p_plug_name=>unistr('Informe o c\00F3digo de verifica\00E7\00E3o')
,p_parent_plug_id=>wwv_flow_imp.id(454996123165947268)
,p_region_css_classes=>'st-back-transparente'
,p_icon_css_classes=>'fa-mobile'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--customIcons:t-Alert--warning:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(341005634629556219)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<div class="st-titulo-login">Informe o c\00F3digo de verifica\00E7\00E3o</div>'),
'<div class="st-detalhe-login">gerado pelo aplicativo STAFF Autenticador</div>',
'',
'<div class="st-vertical-center" id="form">',
'    <input  id="digito1" type="text" onkeyup="moveToNext(event, ''digito2'')" maxLength="1" size="1" min="0" max="9" pattern="[0-9]{1}" />',
'    <input  id="digito2" type="text" onkeyup="moveToNext(event, ''digito3'')" maxLength="1" size="1" min="0" max="9" pattern="[0-9]{1}" />',
'    <input  id="digito3" type="text" onkeyup="moveToNext(event, ''digito4'')" maxLength="1" size="1" min="0" max="9" pattern="[0-9]{1}" />',
'    <input  id="digito4" type="text" onkeyup="moveToNext(event, ''digito4'')" maxLength="1" size="1" min="0" max="9" pattern="[0-9]{1}" style="margin-right: 0px;" />',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(452232377760299022)
,p_plug_name=>'Bloco aviso aplicativo'
,p_parent_plug_id=>wwv_flow_imp.id(454996123165947268)
,p_region_css_classes=>'st-back-transp'
,p_icon_css_classes=>'fa-mobile'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--wizard:t-Alert--noIcon:t-Alert--info:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(341005634629556219)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P9996_MODELO_MFA'
,p_plug_display_when_cond2=>'1'
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<div style="text-align: center; font-size: 12px;">Se voc\00EA ainda n\00E3o instalou o nosso aplicativo <strong>STAFF Autenticador</strong>, clique na imagem a seguir.</div>'),
'<a href="https://geae26552a5af32-dbng.adb.sa-vinhedo-1.oraclecloudapps.com/ords/r/wksp_desenv/staff-autenticador/lista-de-usu%C3%A1rios" target="_blank">',
'    <div style="text-align: center;">',
'        <span>Acessar STAFF Autenticador</span>',
'    </div>',
'</a>',
'<div style="text-align: center; margin-top: 10px; font-size: 12px;">',
unistr('    <span>Caso tenha alguma d\00FAvida sobre como acessar o aplicativo STAFF Autenticador,</span>'),
'    <a href="https://scribehow.com/shared/Acessando_o_STAFF_autenticador__00GgZSD7QqiVL4xE-oxUrw" target="_blank">',
'        <span style="text-align: center;">acesse o guia aqui.</span>',
'    </a>',
'</div>',
'<br>',
'',
'',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(452232649307299025)
,p_plug_name=>'Bloco aviso email'
,p_parent_plug_id=>wwv_flow_imp.id(454996123165947268)
,p_region_css_classes=>'st-back-transp'
,p_icon_css_classes=>'fa-envelope-o'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--customIcons:t-Alert--info:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(341005634629556219)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P9996_MODELO_MFA'
,p_plug_display_when_cond2=>'2'
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<div class="st-titulo-login">Informe o c\00F3digo de verifica\00E7\00E3o</div>'),
unistr('<div class="st-detalhe-login">envido para o e-mail do usu\00E1rio</div>')))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(271382185627105420)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(452109215670001924)
,p_button_name=>'LOGIN'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341144157120556305)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Acessar'
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(48173949299220083)
,p_branch_name=>'Go to 9995'
,p_branch_action=>'f?p=&APP_ID.:9995:&SESSION.::&DEBUG.:9995:P9995_USERNAME,P9995_TOKEN_OK:&P9996_USERNAME.,ok&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_branch_condition=>'P9996_SITUACAO_USUARIO'
,p_branch_condition_text=>'3'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48173775027220081)
,p_name=>'P9996_SITUACAO_USUARIO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(499215307400101301)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('1 - Aplicativo de autentica\00E7\00E3o'),
'2 - E-mail',
'3 - SMS'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(271382605165105421)
,p_name=>'P9996_USERNAME'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(499215307400101301)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(271383065263105421)
,p_name=>'P9996_MODELO_MFA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(499215307400101301)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('1 - Aplicativo de autentica\00E7\00E3o'),
'2 - E-mail',
'3 - SMS'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(271384002401105422)
,p_name=>'P9996_TOKEN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(452109215670001924)
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(48173878538220082)
,p_computation_sequence=>10
,p_computation_item=>'P9996_SITUACAO_USUARIO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>'select situacao_cadastral from mpd_usuario where lower(login) = lower(:P9996_USERNAME)'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(271385139755105423)
,p_validation_name=>'P9996_TOKEN-Valid Token'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_message varchar(255);',
'begin',
'    l_message := PKG_API_SEGURANCA.valid_mfa(:P9996_USERNAME,:P9996_TOKEN, :P9996_MODELO_MFA);',
'    return l_message;',
'end;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(271382185627105420)
,p_associated_item=>wwv_flow_imp.id(271384002401105422)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(271385501387105423)
,p_validation_name=>'P9996_TOKEN-Valid Not Null'
,p_validation_sequence=>20
,p_validation=>'P9996_TOKEN'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('C\00F3digo de verifica\00E7\00E3o deve ser informado')
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(271382185627105420)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(271385827780105423)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Login'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_API_SEGURANCA'
,p_attribute_04=>'PROCESS_LOGIN'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(271382185627105420)
,p_process_when=>'P9996_SITUACAO_USUARIO'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'3'
,p_internal_uid=>62039162045117829
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(165194014283149567)
,p_page_process_id=>wwv_flow_imp.id(271385827780105423)
,p_page_id=>9996
,p_name=>'p_convite'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>true
,p_display_sequence=>50
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(271386322339105423)
,p_page_process_id=>wwv_flow_imp.id(271385827780105423)
,p_page_id=>9996
,p_name=>'p_user_name'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P9996_USERNAME'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(271386809405105424)
,p_page_process_id=>wwv_flow_imp.id(271385827780105423)
,p_page_id=>9996
,p_name=>'p_password'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P9996_TOKEN'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(271387276044105424)
,p_page_process_id=>wwv_flow_imp.id(271385827780105423)
,p_page_id=>9996
,p_name=>'p_auth_type'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>true
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P9996_MODELO_MFA'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(271387798352105425)
,p_page_process_id=>wwv_flow_imp.id(271385827780105423)
,p_page_id=>9996
,p_name=>'p_app_id'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>40
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>':APP_ID'
);
wwv_flow_imp.component_end;
end;
/
