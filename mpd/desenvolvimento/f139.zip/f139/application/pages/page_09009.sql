prompt --application/pages/page_09009
begin
--   Manifest
--     PAGE: 09009
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>9009
,p_name=>'Template - Mais detalhes'
,p_alias=>'TEMPLATE-MAIS-DETALHES1'
,p_step_title=>'Template - Mais detalhes'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://unpkg.com/intro.js/intro.js'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function openRegion(staticRegionId) {',
'    apex.theme.openRegion(staticRegionId);',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''.ui-dialog-title'').append($(''#BTN_DESFIXAR''));',
'',
''))
,p_css_file_urls=>'https://unpkg.com/intro.js/introjs.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-button--actions{',
'    display: none;',
'}',
'',
'.a-CardView-body{',
'    padding-bottom: 0px;',
'    padding-top: 0px;',
'}',
'',
'.a-CardView-actions{',
'    padding-bottom: 0px;',
'}',
'',
'.fundo-azul .a-CardView-header {',
'    background-color: aliceblue;',
'}',
'',
'.container-card {',
'    display: flex;',
'    justify-content: space-between;',
'    /*align-items: center;*/',
'    flex-wrap: wrap;',
'}',
'',
'.left-element {',
'    flex-grow: 1;',
'}',
'',
'.right-element {',
unistr('    margin-left: 20px; /* Espa\00E7amento entre os elementos */'),
'    white-space: nowrap; /* Impede quebra de linha no segundo elemento */',
'}',
'',
'.ocultar{',
'    display: none;',
'}',
'',
'.a-CardView-opcao {',
'    grid-area: icon-end;',
'    padding-left: 15px;',
'    order: 4;',
'}',
'',
'.t-Form--floatLeft .col {',
'    flex-grow: 1!IMPORTANT;',
'}',
'',
'.margem-lateral{',
'    margin-left: 30rem;',
'    margin-right: 30rem;',
'}'))
,p_step_template=>wwv_flow_imp.id(340985230573556208)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(225546868302211669)
,p_protection_level=>'C'
,p_page_component_map=>'25'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(115702689965938017)
,p_plug_name=>'Cabecalho Principal'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(341010888912556224)
,p_plug_display_sequence=>10
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_html clob;',
'    l_pagina varchar2(256) := nvl(:P9009_CODIGO_ARTEFATO,''TD708'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_html := UI_MPD_''||l_pagina||''.cabecalho_principal(p_param1 => :param1); END;''',
'        USING OUT l_html, IN :P9009_ID;',
'    return l_html;       ',
'    exception',
'        when others then',
unistr('            return ''<div>Por favor realize as defini\00E7\00F5es da fun\00E7\00E3o cabecalho_principal de tela criando o UI para o artefato ''||l_pagina||'' </div>'';'),
'end;',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P9009_ID'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from all_procedures',
'where upper(object_name) = upper(''ui_mpd_''||:p9009_codigo_artefato)',
'and upper(procedure_name) = upper(''cabecalho_principal'')',
'and upper(object_type) = upper(''package'');'))
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(115702857471938019)
,p_plug_name=>'Cabecalho Secundario'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(341010888912556224)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_html clob;',
'    l_pagina varchar2(256) := nvl(:P9009_CODIGO_ARTEFATO,''TD708'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_html := UI_MPD_''||l_pagina||''.cabecalho_secundario(p_param1 => :param1); END;''',
'        USING OUT l_html, IN :P9009_ID;',
'    return l_html;       ',
'    exception',
'        when others then',
unistr('            return ''<div>Por favor realize as defini\00E7\00F5es da fun\00E7\00E3o cabecalho_secundario de tela criando o UI para o artefato ''||l_pagina||'' </div>'';'),
'end;',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P9009_ID'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from all_procedures',
'where upper(object_name) = upper(''ui_mpd_''||:p9009_codigo_artefato)',
'and upper(procedure_name) = upper(''cabecalho_secundario'')',
'and upper(object_type) = upper(''package'');'))
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(504214770648654689)
,p_plug_name=>'Filtrar por Esquerda'
,p_title=>'&P9005_LABEL_FILTRAR.'
,p_region_name=>'PAINEL_LEFT'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_02'
,p_location=>null
,p_required_patch=>wwv_flow_imp.id(340973604135556181)
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(19944447438252086)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(504214770648654689)
,p_button_name=>'fixar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'botao.fixar-desfixar.l'
,p_button_position=>'COPY'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-thumb-tack'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(19945783016252092)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(17161532936247037)
,p_button_name=>'filter'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Filter'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-filter'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(19946624357252094)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(17161532936247037)
,p_button_name=>'Menu'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Menu'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:9000:&SESSION.::&DEBUG.:9000:P9000_PAGINA:&P9009_CODIGO_ARTEFATO.'
,p_button_condition=>'PKG_UI.verifica_se_tem_linhas(PKG_UI.buscar_acoes(0,:P9009_CODIGO_ARTEFATO,''W'')) = true'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-ellipsis-v-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(19946209225252093)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(17161532936247037)
,p_button_name=>'New'
,p_button_static_id=>'NEW'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'New'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'&P9009_URL_NEW.'
,p_button_condition=>'P9009_URL_NEW'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_button_css_classes=>'apex_disabled'
,p_icon_css_classes=>'fa-plus-circle'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(115505753566763915)
,p_name=>'P9009_TITULO_LISTA1'
,p_item_sequence=>200
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(115506846176763926)
,p_name=>'P9009_TITULO_LISTA2'
,p_item_sequence=>210
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(115702022375938000)
,p_name=>'P9009_VISUALIZAR'
,p_item_sequence=>160
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(115705358065938034)
,p_name=>'P9009_ORDER'
,p_item_sequence=>170
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(115705506579938035)
,p_name=>'P9009_CARD_OU_LISTA'
,p_item_sequence=>180
,p_item_default=>'CARD'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(115705953696938040)
,p_name=>'P9009_TIPO_PESQUISA'
,p_item_sequence=>190
,p_item_default=>'CARD'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(202976123113145524)
,p_name=>'P9009_ID'
,p_item_sequence=>110
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(353682933296280133)
,p_name=>'P9009_PARAMETRO2'
,p_item_sequence=>150
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(396801501084786137)
,p_name=>'P9009_PARAMETRO'
,p_item_sequence=>140
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(470801767953273155)
,p_name=>'P9009_TELA_TITULO'
,p_item_sequence=>120
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(470802206705273160)
,p_name=>'P9009_TELA_HELP'
,p_item_sequence=>130
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(506287104629009422)
,p_name=>'P9009_CODIGO_ARTEFATO'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(506288026544009431)
,p_name=>'P9009_URL_NEW'
,p_item_sequence=>100
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(19951092764252119)
,p_computation_sequence=>10
,p_computation_item=>'P9009_TITULO_LISTA1'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_html clob;',
'    l_pagina varchar2(256) := nvl(:P9009_CODIGO_ARTEFATO,''TD708'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_html := UI_MPD_''||l_pagina||''.titulo_lista1(p_param1 => :param1); END;''',
'        USING OUT l_html, IN :P9009_ID;',
'   return l_html;       ',
'    exception',
'        when others then',
unistr('            return ''<div>Por favor realize as defini\00E7\00F5es de tela criando o UI para o artefato ''||l_pagina||'' </div>'';'),
'end;',
''))
,p_compute_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from all_procedures',
'where upper(object_name) = upper(''ui_mpd_''||:p9009_codigo_artefato)',
'and upper(procedure_name) = upper(''titulo_lista1'')',
'and upper(object_type) = upper(''package'');'))
,p_compute_when_type=>'EXISTS'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(19951445266252121)
,p_computation_sequence=>20
,p_computation_item=>'P9009_TITULO_LISTA2'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_html clob;',
'    l_pagina varchar2(256) := nvl(:P9009_CODIGO_ARTEFATO,''TD708'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_html := UI_MPD_''||l_pagina||''.titulo_lista2(p_param1 => :param1); END;''',
'        USING OUT l_html, IN :P9009_ID;',
'   return l_html;       ',
'    exception',
'        when others then',
unistr('            return ''<div>Por favor realize as defini\00E7\00F5es de tela criando o UI para o artefato ''||l_pagina||'' </div>'';'),
'end;',
''))
,p_compute_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from all_procedures',
'where upper(object_name) = upper(''ui_mpd_''||:p9009_codigo_artefato)',
'and upper(procedure_name) = upper(''titulo_lista2'')',
'and upper(object_type) = upper(''package'');'))
,p_compute_when_type=>'EXISTS'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19956927184252142)
,p_name=>'onClickFixar'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(19944447438252086)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19957344432252144)
,p_event_id=>wwv_flow_imp.id(19956927184252142)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (apex.item( "P9009_TIPO_PESQUISA" ).getValue() == 1){',
'    apex.item( "P9009_TIPO_PESQUISA" ).setValue( 2 );',
'} else {',
'    apex.item( "P9009_TIPO_PESQUISA" ).setValue( 1 );',
'}',
'    '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19957794040252145)
,p_name=>'onChangeTipoPesquisa = Esquerda'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9009_TIPO_PESQUISA'
,p_condition_element=>'P9009_TIPO_PESQUISA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19958256289252147)
,p_event_id=>wwv_flow_imp.id(19957794040252145)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#PESQUISA'').appendTo(''#PAINEL_LEFT'');',
'$(''#PESQUISA_LISTA'').appendTo(''#PAINEL_LEFT'');',
'$(''#t_Body_side'').show();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19958687908252148)
,p_name=>'onChangeTipoPesquisa = Modal'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9009_TIPO_PESQUISA'
,p_condition_element=>'P9009_TIPO_PESQUISA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19959206631252149)
,p_event_id=>wwv_flow_imp.id(19958687908252148)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#PESQUISA'').appendTo(''#PAINEL_MODAL .t-DrawerRegion-body'');    ',
'$(''#PESQUISA_LISTA'').appendTo(''#PAINEL_MODAL .t-DrawerRegion-body'');    ',
'$(''#t_Body_side'').hide();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19959627936252151)
,p_name=>'onMouseEnterTooltip'
,p_event_sequence=>70
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'$("#icon_info")'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'mouseenter'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19960076700252153)
,p_event_id=>wwv_flow_imp.id(19959627936252151)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'PLUGIN_COM.FOS.TOOLTIP'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'$("#icon_info")'
,p_attribute_01=>'static'
,p_attribute_05=>'&P9009_TELA_HELP. (&P9009_CODIGO_ARTEFATO.)'
,p_attribute_08=>'#007BFE'
,p_attribute_09=>'#FFFFFF'
,p_attribute_10=>'scale'
,p_attribute_11=>'500'
,p_attribute_12=>'hover'
,p_attribute_13=>'top'
,p_attribute_14=>'cache-result,escape-html'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19960496690252154)
,p_name=>'onCloseNew'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(19946209225252093)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19960844901252155)
,p_name=>'onPageLoad'
,p_event_sequence=>110
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19961399446252158)
,p_event_id=>wwv_flow_imp.id(19960844901252155)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(19946209225252093)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19962531168252162)
,p_name=>'onClickBotaoOrder'
,p_event_sequence=>200
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#botao_order'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19961794950252159)
,p_name=>'onCloseMenu'
,p_event_sequence=>210
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(19946624357252094)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19962190842252160)
,p_name=>'New'
,p_event_sequence=>220
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(115702689965938017)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_required_patch=>wwv_flow_imp.id(340973604135556181)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(19954122039252133)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'url_new'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'URL_NEW'
,p_internal_uid=>62824993699894406
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19954615803252134)
,p_page_process_id=>wwv_flow_imp.id(19954122039252133)
,p_page_id=>9009
,p_name=>'p_param2'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>70
,p_value_type=>'ITEM'
,p_value=>'P9009_PARAMETRO2'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19955092418252136)
,p_page_process_id=>wwv_flow_imp.id(19954122039252133)
,p_page_id=>9009
,p_name=>'p_param1'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>60
,p_value_type=>'ITEM'
,p_value=>'P9009_PARAMETRO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19955574186252137)
,p_page_process_id=>wwv_flow_imp.id(19954122039252133)
,p_page_id=>9009
,p_name=>'p_url'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>40
,p_value_type=>'ITEM'
,p_value=>'P9009_URL_NEW'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19956074212252139)
,p_page_process_id=>wwv_flow_imp.id(19954122039252133)
,p_page_id=>9009
,p_name=>'p_codigo_arfato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>50
,p_value_type=>'ITEM'
,p_value=>'P9009_CODIGO_ARTEFATO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(19952178444252123)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'retorna_titulo_tela'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'RETORNA_TITULO_TELA'
,p_internal_uid=>62823050104894396
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19952646299252128)
,p_page_process_id=>wwv_flow_imp.id(19952178444252123)
,p_page_id=>9009
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P9009_CODIGO_ARTEFATO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19953201415252130)
,p_page_process_id=>wwv_flow_imp.id(19952178444252123)
,p_page_id=>9009
,p_name=>'p_titulo'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P0_TITULO_TELA'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19953655008252131)
,p_page_process_id=>wwv_flow_imp.id(19952178444252123)
,p_page_id=>9009
,p_name=>'p_help'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P9009_TELA_HELP'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(19951776325252121)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    /*',
'    PKG_UI.prc_configurar_filtros(',
'        p_id_usuario => :ID_USUARIO_LOGADO ,',
'        p_codigo_artefato => :P9009_CODIGO_ARTEFATO,',
'        p_app_page_id => :app_page_id   ',
'    );*/',
'end;',
'',
'',
'    ',
''))
,p_process_clob_language=>'PLSQL'
,p_required_patch=>wwv_flow_imp.id(340973604135556181)
,p_internal_uid=>62822647985894394
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(19956434706252140)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GETIMAGE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    ',
'',
'    for c1 in (select *',
'               from   MPD_USUARIO',
'               where  id = :P9009_ID) loop',
'        sys.htp.init;',
'        sys.owa_util.Mime_header(c1.foto_mimetype, false);',
'        sys.htp.P(''Content-length: ''|| sys.dbms_lob.Getlength(c1.foto));',
'        sys.htp.P(''Content-Disposition: attachment; filename="''|| c1.foto_name|| ''"'');',
'        sys.htp.P(''Cache-Control: max-age=1'');',
'        sys.owa_util.http_header_close;',
'        sys.wpg_docload.Download_file(c1.foto);',
'        apex_application.stop_apex_engine;',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>62827306366894413
);
wwv_flow_imp.component_end;
end;
/
