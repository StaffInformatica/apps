prompt --application/pages/page_00103
begin
--   Manifest
--     PAGE: 00103
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_page.create_page(
 p_id=>103
,p_name=>'Tenant - Mais detalhes'
,p_alias=>'TENANT-MAIS-DETALHES'
,p_step_title=>'Tenant - Mais detalhes'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$("h1").append($("#icon_info"));'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Body-side{',
'    width: auto;',
'    box-shadow: none;',
'    max-width: 450px;',
'}',
'',
'.t-Region-title{',
'    padding-left: 16px;',
'}',
'',
'.st-card-title {',
'    font-weight: bold;',
'    font-size: larger;',
'    padding: 16px;',
'}',
'',
'.overflow_line {',
'    white-space: normal;',
'    overflow: hidden;',
'    word-wrap: break-word;',
'    hyphens: auto;',
'}'))
,p_step_template=>wwv_flow_imp.id(489120808247697591)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'10'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(305452789575606246)
,p_plug_name=>'Titulo'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(489194609147697632)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(489109691639697566)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(489281376410697690)
,p_plug_header=>'<id id="icon_info" class="ico-info-sm margin-bottom-sm" style="display:inline-block;"></id>'
,p_required_patch=>wwv_flow_imp.id(489109181809697564)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(305452906248606247)
,p_plug_name=>'Painel esquerdo'
,p_region_css_classes=>'a-CardView'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>100
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(305452997189606248)
,p_plug_name=>'Dados gerais'
,p_parent_plug_id=>wwv_flow_imp.id(305452906248606247)
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>10
,p_plug_grid_column_css_classes=>'col-xs-12 col-sm-6 col-md-6 col-lg-5 col-xl-4 col-xxl-3'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Begin   ',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''MPD_TENANT.RAZAO_SOCIAL'',''fa-user-lock'',:P103_RAZAO_SOCIAL,p_color=>''1''));',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''MPD_TENANT.INSCRICAO_FEDERAL'',''fa-file-text-o'',:P103_INSCRICAO_FEDERAL,p_color=>''2''));',
'    -- Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''MPD_TENANT.NUMERO_LICENCA_USO_L'',''fa-briefcase'',:P103_NUMERO_LICENCA_USO,p_color=>''3''));    ',
'End;'))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(305453050166606249)
,p_plug_name=>unistr('Informa\00E7\00F5es de autentica\00E7\00E3o')
,p_parent_plug_id=>wwv_flow_imp.id(305452906248606247)
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-xs-12 col-sm-6 col-md-6 col-lg-5 col-xl-4 col-xxl-3'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Begin   ',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''mpd_tenant.autenticacao_mfa_ativa'',''fa-address-card-o'',:P103_AUTENTICACAO_MFA_ATIVA,p_color=>''1''));',
'    if :P103_FORMA_AUTENTICACAO is not null then',
'            Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''mpd_tenant.forma_autenticacao'',''fa-object-ungroup'',:P103_FORMA_AUTENTICACAO,p_color=>''2''));',
'    end if;',
'End;'))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(305453202578606250)
,p_plug_name=>'Outros'
,p_parent_plug_id=>wwv_flow_imp.id(305452906248606247)
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-xs-12 col-sm-6 col-md-6 col-lg-5 col-xl-4 col-xxl-3'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Begin ',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''mpd_tenant.qtd_maxima_tentativa_login'',''fa-sign-in'',:P103_QTD_MAXIMA_TENTATIVA_LOGIN,p_color=>''1''));',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''mpd_tenant.situacao_tenant'',''fa-info-circle-o'',:P103_SITUACAO_TENANT,p_color=>''2''));',
'End;'))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(129450510862611783191)
,p_plug_name=>'form'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--scrollBody:t-Form--large'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>110
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- select ID,',
'--        RAZAO_SOCIAL,',
'--        INSCRICAO_FEDERAL,',
'--        pkg_util.dominio_retorna_tag(''mpd_tenant'',''autenticacao_mfa_ativa'',autenticacao_mfa_ativa) as autenticacao_mfa_ativa,',
'--        pkg_util.dominio_retorna_tag(''mpd_tenant'',''forma_autenticacao'',forma_autenticacao) as forma_autenticacao,',
'--        NUMERO_LICENCA_USO,',
'--        QTD_MAXIMA_TENTATIVA_LOGIN,',
'--        pkg_util.dominio_retorna_tag(''mpd_tenant'',''situacao_tenant'',situacao_tenant) as situacao_tenant,',
'--        ID_USUARIO_INCLUIU,',
'--        DATA_INCLUSAO,',
'--        ID_USUARIO_ALTEROU,',
'--        DATA_ALTERACAO',
'-- from MPD_TENANT t1',
'',
'WITH split_forma_autenticacao AS (',
'    SELECT t1.ID,',
'           REGEXP_SUBSTR(t1.forma_autenticacao, ''[^:]+'', 1, LEVEL) AS forma_autenticacao',
'      FROM MPD_TENANT t1',
'    CONNECT BY REGEXP_SUBSTR(t1.forma_autenticacao, ''[^:]+'', 1, LEVEL) IS NOT NULL',
'       AND PRIOR t1.ID = t1.ID',
'       AND PRIOR SYS_GUID() IS NOT NULL',
')',
'SELECT t1.ID,',
'       t1.RAZAO_SOCIAL,',
'       t1.INSCRICAO_FEDERAL,',
'       pkg_util.dominio_retorna_tag(''mpd_tenant'', ''autenticacao_mfa_ativa'', t1.autenticacao_mfa_ativa) AS autenticacao_mfa_ativa,',
'       (SELECT LISTAGG(pkg_util.dominio_retorna_tag(''mpd_tenant'', ''forma_autenticacao'', sfa.forma_autenticacao), '', '')',
'               WITHIN GROUP (ORDER BY sfa.forma_autenticacao)',
'          FROM split_forma_autenticacao sfa',
'         WHERE sfa.ID = t1.ID) AS forma_autenticacao,',
'       t1.NUMERO_LICENCA_USO,',
'       t1.QTD_MAXIMA_TENTATIVA_LOGIN,',
'       pkg_util.dominio_retorna_tag(''mpd_tenant'', ''situacao_tenant'', t1.situacao_tenant) AS situacao_tenant,',
'       t1.ID_USUARIO_INCLUIU,',
'       t1.DATA_INCLUSAO,',
'       t1.ID_USUARIO_ALTEROU,',
'       t1.DATA_ALTERACAO',
'FROM MPD_TENANT t1;'))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_plug_read_only_when=>'P103_VISUALIZAR'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(197295235384656337)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(305452789575606246)
,p_button_name=>'close'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--simple'
,p_button_template_id=>wwv_flow_imp.id(489278989412697687)
,p_button_image_alt=>'close_l'
,p_button_position=>'CREATE'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-remove'
,p_required_patch=>wwv_flow_imp.id(489109181809697564)
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(305454191714606260)
,p_name=>'P103_SITUACAO_TENANT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(129450510862611783191)
,p_item_source_plug_id=>wwv_flow_imp.id(129450510862611783191)
,p_source=>'SITUACAO_TENANT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(305454236909606261)
,p_name=>'P103_AUTENTICACAO_MFA_ATIVA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_imp.id(129450510862611783191)
,p_item_source_plug_id=>wwv_flow_imp.id(129450510862611783191)
,p_source=>'AUTENTICACAO_MFA_ATIVA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(305454847327606267)
,p_name=>'P103_FORMA_AUTENTICACAO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_imp.id(129450510862611783191)
,p_item_source_plug_id=>wwv_flow_imp.id(129450510862611783191)
,p_source=>'FORMA_AUTENTICACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(349565395162797479)
,p_name=>'P103_VISUALIZAR'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(383744832792400711)
,p_name=>'P103_RAZAO_SOCIAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(129450510862611783191)
,p_item_source_plug_id=>wwv_flow_imp.id(129450510862611783191)
,p_source=>'RAZAO_SOCIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_help_text=>'mpd_tenant.razao_social_h'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(383744888628400712)
,p_name=>'P103_INSCRICAO_FEDERAL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(129450510862611783191)
,p_item_source_plug_id=>wwv_flow_imp.id(129450510862611783191)
,p_source=>'INSCRICAO_FEDERAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_help_text=>'mpd_tenant.inscricao_federal_h'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(383745074916400714)
,p_name=>'P103_NUMERO_LICENCA_USO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(129450510862611783191)
,p_item_source_plug_id=>wwv_flow_imp.id(129450510862611783191)
,p_source=>'NUMERO_LICENCA_USO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_help_text=>'mpd_tenant.numero_licenca_uso_h'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(383745239478400715)
,p_name=>'P103_QTD_MAXIMA_TENTATIVA_LOGIN'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(129450510862611783191)
,p_item_source_plug_id=>wwv_flow_imp.id(129450510862611783191)
,p_source=>'QTD_MAXIMA_TENTATIVA_LOGIN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_help_text=>'mpd_tenant.qtd_maxima_tentativa_login_h'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(384174382210865763)
,p_name=>'P103_RESULTADO'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(384174456899865764)
,p_name=>'P103_RESULTADO_MENSAGEM'
,p_item_sequence=>90
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(384299640914439862)
,p_name=>'P103_COPIA'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(408935857241188175)
,p_name=>'P103_CODIGO_ARTEFATO'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(408935955343188176)
,p_name=>'P103_TELA_TITULO'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(408936016292188177)
,p_name=>'P103_TELA_HELP'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(461038608287786812)
,p_name=>'P103_DATA_INCLUSAO'
,p_source_data_type=>'DATE'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(129450510862611783191)
,p_item_source_plug_id=>wwv_flow_imp.id(129450510862611783191)
,p_source=>'DATA_INCLUSAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(461038712707786813)
,p_name=>'P103_ID_USUARIO_INCLUIU'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(129450510862611783191)
,p_item_source_plug_id=>wwv_flow_imp.id(129450510862611783191)
,p_source=>'ID_USUARIO_INCLUIU'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(461038804909786814)
,p_name=>'P103_DATA_ALTERACAO'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(129450510862611783191)
,p_item_source_plug_id=>wwv_flow_imp.id(129450510862611783191)
,p_format_mask=>'DD-MON-YYYY HH24:MI:SS'
,p_source=>'DATA_ALTERACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(461038912456786815)
,p_name=>'P103_ID_USUARIO_ALTEROU'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(129450510862611783191)
,p_item_source_plug_id=>wwv_flow_imp.id(129450510862611783191)
,p_source=>'ID_USUARIO_ALTEROU'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(689986069200294802)
,p_name=>'P103_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(129450510862611783191)
,p_item_source_plug_id=>wwv_flow_imp.id(129450510862611783191)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(197295411561656338)
,p_name=>'onClickclose'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(197295235384656337)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(197295467221656339)
,p_event_id=>wwv_flow_imp.id(197295411561656338)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'closePage();'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(306693255815489427)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(129450510862611783191)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Form - Initialization'
,p_internal_uid=>123179136130249899
);
wwv_flow_imp.component_end;
end;
/
