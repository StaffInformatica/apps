prompt --application/pages/page_00103
begin
--   Manifest
--     PAGE: 00103
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>103
,p_name=>'Tenant - Mais detalhes'
,p_alias=>'TENANT-MAIS-DETALHES'
,p_step_title=>'Tenant - Mais detalhes'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$("h1").append($("#icon_info"));'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Body-side{',
'    width: auto;',
'    box-shadow: none;',
'    max-width: 450px;',
'}',
'',
'.t-Region-title{',
'    padding-left: 16px;',
'}',
'',
'.st-card-title {',
'    font-weight: bold;',
'    font-size: larger;',
'    padding: 16px;',
'}',
'',
'.overflow_line {',
'    white-space: normal;',
'    overflow: hidden;',
'    word-wrap: break-word;',
'    hyphens: auto;',
'}'))
,p_step_template=>wwv_flow_imp.id(340985230573556208)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'10'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(157317211901464863)
,p_plug_name=>'Titulo'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(341059031473556249)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(340974113965556183)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(341145798736556307)
,p_plug_header=>'<id id="icon_info" class="ico-info-sm margin-bottom-sm" style="display:inline-block;"></id>'
,p_required_patch=>wwv_flow_imp.id(340973604135556181)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(157317328574464864)
,p_plug_name=>'Painel esquerdo'
,p_region_css_classes=>'a-CardView'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>100
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(157317419515464865)
,p_plug_name=>'Dados gerais'
,p_parent_plug_id=>wwv_flow_imp.id(157317328574464864)
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>10
,p_plug_grid_column_css_classes=>'col-xs-12 col-sm-6 col-md-6 col-lg-5 col-xl-4 col-xxl-3'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Begin   ',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''MPD_TENANT.RAZAO_SOCIAL'',''fa-user-lock'',:P103_RAZAO_SOCIAL,p_color=>''1''));',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''MPD_TENANT.INSCRICAO_FEDERAL'',''fa-file-text-o'',:P103_INSCRICAO_FEDERAL,p_color=>''2''));',
'    -- Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''MPD_TENANT.NUMERO_LICENCA_USO_L'',''fa-briefcase'',:P103_NUMERO_LICENCA_USO,p_color=>''3''));    ',
'End;'))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(157317472492464866)
,p_plug_name=>unistr('Informa\00E7\00F5es de autentica\00E7\00E3o')
,p_parent_plug_id=>wwv_flow_imp.id(157317328574464864)
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-xs-12 col-sm-6 col-md-6 col-lg-5 col-xl-4 col-xxl-3'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Begin   ',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''mpd_tenant.autenticacao_mfa_ativa'',''fa-address-card-o'',:P103_AUTENTICACAO_MFA_ATIVA,p_color=>''1''));',
'    if :P103_FORMA_AUTENTICACAO is not null then',
'            Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''mpd_tenant.forma_autenticacao'',''fa-object-ungroup'',:P103_FORMA_AUTENTICACAO,p_color=>''2''));',
'    end if;',
'End;'))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(157317624904464867)
,p_plug_name=>'Outros'
,p_parent_plug_id=>wwv_flow_imp.id(157317328574464864)
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'col-xs-12 col-sm-6 col-md-6 col-lg-5 col-xl-4 col-xxl-3'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Begin ',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''mpd_tenant.qtd_maxima_tentativa_login'',''fa-sign-in'',:P103_QTD_MAXIMA_TENTATIVA_LOGIN,p_color=>''1''));',
'    Htp.p(PKG_COMPONENTES.HTML_CARD_DETAIL(''mpd_tenant.situacao_tenant'',''fa-info-circle-o'',:P103_SITUACAO_TENANT,p_color=>''2''));',
'End;'))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(129302375284937641808)
,p_plug_name=>'form'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--scrollBody:t-Form--large'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>110
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- select ID,',
'--        RAZAO_SOCIAL,',
'--        INSCRICAO_FEDERAL,',
'--        pkg_util.dominio_retorna_tag(''mpd_tenant'',''autenticacao_mfa_ativa'',autenticacao_mfa_ativa) as autenticacao_mfa_ativa,',
'--        pkg_util.dominio_retorna_tag(''mpd_tenant'',''forma_autenticacao'',forma_autenticacao) as forma_autenticacao,',
'--        NUMERO_LICENCA_USO,',
'--        QTD_MAXIMA_TENTATIVA_LOGIN,',
'--        pkg_util.dominio_retorna_tag(''mpd_tenant'',''situacao_tenant'',situacao_tenant) as situacao_tenant,',
'--        ID_USUARIO_INCLUIU,',
'--        DATA_INCLUSAO,',
'--        ID_USUARIO_ALTEROU,',
'--        DATA_ALTERACAO',
'-- from MPD_TENANT t1',
'',
'WITH split_forma_autenticacao AS (',
'    SELECT t1.ID,',
'           REGEXP_SUBSTR(t1.forma_autenticacao, ''[^:]+'', 1, LEVEL) AS forma_autenticacao',
'      FROM MPD_TENANT t1',
'    CONNECT BY REGEXP_SUBSTR(t1.forma_autenticacao, ''[^:]+'', 1, LEVEL) IS NOT NULL',
'       AND PRIOR t1.ID = t1.ID',
'       AND PRIOR SYS_GUID() IS NOT NULL',
')',
'SELECT t1.ID,',
'       t1.RAZAO_SOCIAL,',
'       t1.INSCRICAO_FEDERAL,',
'       pkg_util.dominio_retorna_tag(''mpd_tenant'', ''autenticacao_mfa_ativa'', t1.autenticacao_mfa_ativa) AS autenticacao_mfa_ativa,',
'       (SELECT LISTAGG(pkg_util.dominio_retorna_tag(''mpd_tenant'', ''forma_autenticacao'', sfa.forma_autenticacao), '', '')',
'               WITHIN GROUP (ORDER BY sfa.forma_autenticacao)',
'          FROM split_forma_autenticacao sfa',
'         WHERE sfa.ID = t1.ID) AS forma_autenticacao,',
'       t1.NUMERO_LICENCA_USO,',
'       t1.QTD_MAXIMA_TENTATIVA_LOGIN,',
'       pkg_util.dominio_retorna_tag(''mpd_tenant'', ''situacao_tenant'', t1.situacao_tenant) AS situacao_tenant,',
'       t1.ID_USUARIO_INCLUIU,',
'       t1.DATA_INCLUSAO,',
'       t1.ID_USUARIO_ALTEROU,',
'       t1.DATA_ALTERACAO',
'FROM MPD_TENANT t1;'))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_plug_read_only_when=>'P103_VISUALIZAR'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(49159657710514954)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(157317211901464863)
,p_button_name=>'close'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--simple'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_image_alt=>'close_l'
,p_button_position=>'CREATE'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-remove'
,p_required_patch=>wwv_flow_imp.id(340973604135556181)
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(157318614040464877)
,p_name=>'P103_SITUACAO_TENANT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(129302375284937641808)
,p_item_source_plug_id=>wwv_flow_imp.id(129302375284937641808)
,p_source=>'SITUACAO_TENANT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(157318659235464878)
,p_name=>'P103_AUTENTICACAO_MFA_ATIVA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_imp.id(129302375284937641808)
,p_item_source_plug_id=>wwv_flow_imp.id(129302375284937641808)
,p_source=>'AUTENTICACAO_MFA_ATIVA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(157319269653464884)
,p_name=>'P103_FORMA_AUTENTICACAO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_imp.id(129302375284937641808)
,p_item_source_plug_id=>wwv_flow_imp.id(129302375284937641808)
,p_source=>'FORMA_AUTENTICACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(201429817488656096)
,p_name=>'P103_VISUALIZAR'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(235609255118259328)
,p_name=>'P103_RAZAO_SOCIAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(129302375284937641808)
,p_item_source_plug_id=>wwv_flow_imp.id(129302375284937641808)
,p_source=>'RAZAO_SOCIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_help_text=>'mpd_tenant.razao_social_h'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(235609310954259329)
,p_name=>'P103_INSCRICAO_FEDERAL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(129302375284937641808)
,p_item_source_plug_id=>wwv_flow_imp.id(129302375284937641808)
,p_source=>'INSCRICAO_FEDERAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_help_text=>'mpd_tenant.inscricao_federal_h'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(235609497242259331)
,p_name=>'P103_NUMERO_LICENCA_USO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(129302375284937641808)
,p_item_source_plug_id=>wwv_flow_imp.id(129302375284937641808)
,p_source=>'NUMERO_LICENCA_USO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_help_text=>'mpd_tenant.numero_licenca_uso_h'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(235609661804259332)
,p_name=>'P103_QTD_MAXIMA_TENTATIVA_LOGIN'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(129302375284937641808)
,p_item_source_plug_id=>wwv_flow_imp.id(129302375284937641808)
,p_source=>'QTD_MAXIMA_TENTATIVA_LOGIN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_help_text=>'mpd_tenant.qtd_maxima_tentativa_login_h'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236038804536724380)
,p_name=>'P103_RESULTADO'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236038879225724381)
,p_name=>'P103_RESULTADO_MENSAGEM'
,p_item_sequence=>90
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236164063240298479)
,p_name=>'P103_COPIA'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(260800279567046792)
,p_name=>'P103_CODIGO_ARTEFATO'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(260800377669046793)
,p_name=>'P103_TELA_TITULO'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(260800438618046794)
,p_name=>'P103_TELA_HELP'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(312903030613645429)
,p_name=>'P103_DATA_INCLUSAO'
,p_source_data_type=>'DATE'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(129302375284937641808)
,p_item_source_plug_id=>wwv_flow_imp.id(129302375284937641808)
,p_source=>'DATA_INCLUSAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(312903135033645430)
,p_name=>'P103_ID_USUARIO_INCLUIU'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(129302375284937641808)
,p_item_source_plug_id=>wwv_flow_imp.id(129302375284937641808)
,p_source=>'ID_USUARIO_INCLUIU'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(312903227235645431)
,p_name=>'P103_DATA_ALTERACAO'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(129302375284937641808)
,p_item_source_plug_id=>wwv_flow_imp.id(129302375284937641808)
,p_format_mask=>'DD-MON-YYYY HH24:MI:SS'
,p_source=>'DATA_ALTERACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(312903334782645432)
,p_name=>'P103_ID_USUARIO_ALTEROU'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(129302375284937641808)
,p_item_source_plug_id=>wwv_flow_imp.id(129302375284937641808)
,p_source=>'ID_USUARIO_ALTEROU'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(541850491526153419)
,p_name=>'P103_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(129302375284937641808)
,p_item_source_plug_id=>wwv_flow_imp.id(129302375284937641808)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(49159833887514955)
,p_name=>'onClickclose'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(49159657710514954)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(49159889547514956)
,p_event_id=>wwv_flow_imp.id(49159833887514955)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'closePage();'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(158557678141348044)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(129302375284937641808)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Form - Initialization'
,p_internal_uid=>123179136130249899
);
wwv_flow_imp.component_end;
end;
/
