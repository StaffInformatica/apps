prompt --application/pages/page_09005
begin
--   Manifest
--     PAGE: 09005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_page.create_page(
 p_id=>9005
,p_name=>'Template - Cards avancado'
,p_alias=>'TEMPLATE-CARDS-AVANCADO'
,p_step_title=>'Template - Cards avancado'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://unpkg.com/intro.js/intro.js'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''.ui-dialog-title'').append($(''#BTN_DESFIXAR''));',
'',
'const toggleCardBody = (header) => {',
'  const card = header.closest(''.a-CardView'');',
'  if (!card) return;',
'  const body = card.querySelector(''.a-CardView-body'');',
'  if (!body) return;',
'',
'  body.style.display = (body.style.display === ''none'' || !body.style.display) ? ''block'' : ''none'';',
'};',
'',
'(function(){',
'    // Tempo inicial',
'    // console.log(''Log start:''+start);',
'',
unistr('    // Quando a p\00E1gina estiver completamente carregada'),
'    window.addEventListener("load", function(){',
'        var start = window.tempoInicio;',
'        var end = performance.now();',
'        var tempoTotal = Math.round(end - start); // em ms',
'',
'        console.log(''Log end:''+end);',
'        console.log(''Log tempoTotal:''+tempoTotal);',
'',
'        // Envia para o processo Ajax',
'        apex.server.process(',
'            "LOGAR_TEMPO_TELA",',
'            { x01: tempoTotal },',
'            { dataType: "text" }',
'        );',
'    });',
'})();',
'',
'',
'document.querySelectorAll(".progress-bar-cell").forEach(function(el) {',
'  var value = parseFloat(el.dataset.value) || 0;',
'  var total = parseFloat(el.dataset.value1) || 0;',
'  ',
unistr('  // Evita criar barra duplicada (se j\00E1 tiver um SVG dentro, pula)'),
'  if (el.querySelector("svg")) return;',
'',
'  var bar = new ProgressBar.Line(el, {',
'    strokeWidth: 4,',
'    color: ''#4caf50'',',
'    trailColor: ''#eee'',',
'    trailWidth: 4,',
'    svgStyle: {width: ''100%'', height: ''100%''}',
'  });',
'',
unistr('  bar.animate(value / total); // de 0\2013100 para 0\20131'),
'});'))
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://unpkg.com/intro.js/introjs.css',
'https://cdn.tailwindcss.com'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* .a-IRR-button--actions{',
'    display: none;',
'} */',
'',
'.text-red-strike {',
'  background-color: #f87171; /* vermelho claro (equivalente a bg-red-400 do Tailwind) */',
'  color: #991b1b;            /* vermelho escuro para contraste (equivalente a text-red-800 do Tailwind) */',
'  text-decoration: line-through;',
unistr('  padding: 0.25rem 0.5rem;  /* espa\00E7amento interno para ficar parecido com um badge */'),
'  border-radius: 0.375rem;  /* cantos arredondados (6px) */',
'  display: inline-block;    /* para respeitar o padding e arredondamento */',
'}',
'',
'.text-green-bg {',
'  background-color: #d1fae5; /* verde claro, parecido com bg-green-100 */',
'  color: #065f46;            /* verde escuro, parecido com text-green-800 */',
unistr('  padding: 0.25rem 0.5rem;  /* espa\00E7amento interno */'),
'  border-radius: 0.375rem;  /* cantos arredondados */',
'  display: inline-block;    /* para respeitar padding e border-radius */',
'}',
'',
'.diff-arrow {',
'  display: inline-block;',
'  margin-left: 0.5rem;   /* mx-2 equivale a 0.5rem = 8px */',
'  margin-right: 0.5rem;',
'  color: #6B7280;        /* text-gray-500 do Tailwind */',
'  font-weight: 700;',
'  user-select: none;',
'  pointer-events: none;',
'}',
'',
'.diff-arrow::before {',
unistr('  content: ''\2192'';          /* seta para indicar diferen\00E7a */'),
'  font-size: 1rem;',
'}',
'',
'.container-card {',
'    display: flex;',
'    justify-content: space-between;',
'    align-items: center;',
'}',
'',
'.left-element {',
'    flex-grow: 1;',
'}',
'',
'.right-element {',
unistr('    margin-left: 20px; /* Espa\00E7amento entre os elementos */'),
'    white-space: nowrap; /* Impede quebra de linha no segundo elemento */',
'}',
'',
'.ocultar{',
'    display: none;',
'}',
'',
'.a-CardView-opcao {',
'    grid-area: icon-end;',
'    padding-left: 15px;',
'    order: 4;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(373682445976353052)
,p_protection_level=>'C'
,p_page_component_map=>'22'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(177357158519447024)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_plug_template=>wwv_flow_imp.id(489175136164697621)
,p_plug_display_sequence=>240
,p_location=>null
,p_plug_source=>'<div>Northonn</div>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(376273412210021292)
,p_plug_name=>unistr('Opera\00E7\00F5es')
,p_parent_plug_id=>wwv_flow_imp.id(177357158519447024)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(489146466586697607)
,p_plug_display_sequence=>10
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return PKG_UI.buscar_acoes(:P9005_ID_ATUAL,:P9005_CODIGO_ARTEFATO,''E'',false,:P9005_PARAMETRO);',
''))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_BOT_ES_A__ES'
,p_ajax_items_to_submit=>'P9005_CODIGO_ARTEFATO,P9005_PARAMETRO'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_plug_query_no_data_found=>unistr('Nenhuma opera\00E7\00E3o dispon\00EDvel')
,p_no_data_found_icon_classes=>'fa-robot'
,p_show_total_row_count=>false
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'ICON', 'ICON',
  'LABEL', 'LABEL',
  'LINK', 'LINK',
  'MY_SECOND_PLACEHOLDER', 'HELP')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(177357803685447030)
,p_name=>'SQL_VALIDACAO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SQL_VALIDACAO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(219721528935791614)
,p_name=>'LABEL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LABEL'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(219721594051791615)
,p_name=>'HELP'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'HELP'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(376470005468229161)
,p_name=>'LINK'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LINK'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(376470084036229162)
,p_name=>'ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(194591347662162135)
,p_plug_name=>'Colunas'
,p_title=>'Colunas'
,p_region_name=>'COLUNAS'
,p_region_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--md'
,p_plug_template=>wwv_flow_imp.id(489175136164697621)
,p_plug_display_sequence=>180
,p_plug_display_point=>'REGION_POSITION_04'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(195192915356267642)
,p_plug_name=>'Order'
,p_region_template_options=>'#DEFAULT#:margin-bottom-md'
,p_component_template_options=>'[object Object]:[object Object]:[object Object]:t-BadgeList--circular:t-BadgeList--fixed:t-BadgeList--large'
,p_plug_template=>wwv_flow_imp.id(489146466586697607)
,p_plug_display_sequence=>20
,p_location=>null
,p_list_id=>wwv_flow_imp.id(196915103182293854)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(180904633691745375)
,p_required_patch=>wwv_flow_imp.id(489109181809697564)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(453146782770912131)
,p_plug_name=>'Header'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(489149217063697608)
,p_plug_display_sequence=>30
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD367'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_cabecalho(:param1,:param2); END;''',
'        USING OUT l_sql, IN nvl(:P9005_PARAMETRO, 0),nvl(:P9005_PARAMETRO2, 0);',
'',
'    return l_sql;       ',
'end;',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P9005_PARAMETRO'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from dual',
' where existe_na_package(''UI_MPD_''||nvl(:P9005_CODIGO_ARTEFATO,''TD367''), ''sql_cabecalho'') > 0'))
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(493775594544169375)
,p_plug_name=>'Filtrar por Esquerda'
,p_title=>'&P0_LABEL_FILTRAR.'
,p_region_name=>'PAINEL_LEFT'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_02'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(443473823310101348)
,p_plug_name=>'Arvore'
,p_parent_plug_id=>wwv_flow_imp.id(493775594544169375)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody:margin-top-sm:margin-left-sm:margin-right-sm'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD150'');',
'begin',
'    begin',
'        EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_tree(:param1); END;''',
'        USING OUT l_sql, IN :P9005_PARAMETRO;',
'',
'        exception',
'            when others then',
'                return ''select null id, null titulo, null chave_pai from dual'';',
'    end;',
'    return l_sql;       ',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_JSTREE'
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD150'');',
'begin',
'    begin',
'        EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_tree(:param1); END;''',
'        USING OUT l_sql, IN :P9005_PARAMETRO;',
'',
'        exception',
'            when others then',
'                return false;',
'    end;',
'    return true;       ',
'end;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'activate_node_link_with', 'S',
  'default_icon_css_class', 'icon-tree-folder',
  'icon_type_css_class', 'a-Icon',
  'node_id_column', 'ID',
  'node_label_column', 'TITULO',
  'parent_key_column', 'CHAVE_PAI',
  'start_tree_with', 'NULL',
  'tree_hierarchy', 'SQL',
  'tree_tooltip', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(495847875783475775)
,p_plug_name=>'PesquisaCard'
,p_region_name=>'PESQUISA'
,p_parent_plug_id=>wwv_flow_imp.id(493775594544169375)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(545498802259556720)
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P9005_CARD_OU_LISTA'
,p_plug_display_when_cond2=>'CAR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'batch_facet_search', 'Y',
  'compact_numbers_threshold', '10000',
  'display_chart_for_top_n_values', '10',
  'show_charts', 'Y',
  'show_current_facets', 'N',
  'show_total_row_count', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(508785348082911573)
,p_plug_name=>'Pesquisa Lista'
,p_region_name=>'PESQUISA_LISTA'
,p_parent_plug_id=>wwv_flow_imp.id(493775594544169375)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(507459522893908524)
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P9005_CARD_OU_LISTA'
,p_plug_display_when_cond2=>'GRI'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'batch_facet_search', 'Y',
  'compact_numbers_threshold', '10000',
  'display_chart_for_top_n_values', '10',
  'show_charts', 'Y',
  'show_current_facets', 'N',
  'show_total_row_count', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(493776519519169384)
,p_plug_name=>'Filtrar por Modal'
,p_title=>'&P0_LABEL_FILTRAR.'
,p_region_name=>'PAINEL_MODAL'
,p_region_template_options=>'#DEFAULT#:t-DialogRegion--noPadding:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--md'
,p_plug_template=>wwv_flow_imp.id(489175136164697621)
,p_plug_display_sequence=>120
,p_plug_display_point=>'REGION_POSITION_04'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(507459522893908524)
,p_name=>'Lista Oculta'
,p_region_name=>'LISTA_CR'
,p_template=>wwv_flow_imp.id(489146466586697607)
,p_display_sequence=>220
,p_region_css_classes=>'ocultar'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD778'');',
'begin',
'    if :P9005_CARD_OU_LISTA = ''GRI'' then',
'        EXECUTE IMMEDIATE',
'            ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_lista_oculta(:param1,:param2,:param3); END;''',
'            USING OUT l_sql, IN :P9005_PARAMETRO,:P9005_PARAMETRO2,:P9005_PARAMETRO3;',
'    else',
'        l_sql := q''~',
'            select ',
'                null              id,',
'                null              campo1,             ',
'                null              campo2,             ',
'                null              campo3,             ',
'                null              campo4,             ',
'                null              campo5,             ',
'                null              campo6,             ',
'                null              campo7,             ',
'                null              campo8,                                      ',
'                null              campo9,      ',
'                null              campo10,                                ',
'                null              filtro1,',
'                null              filtro2,',
'                null              filtro3,',
'                null              filtro4,',
'                null              filtro5,',
'                null              filtro_mult1,',
'                null              filtro_mult2,',
'                null              filtro_mult3,',
'                null              filtro_mult4,',
'                null              filtro_mult5,',
'                null              filtro_rangen,',
'                null              filtro_ranged,',
'                pkg_componentes.icone_opcao opcao',
'            from dual    ',
'        ~'';',
'    end if;',
'',
'    return l_sql;       ',
'end;'))
,p_optimizer_hint=>'APEX$USE_NO_GROUPING_SETS'
,p_display_when_condition=>'P9005_CARD_OU_LISTA'
,p_display_when_cond2=>'GRI'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P9005_PARAMETRO,P9005_CODIGO_ARTEFATO,P9005_CARD_OU_LISTA,P9005_PARAMETRO2,P9005_PARAMETRO3'
,p_lazy_loading=>true
,p_query_row_template=>wwv_flow_imp.id(489233170713697656)
,p_query_num_rows=>99999
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(192495354588659954)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'Id'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(194507960107771349)
,p_query_column_id=>2
,p_column_alias=>'CAMPO1'
,p_column_display_sequence=>20
,p_column_heading=>'Campo1'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(194508312213771350)
,p_query_column_id=>3
,p_column_alias=>'CAMPO2'
,p_column_display_sequence=>30
,p_column_heading=>'Campo2'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(194508748745771351)
,p_query_column_id=>4
,p_column_alias=>'CAMPO3'
,p_column_display_sequence=>40
,p_column_heading=>'Campo3'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(194509008859771353)
,p_query_column_id=>5
,p_column_alias=>'CAMPO4'
,p_column_display_sequence=>50
,p_column_heading=>'Campo4'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(194509437993771354)
,p_query_column_id=>6
,p_column_alias=>'CAMPO5'
,p_column_display_sequence=>60
,p_column_heading=>'Campo5'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(194509846204771356)
,p_query_column_id=>7
,p_column_alias=>'CAMPO6'
,p_column_display_sequence=>70
,p_column_heading=>'Campo6'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(194510264489771357)
,p_query_column_id=>8
,p_column_alias=>'CAMPO7'
,p_column_display_sequence=>80
,p_column_heading=>'Campo7'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(194510650835771358)
,p_query_column_id=>9
,p_column_alias=>'CAMPO8'
,p_column_display_sequence=>90
,p_column_heading=>'Campo8'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(194511011103771359)
,p_query_column_id=>10
,p_column_alias=>'CAMPO9'
,p_column_display_sequence=>100
,p_column_heading=>'Campo9'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(194511439314771360)
,p_query_column_id=>11
,p_column_alias=>'CAMPO10'
,p_column_display_sequence=>110
,p_column_heading=>'Campo10'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(192494361681659944)
,p_query_column_id=>12
,p_column_alias=>'FILTRO1'
,p_column_display_sequence=>130
,p_column_heading=>'Filtro1'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(192494463349659945)
,p_query_column_id=>13
,p_column_alias=>'FILTRO2'
,p_column_display_sequence=>140
,p_column_heading=>'Filtro2'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(192494553022659946)
,p_query_column_id=>14
,p_column_alias=>'FILTRO3'
,p_column_display_sequence=>150
,p_column_heading=>'Filtro3'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(192494869056659949)
,p_query_column_id=>15
,p_column_alias=>'FILTRO4'
,p_column_display_sequence=>180
,p_column_heading=>'Filtro4'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(192494951643659950)
,p_query_column_id=>16
,p_column_alias=>'FILTRO5'
,p_column_display_sequence=>190
,p_column_heading=>'Filtro5'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(192494695495659947)
,p_query_column_id=>17
,p_column_alias=>'FILTRO_MULT1'
,p_column_display_sequence=>200
,p_column_heading=>'Filtro Mult1'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(192494766109659948)
,p_query_column_id=>18
,p_column_alias=>'FILTRO_MULT2'
,p_column_display_sequence=>210
,p_column_heading=>'Filtro Mult2'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(192495089784659951)
,p_query_column_id=>19
,p_column_alias=>'FILTRO_MULT3'
,p_column_display_sequence=>220
,p_column_heading=>'Filtro Mult3'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(192495122236659952)
,p_query_column_id=>20
,p_column_alias=>'FILTRO_MULT4'
,p_column_display_sequence=>230
,p_column_heading=>'Filtro Mult4'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(192495226159659953)
,p_query_column_id=>21
,p_column_alias=>'FILTRO_MULT5'
,p_column_display_sequence=>240
,p_column_heading=>'Filtro Mult5'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(150242158839014722)
,p_query_column_id=>22
,p_column_alias=>'FILTRO_RANGEN'
,p_column_display_sequence=>250
,p_column_heading=>'Filtro Rangen'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(150242062865014721)
,p_query_column_id=>23
,p_column_alias=>'FILTRO_RANGED'
,p_column_display_sequence=>260
,p_column_heading=>'Filtro Ranged'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(194511893120771361)
,p_query_column_id=>24
,p_column_alias=>'OPCAO'
,p_column_display_sequence=>120
,p_column_heading=>'Opcao'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(507470729356910166)
,p_plug_name=>'Lista'
,p_region_name=>'LISTA'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(489179976861697624)
,p_plug_display_sequence=>230
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD150'');',
'begin',
'    begin',
'        EXECUTE IMMEDIATE ',
'            ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_report(:order); END;''',
'            -- ''BEGIN :l_sql := UI_MPD_100.sql_report; END;''',
'            USING OUT l_sql, IN :P9005_ORDER; ',
'        exception ',
'            when others then',
'                return ''select 1 from dual'';',
'    end;',
'    return l_sql;       ',
'end;'))
,p_optimizer_hint=>'APEX$USE_NO_GROUPING_SETS'
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P9005_CODIGO_ARTEFATO,P9005_ORDER'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P9005_CARD_OU_LISTA'
,p_plug_display_when_cond2=>'GRI'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(507470824206910167)
,p_max_row_count=>'999999'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_textbox=>'N'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'NTO'
,p_internal_uid=>402206118193411057
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(195193892371267651)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'AG'
,p_column_label=>'Id'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(195193997656267652)
,p_db_column_name=>'CAMPO1'
,p_display_order=>20
,p_column_identifier=>'AH'
,p_column_label=>'&P9005_LABEL_COLUNA1.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P9005_LABEL_COLUNA1 is not null and :P9005_MOSTRA_CAMPO1 = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(195194013579267653)
,p_db_column_name=>'CAMPO2'
,p_display_order=>30
,p_column_identifier=>'AI'
,p_column_label=>'&P9005_LABEL_COLUNA2.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P9005_LABEL_COLUNA2 is not null and :P9005_MOSTRA_CAMPO2 = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(195194135211267654)
,p_db_column_name=>'CAMPO3'
,p_display_order=>40
,p_column_identifier=>'AJ'
,p_column_label=>'&P9005_LABEL_COLUNA3.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P9005_LABEL_COLUNA3 is not null and :P9005_MOSTRA_CAMPO3 = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(195194292460267655)
,p_db_column_name=>'CAMPO4'
,p_display_order=>50
,p_column_identifier=>'AK'
,p_column_label=>'&P9005_LABEL_COLUNA4.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P9005_LABEL_COLUNA4 is not null and :P9005_MOSTRA_CAMPO4 = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(195194324147267656)
,p_db_column_name=>'CAMPO5'
,p_display_order=>60
,p_column_identifier=>'AL'
,p_column_label=>'&P9005_LABEL_COLUNA5.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P9005_LABEL_COLUNA5 is not null and :P9005_MOSTRA_CAMPO5 = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(195194478726267657)
,p_db_column_name=>'CAMPO6'
,p_display_order=>70
,p_column_identifier=>'AM'
,p_column_label=>'&P9005_LABEL_COLUNA6.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P9005_LABEL_COLUNA6 is not null and :P9005_MOSTRA_CAMPO6 = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(195194538532267658)
,p_db_column_name=>'CAMPO7'
,p_display_order=>80
,p_column_identifier=>'AN'
,p_column_label=>'&P9005_LABEL_COLUNA7.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P9005_LABEL_COLUNA7 is not null and :P9005_MOSTRA_CAMPO7 = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(195194681389267659)
,p_db_column_name=>'CAMPO8'
,p_display_order=>90
,p_column_identifier=>'AO'
,p_column_label=>'&P9005_LABEL_COLUNA8.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P9005_LABEL_COLUNA8 is not null and :P9005_MOSTRA_CAMPO8 = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(195194789813267660)
,p_db_column_name=>'CAMPO9'
,p_display_order=>100
,p_column_identifier=>'AP'
,p_column_label=>'&P9005_LABEL_COLUNA9.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P9005_LABEL_COLUNA9 is not null and :P9005_MOSTRA_CAMPO9 = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(197548815391077911)
,p_db_column_name=>'CAMPO10'
,p_display_order=>110
,p_column_identifier=>'AQ'
,p_column_label=>'&P9005_LABEL_COLUNA10.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P9005_LABEL_COLUNA10 is not null and :P9005_MOSTRA_CAMPO10 = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(197548979322077912)
,p_db_column_name=>'OPCAO'
,p_display_order=>120
,p_column_identifier=>'AR'
,p_column_label=>'&P0_LABEL_OPCAO.'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div style="display: flex; align-items: center; justify-content: center; flex-grow: 1;">',
'    <span #OPCAO# style="cursor: pointer; color: var(--a-button-state-text-color, var(--a-button-type-text-color, var(--a-button-text-color, inherit)));" ',
'        class="fa fa-ellipsis-v js-dlg-refresh" title="&P0_LABEL_OPCAO!RAW.">',
'    </span>',
'</div>',
'    '))
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(507596215173363621)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'355331'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'CAMPO1:CAMPO2:CAMPO3:CAMPO4:CAMPO5:CAMPO6:CAMPO7:CAMPO8:OPCAO:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(511336211431033960)
,p_plug_name=>unistr('Defini\00E7\00F5es do relat\00F3rio')
,p_region_name=>'ACTION'
,p_region_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--sm'
,p_component_template_options=>'t-MediaList--showIcons:t-MediaList--showDesc:u-colors'
,p_plug_template=>wwv_flow_imp.id(489175136164697621)
,p_plug_display_sequence=>170
,p_plug_display_point=>'REGION_POSITION_04'
,p_location=>null
,p_list_id=>wwv_flow_imp.id(370408162890364141)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(489261137203697672)
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(545498802259556720)
,p_plug_name=>'Card avancado'
,p_region_name=>'CARD'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(489153535293697610)
,p_plug_display_sequence=>80
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- declare',
'--     l_sql clob;',
'--     l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD711'');',
'-- begin',
'--     EXECUTE IMMEDIATE',
'--         ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_card(p_param1 => :param1, p_param3 => :order, p_param4 => :carrega); END;''',
'--         USING OUT l_sql, IN :P9005_PARAMETRO, :P9005_ORDER, :P9005_CARREGA_CONSULTA_CARD;',
'--     return l_sql;   ',
'-- end;',
'',
'',
'',
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD150'');',
' ',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_card(:param1,:param2,:param3); END;''',
'        USING OUT l_sql, IN :P9005_PARAMETRO,:P9005_PARAMETRO2,:P9005_PARAMETRO3;',
'    return l_sql;       ',
'end;',
''))
,p_optimizer_hint=>'APEX$USE_NO_GROUPING_SETS'
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P9005_CODIGO_ARTEFATO,P9005_PARAMETRO,P9005_PARAMETRO2,P9005_PARAMETRO3'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_existe number := 0;',
'begin',
'    select 1 into l_existe',
'      from dual',
'    where existe_na_package(''UI_MPD_''||nvl(:P9005_CODIGO_ARTEFATO,''TD367''), ''sql_card'') > 0;',
'    return :P9005_CARD_OU_LISTA = ''CAR'' and l_existe > 0;',
'end;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(194502444421771320)
,p_region_id=>wwv_flow_imp.id(545498802259556720)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>true
,p_title_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="a-CardView-header1" style="padding: 0;">',
'    &ICON!RAW.',
'    <div class="a-CardView-headerBody">',
'        <h3 class="a-CardView-title" title="&LABEL_TITULO!RAW.">&TITULO!RAW.</h3>',
'        <h4 class="a-CardView-subTitle" title="&LABEL_SUBTITULO!RAW.">&SUBTITULO!RAW.</h4>        ',
'    </div>',
'    <div class="a-CardView-badge &CLASS_DISTINTIVO!RAW." title="&LISTA_DISTINTIVO!RAW.">',
'        <span class="a-CardView-badgeValue" title="&LABEL_DISTINTIVO!RAW.">&DISTINTIVO!RAW.</span>',
'    </div>',
'    <div class="a-CardView-opcao" style="cursor: pointer;">',
'        <div style="display: flex; align-items: center; justify-content: center; flex-grow: 1;">',
'            <a &OPCAO!RAW. style="cursor: pointer; color: var(--a-button-state-text-color, var(--a-button-type-text-color, var(--a-button-text-color, inherit)));" ',
'                class="fa fa-ellipsis-v js-dlg-refresh" title="&P0_LABEL_OPCAO!RAW.">',
'            </a>',
'        </div>',
'    </div>',
'</div>',
'',
''))
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="container-card">',
'    <div class="left-element">',
'        <div class="row" style="display: flex; flex-wrap: wrap; justify-content: space-between;">',
'            &ATRIBUTO1!RAW.',
'            &ATRIBUTO2!RAW.',
'            &ATRIBUTO3!RAW.    ',
'            &ATRIBUTO4!RAW.',
'            &ATRIBUTO5!RAW.',
'            &ATRIBUTO6!RAW.',
'            &ATRIBUTO7!RAW.',
'            &ATRIBUTO8!RAW.',
'        </div>',
'    </div>',
'</div>',
'<div class="a-CardView-actionsPrimary" style="padding-top:16px;"> ',
'    <span class="a-CardView-button t-Button--link padding-none">',
'        <span class="a-CardView-buttonLabel" &URL_MAIS_DETALHES!RAW.>&P0_LABEL_MAIS_DETALHES.</span>',
'    </span>',
'</div>',
''))
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(194491753620771247)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(493776519519169384)
,p_button_name=>'desfixar'
,p_button_static_id=>'BTN_DESFIXAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(489278989412697687)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_FIXAR.'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'u-pullRight'
,p_icon_css_classes=>'fa-thumb-tack'
,p_button_cattributes=>'style="margin-left: auto; "'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(194501273317771311)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(493775594544169375)
,p_button_name=>'fixar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(489278989412697687)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_FIXAR.'
,p_button_position=>'COPY'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-thumb-tack'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(194591829168162140)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(194591347662162135)
,p_button_name=>'Save'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(489279734794697688)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_SALVAR.'
,p_button_position=>'CREATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(153842698782851913)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(165297110610388420)
,p_button_name=>'favNao'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(489278989412697687)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_ADICIONAR_FAV.'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P9005_FAVORITO = 0 and :P9005_PARAMETRO is null'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-star-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(153842647785851912)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(165297110610388420)
,p_button_name=>'favSim'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--warning:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(489278989412697687)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_REMOVER_FAV.'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P9005_FAVORITO = 1 and :P9005_PARAMETRO is null'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-star'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(194516084090771387)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(165297110610388420)
,p_button_name=>'VisaoReport'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(489278989412697687)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_VISAO_LISTA.'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P9005_CARD_OU_LISTA'
,p_button_condition2=>'CAR'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-columns'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(194516424524771389)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(165297110610388420)
,p_button_name=>'VisaoCard'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(489278989412697687)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_VISAO_CARD.'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P9005_CARD_OU_LISTA'
,p_button_condition2=>'GRI'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-list-ul'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(194516893250771390)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(165297110610388420)
,p_button_name=>'filter'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(489278989412697687)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_ESCONDER_MOSTRAR_PESQUISA.'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-filter'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(162914530508067547)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(165297110610388420)
,p_button_name=>'log'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(489278989412697687)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_HISTORICO_EXCLUSAO.'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:9010:&SESSION.::&DEBUG.:9010:P9010_CODIGO_ARTEFATO,P0_CODIGO_ARTEFATO,P9010_PARAMETRO,P9010_VISUALIZAR:TD833,TD833,&P9005_CODIGO_ARTEFATO.,1'
,p_icon_css_classes=>'fa-history fam-x fam-is-danger'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(194517702946771392)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(165297110610388420)
,p_button_name=>'Menu'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(489278989412697687)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_OPCAO.'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:9000:&SESSION.::&DEBUG.:9000:P9000_PAGINA:&P9005_CODIGO_ARTEFATO.'
,p_button_condition=>'PKG_UI.verifica_se_tem_linhas(PKG_UI.buscar_acoes(0,:P9005_CODIGO_ARTEFATO,''W'')) = true'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-ellipsis-v-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(194517289625771391)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(165297110610388420)
,p_button_name=>'New'
,p_button_static_id=>'NEW'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(489278989412697687)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_NOVO.'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'&P9005_URL_NEW.'
,p_button_css_classes=>'apex_disabled'
,p_icon_css_classes=>'fa-plus-circle'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(194497127773771290)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(507470729356910166)
,p_button_name=>'Opcoes'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(489278989412697687)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_CONFIGURACAO_LISTA.'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-gear'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(148189459302111911)
,p_name=>'P9005_ID_ATUAL'
,p_item_sequence=>210
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(148189831201111915)
,p_name=>'P9005_ATUALIZA_PAGINA'
,p_item_sequence=>30
,p_item_display_point=>'REGION_POSITION_01'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_retorno varchar2(10);',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD367'');',
'begin',
'    begin',
'        EXECUTE IMMEDIATE',
'            ''BEGIN :l_retorno := UI_MPD_''||l_pagina||''.atualizar_tela; END;''',
'            USING OUT l_retorno;',
'',
'        return l_retorno;       ',
'    exception',
'        when others then',
'        return ''false'';       ',
'    end;',
'end;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(149739833852659648)
,p_name=>'P9005_URL'
,p_item_sequence=>10
,p_item_display_point=>'REGION_POSITION_01'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(150242885798014729)
,p_name=>'P9005_FILTRO_RANGED_LISTA'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(508785348082911573)
,p_prompt=>'&P9005_NOME_FILTRO_RANGED.'
,p_source=>'FILTRO_RANGED'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD778'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''RD''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''RD''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'manual_entry', 'Y',
  'select_multiple', 'N')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(150243039518014730)
,p_name=>'P9005_FILTRO_RANGEN_LISTA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(508785348082911573)
,p_prompt=>'&P9005_NOME_FILTRO_RANGEN.'
,p_source=>'FILTRO_RANGEN'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD778'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''RN''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''RN''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'manual_entry', 'Y',
  'select_multiple', 'N')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(150244874081014749)
,p_name=>'P9005_NOME_FILTRO_RANGED'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(493775594544169375)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD778'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''RD''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';        ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(150244995310014750)
,p_name=>'P9005_NOME_FILTRO_RANGEN'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(493775594544169375)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD778'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''RN''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';        ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(150245123351014751)
,p_name=>'P9005_FILTRO_RANGED_CARD'
,p_source_data_type=>'TIMESTAMP_TZ'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(495847875783475775)
,p_prompt=>'&P9005_NOME_FILTRO_RANGED.'
,p_source=>'FILTRO_RANGED'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD778'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''RD''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''RD''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'manual_entry', 'Y',
  'select_multiple', 'N')).to_clob
,p_fc_show_label=>false
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(150245165448014752)
,p_name=>'P9005_FILTRO_RANGEN_CARD'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(495847875783475775)
,p_prompt=>'&P9005_NOME_FILTRO_RANGEN!RAW.'
,p_source=>'FILTRO_RANGEN'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD778'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''RN''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''RN''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'manual_entry', 'Y',
  'select_multiple', 'N')).to_clob
,p_fc_show_label=>false
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(153842075675851907)
,p_name=>'P9005_FAVORITO'
,p_item_sequence=>20
,p_item_display_point=>'REGION_POSITION_01'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(162946533060994122)
,p_name=>'P9005_CARREGA_CONSULTA_CARD'
,p_item_sequence=>200
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(192494029128659941)
,p_name=>'P9005_FILTRO_MULT_LISTA1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(508785348082911573)
,p_prompt=>'&P9005_NOME_FILTRO_MULT1.'
,p_source=>'FILTRO_MULT1'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''M1''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''M1''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(192494163489659942)
,p_name=>'P9005_FILTRO_MULT_LISTA2'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(508785348082911573)
,p_prompt=>'&P9005_NOME_FILTRO_MULT2.'
,p_source=>'FILTRO_MULT2'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''M2''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''M2''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(192494258107659943)
,p_name=>'P9005_ID'
,p_item_sequence=>130
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(192495499878659955)
,p_name=>'P9005_FILTRO_LISTA4'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(508785348082911573)
,p_prompt=>'&P9005_NOME_FILTRO4.'
,p_source=>'FILTRO4'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''4''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''4''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(192495602727659956)
,p_name=>'P9005_FILTRO_LISTA5'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(508785348082911573)
,p_prompt=>'&P9005_NOME_FILTRO5.'
,p_source=>'FILTRO5'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''5''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''5''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(192495617854659957)
,p_name=>'P9005_FILTRO_MULT_LISTA3'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(508785348082911573)
,p_prompt=>'&P9005_NOME_FILTRO_MULT3.'
,p_source=>'FILTRO_MULT3'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''M3''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''M3''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(192495805698659958)
,p_name=>'P9005_FILTRO_MULT_LISTA4'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(508785348082911573)
,p_prompt=>'&P9005_NOME_FILTRO_MULT4.'
,p_source=>'FILTRO_MULT4'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''M4''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''M4''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(192495834859659959)
,p_name=>'P9005_FILTRO_MULT_LISTA5'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(508785348082911573)
,p_prompt=>'&P9005_NOME_FILTRO_MULT5.'
,p_source=>'FILTRO_MULT5'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''M5''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''M5''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(192495992626659960)
,p_name=>'P9005_FILTRO_CARD4'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(495847875783475775)
,p_prompt=>'&P9005_NOME_FILTRO4.'
,p_source=>'FILTRO4'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''4''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''4''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(194589005922162111)
,p_name=>'P9005_FILTRO_CARD5'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(495847875783475775)
,p_prompt=>'&P9005_NOME_FILTRO5.'
,p_source=>'FILTRO5'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''5''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''5''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(194589086625162112)
,p_name=>'P9005_FILTRO_MULT_CARD3'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(495847875783475775)
,p_prompt=>'&P9005_NOME_FILTRO_MULT3.'
,p_source=>'FILTRO_MULT3'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''M3''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''M3''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(194589164690162113)
,p_name=>'P9005_FILTRO_MULT_CARD4'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(495847875783475775)
,p_prompt=>'&P9005_NOME_FILTRO_MULT4.'
,p_source=>'FILTRO_MULT4'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''M4''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''M4''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(194589283588162114)
,p_name=>'P9005_FILTRO_MULT_CARD5'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(495847875783475775)
,p_prompt=>'&P9005_NOME_FILTRO_MULT5.'
,p_source=>'FILTRO_MULT5'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''M5''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''M5''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(194589328814162115)
,p_name=>'P9005_NOME_FILTRO4'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(493775594544169375)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''F4''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';        ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(194589499345162116)
,p_name=>'P9005_NOME_FILTRO5'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(493775594544169375)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''F5''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';        ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(194589516989162117)
,p_name=>'P9005_NOME_FILTRO_MULT3'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(493775594544169375)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''M3''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';        ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(194589635118162118)
,p_name=>'P9005_NOME_FILTRO_MULT4'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(493775594544169375)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''M4''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';        ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(194589744128162119)
,p_name=>'P9005_NOME_FILTRO_MULT5'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(493775594544169375)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''M5''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';        ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(194591485804162136)
,p_name=>'P9005_COLUNAS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(194591347662162135)
,p_prompt=>'Mova para a direita as colunas que deseja esconder'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH colunas AS (',
'    SELECT ''CAMPO1'' id_coluna, :P9005_LABEL_COLUNA1 label FROM dual UNION ALL',
'    SELECT ''CAMPO2'', :P9005_LABEL_COLUNA2 FROM dual UNION ALL',
'    SELECT ''CAMPO3'', :P9005_LABEL_COLUNA3 FROM dual UNION ALL',
'    SELECT ''CAMPO4'', :P9005_LABEL_COLUNA4 FROM dual UNION ALL',
'    SELECT ''CAMPO5'', :P9005_LABEL_COLUNA5 FROM dual UNION ALL',
'    SELECT ''CAMPO6'', :P9005_LABEL_COLUNA6 FROM dual UNION ALL',
'    SELECT ''CAMPO7'', :P9005_LABEL_COLUNA7 FROM dual UNION ALL',
'    SELECT ''CAMPO8'', :P9005_LABEL_COLUNA8 FROM dual UNION ALL',
'    SELECT ''CAMPO9'', :P9005_LABEL_COLUNA9 FROM dual UNION ALL',
'    SELECT ''CAMPO10'', :P9005_LABEL_COLUNA10 FROM dual',
')',
'SELECT c.label d, c.id_coluna r',
'FROM colunas c',
'LEFT JOIN MPD_USUARIO_GRID_OCULTA_COLUNA u',
'    ON u.id_usuario = :ID_USUARIO_LOGADO',
'    AND u.codigo_artefato = :P9005_CODIGO_ARTEFATO',
'    AND u.id_coluna LIKE ''%'' || c.id_coluna || ''%''',
'WHERE --u.id_coluna IS NULL and ',
'c.label is not null',
''))
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(489277194088697685)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'MOVE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(194593342449162155)
,p_name=>'P9005_MOSTRA_CAMPO1'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(194591347662162135)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(194593444413162156)
,p_name=>'P9005_MOSTRA_CAMPO2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(194591347662162135)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(194593600369162157)
,p_name=>'P9005_MOSTRA_CAMPO3'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(194591347662162135)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(194593645058162158)
,p_name=>'P9005_MOSTRA_CAMPO4'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(194591347662162135)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(194593771135162159)
,p_name=>'P9005_MOSTRA_CAMPO5'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(194591347662162135)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(194593839514162160)
,p_name=>'P9005_MOSTRA_CAMPO6'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(194591347662162135)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(195189815172267611)
,p_name=>'P9005_MOSTRA_CAMPO7'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(194591347662162135)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(195189913633267612)
,p_name=>'P9005_MOSTRA_CAMPO8'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(194591347662162135)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(195190102184267613)
,p_name=>'P9005_MOSTRA_CAMPO9'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(194591347662162135)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(195190106357267614)
,p_name=>'P9005_MOSTRA_CAMPO10'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(194591347662162135)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(195193007484267643)
,p_name=>'P9005_ORDER'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213583546714003214)
,p_name=>'P9005_PARAMETRO3'
,p_item_sequence=>190
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(343201068290794552)
,p_name=>'P9005_PARAMETRO2'
,p_item_sequence=>180
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(369206595917983095)
,p_name=>'P9005_CARD_OU_LISTA'
,p_item_sequence=>140
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(370380044348065986)
,p_name=>'P9005_FILTRO_LIVRE_LISTA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(508785348082911573)
,p_prompt=>'Filtro Livre Lista'
,p_source=>'CAMPO1,CAMPO2,CAMPO3,CAMPO4'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'input_field', 'FACET',
  'search_type', 'ROW')).to_clob
,p_fc_show_chart=>false
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(386319636079300556)
,p_name=>'P9005_PARAMETRO'
,p_item_sequence=>170
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(460319902947787574)
,p_name=>'P9005_TELA_TITULO'
,p_item_sequence=>150
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(460320341699787579)
,p_name=>'P9005_TELA_HELP'
,p_item_sequence=>160
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(460568836661500365)
,p_name=>'P9005_FILTRO_CARD2'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(495847875783475775)
,p_prompt=>'&P9005_NOME_FILTRO2.'
,p_source=>'FILTRO2'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''2''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''2''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(460568965203500366)
,p_name=>'P9005_NOME_FILTRO2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(493775594544169375)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''F2''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';        ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(460569009475500367)
,p_name=>'P9005_FILTRO_CARD3'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(495847875783475775)
,p_prompt=>'&P9005_NOME_FILTRO3.'
,p_source=>'FILTRO3'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''3''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''3''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(460569132040500368)
,p_name=>'P9005_NOME_FILTRO3'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(493775594544169375)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''F3''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';        ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(460571019595500387)
,p_name=>'P9005_FILTRO_MULT_CARD1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(495847875783475775)
,p_prompt=>'&P9005_NOME_FILTRO_MULT1.'
,p_source=>'FILTRO_MULT1'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''M1''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''M1''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(460571081893500388)
,p_name=>'P9005_FILTRO_MULT_CARD2'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(495847875783475775)
,p_prompt=>'&P9005_NOME_FILTRO_MULT2.'
,p_source=>'FILTRO_MULT2'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''M2''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''M2''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(460571271764500389)
,p_name=>'P9005_NOME_FILTRO_MULT1'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(493775594544169375)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''M1''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';        ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(460571343204500390)
,p_name=>'P9005_NOME_FILTRO_MULT2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(493775594544169375)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''M2''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';        ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(475162781228520654)
,p_name=>'P9005_LABEL_COLUNA3'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(507470729356910166)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(475162963139520655)
,p_name=>'P9005_LABEL_COLUNA4'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(507470729356910166)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(475163030603520656)
,p_name=>'P9005_LABEL_COLUNA5'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(507470729356910166)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(475163161674520657)
,p_name=>'P9005_LABEL_COLUNA6'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(507470729356910166)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(475163267542520658)
,p_name=>'P9005_LABEL_COLUNA7'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(507470729356910166)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(475163277649520659)
,p_name=>'P9005_LABEL_COLUNA8'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(507470729356910166)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(475163442641520660)
,p_name=>'P9005_LABEL_COLUNA9'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(507470729356910166)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(475163569671520661)
,p_name=>'P9005_LABEL_COLUNA10'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(507470729356910166)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(481111809200210385)
,p_name=>'P9005_FILTRO_LISTA1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(508785348082911573)
,p_prompt=>'&P9005_NOME_FILTRO1.'
,p_source=>'FILTRO1'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD257'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''1''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD257'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''1''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(493843866691169577)
,p_name=>'P9005_TIPO_PESQUISA'
,p_item_sequence=>110
,p_item_default=>'1'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(495805239623523841)
,p_name=>'P9005_CODIGO_ARTEFATO'
,p_item_sequence=>100
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(495806161538523850)
,p_name=>'P9005_URL_NEW'
,p_item_sequence=>120
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(495867046737475859)
,p_name=>'P9005_FILTRO_LIVRE_CARD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(495847875783475775)
,p_prompt=>'Filtro Livre Card'
,p_source=>'TITULO,SUBTITULO,DISTINTIVO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'input_field', 'FACET',
  'search_type', 'ROW')).to_clob
,p_fc_show_chart=>false
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(495867086373475860)
,p_name=>'P9005_FILTRO_CARD1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(495847875783475775)
,p_prompt=>'&P9005_NOME_FILTRO1.'
,p_source=>'FILTRO1'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''1''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''1''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(495867198139475861)
,p_name=>'P9005_NOME_FILTRO1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(493775594544169375)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''F1''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';        ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(507865245157934294)
,p_name=>'P9005_LABEL_COLUNA1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(507470729356910166)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(507865396960934295)
,p_name=>'P9005_LABEL_COLUNA2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(507470729356910166)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(508896417195218160)
,p_name=>'P9005_FILTRO_LISTA2'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(508785348082911573)
,p_prompt=>'&P9005_NOME_FILTRO2.'
,p_source=>'FILTRO2'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD150'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''2''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD150'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''2''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(508897973845218176)
,p_name=>'P9005_FILTRO_LISTA3'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(508785348082911573)
,p_prompt=>'&P9005_NOME_FILTRO3.'
,p_source=>'FILTRO3'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''3''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''3''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(194520695914771408)
,p_computation_sequence=>10
,p_computation_item=>'P9005_LABEL_COLUNA1'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''1''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';       ',
'',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(194521041203771410)
,p_computation_sequence=>20
,p_computation_item=>'P9005_LABEL_COLUNA2'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''2''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';       ',
'',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(194521474154771411)
,p_computation_sequence=>30
,p_computation_item=>'P9005_LABEL_COLUNA3'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''3''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(194521867647771412)
,p_computation_sequence=>40
,p_computation_item=>'P9005_LABEL_COLUNA4'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''4''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;  ',
'    exception',
'        when others then',
'            return '''';       ',
'',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(194522277943771413)
,p_computation_sequence=>50
,p_computation_item=>'P9005_LABEL_COLUNA5'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''5''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(194522642571771414)
,p_computation_sequence=>60
,p_computation_item=>'P9005_LABEL_COLUNA6'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''6''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(194523056457771415)
,p_computation_sequence=>70
,p_computation_item=>'P9005_LABEL_COLUNA7'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''7''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(194523464998771416)
,p_computation_sequence=>80
,p_computation_item=>'P9005_LABEL_COLUNA8'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''8''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(194523819438771417)
,p_computation_sequence=>90
,p_computation_item=>'P9005_LABEL_COLUNA9'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''9''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(194524290293771418)
,p_computation_sequence=>100
,p_computation_item=>'P9005_LABEL_COLUNA10'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''10''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(194530182583771445)
,p_name=>'onClickFixar'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(194501273317771311)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(194530617954771447)
,p_event_id=>wwv_flow_imp.id(194530182583771445)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (apex.item( "P9005_TIPO_PESQUISA" ).getValue() == 1){',
'    apex.item( "P9005_TIPO_PESQUISA" ).setValue( 2 );',
'} else {',
'    apex.item( "P9005_TIPO_PESQUISA" ).setValue( 1 );',
'}',
'    '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(194531085360771448)
,p_name=>'onChangeTipoPesquisa = Esquerda'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9005_TIPO_PESQUISA'
,p_condition_element=>'P9005_TIPO_PESQUISA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(194531564729771449)
,p_event_id=>wwv_flow_imp.id(194531085360771448)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#PESQUISA'').appendTo(''#PAINEL_LEFT'');',
'$(''#PESQUISA_LISTA'').appendTo(''#PAINEL_LEFT'');',
'$(''#t_Body_side'').show();'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(194532060361771450)
,p_event_id=>wwv_flow_imp.id(194531085360771448)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(493776519519169384)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(194532454359771451)
,p_name=>'onChangeTipoPesquisa = Modal'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9005_TIPO_PESQUISA'
,p_condition_element=>'P9005_TIPO_PESQUISA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(194532889106771453)
,p_event_id=>wwv_flow_imp.id(194532454359771451)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#PESQUISA'').appendTo(''#PAINEL_MODAL .t-DrawerRegion-body'');    ',
'$(''#PESQUISA_LISTA'').appendTo(''#PAINEL_MODAL .t-DrawerRegion-body'');    ',
'$(''#t_Body_side'').hide();'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(194533383940771455)
,p_event_id=>wwv_flow_imp.id(194532454359771451)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(493776519519169384)
,p_build_option_id=>wwv_flow_imp.id(489109181809697564)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(194533766351771456)
,p_name=>'onClickDesfixar'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(194491753620771247)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(194534238247771457)
,p_event_id=>wwv_flow_imp.id(194533766351771456)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (apex.item( "P9005_TIPO_PESQUISA" ).getValue() == 1){',
'    apex.item( "P9005_TIPO_PESQUISA" ).setValue( 2 );',
'} else {',
'    apex.item( "P9005_TIPO_PESQUISA" ).setValue( 1 );',
'}',
'    '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(194534690148771458)
,p_name=>'onMouseEnterTooltip'
,p_event_sequence=>70
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'$("#icon_info")'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'mouseenter'
,p_required_patch=>wwv_flow_imp.id(489109181809697564)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(194535174271771460)
,p_event_id=>wwv_flow_imp.id(194534690148771458)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'PLUGIN_COM.FOS.TOOLTIP'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'$("#icon_info")'
,p_attribute_01=>'static'
,p_attribute_05=>'&P9005_TELA_HELP. (&P9005_CODIGO_ARTEFATO.)'
,p_attribute_08=>'#007BFE'
,p_attribute_09=>'#FFFFFF'
,p_attribute_10=>'scale'
,p_attribute_11=>'500'
,p_attribute_12=>'hover'
,p_attribute_13=>'top'
,p_attribute_14=>'cache-result,escape-html'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(194535541584771461)
,p_name=>'onCloseNew'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(194517289625771391)
,p_condition_element=>'P9005_ATUALIZA_PAGINA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'true'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(148189960871111916)
,p_event_id=>wwv_flow_imp.id(194535541584771461)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'location.reload();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(188100866724846924)
,p_event_id=>wwv_flow_imp.id(194535541584771461)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(545498802259556720)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(188100960203846925)
,p_event_id=>wwv_flow_imp.id(194535541584771461)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(507470729356910166)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(188103805568846953)
,p_event_id=>wwv_flow_imp.id(194535541584771461)
,p_event_result=>'FALSE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(495847875783475775)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(188103840867846954)
,p_event_id=>wwv_flow_imp.id(194535541584771461)
,p_event_result=>'FALSE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(508785348082911573)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(194535928106771462)
,p_name=>'onClickFilter = Esquerda'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(194516893250771390)
,p_condition_element=>'P9005_TIPO_PESQUISA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(194536410001771463)
,p_event_id=>wwv_flow_imp.id(194535928106771462)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#t_Body_side'').is('':visible'')) {',
'    $(''#t_Body_side'').hide();',
'} else {',
'    $(''#t_Body_side'').show();',
'}',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(194536820285771464)
,p_name=>'onClickFilter = Modal'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(194516893250771390)
,p_condition_element=>'P9005_TIPO_PESQUISA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(194537397467771465)
,p_event_id=>wwv_flow_imp.id(194536820285771464)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(493776519519169384)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(194537777280771466)
,p_name=>'onPageLoad'
,p_event_sequence=>110
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(194538223826771468)
,p_event_id=>wwv_flow_imp.id(194537777280771466)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(194517289625771391)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(194529288457771440)
,p_name=>'onClickOpcoes'
,p_event_sequence=>150
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(194497127773771290)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(194529724203771443)
,p_event_id=>wwv_flow_imp.id(194529288457771440)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(511336211431033960)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(195191377187267626)
,p_name=>'onAfterRefreshPesquisaCard'
,p_event_sequence=>160
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(495847875783475775)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(195191423561267627)
,p_event_id=>wwv_flow_imp.id(195191377187267626)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9005_CARREGA_CONSULTA_CARD'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'S'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P9005_FILTRO_LIVRE_CARD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(195192247224267635)
,p_event_id=>wwv_flow_imp.id(195191377187267626)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9005_CARREGA_CONSULTA_CARD'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'NULL'
,p_client_condition_element=>'P9005_FILTRO_LIVRE_CARD'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(188101232733846928)
,p_name=>'onCloseCard'
,p_event_sequence=>180
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(545498802259556720)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(188101392452846929)
,p_event_id=>wwv_flow_imp.id(188101232733846928)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(545498802259556720)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(188103997838846955)
,p_event_id=>wwv_flow_imp.id(188101232733846928)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(495847875783475775)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(188101483182846930)
,p_name=>'onCloseLista'
,p_event_sequence=>190
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(507470729356910166)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(188101593166846931)
,p_event_id=>wwv_flow_imp.id(188101483182846930)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(507470729356910166)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(188104011379846956)
,p_event_id=>wwv_flow_imp.id(188101483182846930)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(508785348082911573)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(195193174125267644)
,p_name=>'onClickBotaoOrder'
,p_event_sequence=>200
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#botao_order'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(195193215499267645)
,p_event_id=>wwv_flow_imp.id(195193174125267644)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(545498802259556720)
,p_attribute_01=>'N'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P9005_CARD_OU_LISTA'
,p_client_condition_expression=>'CAR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(195193688261267649)
,p_event_id=>wwv_flow_imp.id(195193174125267644)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(507470729356910166)
,p_attribute_01=>'N'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P9005_CARD_OU_LISTA'
,p_client_condition_expression=>'GRI'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(177358251127447035)
,p_name=>'onClickA-CardView-item '
,p_event_sequence=>210
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.a-CardView-item '
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(177357859765447031)
,p_event_id=>wwv_flow_imp.id(177358251127447035)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9005_ID_ATUAL'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.dataset[''id'']'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(188103308245846949)
,p_name=>'onCloseMenu'
,p_event_sequence=>220
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(194517702946771392)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(188103462245846950)
,p_event_id=>wwv_flow_imp.id(188103308245846949)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(545498802259556720)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(188103507444846951)
,p_event_id=>wwv_flow_imp.id(188103308245846949)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(507470729356910166)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(188104109887846957)
,p_event_id=>wwv_flow_imp.id(188103308245846949)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(495847875783475775)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(188104293173846958)
,p_event_id=>wwv_flow_imp.id(188103308245846949)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(508785348082911573)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(210123517429860938)
,p_name=>'onAfterRefreshListaOculta'
,p_event_sequence=>230
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(507459522893908524)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(210123618067860939)
,p_event_id=>wwv_flow_imp.id(210123517429860938)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(507470729356910166)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(177357005788447022)
,p_name=>'New_1'
,p_event_sequence=>250
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(376273412210021292)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(177356894325447021)
,p_event_id=>wwv_flow_imp.id(177357005788447022)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(177357158519447024)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(153843597175851922)
,p_name=>'onClickVisaoReport'
,p_event_sequence=>260
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(194516084090771387)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(153843524086851921)
,p_event_id=>wwv_flow_imp.id(153843597175851922)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    p_sucesso clob;',
'    p_messages pkg_mensagem.message_record_table;',
'begin',
'    bo_mpd_usuario_artefato_formato.inclui_ou_altera_registro(',
'        p_codigo_artefato => :P9005_CODIGO_ARTEFATO,',
'        p_formato => ''GRI'',',
'        p_sucesso => p_sucesso,',
'        p_messages => p_messages',
'    );',
'    :P9005_URL := apex_page.get_url( ',
'        p_page => 9005,  ',
'        p_items => ''P9005_CODIGO_ARTEFATO,P9005_PARAMETRO,P9005_PARAMETRO2'', ',
'        p_values => :P9005_CODIGO_ARTEFATO||'',''||:P9005_PARAMETRO||'',''||:P9005_PARAMETRO2);         ',
'end;'))
,p_attribute_02=>'P9005_CODIGO_ARTEFATO'
,p_attribute_03=>'P9005_URL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(149739705834659647)
,p_event_id=>wwv_flow_imp.id(153843597175851922)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v(''P9005_URL''))',
'    window.location.replace($v(''P9005_URL''));        '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(153843424792851920)
,p_name=>'onClickVisaoCard'
,p_event_sequence=>270
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(194516424524771389)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(153843205762851918)
,p_event_id=>wwv_flow_imp.id(153843424792851920)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    p_sucesso clob;',
'    p_messages pkg_mensagem.message_record_table;',
'begin',
'    bo_mpd_usuario_artefato_formato.inclui_ou_altera_registro(',
'        p_codigo_artefato => :P9005_CODIGO_ARTEFATO,',
'        p_formato => ''CAR'',',
'        p_sucesso => p_sucesso,',
'        p_messages => p_messages',
'    );',
'    :P9005_URL := apex_page.get_url( ',
'        p_page => 9005,  ',
'        p_items => ''P9005_CODIGO_ARTEFATO,P9005_PARAMETRO,P9005_PARAMETRO2'', ',
'        p_values => :P9005_CODIGO_ARTEFATO||'',''||:P9005_PARAMETRO||'',''||:P9005_PARAMETRO2);        ',
'end;'))
,p_attribute_02=>'P9005_CODIGO_ARTEFATO'
,p_attribute_03=>'P9005_URL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(149739630574659646)
,p_event_id=>wwv_flow_imp.id(153843424792851920)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v(''P9005_URL''))',
'    window.location.replace($v(''P9005_URL''));        '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(153842474473851911)
,p_name=>'onClickFavNao'
,p_event_sequence=>280
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(153842698782851913)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(153842381333851910)
,p_event_id=>wwv_flow_imp.id(153842474473851911)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    p_sucesso clob;',
'    p_messages pkg_mensagem.message_record_table;',
'begin',
'    bo_mpd_usuario_artefato_favorito.inclui_ou_exclui_registro(',
'        p_codigo_artefato => :P9005_CODIGO_ARTEFATO,',
'        p_acao => 1, -- inclui favorito',
'        p_sucesso => p_sucesso,',
'        p_messages => p_messages',
'    );',
'    :P9005_URL := apex_page.get_url( ',
'        p_page => 9005,  ',
'        p_items => ''P9005_CODIGO_ARTEFATO,P9005_PARAMETRO,P9005_PARAMETRO2'', ',
'        p_values => :P9005_CODIGO_ARTEFATO||'',''||:P9005_PARAMETRO||'',''||:P9005_PARAMETRO2);        ',
'end;'))
,p_attribute_02=>'P9005_CODIGO_ARTEFATO'
,p_attribute_03=>'P9005_URL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(149738848049659638)
,p_event_id=>wwv_flow_imp.id(153842474473851911)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v(''P9005_URL''))',
'    window.location.replace($v(''P9005_URL''));        '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(153842250757851909)
,p_name=>'onClickFavSim'
,p_event_sequence=>290
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(153842647785851912)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(153842216221851908)
,p_event_id=>wwv_flow_imp.id(153842250757851909)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    p_sucesso clob;',
'    p_messages pkg_mensagem.message_record_table;',
'begin',
'    bo_mpd_usuario_artefato_favorito.inclui_ou_exclui_registro(',
'        p_codigo_artefato => :P9005_CODIGO_ARTEFATO,',
'        p_acao => 2, -- exclui',
'        p_sucesso => p_sucesso,',
'        p_messages => p_messages',
'    );',
'    :P9005_URL := apex_page.get_url( ',
'        p_page => 9005,  ',
'        p_items => ''P9005_CODIGO_ARTEFATO,P9005_PARAMETRO,P9005_PARAMETRO2'', ',
'        p_values => :P9005_CODIGO_ARTEFATO||'',''||:P9005_PARAMETRO||'',''||:P9005_PARAMETRO2);        ',
'end;'))
,p_attribute_02=>'P9005_CODIGO_ARTEFATO'
,p_attribute_03=>'P9005_URL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(149738660004659637)
,p_event_id=>wwv_flow_imp.id(153842250757851909)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v(''P9005_URL''))',
'    window.location.replace($v(''P9005_URL''));        '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(167909359314720811)
,p_name=>'onAfterRefreshPesquisaLista'
,p_event_sequence=>300
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(508785348082911573)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(167909521558720813)
,p_event_id=>wwv_flow_imp.id(167909359314720811)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9005_CARREGA_CONSULTA_CARD'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'S'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P9005_FILTRO_LIVRE_CARD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(167909626734720814)
,p_event_id=>wwv_flow_imp.id(167909359314720811)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9005_CARREGA_CONSULTA_CARD'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'NULL'
,p_client_condition_element=>'P9005_FILTRO_LIVRE_CARD'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(201573476826918445)
,p_name=>'onChangeUrlNew'
,p_event_sequence=>310
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9005_URL_NEW'
,p_condition_element=>'P9005_URL_NEW'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(201573545842918446)
,p_event_id=>wwv_flow_imp.id(201573476826918445)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(194517289625771391)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(201573689662918447)
,p_event_id=>wwv_flow_imp.id(201573476826918445)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(194517289625771391)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(194591982758162141)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>unistr('Salvar personaliza\00E7\00E3o das colunas')
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'BO_MPD_USUARIO_GRID_OCULTA_COLUNA'
,p_attribute_04=>'INCLUI_OU_ALTERA_REGISTRO'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(194591829168162140)
,p_internal_uid=>89327276744663031
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(195190584514267618)
,p_page_process_id=>wwv_flow_imp.id(194591982758162141)
,p_page_id=>9005
,p_name=>'p_id_coluna'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P9005_COLUNAS'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(195190698304267619)
,p_page_process_id=>wwv_flow_imp.id(194591982758162141)
,p_page_id=>9005
,p_name=>'p_id_usuario'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'ID_USUARIO_LOGADO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(195190793050267620)
,p_page_process_id=>wwv_flow_imp.id(194591982758162141)
,p_page_id=>9005
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P9005_CODIGO_ARTEFATO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(195190843120267621)
,p_page_process_id=>wwv_flow_imp.id(194591982758162141)
,p_page_id=>9005
,p_name=>'p_pagina'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>true
,p_display_sequence=>40
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(195190981558267622)
,p_page_process_id=>wwv_flow_imp.id(194591982758162141)
,p_page_id=>9005
,p_name=>'p_encadeado'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>50
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(195191047555267623)
,p_page_process_id=>wwv_flow_imp.id(194591982758162141)
,p_page_id=>9005
,p_name=>'p_sucesso'
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>true
,p_display_sequence=>60
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(195191204006267624)
,p_page_process_id=>wwv_flow_imp.id(194591982758162141)
,p_page_id=>9005
,p_name=>'p_messages'
,p_direction=>'OUT'
,p_data_type=>'pkg_mensagem.message_record_table'
,p_display_sequence=>70
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(194526837897771433)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'url_new'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'URL_NEW'
,p_internal_uid=>89262131884272323
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(194527375139771434)
,p_page_process_id=>wwv_flow_imp.id(194526837897771433)
,p_page_id=>9005
,p_name=>'p_param2'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>70
,p_value_type=>'ITEM'
,p_value=>'P9005_PARAMETRO2'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(194527835569771435)
,p_page_process_id=>wwv_flow_imp.id(194526837897771433)
,p_page_id=>9005
,p_name=>'p_param1'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>60
,p_value_type=>'ITEM'
,p_value=>'P9005_PARAMETRO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(194528340039771437)
,p_page_process_id=>wwv_flow_imp.id(194526837897771433)
,p_page_id=>9005
,p_name=>'p_url'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>40
,p_value_type=>'ITEM'
,p_value=>'P9005_URL_NEW'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(194528848074771438)
,p_page_process_id=>wwv_flow_imp.id(194526837897771433)
,p_page_id=>9005
,p_name=>'p_codigo_arfato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>50
,p_value_type=>'ITEM'
,p_value=>'P9005_CODIGO_ARTEFATO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(194524953003771421)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'retorna_titulo_tela'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'RETORNA_TITULO_TELA'
,p_internal_uid=>89260246990272311
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(194525462737771429)
,p_page_process_id=>wwv_flow_imp.id(194524953003771421)
,p_page_id=>9005
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P9005_CODIGO_ARTEFATO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(194525947318771431)
,p_page_process_id=>wwv_flow_imp.id(194524953003771421)
,p_page_id=>9005
,p_name=>'p_titulo'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P0_TITULO_TELA'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(194526499515771432)
,p_page_process_id=>wwv_flow_imp.id(194524953003771421)
,p_page_id=>9005
,p_name=>'p_help'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P0_HELP_TELA'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(194524578701771419)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_formato varchar2(3);',
'    l_id number;',
'    l_data_alteracao timestamp;',
'begin',
'    ',
'    PKG_UI.prc_configurar_filtros(',
'        p_id_usuario => :ID_USUARIO_LOGADO ,',
'        p_codigo_artefato => :P9005_CODIGO_ARTEFATO,',
'        p_app_page_id => :app_page_id   ',
'    );',
'',
'    begin',
'        select formato into l_formato from mpd_usuario_artefato_formato ',
'        where upper(login) = upper(apex_custom_auth.get_username) ',
'        and upper(codigo_artefato) = upper(:P9005_CODIGO_ARTEFATO)',
'        and aplicacao = apex_application.g_flow_id;',
'        exception',
'            when no_data_found then',
'                l_formato := null;',
'    end;',
'',
'    :P9005_CARD_OU_LISTA := l_formato;    ',
'    if :P9005_CARD_OU_LISTA is null then',
'        :P9005_CARD_OU_LISTA := ''CAR'';',
'    end if;    ',
'',
'    bo_mpd_usuario_artefato_favorito.retorna_registro( ',
'        p_login => upper(apex_custom_auth.get_username),',
'        p_codigo_artefato => :P9005_CODIGO_ARTEFATO,',
'        p_aplicacao => apex_application.g_flow_id,',
'        p_id => l_id,',
'        p_data_alteracao => l_data_alteracao',
'    );    ',
'    if l_id is not null then',
'        :P9005_FAVORITO := 1;',
'    else',
'        :P9005_FAVORITO := 0;',
'    end if;',
'',
'end;',
'',
'',
'    ',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>89259872688272309
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(194591238716162134)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GETIMAGE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    ',
'',
'    for c1 in (select *',
'               from   MPD_USUARIO',
'               where  id = :P9005_ID) loop',
'        sys.htp.init;',
'        sys.owa_util.Mime_header(c1.foto_mimetype, false);',
'        sys.htp.P(''Content-length: ''|| sys.dbms_lob.Getlength(c1.foto));',
'        sys.htp.P(''Content-Disposition: attachment; filename="''|| c1.foto_name|| ''"'');',
'        sys.htp.P(''Cache-Control: max-age=1'');',
'        sys.owa_util.http_header_close;',
'        sys.wpg_docload.Download_file(c1.foto);',
'        apex_application.stop_apex_engine;',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>89326532702663024
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(151866697240383507)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LOGAR_TEMPO_TELA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_usuario VARCHAR2(255) := NVL(apex_application.g_user, ''ANONYMOUS'');',
'BEGIN',
'    INSERT INTO log_tempo_tela (usuario, app_id, page_id, codigo_artefato, tempo_ms)',
'    VALUES (',
'        v_usuario,',
'        :APP_ID,',
'        :APP_PAGE_ID,',
'        :P0_CODIGO_ARTEFATO,',
'        TO_NUMBER(apex_application.g_x01) -- tempo enviado pelo JS',
'    );',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>39139752094400149
);
wwv_flow_imp.component_end;
end;
/
