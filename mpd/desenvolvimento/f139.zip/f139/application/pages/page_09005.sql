prompt --application/pages/page_09005
begin
--   Manifest
--     PAGE: 09005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>9005
,p_name=>'Template - Cards avancado'
,p_alias=>'TEMPLATE-CARDS-AVANCADO'
,p_step_title=>'Template - Cards avancado'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://unpkg.com/intro.js/intro.js',
'#APP_FILES#ordenacao#MIN#.js'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'window.pageSort = SortComponent.create({',
'  columnsItem: ''P9005_SORT_JSON'',',
'  defaultSortItem: ''P9005_SORT_JSON_DEFAULT'',',
'  outputJsonItem: ''P9005_SORT_JSON'',',
'  outputOrderItem: ''P9005_ORDER'',',
'  selectItem: ''P9005_SORT_COLUMN'',',
'  listElementId: ''SORT_LIST'',',
'  viewModeItem: ''P9005_CARD_OU_LISTA'',',
'  cardRegion: ''CARD'',',
'  listRegion: ''LISTA''',
'});',
'',
'$(''.ui-dialog-title'').append($(''#BTN_DESFIXAR''));',
'',
'const toggleCardBody = (header) => {',
'  const card = header.closest(''.a-CardView'');',
'  if (!card) return;',
'  const body = card.querySelector(''.a-CardView-body'');',
'  if (!body) return;',
'',
'  body.style.display = (body.style.display === ''none'' || !body.style.display) ? ''block'' : ''none'';',
'};',
'',
'(function(){',
'    // Tempo inicial',
'    // console.log(''Log start:''+start);',
'',
unistr('    // Quando a p\00E1gina estiver completamente carregada'),
'    window.addEventListener("load", function(){',
'        var start = window.tempoInicio;',
'        var end = performance.now();',
'        var tempoTotal = Math.round(end - start); // em ms',
'',
'        console.log(''Log end:''+end);',
'        console.log(''Log tempoTotal:''+tempoTotal);',
'',
'        // Envia para o processo Ajax',
'        apex.server.process(',
'            "LOGAR_TEMPO_TELA",',
'            { x01: tempoTotal },',
'            { dataType: "text" }',
'        );',
'    });',
'})();',
'',
'',
'document.querySelectorAll(".progress-bar-cell").forEach(function(el) {',
'  var value = parseFloat(el.dataset.value) || 0;',
'  var total = parseFloat(el.dataset.value1) || 0;',
'  ',
unistr('  // Evita criar barra duplicada (se j\00E1 tiver um SVG dentro, pula)'),
'  if (el.querySelector("svg")) return;',
'',
'  var bar = new ProgressBar.Line(el, {',
'    strokeWidth: 4,',
'    color: ''#4caf50'',',
'    trailColor: ''#eee'',',
'    trailWidth: 4,',
'    svgStyle: {width: ''100%'', height: ''100%''}',
'  });',
'',
unistr('  bar.animate(value / total); // de 0\2013100 para 0\20131'),
'});'))
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://unpkg.com/intro.js/introjs.css',
'https://cdn.tailwindcss.com',
'#APP_FILES#sort-component.css',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-button--actions{',
'    display: none;',
'}',
'',
'.text-red-strike {',
'  background-color: #f87171; /* vermelho claro (equivalente a bg-red-400 do Tailwind) */',
'  color: #991b1b;            /* vermelho escuro para contraste (equivalente a text-red-800 do Tailwind) */',
'  text-decoration: line-through;',
unistr('  padding: 0.25rem 0.5rem;  /* espa\00E7amento interno para ficar parecido com um badge */'),
'  border-radius: 0.375rem;  /* cantos arredondados (6px) */',
'  display: inline-block;    /* para respeitar o padding e arredondamento */',
'}',
'',
'.text-green-bg {',
'  background-color: #d1fae5; /* verde claro, parecido com bg-green-100 */',
'  color: #065f46;            /* verde escuro, parecido com text-green-800 */',
unistr('  padding: 0.25rem 0.5rem;  /* espa\00E7amento interno */'),
'  border-radius: 0.375rem;  /* cantos arredondados */',
'  display: inline-block;    /* para respeitar padding e border-radius */',
'}',
'',
'.diff-arrow {',
'  display: inline-block;',
'  margin-left: 0.5rem;   /* mx-2 equivale a 0.5rem = 8px */',
'  margin-right: 0.5rem;',
'  color: #6B7280;        /* text-gray-500 do Tailwind */',
'  font-weight: 700;',
'  user-select: none;',
'  pointer-events: none;',
'}',
'',
'.diff-arrow::before {',
unistr('  content: ''\2192'';          /* seta para indicar diferen\00E7a */'),
'  font-size: 1rem;',
'}',
'',
'.container-card {',
'    display: flex;',
'    justify-content: space-between;',
'    align-items: center;',
'}',
'',
'.left-element {',
'    flex-grow: 1;',
'}',
'',
'.right-element {',
unistr('    margin-left: 20px; /* Espa\00E7amento entre os elementos */'),
'    white-space: nowrap; /* Impede quebra de linha no segundo elemento */',
'}',
'',
'.ocultar{',
'    display: none;',
'}',
'',
'.a-CardView-opcao {',
'    grid-area: icon-end;',
'    padding-left: 15px;',
'    order: 4;',
'}',
'',
'',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(225546868302211669)
,p_protection_level=>'C'
,p_page_component_map=>'22'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(29221580845305641)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_plug_template=>wwv_flow_imp.id(341039558490556238)
,p_plug_display_sequence=>240
,p_location=>null
,p_plug_source=>'<div>Northonn</div>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(228137834535879909)
,p_plug_name=>unistr('Opera\00E7\00F5es')
,p_parent_plug_id=>wwv_flow_imp.id(29221580845305641)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(341010888912556224)
,p_plug_display_sequence=>10
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return PKG_UI.buscar_acoes(:P9005_ID_ATUAL,:P9005_CODIGO_ARTEFATO,''E'',false,:P9005_PARAMETRO);',
''))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_BOT_ES_A__ES'
,p_ajax_items_to_submit=>'P9005_CODIGO_ARTEFATO,P9005_PARAMETRO'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_plug_query_no_data_found=>unistr('Nenhuma opera\00E7\00E3o dispon\00EDvel')
,p_no_data_found_icon_classes=>'fa-robot'
,p_show_total_row_count=>false
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'ICON', 'ICON',
  'LABEL', 'LABEL',
  'LINK', 'LINK',
  'MY_SECOND_PLACEHOLDER', 'HELP')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(29222226011305647)
,p_name=>'SQL_VALIDACAO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SQL_VALIDACAO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(71585951261650231)
,p_name=>'LABEL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LABEL'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(71586016377650232)
,p_name=>'HELP'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'HELP'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(228334427794087778)
,p_name=>'LINK'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LINK'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(228334506362087779)
,p_name=>'ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33650365556997828)
,p_plug_name=>unistr('Ordena\00E7\00E3o')
,p_region_template_options=>'#DEFAULT#:margin-top-sm'
,p_plug_template=>wwv_flow_imp.id(341010888912556224)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="sort-wrapper">',
'  <div class="sort-region">',
'    <div class="a-CardView-title">Ordenado por</div>',
'',
'    <div id="SORT_LIST" class="sort-list">',
'      <div class="u-font-size-sm u-italics">Nenhum campo selecionado</div>',
'    </div>',
'  </div>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(46455769988020752)
,p_plug_name=>'Colunas'
,p_title=>'Colunas'
,p_region_name=>'COLUNAS'
,p_region_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--md'
,p_plug_template=>wwv_flow_imp.id(341039558490556238)
,p_plug_display_sequence=>180
,p_plug_display_point=>'REGION_POSITION_04'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(295338245635959965)
,p_plug_name=>unistr('Visualiza\00E7\00E3o estruturada do cadastro')
,p_region_name=>'TREE_MENU'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_02'
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD150'');',
'begin',
'    begin',
'        EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_tree(:param1); END;''',
'        USING OUT l_sql, IN :P9005_PARAMETRO;',
'',
'        exception',
'            when others then',
'                return ''select null id, null titulo, null chave_pai, ''''icon-tree-folder'''' icone from dual'';',
'    end;',
'    return l_sql;       ',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_JSTREE'
,p_ajax_items_to_submit=>'P9005_PARAMETRO'
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD150'');',
'begin',
'    begin',
'        EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_tree(:param1); END;''',
'        USING OUT l_sql, IN :P9005_PARAMETRO;',
'',
'        exception',
'            when others then',
'                return false;',
'    end;',
'    return true;       ',
'end;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'activate_node_link_with', 'S',
  'default_icon_css_class', 'icon-tree-folder',
  'icon_css_class_column', 'ICONE',
  'icon_type_css_class', 'a-Icon',
  'node_id_column', 'ID',
  'node_label_column', 'TITULO',
  'parent_key_column', 'CHAVE_PAI',
  'start_tree_with', 'NULL',
  'tree_hierarchy', 'SQL',
  'tree_tooltip', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(305011205096770748)
,p_plug_name=>'Header'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(341013639389556225)
,p_plug_display_sequence=>80
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD367'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_cabecalho(:param1,:param2); END;''',
'        USING OUT l_sql, IN nvl(:P9005_PARAMETRO, 0),nvl(:P9005_PARAMETRO2, 0);',
'',
'    return l_sql;       ',
'end;',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P9005_PARAMETRO'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from dual',
' where existe_na_package(''UI_MPD_''||nvl(:P9005_CODIGO_ARTEFATO,''TD367''), ''sql_cabecalho'') > 0'))
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(345640016870027992)
,p_plug_name=>'Filtrar por Esquerda'
,p_title=>'&P0_LABEL_FILTRAR.'
,p_region_name=>'PAINEL_LEFT'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_02'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(347712298109334392)
,p_plug_name=>'PesquisaCard'
,p_region_name=>'PESQUISA'
,p_parent_plug_id=>wwv_flow_imp.id(345640016870027992)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(397363224585415337)
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P9005_CARD_OU_LISTA'
,p_plug_display_when_cond2=>'CAR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'batch_facet_search', 'Y',
  'compact_numbers_threshold', '10000',
  'display_chart_for_top_n_values', '10',
  'show_charts', 'Y',
  'show_current_facets', 'N',
  'show_total_row_count', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(360649770408770190)
,p_plug_name=>'Pesquisa Lista'
,p_region_name=>'PESQUISA_LISTA'
,p_parent_plug_id=>wwv_flow_imp.id(345640016870027992)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(359323945219767141)
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P9005_CARD_OU_LISTA'
,p_plug_display_when_cond2=>'GRI'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'batch_facet_search', 'Y',
  'compact_numbers_threshold', '10000',
  'display_chart_for_top_n_values', '10',
  'show_charts', 'Y',
  'show_current_facets', 'N',
  'show_total_row_count', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(345640941845028001)
,p_plug_name=>'Filtrar por Modal'
,p_title=>'&P0_LABEL_FILTRAR.'
,p_region_name=>'PAINEL_MODAL'
,p_region_template_options=>'#DEFAULT#:t-DialogRegion--noPadding:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--md'
,p_plug_template=>wwv_flow_imp.id(341039558490556238)
,p_plug_display_sequence=>120
,p_plug_display_point=>'REGION_POSITION_04'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(359323945219767141)
,p_name=>'Lista Oculta'
,p_region_name=>'LISTA_CR'
,p_template=>wwv_flow_imp.id(341010888912556224)
,p_display_sequence=>220
,p_region_css_classes=>'ocultar'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD778'');',
'begin',
'    if :P9005_CARD_OU_LISTA = ''GRI'' then',
'        EXECUTE IMMEDIATE',
'            ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_lista_oculta(:param1,:param2,:param3); END;''',
'            USING OUT l_sql, IN :P9005_PARAMETRO,:P9005_PARAMETRO2,:P9005_PRE_FILTRO_LISTA;',
'    else',
'        l_sql := q''~',
'            select ',
'                null              id,',
'                null              campo1,             ',
'                null              campo2,             ',
'                null              campo3,             ',
'                null              campo4,             ',
'                null              campo5,             ',
'                null              campo6,             ',
'                null              campo7,             ',
'                null              campo8,                                      ',
'                null              campo9,      ',
'                null              campo10,                                ',
'                null              filtro1,',
'                null              filtro2,',
'                null              filtro3,',
'                null              filtro4,',
'                null              filtro5,',
'                null              filtro_mult1,',
'                null              filtro_mult2,',
'                null              filtro_mult3,',
'                null              filtro_mult4,',
'                null              filtro_mult5,',
'                null              filtro_rangen,',
'                null              filtro_ranged,',
'                pkg_componentes.icone_opcao opcao',
'            from dual    ',
'        ~'';',
'    end if;',
'',
'    return l_sql;       ',
'end;'))
,p_optimizer_hint=>'APEX$USE_NO_GROUPING_SETS'
,p_display_when_condition=>'P9005_CARD_OU_LISTA'
,p_display_when_cond2=>'GRI'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P9005_PARAMETRO,P9005_CODIGO_ARTEFATO,P9005_CARD_OU_LISTA,P9005_PARAMETRO2,P9005_PARAMETRO3,P9005_PRE_FILTRO_LISTA'
,p_lazy_loading=>true
,p_query_row_template=>wwv_flow_imp.id(341097593039556273)
,p_query_num_rows=>99999
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(44359776914518571)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'Id'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(46372382433629966)
,p_query_column_id=>2
,p_column_alias=>'CAMPO1'
,p_column_display_sequence=>20
,p_column_heading=>'Campo1'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(46372734539629967)
,p_query_column_id=>3
,p_column_alias=>'CAMPO2'
,p_column_display_sequence=>30
,p_column_heading=>'Campo2'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(46373171071629968)
,p_query_column_id=>4
,p_column_alias=>'CAMPO3'
,p_column_display_sequence=>40
,p_column_heading=>'Campo3'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(46373431185629970)
,p_query_column_id=>5
,p_column_alias=>'CAMPO4'
,p_column_display_sequence=>50
,p_column_heading=>'Campo4'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(46373860319629971)
,p_query_column_id=>6
,p_column_alias=>'CAMPO5'
,p_column_display_sequence=>60
,p_column_heading=>'Campo5'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(46374268530629973)
,p_query_column_id=>7
,p_column_alias=>'CAMPO6'
,p_column_display_sequence=>70
,p_column_heading=>'Campo6'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(46374686815629974)
,p_query_column_id=>8
,p_column_alias=>'CAMPO7'
,p_column_display_sequence=>80
,p_column_heading=>'Campo7'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(46375073161629975)
,p_query_column_id=>9
,p_column_alias=>'CAMPO8'
,p_column_display_sequence=>90
,p_column_heading=>'Campo8'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(46375433429629976)
,p_query_column_id=>10
,p_column_alias=>'CAMPO9'
,p_column_display_sequence=>100
,p_column_heading=>'Campo9'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(46375861640629977)
,p_query_column_id=>11
,p_column_alias=>'CAMPO10'
,p_column_display_sequence=>110
,p_column_heading=>'Campo10'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(44358784007518561)
,p_query_column_id=>12
,p_column_alias=>'FILTRO1'
,p_column_display_sequence=>130
,p_column_heading=>'Filtro1'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(44358885675518562)
,p_query_column_id=>13
,p_column_alias=>'FILTRO2'
,p_column_display_sequence=>140
,p_column_heading=>'Filtro2'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(44358975348518563)
,p_query_column_id=>14
,p_column_alias=>'FILTRO3'
,p_column_display_sequence=>150
,p_column_heading=>'Filtro3'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(44359291382518566)
,p_query_column_id=>15
,p_column_alias=>'FILTRO4'
,p_column_display_sequence=>180
,p_column_heading=>'Filtro4'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(44359373969518567)
,p_query_column_id=>16
,p_column_alias=>'FILTRO5'
,p_column_display_sequence=>190
,p_column_heading=>'Filtro5'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(44359117821518564)
,p_query_column_id=>17
,p_column_alias=>'FILTRO_MULT1'
,p_column_display_sequence=>200
,p_column_heading=>'Filtro Mult1'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(44359188435518565)
,p_query_column_id=>18
,p_column_alias=>'FILTRO_MULT2'
,p_column_display_sequence=>210
,p_column_heading=>'Filtro Mult2'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(44359512110518568)
,p_query_column_id=>19
,p_column_alias=>'FILTRO_MULT3'
,p_column_display_sequence=>220
,p_column_heading=>'Filtro Mult3'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(44359544562518569)
,p_query_column_id=>20
,p_column_alias=>'FILTRO_MULT4'
,p_column_display_sequence=>230
,p_column_heading=>'Filtro Mult4'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(44359648485518570)
,p_query_column_id=>21
,p_column_alias=>'FILTRO_MULT5'
,p_column_display_sequence=>240
,p_column_heading=>'Filtro Mult5'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2106581164873339)
,p_query_column_id=>22
,p_column_alias=>'FILTRO_RANGEN'
,p_column_display_sequence=>250
,p_column_heading=>'Filtro Rangen'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2106485190873338)
,p_query_column_id=>23
,p_column_alias=>'FILTRO_RANGED'
,p_column_display_sequence=>260
,p_column_heading=>'Filtro Ranged'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(46376315446629978)
,p_query_column_id=>24
,p_column_alias=>'OPCAO'
,p_column_display_sequence=>120
,p_column_heading=>'Opcao'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(359335151682768783)
,p_plug_name=>'Lista'
,p_region_name=>'LISTA'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(341044399187556241)
,p_plug_display_sequence=>230
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql    clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO, ''TD150'');',
'begin',
'    begin',
'        execute immediate',
'            ''begin :l_sql := UI_MPD_'' || l_pagina || ''.sql_report(:order); end;''',
'            using out l_sql, in :P9005_ORDER;',
'',
'    exception',
'        when others then',
'            begin',
'                execute immediate',
'                    ''begin :l_sql := UI_MPD_'' || l_pagina || ''.sql_report; end;''',
'                    using out l_sql;',
'',
'            exception',
'                when others then',
'                    return ''select 1 from dual'';',
'            end;',
'    end;',
'',
'    return l_sql;',
'end;'))
,p_optimizer_hint=>'APEX$USE_NO_GROUPING_SETS'
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P9005_ORDER'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P9005_CARD_OU_LISTA'
,p_plug_display_when_cond2=>'GRI'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(359335246532768784)
,p_max_row_count=>'999999'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_textbox=>'N'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'NTO'
,p_internal_uid=>402206118193411057
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(47058314697126268)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'AG'
,p_column_label=>'Id'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(47058419982126269)
,p_db_column_name=>'CAMPO1'
,p_display_order=>20
,p_column_identifier=>'AH'
,p_column_label=>'&P9005_LABEL_COLUNA1.'
,p_allow_sorting=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P9005_LABEL_COLUNA1 is not null and :P9005_MOSTRA_CAMPO1 = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(47058435905126270)
,p_db_column_name=>'CAMPO2'
,p_display_order=>30
,p_column_identifier=>'AI'
,p_column_label=>'&P9005_LABEL_COLUNA2.'
,p_allow_sorting=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P9005_LABEL_COLUNA2 is not null and :P9005_MOSTRA_CAMPO2 = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(47058557537126271)
,p_db_column_name=>'CAMPO3'
,p_display_order=>40
,p_column_identifier=>'AJ'
,p_column_label=>'&P9005_LABEL_COLUNA3.'
,p_allow_sorting=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P9005_LABEL_COLUNA3 is not null and :P9005_MOSTRA_CAMPO3 = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(47058714786126272)
,p_db_column_name=>'CAMPO4'
,p_display_order=>50
,p_column_identifier=>'AK'
,p_column_label=>'&P9005_LABEL_COLUNA4.'
,p_allow_sorting=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P9005_LABEL_COLUNA4 is not null and :P9005_MOSTRA_CAMPO4 = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(47058746473126273)
,p_db_column_name=>'CAMPO5'
,p_display_order=>60
,p_column_identifier=>'AL'
,p_column_label=>'&P9005_LABEL_COLUNA5.'
,p_allow_sorting=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P9005_LABEL_COLUNA5 is not null and :P9005_MOSTRA_CAMPO5 = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(47058901052126274)
,p_db_column_name=>'CAMPO6'
,p_display_order=>70
,p_column_identifier=>'AM'
,p_column_label=>'&P9005_LABEL_COLUNA6.'
,p_allow_sorting=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P9005_LABEL_COLUNA6 is not null and :P9005_MOSTRA_CAMPO6 = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(47058960858126275)
,p_db_column_name=>'CAMPO7'
,p_display_order=>80
,p_column_identifier=>'AN'
,p_column_label=>'&P9005_LABEL_COLUNA7.'
,p_allow_sorting=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P9005_LABEL_COLUNA7 is not null and :P9005_MOSTRA_CAMPO7 = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(47059103715126276)
,p_db_column_name=>'CAMPO8'
,p_display_order=>90
,p_column_identifier=>'AO'
,p_column_label=>'&P9005_LABEL_COLUNA8.'
,p_allow_sorting=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P9005_LABEL_COLUNA8 is not null and :P9005_MOSTRA_CAMPO8 = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(47059212139126277)
,p_db_column_name=>'CAMPO9'
,p_display_order=>100
,p_column_identifier=>'AP'
,p_column_label=>'&P9005_LABEL_COLUNA9.'
,p_allow_sorting=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P9005_LABEL_COLUNA9 is not null and :P9005_MOSTRA_CAMPO9 = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(49413237716936528)
,p_db_column_name=>'CAMPO10'
,p_display_order=>110
,p_column_identifier=>'AQ'
,p_column_label=>'&P9005_LABEL_COLUNA10.'
,p_allow_sorting=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P9005_LABEL_COLUNA10 is not null and :P9005_MOSTRA_CAMPO10 = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(49413401647936529)
,p_db_column_name=>'OPCAO'
,p_display_order=>120
,p_column_identifier=>'AR'
,p_column_label=>'&P0_LABEL_OPCAO.'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div style="display: flex; align-items: center; justify-content: center; flex-grow: 1;">',
'    <span #OPCAO# style="cursor: pointer; color: var(--a-button-state-text-color, var(--a-button-type-text-color, var(--a-button-text-color, inherit)));" ',
'        class="fa fa-ellipsis-v js-dlg-refresh" title="&P0_LABEL_OPCAO!RAW.">',
'    </span>',
'</div>',
'    '))
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(359460637499222238)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'355331'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'CAMPO1:CAMPO2:CAMPO3:CAMPO4:CAMPO5:CAMPO6:CAMPO7:CAMPO8:OPCAO:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(363200633756892577)
,p_plug_name=>unistr('Defini\00E7\00F5es do relat\00F3rio')
,p_region_name=>'ACTION'
,p_region_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--sm'
,p_component_template_options=>'t-MediaList--showIcons:t-MediaList--showDesc:u-colors'
,p_plug_template=>wwv_flow_imp.id(341039558490556238)
,p_plug_display_sequence=>170
,p_plug_display_point=>'REGION_POSITION_04'
,p_location=>null
,p_list_id=>wwv_flow_imp.id(222272585216222758)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(341125559529556289)
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(397363224585415337)
,p_plug_name=>'Card avancado'
,p_region_name=>'CARD'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(341017957619556227)
,p_plug_display_sequence=>90
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD150'');',
' ',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_card(:param1,:param2,:param3,:param4); END;''',
'        USING OUT l_sql, IN :P9005_PARAMETRO,:P9005_PARAMETRO2,:P9005_PRE_FILTRO_CARD,:P9005_ORDER;',
'    return l_sql;       ',
'end;',
''))
,p_optimizer_hint=>'APEX$USE_NO_GROUPING_SETS'
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P9005_CODIGO_ARTEFATO,P9005_PARAMETRO,P9005_PARAMETRO2,P9005_PARAMETRO3,P9005_ORDER,P9005_PRE_FILTRO_CARD'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>true
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_existe number := 0;',
'begin',
'    select 1 into l_existe',
'      from dual',
'    where existe_na_package(''UI_MPD_''||nvl(:P9005_CODIGO_ARTEFATO,''TD367''), ''sql_card'') > 0;',
'    return :P9005_CARD_OU_LISTA = ''CAR'' and l_existe > 0;',
'end;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(46366866747629937)
,p_region_id=>wwv_flow_imp.id(397363224585415337)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>true
,p_title_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="a-CardView-header1" style="padding: 0;">',
'    &ICON!RAW.',
'    <div class="a-CardView-headerBody">',
'        <h3 class="a-CardView-title" title="&LABEL_TITULO!RAW.">&TITULO!RAW.</h3>',
'        <h4 class="a-CardView-subTitle" title="&LABEL_SUBTITULO!RAW.">&SUBTITULO!RAW.</h4>        ',
'    </div>',
'    <div class="a-CardView-badge &CLASS_DISTINTIVO!RAW." title="&LISTA_DISTINTIVO!RAW.">',
'        <span class="a-CardView-badgeValue" title="&LABEL_DISTINTIVO!RAW.">&DISTINTIVO!RAW.</span>',
'    </div>',
'    <div class="a-CardView-opcao" style="cursor: pointer;">',
'        <div style="display: flex; align-items: center; justify-content: center; flex-grow: 1;">',
'            <a &OPCAO!RAW. style="cursor: pointer; color: var(--a-button-state-text-color, var(--a-button-type-text-color, var(--a-button-text-color, inherit)));" ',
'                class="fa fa-ellipsis-v js-dlg-refresh" title="&P0_LABEL_OPCAO!RAW.">',
'            </a>',
'        </div>',
'    </div>',
'</div>',
'',
''))
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="container-card">',
'    <div class="left-element">',
'        <div class="row" style="display: flex; flex-wrap: wrap; justify-content: space-between;">',
'            &ATRIBUTO1!RAW.',
'            &ATRIBUTO2!RAW.',
'            &ATRIBUTO3!RAW.    ',
'            &ATRIBUTO4!RAW.',
'            &ATRIBUTO5!RAW.',
'            &ATRIBUTO6!RAW.',
'            &ATRIBUTO7!RAW.',
'            &ATRIBUTO8!RAW.',
'        </div>',
'    </div>',
'</div>',
'<div class="a-CardView-actionsPrimary" style="padding-top:16px;"> ',
'    <span class="a-CardView-button t-Button--link padding-none">',
'        <span class="a-CardView-buttonLabel" &URL_MAIS_DETALHES!RAW.>&P0_LABEL_MAIS_DETALHES.</span>',
'    </span>',
'</div>',
''))
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(46356175946629864)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(345640941845028001)
,p_button_name=>'desfixar'
,p_button_static_id=>'BTN_DESFIXAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_FIXAR.'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'u-pullRight'
,p_icon_css_classes=>'fa-thumb-tack'
,p_button_cattributes=>'style="margin-left: auto; "'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(46365695643629928)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(345640016870027992)
,p_button_name=>'fixar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_FIXAR.'
,p_button_position=>'COPY'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-thumb-tack'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(46456251494020757)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(46455769988020752)
,p_button_name=>'Save'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(341144157120556305)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_SALVAR.'
,p_button_position=>'CREATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(5707121108710530)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(17161532936247037)
,p_button_name=>'favNao'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_ADICIONAR_FAV.'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P9005_FAVORITO = 0 and :P9005_PARAMETRO is null'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-star-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(5707070111710529)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(17161532936247037)
,p_button_name=>'favSim'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--warning:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_REMOVER_FAV.'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P9005_FAVORITO = 1 and :P9005_PARAMETRO is null'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-star'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(46380506416630004)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(17161532936247037)
,p_button_name=>'VisaoReport'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_VISAO_LISTA.'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P9005_CARD_OU_LISTA'
,p_button_condition2=>'CAR'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-columns'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(46380846850630006)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(17161532936247037)
,p_button_name=>'VisaoCard'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_VISAO_CARD.'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P9005_CARD_OU_LISTA'
,p_button_condition2=>'GRI'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-list-ul'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(46381315576630007)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(17161532936247037)
,p_button_name=>'filter'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_ESCONDER_MOSTRAR_PESQUISA.'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-filter'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(33649444432997819)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(17161532936247037)
,p_button_name=>'order'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_ESCONDER_MOSTRAR_PESQUISA.'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from dual',
' where existe_na_package(''UI_MPD_''||nvl(:P9005_CODIGO_ARTEFATO,''TD367''), ''campos_ordenacao_default'') > 0'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-sort'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14778952833926164)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(17161532936247037)
,p_button_name=>'log'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_HISTORICO_EXCLUSAO.'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:9010:&SESSION.::&DEBUG.:9010:P9010_CODIGO_ARTEFATO,P0_CODIGO_ARTEFATO,P9010_PARAMETRO,P9010_VISUALIZAR:TD833,TD833,&P9005_CODIGO_ARTEFATO.,1'
,p_icon_css_classes=>'fa-history fam-x fam-is-danger'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(46382125272630009)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(17161532936247037)
,p_button_name=>'Menu'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_OPCAO.'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:9000:&SESSION.::&DEBUG.:9000:P9000_PAGINA:&P9005_CODIGO_ARTEFATO.'
,p_button_condition=>'PKG_UI.verifica_se_tem_linhas(PKG_UI.buscar_acoes(0,:P9005_CODIGO_ARTEFATO,''W'')) = true'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-ellipsis-v-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(46381711951630008)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_imp.id(17161532936247037)
,p_button_name=>'New'
,p_button_static_id=>'NEW'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_NOVO.'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'&P9005_URL_NEW.'
,p_button_css_classes=>'apex_disabled'
,p_icon_css_classes=>'fa-plus-circle'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(46361550099629907)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(359335151682768783)
,p_button_name=>'Opcoes'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_CONFIGURACAO_LISTA.'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-gear'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(53881627970528)
,p_name=>'P9005_ID_ATUAL'
,p_item_sequence=>210
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54253526970532)
,p_name=>'P9005_ATUALIZA_PAGINA'
,p_item_sequence=>30
,p_item_display_point=>'REGION_POSITION_01'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_retorno varchar2(10);',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD367'');',
'begin',
'    begin',
'        EXECUTE IMMEDIATE',
'            ''BEGIN :l_retorno := UI_MPD_''||l_pagina||''.atualizar_tela; END;''',
'            USING OUT l_retorno;',
'',
'        return l_retorno;       ',
'    exception',
'        when others then',
'        return ''false'';       ',
'    end;',
'end;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1604256178518265)
,p_name=>'P9005_URL'
,p_item_sequence=>10
,p_item_display_point=>'REGION_POSITION_01'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2107308123873346)
,p_name=>'P9005_FILTRO_RANGED_LISTA'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(360649770408770190)
,p_prompt=>'&P9005_NOME_FILTRO_RANGED.'
,p_source=>'FILTRO_RANGED'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD778'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''RD''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''RD''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'manual_entry', 'Y',
  'select_multiple', 'N')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2107461843873347)
,p_name=>'P9005_FILTRO_RANGEN_LISTA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(360649770408770190)
,p_prompt=>'&P9005_NOME_FILTRO_RANGEN.'
,p_source=>'FILTRO_RANGEN'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD778'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''RN''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''RN''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'manual_entry', 'Y',
  'select_multiple', 'N')).to_clob
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2109296406873366)
,p_name=>'P9005_NOME_FILTRO_RANGED'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(345640016870027992)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD778'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''RD''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';        ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2109417635873367)
,p_name=>'P9005_NOME_FILTRO_RANGEN'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(345640016870027992)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD778'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''RN''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';        ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2109545676873368)
,p_name=>'P9005_FILTRO_RANGED_CARD'
,p_source_data_type=>'TIMESTAMP_TZ'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(347712298109334392)
,p_prompt=>'&P9005_NOME_FILTRO_RANGED.'
,p_source=>'FILTRO_RANGED'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD778'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''RD''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''RD''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'manual_entry', 'Y',
  'select_multiple', 'N')).to_clob
,p_fc_show_label=>false
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2109587773873369)
,p_name=>'P9005_FILTRO_RANGEN_CARD'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(347712298109334392)
,p_prompt=>'&P9005_NOME_FILTRO_RANGEN!RAW.'
,p_source=>'FILTRO_RANGEN'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD778'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''RN''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''RN''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'manual_entry', 'Y',
  'select_multiple', 'N')).to_clob
,p_fc_show_label=>false
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5706498001710524)
,p_name=>'P9005_FAVORITO'
,p_item_sequence=>20
,p_item_display_point=>'REGION_POSITION_01'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14810955386852739)
,p_name=>'P9005_CARREGA_CONSULTA_CARD'
,p_item_sequence=>200
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33649950742997824)
,p_name=>'P9005_ORDER_SITUACAO'
,p_item_sequence=>50
,p_item_default=>'H'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33650278852997827)
,p_name=>'P9005_SORT_COLUMN'
,p_item_sequence=>30
,p_prompt=>unistr('Colunas para ordena\00E7\00E3o')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_campos clob;',
'    l_labels clob;',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD150'');',
'begin',
'    execute immediate ''begin ui_mpd_''||l_pagina||''.campos_ordenacao(:card_ou_grid,:campos,:labels); end;'' using in :P9005_CARD_OU_LISTA, out l_campos, out l_labels;',
'    execute immediate ''begin :sql := gerar_comando_sql2(:campos,:labels); end;'' using out l_sql, in l_campos, l_labels;',
'    return l_sql;',
'    exception',
'        when others then',
'        return q''~ ',
'            select null as R , null as D from dual    ',
'        ~'';',
'end;',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_tag_css_classes=>'item-round'
,p_colspan=>3
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33650428888997829)
,p_name=>'P9005_SORT_JSON'
,p_item_sequence=>10
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_campos        clob;',
'    l_labels        clob;',
'    l_pagina        varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO, ''TD150'');',
'    l_card_ou_lista varchar2(10)  := :P9005_CARD_OU_LISTA;',
'begin',
'    l_pagina := upper(trim(l_pagina));',
'',
'    if not regexp_like(l_pagina, ''^[A-Z0-9_]+$'') then',
'        raise_application_error(-20001, ''Codigo de artefato invalido.'');',
'    end if;',
'',
'    execute immediate',
'        ''begin ui_mpd_'' || l_pagina || ''.campos_ordenacao(:card_ou_grid, :campos, :labels); end;''',
'        using in l_card_ou_lista, out l_campos, out l_labels;',
'',
'    return monta_json_campos_ordenacao(',
'        p_campos => l_campos,',
'        p_labels => l_labels',
'    );',
'    ',
'    exception',
'        when others then',
'            return null;',
'',
'end;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33651070210997835)
,p_name=>'P9005_SORT_JSON_DEFAULT'
,p_item_sequence=>20
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_order         varchar2(2000);',
'    l_JSON          clob;',
'    l_pagina        varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO, ''TD150'');',
'    l_card_ou_lista varchar2(10)  := :P9005_CARD_OU_LISTA;',
'begin',
'    l_pagina := upper(trim(l_pagina));',
'',
'    if not regexp_like(l_pagina, ''^[A-Z0-9_]+$'') then',
'        raise_application_error(-20001, ''Codigo de artefato invalido.'');',
'    end if;',
'',
'    execute immediate',
'        ''begin ui_mpd_'' || l_pagina || ''.campos_ordenacao_default(:card_ou_grid, :l_order, :l_JSON); end;''',
'        using in l_card_ou_lista, out l_order, out l_JSON;',
'    return l_JSON;',
'',
'    exception',
'        when others then',
'            return null;',
'',
'end;'))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44358451454518558)
,p_name=>'P9005_FILTRO_MULT_LISTA1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(360649770408770190)
,p_prompt=>'&P9005_NOME_FILTRO_MULT1.'
,p_source=>'FILTRO_MULT1'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''M1''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''M1''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44358585815518559)
,p_name=>'P9005_FILTRO_MULT_LISTA2'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(360649770408770190)
,p_prompt=>'&P9005_NOME_FILTRO_MULT2.'
,p_source=>'FILTRO_MULT2'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''M2''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''M2''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44358680433518560)
,p_name=>'P9005_ID'
,p_item_sequence=>130
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44359922204518572)
,p_name=>'P9005_FILTRO_LISTA4'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(360649770408770190)
,p_prompt=>'&P9005_NOME_FILTRO4.'
,p_source=>'FILTRO4'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''4''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''4''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44360025053518573)
,p_name=>'P9005_FILTRO_LISTA5'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(360649770408770190)
,p_prompt=>'&P9005_NOME_FILTRO5.'
,p_source=>'FILTRO5'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''5''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''5''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44360040180518574)
,p_name=>'P9005_FILTRO_MULT_LISTA3'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(360649770408770190)
,p_prompt=>'&P9005_NOME_FILTRO_MULT3.'
,p_source=>'FILTRO_MULT3'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''M3''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''M3''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44360228024518575)
,p_name=>'P9005_FILTRO_MULT_LISTA4'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(360649770408770190)
,p_prompt=>'&P9005_NOME_FILTRO_MULT4.'
,p_source=>'FILTRO_MULT4'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''M4''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''M4''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44360257185518576)
,p_name=>'P9005_FILTRO_MULT_LISTA5'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(360649770408770190)
,p_prompt=>'&P9005_NOME_FILTRO_MULT5.'
,p_source=>'FILTRO_MULT5'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''M5''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''M5''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44360414952518577)
,p_name=>'P9005_FILTRO_CARD4'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(347712298109334392)
,p_prompt=>'&P9005_NOME_FILTRO4.'
,p_source=>'FILTRO4'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''4''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''4''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46453428248020728)
,p_name=>'P9005_FILTRO_CARD5'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(347712298109334392)
,p_prompt=>'&P9005_NOME_FILTRO5.'
,p_source=>'FILTRO5'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''5''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''5''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46453508951020729)
,p_name=>'P9005_FILTRO_MULT_CARD3'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(347712298109334392)
,p_prompt=>'&P9005_NOME_FILTRO_MULT3.'
,p_source=>'FILTRO_MULT3'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''M3''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''M3''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46453587016020730)
,p_name=>'P9005_FILTRO_MULT_CARD4'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(347712298109334392)
,p_prompt=>'&P9005_NOME_FILTRO_MULT4.'
,p_source=>'FILTRO_MULT4'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''M4''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''M4''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46453705914020731)
,p_name=>'P9005_FILTRO_MULT_CARD5'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(347712298109334392)
,p_prompt=>'&P9005_NOME_FILTRO_MULT5.'
,p_source=>'FILTRO_MULT5'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''M5''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''M5''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46453751140020732)
,p_name=>'P9005_NOME_FILTRO4'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(345640016870027992)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''F4''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';        ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46453921671020733)
,p_name=>'P9005_NOME_FILTRO5'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(345640016870027992)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''F5''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';        ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46453939315020734)
,p_name=>'P9005_NOME_FILTRO_MULT3'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(345640016870027992)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''M3''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';        ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46454057444020735)
,p_name=>'P9005_NOME_FILTRO_MULT4'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(345640016870027992)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''M4''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';        ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46454166454020736)
,p_name=>'P9005_NOME_FILTRO_MULT5'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(345640016870027992)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''M5''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';        ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46455908130020753)
,p_name=>'P9005_COLUNAS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(46455769988020752)
,p_prompt=>'Mova para a direita as colunas que deseja esconder'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH colunas AS (',
'    SELECT ''CAMPO1'' id_coluna, :P9005_LABEL_COLUNA1 label FROM dual UNION ALL',
'    SELECT ''CAMPO2'', :P9005_LABEL_COLUNA2 FROM dual UNION ALL',
'    SELECT ''CAMPO3'', :P9005_LABEL_COLUNA3 FROM dual UNION ALL',
'    SELECT ''CAMPO4'', :P9005_LABEL_COLUNA4 FROM dual UNION ALL',
'    SELECT ''CAMPO5'', :P9005_LABEL_COLUNA5 FROM dual UNION ALL',
'    SELECT ''CAMPO6'', :P9005_LABEL_COLUNA6 FROM dual UNION ALL',
'    SELECT ''CAMPO7'', :P9005_LABEL_COLUNA7 FROM dual UNION ALL',
'    SELECT ''CAMPO8'', :P9005_LABEL_COLUNA8 FROM dual UNION ALL',
'    SELECT ''CAMPO9'', :P9005_LABEL_COLUNA9 FROM dual UNION ALL',
'    SELECT ''CAMPO10'', :P9005_LABEL_COLUNA10 FROM dual',
')',
'SELECT c.label d, c.id_coluna r',
'FROM colunas c',
'LEFT JOIN MPD_USUARIO_GRID_OCULTA_COLUNA u',
'    ON u.id_usuario = :ID_USUARIO_LOGADO',
'    AND u.codigo_artefato = :P9005_CODIGO_ARTEFATO',
'    AND u.id_coluna LIKE ''%'' || c.id_coluna || ''%''',
'WHERE --u.id_coluna IS NULL and ',
'c.label is not null',
''))
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'MOVE')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46457764775020772)
,p_name=>'P9005_MOSTRA_CAMPO1'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(46455769988020752)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46457866739020773)
,p_name=>'P9005_MOSTRA_CAMPO2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(46455769988020752)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46458022695020774)
,p_name=>'P9005_MOSTRA_CAMPO3'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(46455769988020752)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46458067384020775)
,p_name=>'P9005_MOSTRA_CAMPO4'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(46455769988020752)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46458193461020776)
,p_name=>'P9005_MOSTRA_CAMPO5'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(46455769988020752)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46458261840020777)
,p_name=>'P9005_MOSTRA_CAMPO6'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(46455769988020752)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47054237498126228)
,p_name=>'P9005_MOSTRA_CAMPO7'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(46455769988020752)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47054335959126229)
,p_name=>'P9005_MOSTRA_CAMPO8'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(46455769988020752)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47054524510126230)
,p_name=>'P9005_MOSTRA_CAMPO9'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(46455769988020752)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47054528683126231)
,p_name=>'P9005_MOSTRA_CAMPO10'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(46455769988020752)
,p_item_default=>'Y'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47057429810126260)
,p_name=>'P9005_ORDER'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65447969039861831)
,p_name=>'P9005_PARAMETRO3'
,p_item_sequence=>190
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(121229618183128301)
,p_name=>'P9005_PRE_FILTRO_CARD'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(347712298109334392)
,p_item_display_point=>'PREVIOUS'
,p_item_default=>'1'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql          clob;',
'    l_package_name varchar2(128);',
'    l_pagina       varchar2(100) := nvl(:P9005_CODIGO_ARTEFATO, ''TD367'');',
'begin',
'    l_package_name := dbms_assert.sql_object_name(',
'        ''UI_MPD_'' || l_pagina',
'    );',
'',
'    execute immediate',
'        ''begin',
'             :resultado := '' || l_package_name || ''.pre_filtro;',
'         end;''',
'        using',
'            out l_sql;',
'',
'    return l_sql;',
'exception',
'    when others then',
'        return q''[',
'            select',
unistr('                ''Erro ao carregar op\00E7\00F5es'' as display_value,'),
'                null                       as return_value',
'            from dual',
'            where 1 = 0',
'        ]'';',
'end;'))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_quantidade number;',
'    l_artefato   varchar2(128);',
'    l_package    varchar2(128);',
'begin',
'    l_artefato := upper(',
'        nvl(:P9005_CODIGO_ARTEFATO, ''TD367'')',
'    );',
'',
'    l_package := ''UI_MPD_'' || l_artefato;',
'',
'    select count(*)',
'      into l_quantidade',
'      from user_procedures',
'     where object_name    = l_package',
'       and lower(procedure_name) = lower(''pre_filtro'');',
'',
'    return l_quantidade > 0;',
'exception',
'    when others then',
'        return false;',
'end;'))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_field_template=>wwv_flow_imp.id(341141341591556301)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '5',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(121229991125130101)
,p_name=>'P9005_PRE_FILTRO_LISTA'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(360649770408770190)
,p_item_display_point=>'PREVIOUS'
,p_item_default=>'1'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql          clob;',
'    l_package_name varchar2(128);',
'    l_pagina       varchar2(100) := nvl(:P9005_CODIGO_ARTEFATO, ''TD367'');',
'begin',
'    l_package_name := dbms_assert.sql_object_name(',
'        ''UI_MPD_'' || l_pagina',
'    );',
'',
'    execute immediate',
'        ''begin',
'             :resultado := '' || l_package_name || ''.pre_filtro;',
'         end;''',
'        using',
'            out l_sql;',
'',
'    return l_sql;',
'exception',
'    when others then',
'        return q''[',
'            select',
unistr('                ''Erro ao carregar op\00E7\00F5es'' as display_value,'),
'                null                       as return_value',
'            from dual',
'            where 1 = 0',
'        ]'';',
'end;'))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_quantidade number;',
'    l_artefato   varchar2(128);',
'    l_package    varchar2(128);',
'begin',
'    l_artefato := upper(',
'        nvl(:P9005_CODIGO_ARTEFATO, ''TD367'')',
'    );',
'',
'    l_package := ''UI_MPD_'' || l_artefato;',
'',
'    select count(*)',
'      into l_quantidade',
'      from user_procedures',
'     where object_name    = l_package',
'       and lower(procedure_name) = lower(''pre_filtro'');',
'',
'    return l_quantidade > 0;',
'exception',
'    when others then',
'        return false;',
'end;'))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_field_template=>wwv_flow_imp.id(341141341591556301)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '5',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(195065490616653169)
,p_name=>'P9005_PARAMETRO2'
,p_item_sequence=>180
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(221071018243841712)
,p_name=>'P9005_CARD_OU_LISTA'
,p_item_sequence=>140
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(222244466673924603)
,p_name=>'P9005_FILTRO_LIVRE_LISTA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(360649770408770190)
,p_prompt=>'Filtro Livre Lista'
,p_source=>'CAMPO1,CAMPO2,CAMPO3,CAMPO4'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'input_field', 'FACET',
  'search_type', 'ROW')).to_clob
,p_fc_show_chart=>false
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(238184058405159173)
,p_name=>'P9005_PARAMETRO'
,p_item_sequence=>170
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(312184325273646191)
,p_name=>'P9005_TELA_TITULO'
,p_item_sequence=>150
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(312184764025646196)
,p_name=>'P9005_TELA_HELP'
,p_item_sequence=>160
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(312433258987358982)
,p_name=>'P9005_FILTRO_CARD2'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(347712298109334392)
,p_prompt=>'&P9005_NOME_FILTRO2.'
,p_source=>'FILTRO2'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''2''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''2''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(312433387529358983)
,p_name=>'P9005_NOME_FILTRO2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(345640016870027992)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''F2''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';        ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(312433431801358984)
,p_name=>'P9005_FILTRO_CARD3'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(347712298109334392)
,p_prompt=>'&P9005_NOME_FILTRO3.'
,p_source=>'FILTRO3'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''3''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''3''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(312433554366358985)
,p_name=>'P9005_NOME_FILTRO3'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(345640016870027992)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''F3''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';        ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(312435441921359004)
,p_name=>'P9005_FILTRO_MULT_CARD1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(347712298109334392)
,p_prompt=>'&P9005_NOME_FILTRO_MULT1.'
,p_source=>'FILTRO_MULT1'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''M1''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''M1''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(312435504219359005)
,p_name=>'P9005_FILTRO_MULT_CARD2'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(347712298109334392)
,p_prompt=>'&P9005_NOME_FILTRO_MULT2.'
,p_source=>'FILTRO_MULT2'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''M2''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''M2''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(312435694090359006)
,p_name=>'P9005_NOME_FILTRO_MULT1'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(345640016870027992)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''M1''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';        ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(312435765530359007)
,p_name=>'P9005_NOME_FILTRO_MULT2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(345640016870027992)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD337'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''M2''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';        ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327027203554379271)
,p_name=>'P9005_LABEL_COLUNA3'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(359335151682768783)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327027385465379272)
,p_name=>'P9005_LABEL_COLUNA4'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(359335151682768783)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327027452929379273)
,p_name=>'P9005_LABEL_COLUNA5'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(359335151682768783)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327027584000379274)
,p_name=>'P9005_LABEL_COLUNA6'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(359335151682768783)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327027689868379275)
,p_name=>'P9005_LABEL_COLUNA7'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(359335151682768783)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327027699975379276)
,p_name=>'P9005_LABEL_COLUNA8'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(359335151682768783)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327027864967379277)
,p_name=>'P9005_LABEL_COLUNA9'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(359335151682768783)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327027991997379278)
,p_name=>'P9005_LABEL_COLUNA10'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(359335151682768783)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(332976231526069002)
,p_name=>'P9005_FILTRO_LISTA1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(360649770408770190)
,p_prompt=>'&P9005_NOME_FILTRO1.'
,p_source=>'FILTRO1'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD257'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''1''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD257'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''1''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(345708289017028194)
,p_name=>'P9005_TIPO_PESQUISA'
,p_item_sequence=>110
,p_item_default=>'1'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(347669661949382458)
,p_name=>'P9005_CODIGO_ARTEFATO'
,p_item_sequence=>100
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(347670583864382467)
,p_name=>'P9005_URL_NEW'
,p_item_sequence=>120
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(347731469063334476)
,p_name=>'P9005_FILTRO_LIVRE_CARD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(347712298109334392)
,p_prompt=>'Filtro Livre Card'
,p_source=>'TITULO,SUBTITULO,DISTINTIVO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'input_field', 'FACET',
  'search_type', 'ROW')).to_clob
,p_fc_show_chart=>false
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(347731508699334477)
,p_name=>'P9005_FILTRO_CARD1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(347712298109334392)
,p_prompt=>'&P9005_NOME_FILTRO1.'
,p_source=>'FILTRO1'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''1''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''1''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(347731620465334478)
,p_name=>'P9005_NOME_FILTRO1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(345640016870027992)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''F1''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';        ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(359729667483792911)
,p_name=>'P9005_LABEL_COLUNA1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(359335151682768783)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(359729819286792912)
,p_name=>'P9005_LABEL_COLUNA2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(359335151682768783)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(360760839521076777)
,p_name=>'P9005_FILTRO_LISTA2'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(360649770408770190)
,p_prompt=>'&P9005_NOME_FILTRO2.'
,p_source=>'FILTRO2'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD150'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''2''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD150'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''2''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(360762396171076793)
,p_name=>'P9005_FILTRO_LISTA3'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(360649770408770190)
,p_prompt=>'&P9005_NOME_FILTRO3.'
,p_source=>'FILTRO3'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''3''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''3''''); END;''',
'        USING OUT l_true;',
'    return l_true;       ',
'    exception',
'        when others then',
'            return false;',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(46385118240630025)
,p_computation_sequence=>10
,p_computation_item=>'P9005_LABEL_COLUNA1'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''1''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';       ',
'',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(46385463529630027)
,p_computation_sequence=>20
,p_computation_item=>'P9005_LABEL_COLUNA2'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''2''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';       ',
'',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(46385896480630028)
,p_computation_sequence=>30
,p_computation_item=>'P9005_LABEL_COLUNA3'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''3''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(46386289973630029)
,p_computation_sequence=>40
,p_computation_item=>'P9005_LABEL_COLUNA4'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''4''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;  ',
'    exception',
'        when others then',
'            return '''';       ',
'',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(46386700269630030)
,p_computation_sequence=>50
,p_computation_item=>'P9005_LABEL_COLUNA5'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''5''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(46387064897630031)
,p_computation_sequence=>60
,p_computation_item=>'P9005_LABEL_COLUNA6'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''6''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(46387478783630032)
,p_computation_sequence=>70
,p_computation_item=>'P9005_LABEL_COLUNA7'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''7''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(46387887324630033)
,p_computation_sequence=>80
,p_computation_item=>'P9005_LABEL_COLUNA8'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''8''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(46388241764630034)
,p_computation_sequence=>90
,p_computation_item=>'P9005_LABEL_COLUNA9'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''9''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(46388712619630035)
,p_computation_sequence=>100
,p_computation_item=>'P9005_LABEL_COLUNA10'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''10''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return '''';       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46394604909630062)
,p_name=>'onClickFixar'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(46365695643629928)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46395040280630064)
,p_event_id=>wwv_flow_imp.id(46394604909630062)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (apex.item( "P9005_TIPO_PESQUISA" ).getValue() == 1){',
'    apex.item( "P9005_TIPO_PESQUISA" ).setValue( 2 );',
'} else {',
'    apex.item( "P9005_TIPO_PESQUISA" ).setValue( 1 );',
'}',
'    '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46395507686630065)
,p_name=>'onChangeTipoPesquisa = Esquerda'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9005_TIPO_PESQUISA'
,p_condition_element=>'P9005_TIPO_PESQUISA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46395987055630066)
,p_event_id=>wwv_flow_imp.id(46395507686630065)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#PESQUISA'').appendTo(''#PAINEL_LEFT'');',
'$(''#PESQUISA_LISTA'').appendTo(''#PAINEL_LEFT'');',
'$(''#t_Body_side'').show();'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46396482687630067)
,p_event_id=>wwv_flow_imp.id(46395507686630065)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(345640941845028001)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46396876685630068)
,p_name=>'onChangeTipoPesquisa = Modal'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9005_TIPO_PESQUISA'
,p_condition_element=>'P9005_TIPO_PESQUISA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46397311432630070)
,p_event_id=>wwv_flow_imp.id(46396876685630068)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#PESQUISA'').appendTo(''#PAINEL_MODAL .t-DrawerRegion-body'');    ',
'$(''#PESQUISA_LISTA'').appendTo(''#PAINEL_MODAL .t-DrawerRegion-body'');    ',
'$(''#t_Body_side'').hide();'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46397806266630072)
,p_event_id=>wwv_flow_imp.id(46396876685630068)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(345640941845028001)
,p_build_option_id=>wwv_flow_imp.id(340973604135556181)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46398188677630073)
,p_name=>'onClickDesfixar'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(46356175946629864)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46398660573630074)
,p_event_id=>wwv_flow_imp.id(46398188677630073)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (apex.item( "P9005_TIPO_PESQUISA" ).getValue() == 1){',
'    apex.item( "P9005_TIPO_PESQUISA" ).setValue( 2 );',
'} else {',
'    apex.item( "P9005_TIPO_PESQUISA" ).setValue( 1 );',
'}',
'    '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46399112474630075)
,p_name=>'onMouseEnterTooltip'
,p_event_sequence=>70
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'$("#icon_info")'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'mouseenter'
,p_required_patch=>wwv_flow_imp.id(340973604135556181)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46399596597630077)
,p_event_id=>wwv_flow_imp.id(46399112474630075)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'PLUGIN_COM.FOS.TOOLTIP'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'$("#icon_info")'
,p_attribute_01=>'static'
,p_attribute_05=>'&P9005_TELA_HELP. (&P9005_CODIGO_ARTEFATO.)'
,p_attribute_08=>'#007BFE'
,p_attribute_09=>'#FFFFFF'
,p_attribute_10=>'scale'
,p_attribute_11=>'500'
,p_attribute_12=>'hover'
,p_attribute_13=>'top'
,p_attribute_14=>'cache-result,escape-html'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46399963910630078)
,p_name=>'onCloseNew'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(46381711951630008)
,p_condition_element=>'P9005_ATUALIZA_PAGINA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'true'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54383196970533)
,p_event_id=>wwv_flow_imp.id(46399963910630078)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'location.reload();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39965289050705541)
,p_event_id=>wwv_flow_imp.id(46399963910630078)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(397363224585415337)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39965382529705542)
,p_event_id=>wwv_flow_imp.id(46399963910630078)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(359335151682768783)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39968227894705570)
,p_event_id=>wwv_flow_imp.id(46399963910630078)
,p_event_result=>'FALSE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(347712298109334392)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39968263193705571)
,p_event_id=>wwv_flow_imp.id(46399963910630078)
,p_event_result=>'FALSE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(360649770408770190)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46400350432630079)
,p_name=>'onClickFilter = Esquerda'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(46381315576630007)
,p_condition_element=>'P9005_TIPO_PESQUISA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46400832327630080)
,p_event_id=>wwv_flow_imp.id(46400350432630079)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#t_Body_side'').is('':visible'')) {',
'    $(''#t_Body_side'').hide();',
'} else {',
'    $(''#t_Body_side'').show();',
'}',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46401242611630081)
,p_name=>'onClickFilter = Modal'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(46381315576630007)
,p_condition_element=>'P9005_TIPO_PESQUISA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46401819793630082)
,p_event_id=>wwv_flow_imp.id(46401242611630081)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(345640941845028001)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46402199606630083)
,p_name=>'onPageLoad'
,p_event_sequence=>110
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46402646152630085)
,p_event_id=>wwv_flow_imp.id(46402199606630083)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(46381711951630008)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33652581601997850)
,p_event_id=>wwv_flow_imp.id(46402199606630083)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9005_SORT_COLUMN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33652663380997851)
,p_event_id=>wwv_flow_imp.id(46402199606630083)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(33650365556997828)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(134758027946891248)
,p_event_id=>wwv_flow_imp.id(46402199606630083)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_EXPAND'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(295338245635959965)
,p_build_option_id=>wwv_flow_imp.id(340973604135556181)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46393710783630057)
,p_name=>'onClickOpcoes'
,p_event_sequence=>150
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(46361550099629907)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46394146529630060)
,p_event_id=>wwv_flow_imp.id(46393710783630057)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(363200633756892577)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(47055799513126243)
,p_name=>'onAfterRefreshPesquisaCard'
,p_event_sequence=>160
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(347712298109334392)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47055845887126244)
,p_event_id=>wwv_flow_imp.id(47055799513126243)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9005_CARREGA_CONSULTA_CARD'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'S'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P9005_FILTRO_LIVRE_CARD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47056669550126252)
,p_event_id=>wwv_flow_imp.id(47055799513126243)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9005_CARREGA_CONSULTA_CARD'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'NULL'
,p_client_condition_element=>'P9005_FILTRO_LIVRE_CARD'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(39965655059705545)
,p_name=>'onCloseCard'
,p_event_sequence=>180
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(397363224585415337)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39965814778705546)
,p_event_id=>wwv_flow_imp.id(39965655059705545)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(397363224585415337)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39968420164705572)
,p_event_id=>wwv_flow_imp.id(39965655059705545)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(347712298109334392)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(39965905508705547)
,p_name=>'onCloseLista'
,p_event_sequence=>190
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(359335151682768783)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39966015492705548)
,p_event_id=>wwv_flow_imp.id(39965905508705547)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(359335151682768783)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39968433705705573)
,p_event_id=>wwv_flow_imp.id(39965905508705547)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(360649770408770190)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(47057596451126261)
,p_name=>'onClickBotaoOrder'
,p_event_sequence=>200
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#botao_order'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47057637825126262)
,p_event_id=>wwv_flow_imp.id(47057596451126261)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(397363224585415337)
,p_attribute_01=>'N'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P9005_CARD_OU_LISTA'
,p_client_condition_expression=>'CAR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(47058110587126266)
,p_event_id=>wwv_flow_imp.id(47057596451126261)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(359335151682768783)
,p_attribute_01=>'N'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P9005_CARD_OU_LISTA'
,p_client_condition_expression=>'GRI'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(29222673453305652)
,p_name=>'onClickA-CardView-item '
,p_event_sequence=>210
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.a-CardView-item '
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(29222282091305648)
,p_event_id=>wwv_flow_imp.id(29222673453305652)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9005_ID_ATUAL'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.dataset[''id'']'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(39967730571705566)
,p_name=>'onCloseMenu'
,p_event_sequence=>220
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(46382125272630009)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39967884571705567)
,p_event_id=>wwv_flow_imp.id(39967730571705566)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(397363224585415337)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39967929770705568)
,p_event_id=>wwv_flow_imp.id(39967730571705566)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(359335151682768783)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39968532213705574)
,p_event_id=>wwv_flow_imp.id(39967730571705566)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(347712298109334392)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39968715499705575)
,p_event_id=>wwv_flow_imp.id(39967730571705566)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(360649770408770190)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(61987939755719555)
,p_name=>'onAfterRefreshListaOculta'
,p_event_sequence=>230
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(359323945219767141)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(61988040393719556)
,p_event_id=>wwv_flow_imp.id(61987939755719555)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(359335151682768783)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(29221428114305639)
,p_name=>'New_1'
,p_event_sequence=>250
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(228137834535879909)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(29221316651305638)
,p_event_id=>wwv_flow_imp.id(29221428114305639)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(29221580845305641)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(5708019501710539)
,p_name=>'onClickVisaoReport'
,p_event_sequence=>260
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(46380506416630004)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5707946412710538)
,p_event_id=>wwv_flow_imp.id(5708019501710539)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    p_sucesso clob;',
'    p_messages pkg_mensagem.message_record_table;',
'begin',
'    bo_mpd_usuario_artefato_formato.inclui_ou_altera_registro(',
'        p_codigo_artefato => :P9005_CODIGO_ARTEFATO,',
'        p_formato => ''GRI'',',
'        p_sucesso => p_sucesso,',
'        p_messages => p_messages',
'    );',
'    :P9005_URL := apex_page.get_url( ',
'        p_page => 9005,  ',
'        p_items => ''P9005_CODIGO_ARTEFATO,P9005_PARAMETRO,P9005_PARAMETRO2,P9005_ORDER'', ',
'        p_values => :P9005_CODIGO_ARTEFATO||'',''||:P9005_PARAMETRO||'',''||:P9005_PARAMETRO2||'','');         ',
'end;'))
,p_attribute_02=>'P9005_CODIGO_ARTEFATO'
,p_attribute_03=>'P9005_URL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1604128160518264)
,p_event_id=>wwv_flow_imp.id(5708019501710539)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v(''P9005_URL''))',
'    window.location.replace($v(''P9005_URL''));        '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(5707847118710537)
,p_name=>'onClickVisaoCard'
,p_event_sequence=>270
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(46380846850630006)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5707628088710535)
,p_event_id=>wwv_flow_imp.id(5707847118710537)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    p_sucesso clob;',
'    p_messages pkg_mensagem.message_record_table;',
'begin',
'    bo_mpd_usuario_artefato_formato.inclui_ou_altera_registro(',
'        p_codigo_artefato => :P9005_CODIGO_ARTEFATO,',
'        p_formato => ''CAR'',',
'        p_sucesso => p_sucesso,',
'        p_messages => p_messages',
'    );',
'    :P9005_URL := apex_page.get_url( ',
'        p_page => 9005,  ',
'        p_items => ''P9005_CODIGO_ARTEFATO,P9005_PARAMETRO,P9005_PARAMETRO2,P9005_ORDER'', ',
'        p_values => :P9005_CODIGO_ARTEFATO||'',''||:P9005_PARAMETRO||'',''||:P9005_PARAMETRO2||'','');        ',
'end;'))
,p_attribute_02=>'P9005_CODIGO_ARTEFATO'
,p_attribute_03=>'P9005_URL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1604052900518263)
,p_event_id=>wwv_flow_imp.id(5707847118710537)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v(''P9005_URL''))',
'    window.location.replace($v(''P9005_URL''));        '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(5706896799710528)
,p_name=>'onClickFavNao'
,p_event_sequence=>280
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(5707121108710530)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5706803659710527)
,p_event_id=>wwv_flow_imp.id(5706896799710528)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    p_sucesso clob;',
'    p_messages pkg_mensagem.message_record_table;',
'begin',
'    bo_mpd_usuario_artefato_favorito.inclui_ou_exclui_registro(',
'        p_codigo_artefato => :P9005_CODIGO_ARTEFATO,',
'        p_acao => 1, -- inclui favorito',
'        p_sucesso => p_sucesso,',
'        p_messages => p_messages',
'    );',
'    :P9005_URL := apex_page.get_url( ',
'        p_page => 9005,  ',
'        p_items => ''P9005_CODIGO_ARTEFATO,P9005_PARAMETRO,P9005_PARAMETRO2'', ',
'        p_values => :P9005_CODIGO_ARTEFATO||'',''||:P9005_PARAMETRO||'',''||:P9005_PARAMETRO2);        ',
'end;'))
,p_attribute_02=>'P9005_CODIGO_ARTEFATO'
,p_attribute_03=>'P9005_URL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1603270375518255)
,p_event_id=>wwv_flow_imp.id(5706896799710528)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v(''P9005_URL''))',
'    window.location.replace($v(''P9005_URL''));        '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(5706673083710526)
,p_name=>'onClickFavSim'
,p_event_sequence=>290
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(5707070111710529)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5706638547710525)
,p_event_id=>wwv_flow_imp.id(5706673083710526)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    p_sucesso clob;',
'    p_messages pkg_mensagem.message_record_table;',
'begin',
'    bo_mpd_usuario_artefato_favorito.inclui_ou_exclui_registro(',
'        p_codigo_artefato => :P9005_CODIGO_ARTEFATO,',
'        p_acao => 2, -- exclui',
'        p_sucesso => p_sucesso,',
'        p_messages => p_messages',
'    );',
'    :P9005_URL := apex_page.get_url( ',
'        p_page => 9005,  ',
'        p_items => ''P9005_CODIGO_ARTEFATO,P9005_PARAMETRO,P9005_PARAMETRO2'', ',
'        p_values => :P9005_CODIGO_ARTEFATO||'',''||:P9005_PARAMETRO||'',''||:P9005_PARAMETRO2);        ',
'end;'))
,p_attribute_02=>'P9005_CODIGO_ARTEFATO'
,p_attribute_03=>'P9005_URL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1603082330518254)
,p_event_id=>wwv_flow_imp.id(5706673083710526)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v(''P9005_URL''))',
'    window.location.replace($v(''P9005_URL''));        '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19773781640579428)
,p_name=>'onAfterRefreshPesquisaLista'
,p_event_sequence=>300
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(360649770408770190)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19773943884579430)
,p_event_id=>wwv_flow_imp.id(19773781640579428)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9005_CARREGA_CONSULTA_CARD'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'S'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P9005_FILTRO_LIVRE_CARD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19774049060579431)
,p_event_id=>wwv_flow_imp.id(19773781640579428)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9005_CARREGA_CONSULTA_CARD'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'NULL'
,p_client_condition_element=>'P9005_FILTRO_LIVRE_CARD'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(53437899152777062)
,p_name=>'onChangeUrlNew'
,p_event_sequence=>310
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9005_URL_NEW'
,p_condition_element=>'P9005_URL_NEW'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(53437968168777063)
,p_event_id=>wwv_flow_imp.id(53437899152777062)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(46381711951630008)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(53438111988777064)
,p_event_id=>wwv_flow_imp.id(53437899152777062)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(46381711951630008)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(33649594281997820)
,p_name=>'onClickOrder'
,p_event_sequence=>320
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(33649444432997819)
,p_condition_element=>'P9005_ORDER_SITUACAO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'S'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33649647942997821)
,p_event_id=>wwv_flow_imp.id(33649594281997820)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(33650365556997828)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33649870363997823)
,p_event_id=>wwv_flow_imp.id(33649594281997820)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(33650365556997828)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33650898521997833)
,p_event_id=>wwv_flow_imp.id(33649594281997820)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9005_SORT_COLUMN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33650945344997834)
,p_event_id=>wwv_flow_imp.id(33649594281997820)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9005_SORT_COLUMN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33650081984997825)
,p_event_id=>wwv_flow_imp.id(33649594281997820)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9005_ORDER_SITUACAO'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'H'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33650215529997826)
,p_event_id=>wwv_flow_imp.id(33649594281997820)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9005_ORDER_SITUACAO'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'S'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(121230923257136518)
,p_name=>'onChangePrefiltroCard'
,p_event_sequence=>330
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9005_PRE_FILTRO_CARD'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(121231046734136519)
,p_event_id=>wwv_flow_imp.id(121230923257136518)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(397363224585415337)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(121231146139136520)
,p_event_id=>wwv_flow_imp.id(121230923257136518)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(347712298109334392)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(121231322169136521)
,p_name=>'onChangePrefiltroLista'
,p_event_sequence=>340
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9005_PRE_FILTRO_LISTA'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(121231380388136522)
,p_event_id=>wwv_flow_imp.id(121231322169136521)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(359323945219767141)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(121231424446136523)
,p_event_id=>wwv_flow_imp.id(121231322169136521)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(360649770408770190)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(46456405084020758)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>unistr('Salvar personaliza\00E7\00E3o das colunas')
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'BO_MPD_USUARIO_GRID_OCULTA_COLUNA'
,p_attribute_04=>'INCLUI_OU_ALTERA_REGISTRO'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(46456251494020757)
,p_internal_uid=>89327276744663031
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(47055006840126235)
,p_page_process_id=>wwv_flow_imp.id(46456405084020758)
,p_page_id=>9005
,p_name=>'p_id_coluna'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P9005_COLUNAS'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(47055120630126236)
,p_page_process_id=>wwv_flow_imp.id(46456405084020758)
,p_page_id=>9005
,p_name=>'p_id_usuario'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'ID_USUARIO_LOGADO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(47055215376126237)
,p_page_process_id=>wwv_flow_imp.id(46456405084020758)
,p_page_id=>9005
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P9005_CODIGO_ARTEFATO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(47055265446126238)
,p_page_process_id=>wwv_flow_imp.id(46456405084020758)
,p_page_id=>9005
,p_name=>'p_pagina'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>true
,p_display_sequence=>40
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(47055403884126239)
,p_page_process_id=>wwv_flow_imp.id(46456405084020758)
,p_page_id=>9005
,p_name=>'p_encadeado'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>50
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(47055469881126240)
,p_page_process_id=>wwv_flow_imp.id(46456405084020758)
,p_page_id=>9005
,p_name=>'p_sucesso'
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>true
,p_display_sequence=>60
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(47055626332126241)
,p_page_process_id=>wwv_flow_imp.id(46456405084020758)
,p_page_id=>9005
,p_name=>'p_messages'
,p_direction=>'OUT'
,p_data_type=>'pkg_mensagem.message_record_table'
,p_display_sequence=>70
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(46391260223630050)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'url_new'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'URL_NEW'
,p_internal_uid=>89262131884272323
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(46391797465630051)
,p_page_process_id=>wwv_flow_imp.id(46391260223630050)
,p_page_id=>9005
,p_name=>'p_param2'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>70
,p_value_type=>'ITEM'
,p_value=>'P9005_PARAMETRO2'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(46392257895630052)
,p_page_process_id=>wwv_flow_imp.id(46391260223630050)
,p_page_id=>9005
,p_name=>'p_param1'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>60
,p_value_type=>'ITEM'
,p_value=>'P9005_PARAMETRO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(46392762365630054)
,p_page_process_id=>wwv_flow_imp.id(46391260223630050)
,p_page_id=>9005
,p_name=>'p_url'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>40
,p_value_type=>'ITEM'
,p_value=>'P9005_URL_NEW'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(46393270400630055)
,p_page_process_id=>wwv_flow_imp.id(46391260223630050)
,p_page_id=>9005
,p_name=>'p_codigo_arfato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>50
,p_value_type=>'ITEM'
,p_value=>'P9005_CODIGO_ARTEFATO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(46389375329630038)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'retorna_titulo_tela'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'RETORNA_TITULO_TELA'
,p_internal_uid=>89260246990272311
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(46389885063630046)
,p_page_process_id=>wwv_flow_imp.id(46389375329630038)
,p_page_id=>9005
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P9005_CODIGO_ARTEFATO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(46390369644630048)
,p_page_process_id=>wwv_flow_imp.id(46389375329630038)
,p_page_id=>9005
,p_name=>'p_titulo'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P0_TITULO_TELA'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(46390921841630049)
,p_page_process_id=>wwv_flow_imp.id(46389375329630038)
,p_page_id=>9005
,p_name=>'p_help'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P0_HELP_TELA'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(46389001027630036)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_formato varchar2(3);',
'    l_id number;',
'    l_data_alteracao timestamp;',
'begin',
'    :P9005_ORDER := null;',
'    ',
'    PKG_UI.prc_configurar_filtros(',
'        p_id_usuario => :ID_USUARIO_LOGADO ,',
'        p_codigo_artefato => :P9005_CODIGO_ARTEFATO,',
'        p_app_page_id => :app_page_id   ',
'    );',
'',
'    begin',
'        select formato into l_formato from mpd_usuario_artefato_formato ',
'        where upper(login) = upper(apex_custom_auth.get_username) ',
'        and upper(codigo_artefato) = upper(:P9005_CODIGO_ARTEFATO)',
'        and aplicacao = apex_application.g_flow_id;',
'        exception',
'            when no_data_found then',
'                l_formato := null;',
'    end;',
'',
'    :P9005_CARD_OU_LISTA := l_formato;    ',
'    if :P9005_CARD_OU_LISTA is null then',
'        :P9005_CARD_OU_LISTA := ''CAR'';',
'    end if;    ',
'',
'    bo_mpd_usuario_artefato_favorito.retorna_registro( ',
'        p_login => upper(apex_custom_auth.get_username),',
'        p_codigo_artefato => :P9005_CODIGO_ARTEFATO,',
'        p_aplicacao => apex_application.g_flow_id,',
'        p_id => l_id,',
'        p_data_alteracao => l_data_alteracao',
'    );    ',
'    if l_id is not null then',
'        :P9005_FAVORITO := 1;',
'    else',
'        :P9005_FAVORITO := 0;',
'    end if;',
'',
'end;',
'',
'',
'    ',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>89259872688272309
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(33651281458997837)
,p_process_sequence=>40
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load default order'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_order         varchar2(2000);',
'    l_json          clob;',
'    l_pagina        varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO, ''TD150'');',
'    l_card_ou_lista varchar2(10)  := :P9005_CARD_OU_LISTA;',
'begin',
'    l_pagina := upper(trim(l_pagina));',
'',
'    if not regexp_like(l_pagina, ''^[A-Z0-9_]+$'') then',
'        raise_application_error(-20001, ''Codigo de artefato invalido.'');',
'    end if;',
'',
'    execute immediate',
'        ''begin ui_mpd_'' || l_pagina || ''.campos_ordenacao_default(:card_ou_grid, :order, :json); end;''',
'        using in l_card_ou_lista, out l_order, out l_json;',
'',
'    :P9005_ORDER := l_order;',
'    ',
'    exception',
'        when others then',
'            :P9005_ORDER := null;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>181786859133139220
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(46455661042020751)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GETIMAGE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    ',
'',
'    for c1 in (select *',
'               from   MPD_USUARIO',
'               where  id = :P9005_ID) loop',
'        sys.htp.init;',
'        sys.owa_util.Mime_header(c1.foto_mimetype, false);',
'        sys.htp.P(''Content-length: ''|| sys.dbms_lob.Getlength(c1.foto));',
'        sys.htp.P(''Content-Disposition: attachment; filename="''|| c1.foto_name|| ''"'');',
'        sys.htp.P(''Cache-Control: max-age=1'');',
'        sys.owa_util.http_header_close;',
'        sys.wpg_docload.Download_file(c1.foto);',
'        apex_application.stop_apex_engine;',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>89326532702663024
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3731119566242124)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LOGAR_TEMPO_TELA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_usuario VARCHAR2(255) := NVL(apex_application.g_user, ''ANONYMOUS'');',
'BEGIN',
'    INSERT INTO log_tempo_tela (usuario, app_id, page_id, codigo_artefato, tempo_ms)',
'    VALUES (',
'        v_usuario,',
'        :APP_ID,',
'        :APP_PAGE_ID,',
'        :P0_CODIGO_ARTEFATO,',
'        TO_NUMBER(apex_application.g_x01) -- tempo enviado pelo JS',
'    );',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>39139752094400149
);
wwv_flow_imp.component_end;
end;
/
