prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 139
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(489307990446697728)
,p_group_name=>'Administration'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(360753813084726995)
,p_group_name=>'Agendamentos'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(360437071456038216)
,p_group_name=>'Artefatos'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(374412119720621928)
,p_group_name=>'Cadastro auxiliar'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(357506617581202256)
,p_group_name=>'Chamados'
,p_group_desc=>unistr('Grupo de p\00E1ginas do projeto de chamados.')
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(371274943978184288)
,p_group_name=>'Controle de acesso'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(359429206409640204)
,p_group_name=>'Convites'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(375805476205979528)
,p_group_name=>'Importar dados'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(370511843251763518)
,p_group_name=>'Login'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(376628966173032498)
,p_group_name=>'Tabela'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(370511911313764504)
,p_group_name=>'Template'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(359667317674293880)
,p_group_name=>'Tutorial'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(360657302818349521)
,p_group_name=>'Usuarios'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(360774164628342447)
,p_group_name=>'Webservices'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(359043379004724757)
,p_group_name=>'Workspace'
);
wwv_flow_imp.component_end;
end;
/
