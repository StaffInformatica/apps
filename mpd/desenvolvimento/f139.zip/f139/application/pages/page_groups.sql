prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 139
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(341172412772556345)
,p_group_name=>'Administration'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(212618235410585612)
,p_group_name=>'Agendamentos'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(212301493781896833)
,p_group_name=>'Artefatos'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(226276542046480545)
,p_group_name=>'Cadastro auxiliar'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(209371039907060873)
,p_group_name=>'Chamados'
,p_group_desc=>unistr('Grupo de p\00E1ginas do projeto de chamados.')
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(223139366304042905)
,p_group_name=>'Controle de acesso'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(211293628735498821)
,p_group_name=>'Convites'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(227669898531838145)
,p_group_name=>'Importar dados'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(222376265577622135)
,p_group_name=>'Login'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(228493388498891115)
,p_group_name=>'Tabela'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(222376333639623121)
,p_group_name=>'Template'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(211531740000152497)
,p_group_name=>'Tutorial'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(212521725144208138)
,p_group_name=>'Usuarios'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(212638586954201064)
,p_group_name=>'Webservices'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(210907801330583374)
,p_group_name=>'Workspace'
);
wwv_flow_imp.component_end;
end;
/
