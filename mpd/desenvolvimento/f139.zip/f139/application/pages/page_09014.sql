prompt --application/pages/page_09014
begin
--   Manifest
--     PAGE: 09014
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_page.create_page(
 p_id=>9014
,p_name=>'Template - Lista com Wizard'
,p_alias=>'TEMPLATE-LISTA-COM-WIZARD'
,p_page_mode=>'MODAL'
,p_step_title=>'Template - Lista com Wizard'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function seleciona(item) {',
'  console.log(''seleciona'');',
'  var id = item.value;',
'',
'  var item = apex.item("P9014_ITENS_SELECIONADOS");',
'  var currentValue = item.getValue(); // string tipo "123,456"',
'',
'  // Transforma em array',
unistr('  var valores = currentValue ? currentValue.split(",") : []; // L\00E9o(31/07/25) \00DAnico separador que funcionou (||''||''||)'),
'',
'  var index = valores.indexOf(id);',
'  if (index > -1) {',
unistr('    // Remove se j\00E1 existir'),
'    valores.splice(index, 1);',
'  } else {',
unistr('    // Adiciona se n\00E3o existir'),
'    valores.push(id);',
'  }',
'',
'  // Atualiza o item com nova string',
'    item.setValue(valores.join(","));',
'    $s("P9014_ITENS_SELECIONADOS", valores.join(","));',
'',
'    apex.server.process(',
'    "SETITEM", // Nome do processo PL/SQL definido no APEX',
'    {',
'      x01: apex.item("P9014_ITENS_SELECIONADOS").getValue()',
'',
'    },',
'    {',
'      dataType: ''text'',',
'      success: function(pData) {',
'        console.log("SETITEM com sucesso:", pData);',
'      }',
'    }',
'  );',
'}',
'',
'function copiarValor(origemId, destinoId) {',
'    var datePicker = document.getElementById(origemId);',
'    var valorOrigem = datePicker ? datePicker.value : ''''; ',
'    document.getElementById(destinoId).value = valorOrigem;',
'    //console.log(document.getElementById(destinoId).value);',
'}',
'',
'function checkInputAndToggleClass(inputElement) {',
unistr('    // Verificar se o campo de entrada est\00E1 preenchido'),
'    //console.log(inputElement.value);',
'    if (inputElement.value.trim() !== "") {',
unistr('        // Localizar a div pai que cont\00E9m "CONTAINER" no ID'),
'        let parentDiv = inputElement.closest("div[id*=''CONTAINER'']");',
'        ',
'        // Se a div for encontrada, adicionar a classe js-show-label',
'        if (parentDiv) {',
'            parentDiv.classList.add("js-show-label");',
'        }',
'    } else {',
'        // Se o valor estiver vazio, remover a classe js-show-label',
'        let parentDiv = inputElement.closest("div[id*=''CONTAINER'']");',
'        ',
'        // Remover a classe js-show-label se ela existir',
'        if (parentDiv) {',
'            parentDiv.classList.remove("js-show-label");',
'        }',
'    }',
'}',
'',
'document.addEventListener("DOMContentLoaded", function() {',
'  //   toggleFileUpload();  ',
'  var windowWidth = 400;  // Largura da janela popup',
'  var windowHeight = 450;  // Altura da janela popup',
'',
'  // Calcula o centro da tela',
'  var left = (window.screen.width - windowWidth) / 2;',
'  var top = (window.screen.height - windowHeight) / 2;',
'',
unistr('  // Modifica os par\00E2metros de ''left'' e ''top'' no popup gerado'),
'  var originalOpen = window.open;',
'  window.open = function(url, name, specs) {',
unistr('    // Adiciona ou substitui os par\00E2metros ''left'' e ''top'''),
'    specs = specs.replace(/left=\d+/, ''left='' + left);',
'    specs = specs.replace(/top=\d+/, ''top='' + top);',
'',
unistr('    // Se ''left'' e ''top'' n\00E3o existirem, adiciona os par\00E2metros'),
'    if (!specs.includes(''left='')) specs += '',left='' + left;',
'    if (!specs.includes(''top='')) specs += '',top='' + top;',
'',
unistr('    // Chama a fun\00E7\00E3o window.open original com as modifica\00E7\00F5es'),
'    return originalOpen.call(window, url, name, specs);',
'  };',
'});'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'tituloTela($v("P9014_TELA_TITULO")+'' (''+$v("P9014_CODIGO_ARTEFATO")+'')'');',
'',
'$(document).on(''click'', ''#checkAll'', function () {',
'  const check = this.checked;',
'',
'  $(''input[name="f01"]'').each(function () {',
unistr('    // S\00F3 atualiza se o estado for diferente (evita repeti\00E7\00E3o desnecess\00E1ria)'),
'    if (this.checked !== check) {',
'      this.checked = check;',
'      seleciona(this);',
'    }',
'  });',
'});',
'',
unistr('//Popula o P9014_ITENS_SELECIONADOS quando carrega a tela com ID''s dos itens j\00E1 selecionados'),
'(function () {',
unistr('    // Pega todos os checkboxes da lista com name="f01" j\00E1 marcados'),
'    var checkboxes = document.querySelectorAll(''input[name="f01"]:checked'');',
'',
'    // Extrai os valores (IDs)',
'    var ids = Array.from(checkboxes).map(function(cb) {',
'        return cb.value;',
'    });',
'',
unistr('    // Junta em uma string separada por v\00EDrgula'),
'    var listaIds = ids.join('','');',
'',
unistr('    // Atualiza o item de p\00E1gina no APEX'),
'    console.log(''listaIds:''+listaIds);',
'    apex.item("P9014_ITENS_SELECIONADOS").setValue(listaIds);',
'})();'))
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Region-body{',
'    padding: 8px;',
'}'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-controls{',
'    display: contents;',
'}',
'',
'.centro{',
'    display: grid;',
'    justify-items: center;',
'}',
'',
'.select option.selected {',
'    color: #888; /* Cor mais clara para parecer um placeholder */',
'    opacity: 0.5; /* Reduz a opacidade */',
'}',
'',
'.t-Region-body,.t-ButtonRegion-col--content{',
'    padding: 8px;',
'}',
''))
,p_step_template=>wwv_flow_imp.id(489110489949697573)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_protection_level=>'C'
,p_page_component_map=>'25'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(303236651213560401)
,p_plug_name=>'List'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>210
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9014_CODIGO_ARTEFATO,''TD501'');',
'begin',
'    begin',
'        EXECUTE IMMEDIATE ',
'            ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_report_selecao(:param1); END;''',
'            -- ''BEGIN :l_sql := UI_MPD_100.sql_report; END;''',
'            USING OUT l_sql, IN :P9014_PARAMETRO; ',
'        exception ',
'            when others then',
'                return ''select 1 from dual'';',
'    end;',
'    return l_sql;       ',
'end;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P9014_PARAMETRO'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(303236766204560402)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'Nenhum registro adicionado ainda.'
,p_show_actions_menu=>'N'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'TESTE'
,p_internal_uid=>197972060191061292
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(217411649428639074)
,p_db_column_name=>'SELECTED'
,p_display_order=>10
,p_column_identifier=>'P'
,p_column_label=>'&P9014_LABEL_SELECIONA_TODOS.'
,p_alternative_label=>'Vazio'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P9014_PERMITE_SELECAO'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(217411821542639075)
,p_db_column_name=>'ID'
,p_display_order=>20
,p_column_identifier=>'Q'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(217411877707639076)
,p_db_column_name=>'CAMPO1'
,p_display_order=>30
,p_column_identifier=>'R'
,p_column_label=>'&P9014_LABEL_CAMPO1.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P9014_LABEL_CAMPO1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(217411950268639077)
,p_db_column_name=>'CAMPO2'
,p_display_order=>40
,p_column_identifier=>'S'
,p_column_label=>'&P9014_LABEL_CAMPO2.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P9014_LABEL_CAMPO2'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(217412053144639078)
,p_db_column_name=>'CAMPO3'
,p_display_order=>50
,p_column_identifier=>'T'
,p_column_label=>'&P9014_LABEL_CAMPO3.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P9014_LABEL_CAMPO3'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(217412175166639079)
,p_db_column_name=>'CAMPO4'
,p_display_order=>60
,p_column_identifier=>'U'
,p_column_label=>'&P9014_LABEL_CAMPO4.'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P9014_LABEL_CAMPO4'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(224809133581549230)
,p_db_column_name=>'CAMPO5'
,p_display_order=>70
,p_column_identifier=>'V'
,p_column_label=>'&P9014_LABEL_CAMPO5.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P9014_LABEL_CAMPO5'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(224809306651549231)
,p_db_column_name=>'CAMPO6'
,p_display_order=>80
,p_column_identifier=>'W'
,p_column_label=>'&P9014_LABEL_CAMPO6.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P9014_LABEL_CAMPO6'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(224809368019549232)
,p_db_column_name=>'CAMPO7'
,p_display_order=>90
,p_column_identifier=>'X'
,p_column_label=>'&P9014_LABEL_CAMPO7.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P9014_LABEL_CAMPO7'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(224809488499549233)
,p_db_column_name=>'CAMPO8'
,p_display_order=>100
,p_column_identifier=>'Y'
,p_column_label=>'&P9014_LABEL_CAMPO8.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P9014_LABEL_CAMPO8'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(224809543959549234)
,p_db_column_name=>'CAMPO9'
,p_display_order=>110
,p_column_identifier=>'Z'
,p_column_label=>'&P9014_LABEL_CAMPO9.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P9014_LABEL_CAMPO9'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(224809730478549235)
,p_db_column_name=>'CAMPO10'
,p_display_order=>120
,p_column_identifier=>'AA'
,p_column_label=>'&P9014_LABEL_CAMPO10.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P9014_LABEL_CAMPO10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(224809748139549236)
,p_db_column_name=>'OPCAO'
,p_display_order=>130
,p_column_identifier=>'AB'
,p_column_label=>'&P0_LABEL_OPCAO.'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div style="display: flex; align-items: center; justify-content: center; flex-grow: 1;">',
'    <span #OPCAO# style="cursor: pointer; color: var(--a-button-state-text-color, var(--a-button-type-text-color, var(--a-button-text-color, inherit)));" ',
'        class="fa fa-ellipsis-v js-dlg-refresh" title="&P0_LABEL_OPCAO!RAW.">',
'    </span>',
'</div>'))
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P9014_ESCONDE_OPCAO'
,p_display_condition2=>'NO'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(304284339204850025)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'796391'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SELECTED:CAMPO1:CAMPO10:CAMPO2:CAMPO3:CAMPO4:CAMPO5:CAMPO6:CAMPO7:CAMPO8:CAMPO9:OPCAO:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(304302005509998492)
,p_plug_name=>'Header'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--slimPadding:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(489149217063697608)
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9014_CODIGO_ARTEFATO,''TD452'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_cabecalho(:param1,:param2,:param3); END;''',
'        USING OUT l_sql, IN nvl(:P9014_ID,:P9014_PARAMETRO),nvl(:P9014_PARAMETRO2,:P9014_PARAMETRO),:P9014_PARAMETRO3;',
'',
'    return l_sql;       ',
'end;',
''))
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P9014_ID,P9014_PARAMETRO,P9014_PARAMETRO2,P9014_PARAMETRO3'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from all_procedures',
'where upper(object_name) = upper(''ui_mpd_''||:p9014_codigo_artefato)',
'and upper(procedure_name) = upper(''sql_cabecalho'')',
'and upper(object_type) = upper(''package'');'))
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(458095468828472903)
,p_plug_name=>'Steps'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#:t-WizardSteps--displayLabels'
,p_plug_template=>wwv_flow_imp.id(489194609147697632)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_list_id=>wwv_flow_imp.id(167955282233907082)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(489271776772697681)
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    1',
'from srv_artefato_wizard a',
'join srv_artefato_versionado b on b.id = a.id_artefato_versionado',
'join srv_artefato c on c.id = b.id_artefato',
'join srv_artefato_versionado b1 on b1.id = a.id_artefato_versionado_base',
'join srv_artefato c1 on c1.id = b1.id_artefato',
'where c.codigo_artefato = nvl( apex_util.get_session_state(''P''||:APP_PAGE_ID||''_CODIGO_WIZARD''),:p0_codigo_artefato)'))
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(458095951260474550)
,p_plug_name=>'Footer'
,p_region_css_classes=>'u-margin-bottom-none'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(489149217063697608)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(619159581908436599)
,p_plug_name=>unistr('Formul\00E1rio')
,p_title=>'Informe'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody:t-Form--large'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>20
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_html clob;        ',
'    l_codigo_artefato varchar2(128) := nvl(:P9014_CODIGO_ARTEFATO,100);',
'begin',
'    pkg_ui.gerar_formulario(l_codigo_artefato,nvl(:P9014_ID,:P9014_COPIA),:P9014_VISUALIZAR,l_html,:P9014_PARAMETRO,:P9014_PARAMETRO2); ',
'    return l_html;',
'end;'))
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P9014_CODIGO_ARTEFATO,P9014_COPIA,P9014_PARAMETRO,P9014_PARAMETRO2,P9014_VISUALIZAR'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from all_procedures',
'where upper(object_name) = upper(''ui_mpd_''||:p9014_codigo_artefato)',
'and upper(procedure_name) = upper(''formulario'')',
'and upper(object_type) = upper(''package'');'))
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(168011742172913456)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(303236651213560401)
,p_button_name=>'incluir'
,p_button_static_id=>'NEW'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(489279883613697688)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_NOVO.'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'&P9014_URL_INCLUIR.'
,p_button_condition=>'P9014_URL_INCLUIR'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-plus-circle'
,p_button_cattributes=>'style="margin-top:0px;"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(168017663329913483)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(458095951260474550)
,p_button_name=>'Proximo'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(489279883613697688)
,p_button_image_alt=>'Proximo'
,p_button_position=>'NEXT'
,p_button_condition=>'P9014_URL_PROXIMO'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-angle-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(168012172407913457)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(303236651213560401)
,p_button_name=>'opcao'
,p_button_static_id=>'BOTAO_OPCAO'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(489278989412697687)
,p_button_image_alt=>'Opcao'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'&P9014_URL_OPCAO.'
,p_button_condition=>'P9014_URL_OPCAO'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_button_css_classes=>'color-text'
,p_icon_css_classes=>'fa-ellipsis-v-o'
,p_button_cattributes=>'style="margin-top:0px;"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(168017285190913482)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(458095951260474550)
,p_button_name=>'DoneC'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(489279883613697688)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Concluir'
,p_button_position=>'NEXT'
,p_button_condition=>':P9014_ID is null and :P9014_URL_PROXIMO is null'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-check-circle'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(168018086237913484)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(458095951260474550)
,p_button_name=>'Voltar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(489279883613697688)
,p_button_image_alt=>'Voltar'
,p_button_position=>'PREVIOUS'
,p_button_condition=>'P9014_URL_ANTERIOR'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-angle-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(168047255830913589)
,p_branch_name=>'goto_anterior'
,p_branch_action=>'P9014_URL_ANTERIOR'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'BRANCH_TO_URL_IDENT_BY_ITEM'
,p_branch_when_button_id=>wwv_flow_imp.id(168018086237913484)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(168047656222913590)
,p_branch_name=>'goto_proximo'
,p_branch_action=>'P9014_URL_PROXIMO'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'BRANCH_TO_URL_IDENT_BY_ITEM'
,p_branch_when_button_id=>wwv_flow_imp.id(168017663329913483)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(168048056216913591)
,p_branch_name=>'goto_atual'
,p_branch_action=>'f?p=&APP_ID.:9014:&SESSION.::&DEBUG.:9014:P9014_PARAMETRO,P9014_CODIGO_ARTEFATO,P0_CODIGO_ARTEFATO,P9014_PARAMETRO2,P9014_CODIGO_WIZARD:&P9014_PARAMETRO.,&P9014_CODIGO_ARTEFATO.,&P0_CODIGO_ARTEFATO.,&P9014_PARAMETRO2.,&P9014_CODIGO_WIZARD.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>30
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(166313462012903254)
,p_name=>'P9014_ESCONDE_OPCAO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(303236651213560401)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(224815927913549268)
,p_name=>'P9014_PERMITE_SELECAO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(303236651213560401)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(224822490937549298)
,p_name=>'P9014_ITENS_SELECIONADOS'
,p_item_sequence=>200
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(226948967783809691)
,p_name=>'P9014_PERMITE_SELECAO_TODOS'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(303236651213560401)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(226949461095809695)
,p_name=>'P9014_LABEL_SELECIONA_TODOS'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(303236651213560401)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(226953860458809704)
,p_name=>'P9014_URL_INCLUIR'
,p_item_sequence=>60
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_url clob;',
'    l_pagina varchar2(256) := nvl(:P9014_CODIGO_ARTEFATO,''TD452'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :url := UI_MPD_''||l_pagina||''.mostra_incluir(:param1,:param2,:param3); END;''',
'        USING OUT l_url, IN nvl(:P9014_ID,:P9014_PARAMETRO),nvl(:P9014_PARAMETRO2,:P9014_PARAMETRO),:P9014_PARAMETRO3;',
'',
'    return l_url;       ',
'end;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from all_procedures',
'where upper(object_name) = upper(''ui_mpd_''||:p9014_codigo_artefato)',
'and upper(procedure_name) = upper(''mostra_incluir'')',
'and upper(object_type) = upper(''package'');'))
,p_display_when_type=>'EXISTS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(226954032398809705)
,p_name=>'P9014_REALIZA_POST'
,p_item_sequence=>70
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from all_procedures',
'where upper(object_name) = upper(''ui_mpd_''||:p9014_codigo_artefato)',
'and upper(procedure_name) = upper(''post'')',
'and upper(object_type) = upper(''package'');'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(234667807957385692)
,p_name=>'P9014_PARAMETRO3'
,p_item_sequence=>150
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236362600311915626)
,p_name=>'P9014_CODIGO_WIZARD'
,p_item_sequence=>90
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(239897271403480830)
,p_name=>'P9014_PODE_AVANCAR'
,p_item_sequence=>240
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9014_CODIGO_ARTEFATO,''TD452'');',
'    l_log_1 boolean;',
'    l_log_2 boolean;',
'begin',
'    --l_log_1 := :P9014_ID is null and :P9014_URL_PROXIMO is null;',
'    begin',
'        EXECUTE IMMEDIATE ',
'            ''BEGIN :l_log_2 := UI_MPD_''||l_pagina||''.condicao_proximo(:param1); END;''',
'            USING OUT l_log_2, IN :P9014_PARAMETRO; ',
'        exception ',
'            when others then',
'                l_log_2 := true;',
'    end;',
'    if l_log_2 then    ',
'        return ''true'';',
'    else',
'        return ''false'';',
'    end if;',
'end;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(256551301208422329)
,p_name=>'P9014_URL_OPCAO'
,p_item_sequence=>50
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_url clob;',
'    l_pagina varchar2(256) := nvl(:P9014_CODIGO_ARTEFATO,''TD452'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :url := UI_MPD_''||l_pagina||''.mostra_opcao(:param1,:param2,:param3); END;''',
'        USING OUT l_url, IN nvl(:P9014_ID,:P9014_PARAMETRO),nvl(:P9014_PARAMETRO2,:P9014_PARAMETRO),:P9014_PARAMETRO3;',
'',
'    return l_url;       ',
'end;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from all_procedures',
'where upper(object_name) = upper(''ui_mpd_''||:p9014_codigo_artefato)',
'and upper(procedure_name) = upper(''mostra_opcao'')',
'and upper(object_type) = upper(''package'');'))
,p_display_when_type=>'EXISTS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303249096638560535)
,p_name=>'P9014_LABEL_CAMPO1'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(303236651213560401)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303249205864560536)
,p_name=>'P9014_LABEL_CAMPO7'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(303236651213560401)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303249275536560537)
,p_name=>'P9014_LABEL_CAMPO2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(303236651213560401)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303249366837560538)
,p_name=>'P9014_LABEL_CAMPO8'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(303236651213560401)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303249471735560539)
,p_name=>'P9014_LABEL_CAMPO6'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(303236651213560401)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303249589976560540)
,p_name=>'P9014_LABEL_CAMPO5'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(303236651213560401)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303249706806560541)
,p_name=>'P9014_LABEL_CAMPO3'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(303236651213560401)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303249807028560542)
,p_name=>'P9014_LABEL_CAMPO4'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(303236651213560401)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303249867184560543)
,p_name=>'P9014_LABEL_CAMPO9'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(303236651213560401)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303249958823560544)
,p_name=>'P9014_LABEL_CAMPO10'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(303236651213560401)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(329526228320689203)
,p_name=>'P9014_ETAPA'
,p_item_sequence=>220
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(382731818655615225)
,p_name=>'P9014_URL_PROXIMO'
,p_item_sequence=>180
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(382731915962615226)
,p_name=>'P9014_URL_ANTERIOR'
,p_item_sequence=>190
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(487354123511683703)
,p_name=>'P9014_ID'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(531760991749857449)
,p_name=>'P9014_PARAMETRO'
,p_item_sequence=>130
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(531761086768857450)
,p_name=>'P9014_PARAMETRO2'
,p_item_sequence=>140
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(531761166850857451)
,p_name=>'P9014_TELA_TITULO'
,p_item_sequence=>160
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(531761237080857452)
,p_name=>'P9014_TELA_HELP'
,p_item_sequence=>170
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(612124425163485419)
,p_name=>'P9014_CODIGO_ARTEFATO'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(612205222160651703)
,p_name=>'P9014_SUCESSO'
,p_item_sequence=>110
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(612356388850648683)
,p_name=>'P9014_VISUALIZAR'
,p_item_sequence=>100
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(614607935373212202)
,p_name=>'P9014_COPIA'
,p_item_sequence=>120
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(168024847674913519)
,p_computation_sequence=>10
,p_computation_item=>'P9014_LABEL_CAMPO1'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9014_CODIGO_ARTEFATO,''TD452'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(1); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return null;',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(168025265672913520)
,p_computation_sequence=>20
,p_computation_item=>'P9014_LABEL_CAMPO2'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9014_CODIGO_ARTEFATO,452);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(2); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return null;',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(168025649530913522)
,p_computation_sequence=>30
,p_computation_item=>'P9014_LABEL_CAMPO3'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9014_CODIGO_ARTEFATO,452);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(3); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return null;',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(168026079833913523)
,p_computation_sequence=>40
,p_computation_item=>'P9014_LABEL_CAMPO4'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9014_CODIGO_ARTEFATO,452);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(4); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return null;',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(168026420639913524)
,p_computation_sequence=>50
,p_computation_item=>'P9014_LABEL_CAMPO5'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9014_CODIGO_ARTEFATO,452);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(5); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return null;',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(168026870113913525)
,p_computation_sequence=>60
,p_computation_item=>'P9014_LABEL_CAMPO6'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9014_CODIGO_ARTEFATO,452);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(6); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return null;',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(168027284241913527)
,p_computation_sequence=>70
,p_computation_item=>'P9014_LABEL_CAMPO7'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9014_CODIGO_ARTEFATO,452);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(7); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return null;',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(168027690205913528)
,p_computation_sequence=>80
,p_computation_item=>'P9014_LABEL_CAMPO8'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9014_CODIGO_ARTEFATO,452);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(8); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return null;',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(168028060647913529)
,p_computation_sequence=>90
,p_computation_item=>'P9014_LABEL_CAMPO9'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9014_CODIGO_ARTEFATO,452);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(9); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return null;',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(168028360158913530)
,p_computation_sequence=>100
,p_computation_item=>'P9014_LABEL_CAMPO10'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9014_CODIGO_ARTEFATO,452);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(10); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return null;',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(168028747614913531)
,p_computation_sequence=>120
,p_computation_item=>'P9014_PERMITE_SELECAO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9014_CODIGO_ARTEFATO,''TD452'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''SEL''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return null;',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(168029110524913533)
,p_computation_sequence=>130
,p_computation_item=>'P9014_PERMITE_SELECAO_TODOS'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9014_CODIGO_ARTEFATO,''TD452'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''ALLSEL''''); END;''',
'        USING OUT l_sql;',
'    return l_sql;       ',
'    exception',
'        when others then',
'            return null;',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(168029514881913534)
,p_computation_sequence=>140
,p_computation_item=>'P9014_LABEL_SELECIONA_TODOS'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'<input type="checkbox" id="checkAll"></input>'
,p_compute_when=>'P9014_PERMITE_SELECAO_TODOS'
,p_compute_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(166313527501903255)
,p_computation_sequence=>150
,p_computation_item=>'P9014_ESCONDE_OPCAO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9014_CODIGO_ARTEFATO,''TD452'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''HIDOPC''''); END;''',
'        USING OUT l_sql;',
'    return nvl(l_sql,''NO'');       ',
'    exception',
'        when others then',
'            return ''NO'';',
'end;',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(168037295370913558)
,p_name=>'onCloseLista'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(303236651213560401)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(168038781896913563)
,p_event_id=>wwv_flow_imp.id(168037295370913558)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(303236651213560401)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(168038278855913561)
,p_event_id=>wwv_flow_imp.id(168037295370913558)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(304302005509998492)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(168037718966913560)
,p_event_id=>wwv_flow_imp.id(168037295370913558)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9014_PODE_AVANCAR'
,p_attribute_01=>'FUNCTION_BODY'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9014_CODIGO_ARTEFATO,''TD452'');',
'    l_log_1 boolean;',
'    l_log_2 boolean;',
'begin',
'    --l_log_1 := :P9014_ID is null and :P9014_URL_PROXIMO is null;',
'    begin',
'        EXECUTE IMMEDIATE ',
'            ''BEGIN :l_log_2 := UI_MPD_''||l_pagina||''.condicao_proximo(:param1); END;''',
'            USING OUT l_log_2, IN :P9014_PARAMETRO; ',
'        exception ',
'            when others then',
'                l_log_2 := true;',
'    end;',
'    if l_log_2 then    ',
'        return ''true'';',
'    else',
'        return ''false'';',
'    end if;',
'end;'))
,p_attribute_07=>'P9014_CODIGO_ARTEFATO,P9014_PARAMETRO'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(168041573170913569)
,p_name=>'onCloseBotaoOpcao'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#BOTAO_OPCAO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(168042010017913572)
,p_event_id=>wwv_flow_imp.id(168041573170913569)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(303236651213560401)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(168042532348913574)
,p_event_id=>wwv_flow_imp.id(168041573170913569)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(304302005509998492)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(168039166614913564)
,p_name=>'onChangePodeAvancar'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9014_PODE_AVANCAR'
,p_condition_element=>'P9014_PODE_AVANCAR'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'true'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(168039681590913565)
,p_event_id=>wwv_flow_imp.id(168039166614913564)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(168017285190913482)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(168041134944913568)
,p_event_id=>wwv_flow_imp.id(168039166614913564)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(168017285190913482)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(168040166212913566)
,p_event_id=>wwv_flow_imp.id(168039166614913564)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(168017663329913483)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(168040690501913567)
,p_event_id=>wwv_flow_imp.id(168039166614913564)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(168017663329913483)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(168042935480913575)
,p_name=>'onClickjs-dlg-setvalue'
,p_event_sequence=>40
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.js-dlg-setvalue'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(168043465363913577)
,p_event_id=>wwv_flow_imp.id(168042935480913575)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'window._lastDlgLinkZoom = $(this.triggeringElement)',
'                    .closest(''span.lov'')   // sobe para o container',
'                    .find(''input[coluna]'') // pega o input que possui atributo ''coluna''',
'                    .attr(''coluna'');                    '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(168045243732913583)
,p_name=>'onClosejs-dlg-setvalue'
,p_event_sequence=>50
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'document'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'!!window._lastDlgLinkZoom'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(168045765990913584)
,p_event_id=>wwv_flow_imp.id(168045243732913583)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'$(''input[coluna="'' + window._lastDlgLinkZoom + ''"]'').closest(''span.lov'').find(''input[type=hidden]'')'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P9004_SELECTED_ITEM_ID'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(168046232965913586)
,p_event_id=>wwv_flow_imp.id(168045243732913583)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'$(''input[coluna="'' + window._lastDlgLinkZoom + ''"]'').closest(''span.lov'').find(''input[type=text]'')'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P9004_SELECTED_ITEM_TEXT'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(168046786167913587)
,p_event_id=>wwv_flow_imp.id(168045243732913583)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'window._lastDlgLinkZoom = null;'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(168043870157913578)
,p_name=>'onClosedIncluir'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(168011742172913456)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(168044849780913581)
,p_event_id=>wwv_flow_imp.id(168043870157913578)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(303236651213560401)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(168044361429913579)
,p_event_id=>wwv_flow_imp.id(168043870157913578)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9014_PODE_AVANCAR'
,p_attribute_01=>'FUNCTION_BODY'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9014_CODIGO_ARTEFATO,''TD452'');',
'    l_log_1 boolean;',
'    l_log_2 boolean;',
'begin',
'    --l_log_1 := :P9014_ID is null and :P9014_URL_PROXIMO is null;',
'    begin',
'        EXECUTE IMMEDIATE ',
'            ''BEGIN :l_log_2 := UI_MPD_''||l_pagina||''.condicao_proximo(:param1); END;''',
'            USING OUT l_log_2, IN :P9014_PARAMETRO; ',
'        exception ',
'            when others then',
'                l_log_2 := true;',
'    end;',
'    if l_log_2 then    ',
'        return ''true'';',
'    else',
'        return ''false'';',
'    end if;',
'end;'))
,p_attribute_07=>'P9014_CODIGO_ARTEFATO,P9014_PARAMETRO'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(168030275957913536)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Post'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_messages pkg_mensagem.message_record_table;',
'    l_pagina varchar2(256) := nvl(:P9014_CODIGO_ARTEFATO,325);',
'BEGIN',
'    v_messages := pkg_mensagem.message_record_table();',
'    EXECUTE IMMEDIATE',
'        ''BEGIN UI_MPD_''|| l_pagina ||''.post''||',
'        ''(p_id => :P9014_ITENS_SELECIONADOS, p_sucesso => :P9014_SUCESSO, p_messages => :v_messages); END;''',
'        USING in :P9014_ITENS_SELECIONADOS, OUT :P9014_SUCESSO, OUT v_messages;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P9014_REALIZA_POST'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'1'
,p_process_success_message=>'&P9014_SUCESSO.'
,p_internal_uid=>62765569944414426
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(168036854906913556)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'DoneC'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>62772148893414446
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(168031040929913539)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'retorna_titulo_help'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'RETORNA_TITULO_TELA'
,p_internal_uid=>62766334916414429
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(168031509277913540)
,p_page_process_id=>wwv_flow_imp.id(168031040929913539)
,p_page_id=>9014
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'nvl(:P9014_CODIGO_ARTEFATO,:APP_PAGE_ID)'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(168032052406913542)
,p_page_process_id=>wwv_flow_imp.id(168031040929913539)
,p_page_id=>9014
,p_name=>'p_titulo'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P9014_TELA_TITULO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(168032510092913543)
,p_page_process_id=>wwv_flow_imp.id(168031040929913539)
,p_page_id=>9014
,p_name=>'p_help'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P9014_TELA_HELP'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(168032911415913544)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'url_wizard'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'URL_WIZARD'
,p_process_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    1',
'from srv_artefato_wizard a',
'join srv_artefato_versionado b on b.id = a.id_artefato_versionado',
'join srv_artefato c on c.id = b.id_artefato',
'join srv_artefato_versionado b1 on b1.id = a.id_artefato_versionado_base',
'join srv_artefato c1 on c1.id = b1.id_artefato',
'where c.codigo_artefato = nvl( apex_util.get_session_state(''P''||:APP_PAGE_ID||''_CODIGO_WIZARD''),:p0_codigo_artefato)'))
,p_process_when_type=>'EXISTS'
,p_internal_uid=>62768205402414434
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(168033428838913546)
,p_page_process_id=>wwv_flow_imp.id(168032911415913544)
,p_page_id=>9014
,p_name=>'p_codigo_artefato_base'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>20
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'case when :P9014_CODIGO_WIZARD is null then :P9014_CODIGO_ARTEFATO else :P9014_CODIGO_WIZARD end'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(168033925643913548)
,p_page_process_id=>wwv_flow_imp.id(168032911415913544)
,p_page_id=>9014
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P9014_CODIGO_ARTEFATO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(168034493061913549)
,p_page_process_id=>wwv_flow_imp.id(168032911415913544)
,p_page_id=>9014
,p_name=>'p_url_anterior'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P9014_URL_ANTERIOR'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(168034965831913551)
,p_page_process_id=>wwv_flow_imp.id(168032911415913544)
,p_page_id=>9014
,p_name=>'p_url_proximo'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>40
,p_value_type=>'ITEM'
,p_value=>'P9014_URL_PROXIMO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(168035450057913552)
,p_page_process_id=>wwv_flow_imp.id(168032911415913544)
,p_page_id=>9014
,p_name=>'p_param1'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>50
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'nvl(:P9014_ID,:P9014_PARAMETRO)'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(168035925156913554)
,p_page_process_id=>wwv_flow_imp.id(168032911415913544)
,p_page_id=>9014
,p_name=>'p_param2'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>60
,p_value_type=>'ITEM'
,p_value=>'P9014_ITENS_SELECIONADOS'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(168036500029913555)
,p_page_process_id=>wwv_flow_imp.id(168032911415913544)
,p_page_id=>9014
,p_name=>'p_etapa'
,p_direction=>'OUT'
,p_data_type=>'NUMBER'
,p_ignore_output=>false
,p_display_sequence=>70
,p_value_type=>'ITEM'
,p_value=>'P9014_ETAPA'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(168030659016913537)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'enviarParamentros'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    prc_enviar_parametros(',
'        apex_application.g_x01,',
'        apex_application.g_x02,',
'        apex_application.g_x03,',
'        apex_application.g_x04',
'    );',
'    if apex_application.g_x01 is not null then',
'        if upper(apex_application.g_x02) = upper(''id_tenant'') and :P9013_ID is null then',
'            :P0_TENANT_INFORMADO := apex_application.g_x03;',
'        end if;',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>62765953003414427
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(168029898535913535)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'atribuiValorAJAX'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_json CLOB;',
'BEGIN',
'    l_json := pkg_formulario_dinamico.executa_sql_parametrizado(',
'        p_param1 => apex_application.g_x01,',
'        p_sql    => apex_application.g_x02',
'    );',
'    htp.p(l_json); -- resposta para o JavaScript',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>62765192522414425
);
wwv_flow_imp.component_end;
end;
/
