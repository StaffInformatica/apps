prompt --application/pages/page_09004
begin
--   Manifest
--     PAGE: 09004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>9004
,p_name=>'Zoom Generico'
,p_alias=>'ZOOM-GENERICO1'
,p_page_mode=>'MODAL'
,p_step_title=>'Zoom Generico'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'tituloTela($v("P9004_TITULO_CONSULTA")+'' (''+$v("P9004_CODIGO_ARTEFATO")+'')'');',
'',
'$("#btnCadastro").appendTo(".a-Toolbar-groupContainer.a-Toolbar-groupContainer--end" );',
'',
'$(document).on("click", "#report_table_GRID tr", function () {',
'    $(this).addClass("selected").siblings().removeClass("selected");',
'',
'    var id = $(this).find("span[data-id]").data("id");',
'    $s("P9004_SELECTED_ITEM_ID", id);',
'',
'    var text = $(this).find("td[headers=''COLUNA1'']").text();',
'    $s("P9004_SELECTED_ITEM_TEXT", text);',
'});'))
,p_step_template=>wwv_flow_imp.id(340974912275556190)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_height=>'885'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'24'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(111128090151218220)
,p_plug_name=>'Filtro'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>100
,p_location=>null
,p_plug_source_type=>'NATIVE_SMART_FILTERS'
,p_filtered_region_id=>wwv_flow_imp.id(571119776611695517)
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P9004_NOME_COLUNA1 is not null or',
':P9004_NOME_COLUNA2 is not null or',
':P9004_NOME_COLUNA3 is not null or',
':P9004_NOME_COLUNA4 is not null or',
':P9004_NOME_COLUNA5 is not null or',
':P9004_NOME_COLUNA6 is not null or',
':P9004_NOME_COLUNA7 is not null or',
':P9004_NOME_COLUNA8 is not null or',
':P9004_NOME_COLUNA9 is not null or',
':P9004_NOME_COLUNA10 is not null'))
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'compact_numbers_threshold', '10000',
  'more_filters_suggestion_chip', 'N',
  'show_total_row_count', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(570687090836968393)
,p_plug_name=>'Rodape'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(341013639389556225)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_03'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(557372259270856430)
,p_plug_name=>'Centralizado'
,p_parent_plug_id=>wwv_flow_imp.id(570687090836968393)
,p_region_css_classes=>'u-textCenter'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(341010888912556224)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(571119776611695517)
,p_name=>'Lista'
,p_region_name=>'GRID'
,p_template=>wwv_flow_imp.id(341044399187556241)
,p_display_sequence=>130
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'begin',
'    l_sql := nvl(:P9004_SQL_CONSULTA, ''select 0 as ID, null as COLUNA1, null as COLUNA2, null as COLUNA3, null as COLUNA4, null as COLUNA5, null as COLUNA6, null as COLUNA7, null as COLUNA8, null as COLUNA9, null as COLUNA10, null FILTRO1 , null FILT'
||'RO2, null FILTRO3 from DUAL'');',
'',
'    if :P9004_FILTRAR = 1 or :P9004_SEARCH is not null or :P9004_FILTRO1 is not null or :P9004_FILTRO2 is not null or :P9004_FILTRO3 is not null  then',
'        l_sql := replace(l_sql,''#ABRIR_VAZIO#'','' where 1 = 1 '');',
'    else',
'        l_sql := replace(l_sql,''#ABRIR_VAZIO#'','' where 0 = 1 '');',
'    end if;',
'',
'    l_sql := replace(l_sql,''#WHERE#'',nvl(:P9004_WHERE_DINAMICO,''''));',
'    ',
'    return l_sql;',
'end;'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P9004_SQL_CONSULTA,P9004_FILTRAR,P9004_WHERE_DINAMICO'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(341097593039556273)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>unistr('N\00E3o h\00E1 registros')
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(19973134252254846)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(19973497120254848)
,p_query_column_id=>2
,p_column_alias=>'COLUNA1'
,p_column_display_sequence=>20
,p_column_heading=>'&P9004_NOME_COLUNA1.'
,p_column_html_expression=>'<span data-id="#ID#">#COLUNA1#</span>'
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P9004_NOME_COLUNA1'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(19973907946254849)
,p_query_column_id=>3
,p_column_alias=>'COLUNA2'
,p_column_display_sequence=>30
,p_column_heading=>'&P9004_NOME_COLUNA2.'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P9004_NOME_COLUNA2'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(19974311381254851)
,p_query_column_id=>4
,p_column_alias=>'COLUNA3'
,p_column_display_sequence=>40
,p_column_heading=>'&P9004_NOME_COLUNA3.'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P9004_NOME_COLUNA3'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(19974644871254853)
,p_query_column_id=>5
,p_column_alias=>'COLUNA4'
,p_column_display_sequence=>50
,p_column_heading=>'&P9004_NOME_COLUNA4.'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P9004_NOME_COLUNA4'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(19975126846254853)
,p_query_column_id=>6
,p_column_alias=>'COLUNA5'
,p_column_display_sequence=>60
,p_column_heading=>'&P9004_NOME_COLUNA5.'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P9004_NOME_COLUNA5'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(19975430533254854)
,p_query_column_id=>7
,p_column_alias=>'COLUNA6'
,p_column_display_sequence=>70
,p_column_heading=>'&P9004_NOME_COLUNA6.'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P9004_NOME_COLUNA6'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(19970389104254838)
,p_query_column_id=>8
,p_column_alias=>'COLUNA7'
,p_column_display_sequence=>80
,p_column_heading=>'&P9004_NOME_COLUNA7.'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P9004_NOME_COLUNA7'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(19970728355254840)
,p_query_column_id=>9
,p_column_alias=>'COLUNA8'
,p_column_display_sequence=>90
,p_column_heading=>'&P9004_NOME_COLUNA8.'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P9004_NOME_COLUNA8'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(19971191741254841)
,p_query_column_id=>10
,p_column_alias=>'COLUNA9'
,p_column_display_sequence=>100
,p_column_heading=>'&P9004_NOME_COLUNA9.'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P9004_NOME_COLUNA9'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(19971535892254842)
,p_query_column_id=>11
,p_column_alias=>'COLUNA10'
,p_column_display_sequence=>110
,p_column_heading=>'&P9004_NOME_COLUNA10.'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P9004_NOME_COLUNA10'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(19971988012254843)
,p_query_column_id=>12
,p_column_alias=>'FILTRO1'
,p_column_display_sequence=>120
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(19972361323254844)
,p_query_column_id=>13
,p_column_alias=>'FILTRO2'
,p_column_display_sequence=>130
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(19972820424254845)
,p_query_column_id=>14
,p_column_alias=>'FILTRO3'
,p_column_display_sequence=>140
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(19978282222254868)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(557372259270856430)
,p_button_name=>'SELECIONAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(341144157120556305)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Selecionar'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(19969712055254833)
,p_button_sequence=>110
,p_button_name=>'btn_cadastro_1'
,p_button_static_id=>'BTN_CADASTRO'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341144157120556305)
,p_button_image_alt=>'Acessar cadastro'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
,p_grid_column_span=>2
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(19969292210254832)
,p_button_sequence=>120
,p_button_name=>'Filtrar'
,p_button_static_id=>'BTN_FILTRAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341144157120556305)
,p_button_image_alt=>'Exibir todos'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-search'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>2
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73381110545413377)
,p_name=>'P9004_CODIGO_ARTEFATO_BASE'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73381251943413378)
,p_name=>'P9004_WHERE_DINAMICO'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73381576723413381)
,p_name=>'P9004_CAMPO'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(111142969184218294)
,p_name=>'P9004_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(111128090151218220)
,p_prompt=>'Search'
,p_source=>'COLUNA1,COLUNA2,COLUNA3'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'collapsed_search_field', 'N',
  'search_type', 'ROW')).to_clob
,p_fc_show_chart=>false
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(111148119001218325)
,p_name=>'P9004_TITULO_CONSULTA'
,p_item_sequence=>300
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(114621855810238194)
,p_name=>'P9004_FILTRO1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(111128090151218220)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_valor clob;',
'    l_pagina varchar2(256) := nvl(:P9004_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_valor := UI_MPD_''||l_pagina||''.valor_filtro(''''F1''''); END;''',
'        USING OUT l_valor;',
'    ',
'    return l_valor;       ',
'',
'    exception',
'        when others then',
'            return null;',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'&P9004_NOME_FILTRO1.'
,p_source=>'FILTRO1'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9004_CODIGO_ARTEFATO,''TD782'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''F1''''); END;''',
'        USING OUT l_sql;',
'',
'    if l_sql is null then',
'        l_sql := ''select null d, null r from dual'';',
'    end if;',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9004_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''F1''''); END;''',
'        USING OUT l_true;',
'',
'    return l_true;       ',
'    ',
'    exception',
'        when others then ',
'            return false;',
'',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>false
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(114621937020238195)
,p_name=>'P9004_FILTRO2'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(111128090151218220)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_valor clob;',
'    l_pagina varchar2(256) := nvl(:P9004_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_valor := UI_MPD_''||l_pagina||''.valor_filtro(''''F2''''); END;''',
'        USING OUT l_valor;',
'    ',
'    return l_valor;       ',
'',
'    exception',
'        when others then',
'            return null;',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'&P9004_NOME_FILTRO2.'
,p_source=>'FILTRO2'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9004_CODIGO_ARTEFATO,''TD782'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''F2''''); END;''',
'        USING OUT l_sql;',
'',
'    if l_sql is null then',
'        l_sql := ''select null d, null r from dual'';',
'    end if;',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9004_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''F2''''); END;''',
'        USING OUT l_true;',
'',
'    return l_true;       ',
'',
'    exception',
'        when others then ',
'            return false;    ',
'            ',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>false
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(114622072799238196)
,p_name=>'P9004_FILTRO3'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(111128090151218220)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_valor clob;',
'    l_pagina varchar2(256) := nvl(:P9004_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_valor := UI_MPD_''||l_pagina||''.valor_filtro(''''F3''''); END;''',
'        USING OUT l_valor;',
'    ',
'    return l_valor;       ',
'',
'    exception',
'        when others then',
'            return null;',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'&P9004_NOME_FILTRO3.'
,p_source=>'FILTRO3'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9004_CODIGO_ARTEFATO,''TD782'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''F3''''); END;''',
'        USING OUT l_sql;',
'',
'    if l_sql is null then',
'        l_sql := ''select null d, null r from dual'';',
'    end if;',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9004_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''F3''''); END;''',
'        USING OUT l_true;',
'',
'    return l_true;       ',
'',
'    exception',
'        when others then ',
'            return false;    ',
'            ',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>false
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(114626623877238221)
,p_name=>'P9004_SELECTED_ITEM_TEXT'
,p_item_sequence=>160
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(114627202883238226)
,p_name=>'P9004_NOME_FILTRO1'
,p_item_sequence=>270
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9004_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''F1''''); END;''',
'        USING OUT l_sql;',
'    ',
'    return l_sql;       ',
'',
'    exception',
'        when others then',
'            return null;',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(114627360224238228)
,p_name=>'P9004_NOME_FILTRO2'
,p_item_sequence=>280
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9004_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''F2''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'    ',
'    exception',
'        when others then',
'            return null;    ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(114627447998238229)
,p_name=>'P9004_NOME_FILTRO3'
,p_item_sequence=>290
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9004_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''F3''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'    ',
'    exception',
'        when others then',
'            return null;    ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(115170336439368589)
,p_name=>'P9004_URL_CADASTRO'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(115171387634368599)
,p_name=>'P9004_FILTRAR'
,p_item_sequence=>320
,p_item_default=>'0'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(115174096213368626)
,p_name=>'P9004_TITULO_CADASTRO'
,p_item_sequence=>310
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(488923584074651107)
,p_name=>'P9004_CODIGO_ARTEFATO'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(488923798410651109)
,p_name=>'P9004_SQL_CONSULTA'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(488923897375651110)
,p_name=>'P9004_RESULTADO'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(488924040027651111)
,p_name=>'P9004_RESULTADO_MENSAGEM'
,p_item_sequence=>90
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(557414857157856709)
,p_name=>'P9004_NOME_ZOOM'
,p_item_sequence=>140
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(571224616624982182)
,p_name=>'P9004_SELECTED_ITEM_ID'
,p_item_sequence=>150
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(571226728599982203)
,p_name=>'P9004_NOME_COLUNA1'
,p_item_sequence=>170
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(571226820571982204)
,p_name=>'P9004_NOME_COLUNA2'
,p_item_sequence=>180
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(571227091216982206)
,p_name=>'P9004_NOME_COLUNA3'
,p_item_sequence=>190
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(571227185166982207)
,p_name=>'P9004_NOME_COLUNA4'
,p_item_sequence=>200
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(571227273713982208)
,p_name=>'P9004_NOME_COLUNA5'
,p_item_sequence=>210
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(571227308141982209)
,p_name=>'P9004_NOME_COLUNA6'
,p_item_sequence=>220
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(571227407189982210)
,p_name=>'P9004_NOME_COLUNA7'
,p_item_sequence=>230
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(571227548536982211)
,p_name=>'P9004_NOME_COLUNA8'
,p_item_sequence=>240
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(571227696568982212)
,p_name=>'P9004_NOME_COLUNA9'
,p_item_sequence=>250
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(571227747006982213)
,p_name=>'P9004_NOME_COLUNA10'
,p_item_sequence=>260
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(19987125714254915)
,p_computation_sequence=>10
,p_computation_item=>'P9004_WHERE_DINAMICO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_where clob;',
'    l_pagina varchar2(256) := nvl(:P9004_CODIGO_ARTEFATO_BASE,100);',
'begin',
'    begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_where := UI_MPD_''||l_pagina||''.where_dinamico(''||aspas(:P9004_CAMPO)||''); END;''',
'        USING OUT l_where;',
'    exception',
'        when others then',
'            return '''';       ',
'',
'    end;',
'    return l_where;       ',
'end;',
''))
,p_compute_when=>'P9004_CODIGO_ARTEFATO_BASE'
,p_compute_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19997724199254949)
,p_name=>'onDoubleClickLista'
,p_event_sequence=>60
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(571119776611695517)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'dblclick'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19998182762254950)
,p_event_id=>wwv_flow_imp.id(19997724199254949)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
,p_attribute_01=>'P9004_SELECTED_ITEM_ID,P9004_SELECTED_ITEM_TEXT'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19998607618254951)
,p_name=>'onClickPesquisar'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(19969292210254832)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20000057175254954)
,p_event_id=>wwv_flow_imp.id(19998607618254951)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9004_SEARCH'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19999603352254953)
,p_event_id=>wwv_flow_imp.id(19998607618254951)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9004_FILTRAR'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19999039891254952)
,p_event_id=>wwv_flow_imp.id(19998607618254951)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(571119776611695517)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(20000445110254955)
,p_name=>'onClickBTN_CADASTRO'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(19969712055254833)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20001005134254957)
,p_event_id=>wwv_flow_imp.id(20000445110254955)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'pagina_modal( apex.item("P9004_TITULO_CADASTRO").getValue(), apex.item("P9004_URL_CADASTRO").getValue(),''#BTN_CADASTRO'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19996892818254944)
,p_name=>'onClosedBTN_CADASTRO'
,p_event_sequence=>90
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#BTN_CADASTRO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19997281199254947)
,p_event_id=>wwv_flow_imp.id(19996892818254944)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(571119776611695517)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(20001339181254958)
,p_name=>'onAfterRefresh'
,p_event_sequence=>100
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(571119776611695517)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20001848013254960)
,p_event_id=>wwv_flow_imp.id(20001339181254958)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let noData = document.querySelector(".t-IRR-region .nodatafound"); ',
'',
'if (noData) {',
unistr('  // quando n\00E3o h\00E1 registros \2192 mostra'),
'    apex.item("BTN_FILTRAR").show();',
'} else {',
unistr('  // quando h\00E1 registros \2192 esconde'),
'    apex.item("BTN_FILTRAR").hide();',
'}'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(19995298752254939)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_01=>'P9004_SELECTED_ITEM_ID,P9004_SELECTED_ITEM_TEXT'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(19978282222254868)
,p_internal_uid=>62866170412897212
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(19995677536254941)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Seta Query'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--:P9004_QUERY := ''select * from ''||:P9004_BO||''.buscar_registros_zoom(:P9004_TABLE_NAME)'';',
':P9004_QUERY := ''select * from PK_UI_TESTE.buscar_registros_zoom(p_table_name => :P9004_TABLE_NAME)'';'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>62866549196897214
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(19996070741254942)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Limpa Filtros'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_region_id apex_application_page_regions.region_id%type;',
'begin',
'',
'   select aapr.region_id',
'     into l_region_id',
'     from apex_application_page_regions aapr',
'    where aapr.application_id = :app_id',
'      and aapr.page_id = :app_page_id',
'      and aapr.static_id = ''GRID'';          ',
'    ',
'    apex_ig.reset_report(',
'        p_page_id   => :app_page_id,',
'        p_region_id => l_region_id,',
'        p_report_id => null);',
'        ',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>62866942401897215
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(19987367833254916)
,p_process_sequence=>40
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'retorna_zoom_dinamico'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'RETORNA_ZOOM_DINAMICO'
,p_process_error_message=>'&P9004_RESULTADO_MENSAGEM.'
,p_process_when=>'P9004_CODIGO_ARTEFATO'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_process_success_message=>'&P9004_RESULTADO_MENSAGEM.'
,p_internal_uid=>62858239493897189
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19987864008254918)
,p_page_process_id=>wwv_flow_imp.id(19987367833254916)
,p_page_id=>9004
,p_name=>'p_sql_consulta'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P9004_SQL_CONSULTA'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19988335476254919)
,p_page_process_id=>wwv_flow_imp.id(19987367833254916)
,p_page_id=>9004
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P9004_CODIGO_ARTEFATO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19988867754254921)
,p_page_process_id=>wwv_flow_imp.id(19987367833254916)
,p_page_id=>9004
,p_name=>'p_label1'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>50
,p_value_type=>'ITEM'
,p_value=>'P9004_NOME_COLUNA1'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19989340233254922)
,p_page_process_id=>wwv_flow_imp.id(19987367833254916)
,p_page_id=>9004
,p_name=>'p_label2'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>60
,p_value_type=>'ITEM'
,p_value=>'P9004_NOME_COLUNA2'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19989863221254923)
,p_page_process_id=>wwv_flow_imp.id(19987367833254916)
,p_page_id=>9004
,p_name=>'p_label3'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>70
,p_value_type=>'ITEM'
,p_value=>'P9004_NOME_COLUNA3'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19990338200254924)
,p_page_process_id=>wwv_flow_imp.id(19987367833254916)
,p_page_id=>9004
,p_name=>'p_label4'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>80
,p_value_type=>'ITEM'
,p_value=>'P9004_NOME_COLUNA4'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19990869400254925)
,p_page_process_id=>wwv_flow_imp.id(19987367833254916)
,p_page_id=>9004
,p_name=>'p_label5'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>90
,p_value_type=>'ITEM'
,p_value=>'P9004_NOME_COLUNA5'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19991385967254926)
,p_page_process_id=>wwv_flow_imp.id(19987367833254916)
,p_page_id=>9004
,p_name=>'p_label6'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>100
,p_value_type=>'ITEM'
,p_value=>'P9004_NOME_COLUNA6'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19991888274254927)
,p_page_process_id=>wwv_flow_imp.id(19987367833254916)
,p_page_id=>9004
,p_name=>'p_label7'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>110
,p_value_type=>'ITEM'
,p_value=>'P9004_NOME_COLUNA7'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19992381675254929)
,p_page_process_id=>wwv_flow_imp.id(19987367833254916)
,p_page_id=>9004
,p_name=>'p_label8'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>120
,p_value_type=>'ITEM'
,p_value=>'P9004_NOME_COLUNA8'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19992878702254931)
,p_page_process_id=>wwv_flow_imp.id(19987367833254916)
,p_page_id=>9004
,p_name=>'p_label9'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>130
,p_value_type=>'ITEM'
,p_value=>'P9004_NOME_COLUNA9'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19993415383254932)
,p_page_process_id=>wwv_flow_imp.id(19987367833254916)
,p_page_id=>9004
,p_name=>'p_label10'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>140
,p_value_type=>'ITEM'
,p_value=>'P9004_NOME_COLUNA10'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19993880435254935)
,p_page_process_id=>wwv_flow_imp.id(19987367833254916)
,p_page_id=>9004
,p_name=>'p_url'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>150
,p_value_type=>'ITEM'
,p_value=>'P9004_URL_CADASTRO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19994395448254936)
,p_page_process_id=>wwv_flow_imp.id(19987367833254916)
,p_page_id=>9004
,p_name=>'p_titulo_consulta'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>160
,p_value_type=>'ITEM'
,p_value=>'P9004_TITULO_CONSULTA'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19994841957254938)
,p_page_process_id=>wwv_flow_imp.id(19987367833254916)
,p_page_id=>9004
,p_name=>'p_titulo_cadastro'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>170
,p_value_type=>'ITEM'
,p_value=>'P9004_TITULO_CADASTRO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(19996441117254942)
,p_process_sequence=>50
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Limapa cache da Lista'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_region_id NUMBER;',
'BEGIN',
'    SELECT region_id',
'      INTO l_region_id',
'      FROM apex_application_page_regions',
'     WHERE application_id = :APP_ID',
'       AND page_id        = 9004',
'       AND static_id      = ''GRID'';',
'',
'    APEX_REGION.RESET (',
'        p_application_id => :APP_ID,',
'        p_page_id        => 9004,',
'        p_region_id      => l_region_id',
'    );',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>62867312777897215
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('Limpa o cache da lista em rela\00E7\00E3o a defini\00E7\00E3o da ordena\00E7\00E3o das colunas'),
''))
);
wwv_flow_imp.component_end;
end;
/
