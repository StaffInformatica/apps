prompt --application/pages/page_09004
begin
--   Manifest
--     PAGE: 09004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_page.create_page(
 p_id=>9004
,p_name=>'Zoom Generico'
,p_alias=>'ZOOM-GENERICO1'
,p_page_mode=>'MODAL'
,p_step_title=>'Zoom Generico'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'tituloTela($v("P9004_TITULO_CONSULTA")+'' (''+$v("P9004_CODIGO_ARTEFATO")+'')'');',
'',
'$("#btnCadastro").appendTo(".a-Toolbar-groupContainer.a-Toolbar-groupContainer--end" );',
'',
'$(document).on("click", "#report_table_GRID tr", function () {',
'    $(this).addClass("selected").siblings().removeClass("selected");',
'',
'    var id = $(this).find("span[data-id]").data("id");',
'    $s("P9004_SELECTED_ITEM_ID", id);',
'',
'    var text = $(this).find("td[headers=''COLUNA1'']").text();',
'    $s("P9004_SELECTED_ITEM_TEXT", text);',
'});'))
,p_step_template=>wwv_flow_imp.id(489110489949697573)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_height=>'885'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'24'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(259263667825359603)
,p_plug_name=>'Filtro'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>100
,p_location=>null
,p_plug_source_type=>'NATIVE_SMART_FILTERS'
,p_filtered_region_id=>wwv_flow_imp.id(719255354285836900)
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P9004_NOME_COLUNA1 is not null or',
':P9004_NOME_COLUNA2 is not null or',
':P9004_NOME_COLUNA3 is not null or',
':P9004_NOME_COLUNA4 is not null or',
':P9004_NOME_COLUNA5 is not null or',
':P9004_NOME_COLUNA6 is not null or',
':P9004_NOME_COLUNA7 is not null or',
':P9004_NOME_COLUNA8 is not null or',
':P9004_NOME_COLUNA9 is not null or',
':P9004_NOME_COLUNA10 is not null'))
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'compact_numbers_threshold', '10000',
  'more_filters_suggestion_chip', 'N',
  'show_total_row_count', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(718822668511109776)
,p_plug_name=>'Rodape'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(489149217063697608)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_03'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(705507836944997813)
,p_plug_name=>'Centralizado'
,p_parent_plug_id=>wwv_flow_imp.id(718822668511109776)
,p_region_css_classes=>'u-textCenter'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(489146466586697607)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(719255354285836900)
,p_name=>'Lista'
,p_region_name=>'GRID'
,p_template=>wwv_flow_imp.id(489179976861697624)
,p_display_sequence=>130
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'begin',
'    l_sql := nvl(:P9004_SQL_CONSULTA, ''select 0 as ID, null as COLUNA1, null as COLUNA2, null as COLUNA3, null as COLUNA4, null as COLUNA5, null as COLUNA6, null as COLUNA7, null as COLUNA8, null as COLUNA9, null as COLUNA10, null FILTRO1 , null FILT'
||'RO2, null FILTRO3 from DUAL'');',
'',
'    if :P9004_FILTRAR = 1 or :P9004_SEARCH is not null or :P9004_FILTRO1 is not null or :P9004_FILTRO2 is not null or :P9004_FILTRO3 is not null  then',
'        l_sql := replace(l_sql,''#ABRIR_VAZIO#'','' where 1 = 1 '');',
'    else',
'        l_sql := replace(l_sql,''#ABRIR_VAZIO#'','' where 0 = 1 '');',
'    end if;',
'',
'    l_sql := replace(l_sql,''#WHERE#'',nvl(:P9004_WHERE_DINAMICO,''''));',
'    ',
'    return l_sql;',
'end;'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P9004_SQL_CONSULTA,P9004_FILTRAR,P9004_WHERE_DINAMICO'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(489233170713697656)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>unistr('N\00E3o h\00E1 registros')
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(168108711926396229)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(168109074794396231)
,p_query_column_id=>2
,p_column_alias=>'COLUNA1'
,p_column_display_sequence=>20
,p_column_heading=>'&P9004_NOME_COLUNA1.'
,p_column_html_expression=>'<span data-id="#ID#">#COLUNA1#</span>'
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P9004_NOME_COLUNA1'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(168109485620396232)
,p_query_column_id=>3
,p_column_alias=>'COLUNA2'
,p_column_display_sequence=>30
,p_column_heading=>'&P9004_NOME_COLUNA2.'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P9004_NOME_COLUNA2'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(168109889055396234)
,p_query_column_id=>4
,p_column_alias=>'COLUNA3'
,p_column_display_sequence=>40
,p_column_heading=>'&P9004_NOME_COLUNA3.'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P9004_NOME_COLUNA3'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(168110222545396236)
,p_query_column_id=>5
,p_column_alias=>'COLUNA4'
,p_column_display_sequence=>50
,p_column_heading=>'&P9004_NOME_COLUNA4.'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P9004_NOME_COLUNA4'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(168110704520396236)
,p_query_column_id=>6
,p_column_alias=>'COLUNA5'
,p_column_display_sequence=>60
,p_column_heading=>'&P9004_NOME_COLUNA5.'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P9004_NOME_COLUNA5'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(168111008207396237)
,p_query_column_id=>7
,p_column_alias=>'COLUNA6'
,p_column_display_sequence=>70
,p_column_heading=>'&P9004_NOME_COLUNA6.'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P9004_NOME_COLUNA6'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(168105966778396221)
,p_query_column_id=>8
,p_column_alias=>'COLUNA7'
,p_column_display_sequence=>80
,p_column_heading=>'&P9004_NOME_COLUNA7.'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P9004_NOME_COLUNA7'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(168106306029396223)
,p_query_column_id=>9
,p_column_alias=>'COLUNA8'
,p_column_display_sequence=>90
,p_column_heading=>'&P9004_NOME_COLUNA8.'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P9004_NOME_COLUNA8'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(168106769415396224)
,p_query_column_id=>10
,p_column_alias=>'COLUNA9'
,p_column_display_sequence=>100
,p_column_heading=>'&P9004_NOME_COLUNA9.'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P9004_NOME_COLUNA9'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(168107113566396225)
,p_query_column_id=>11
,p_column_alias=>'COLUNA10'
,p_column_display_sequence=>110
,p_column_heading=>'&P9004_NOME_COLUNA10.'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P9004_NOME_COLUNA10'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(168107565686396226)
,p_query_column_id=>12
,p_column_alias=>'FILTRO1'
,p_column_display_sequence=>120
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(168107938997396227)
,p_query_column_id=>13
,p_column_alias=>'FILTRO2'
,p_column_display_sequence=>130
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(168108398098396228)
,p_query_column_id=>14
,p_column_alias=>'FILTRO3'
,p_column_display_sequence=>140
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(168113859896396251)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(705507836944997813)
,p_button_name=>'SELECIONAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(489279734794697688)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Selecionar'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(168105289729396216)
,p_button_sequence=>110
,p_button_name=>'btn_cadastro_1'
,p_button_static_id=>'BTN_CADASTRO'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(489279734794697688)
,p_button_image_alt=>'Acessar cadastro'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
,p_grid_column_span=>2
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(168104869884396215)
,p_button_sequence=>120
,p_button_name=>'Filtrar'
,p_button_static_id=>'BTN_FILTRAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(489279734794697688)
,p_button_image_alt=>'Exibir todos'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-search'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>2
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(221516688219554760)
,p_name=>'P9004_CODIGO_ARTEFATO_BASE'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(221516829617554761)
,p_name=>'P9004_WHERE_DINAMICO'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(221517154397554764)
,p_name=>'P9004_CAMPO'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(259278546858359677)
,p_name=>'P9004_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(259263667825359603)
,p_prompt=>'Search'
,p_source=>'COLUNA1,COLUNA2,COLUNA3'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'collapsed_search_field', 'N',
  'search_type', 'ROW')).to_clob
,p_fc_show_chart=>false
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(259283696675359708)
,p_name=>'P9004_TITULO_CONSULTA'
,p_item_sequence=>300
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(262757433484379577)
,p_name=>'P9004_FILTRO1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(259263667825359603)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_valor clob;',
'    l_pagina varchar2(256) := nvl(:P9004_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_valor := UI_MPD_''||l_pagina||''.valor_filtro(''''F1''''); END;''',
'        USING OUT l_valor;',
'    ',
'    return l_valor;       ',
'',
'    exception',
'        when others then',
'            return null;',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'&P9004_NOME_FILTRO1.'
,p_source=>'FILTRO1'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9004_CODIGO_ARTEFATO,''TD782'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''F1''''); END;''',
'        USING OUT l_sql;',
'',
'    if l_sql is null then',
'        l_sql := ''select null d, null r from dual'';',
'    end if;',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9004_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''F1''''); END;''',
'        USING OUT l_true;',
'',
'    return l_true;       ',
'    ',
'    exception',
'        when others then ',
'            return false;',
'',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>false
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(262757514694379578)
,p_name=>'P9004_FILTRO2'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(259263667825359603)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_valor clob;',
'    l_pagina varchar2(256) := nvl(:P9004_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_valor := UI_MPD_''||l_pagina||''.valor_filtro(''''F2''''); END;''',
'        USING OUT l_valor;',
'    ',
'    return l_valor;       ',
'',
'    exception',
'        when others then',
'            return null;',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'&P9004_NOME_FILTRO2.'
,p_source=>'FILTRO2'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9004_CODIGO_ARTEFATO,''TD782'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''F2''''); END;''',
'        USING OUT l_sql;',
'',
'    if l_sql is null then',
'        l_sql := ''select null d, null r from dual'';',
'    end if;',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9004_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''F2''''); END;''',
'        USING OUT l_true;',
'',
'    return l_true;       ',
'',
'    exception',
'        when others then ',
'            return false;    ',
'            ',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>false
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(262757650473379579)
,p_name=>'P9004_FILTRO3'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(259263667825359603)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_valor clob;',
'    l_pagina varchar2(256) := nvl(:P9004_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_valor := UI_MPD_''||l_pagina||''.valor_filtro(''''F3''''); END;''',
'        USING OUT l_valor;',
'    ',
'    return l_valor;       ',
'',
'    exception',
'        when others then',
'            return null;',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'&P9004_NOME_FILTRO3.'
,p_source=>'FILTRO3'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9004_CODIGO_ARTEFATO,''TD782'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(''''F3''''); END;''',
'        USING OUT l_sql;',
'',
'    if l_sql is null then',
'        l_sql := ''select null d, null r from dual'';',
'    end if;',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9004_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(''''F3''''); END;''',
'        USING OUT l_true;',
'',
'    return l_true;       ',
'',
'    exception',
'        when others then ',
'            return false;    ',
'            ',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>false
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(262762201551379604)
,p_name=>'P9004_SELECTED_ITEM_TEXT'
,p_item_sequence=>160
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(262762780557379609)
,p_name=>'P9004_NOME_FILTRO1'
,p_item_sequence=>270
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9004_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''F1''''); END;''',
'        USING OUT l_sql;',
'    ',
'    return l_sql;       ',
'',
'    exception',
'        when others then',
'            return null;',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(262762937898379611)
,p_name=>'P9004_NOME_FILTRO2'
,p_item_sequence=>280
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9004_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''F2''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'    ',
'    exception',
'        when others then',
'            return null;    ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(262763025672379612)
,p_name=>'P9004_NOME_FILTRO3'
,p_item_sequence=>290
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9004_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(''''F3''''); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'    ',
'    exception',
'        when others then',
'            return null;    ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(263305914113509972)
,p_name=>'P9004_URL_CADASTRO'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(263306965308509982)
,p_name=>'P9004_FILTRAR'
,p_item_sequence=>320
,p_item_default=>'0'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(263309673887510009)
,p_name=>'P9004_TITULO_CADASTRO'
,p_item_sequence=>310
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(637059161748792490)
,p_name=>'P9004_CODIGO_ARTEFATO'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(637059376084792492)
,p_name=>'P9004_SQL_CONSULTA'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(637059475049792493)
,p_name=>'P9004_RESULTADO'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(637059617701792494)
,p_name=>'P9004_RESULTADO_MENSAGEM'
,p_item_sequence=>90
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(705550434831998092)
,p_name=>'P9004_NOME_ZOOM'
,p_item_sequence=>140
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(719360194299123565)
,p_name=>'P9004_SELECTED_ITEM_ID'
,p_item_sequence=>150
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(719362306274123586)
,p_name=>'P9004_NOME_COLUNA1'
,p_item_sequence=>170
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(719362398246123587)
,p_name=>'P9004_NOME_COLUNA2'
,p_item_sequence=>180
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(719362668891123589)
,p_name=>'P9004_NOME_COLUNA3'
,p_item_sequence=>190
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(719362762841123590)
,p_name=>'P9004_NOME_COLUNA4'
,p_item_sequence=>200
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(719362851388123591)
,p_name=>'P9004_NOME_COLUNA5'
,p_item_sequence=>210
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(719362885816123592)
,p_name=>'P9004_NOME_COLUNA6'
,p_item_sequence=>220
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(719362984864123593)
,p_name=>'P9004_NOME_COLUNA7'
,p_item_sequence=>230
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(719363126211123594)
,p_name=>'P9004_NOME_COLUNA8'
,p_item_sequence=>240
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(719363274243123595)
,p_name=>'P9004_NOME_COLUNA9'
,p_item_sequence=>250
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(719363324681123596)
,p_name=>'P9004_NOME_COLUNA10'
,p_item_sequence=>260
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(168122703388396298)
,p_computation_sequence=>10
,p_computation_item=>'P9004_WHERE_DINAMICO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_where clob;',
'    l_pagina varchar2(256) := nvl(:P9004_CODIGO_ARTEFATO_BASE,100);',
'begin',
'    begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_where := UI_MPD_''||l_pagina||''.where_dinamico(''||aspas(:P9004_CAMPO)||''); END;''',
'        USING OUT l_where;',
'    exception',
'        when others then',
'            return '''';       ',
'',
'    end;',
'    return l_where;       ',
'end;',
''))
,p_compute_when=>'P9004_CODIGO_ARTEFATO_BASE'
,p_compute_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(168133301873396332)
,p_name=>'onDoubleClickLista'
,p_event_sequence=>60
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(719255354285836900)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'dblclick'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(168133760436396333)
,p_event_id=>wwv_flow_imp.id(168133301873396332)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
,p_attribute_01=>'P9004_SELECTED_ITEM_ID,P9004_SELECTED_ITEM_TEXT'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(168134185292396334)
,p_name=>'onClickPesquisar'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(168104869884396215)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(168135634849396337)
,p_event_id=>wwv_flow_imp.id(168134185292396334)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9004_SEARCH'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(168135181026396336)
,p_event_id=>wwv_flow_imp.id(168134185292396334)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9004_FILTRAR'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(168134617565396335)
,p_event_id=>wwv_flow_imp.id(168134185292396334)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(719255354285836900)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(168136022784396338)
,p_name=>'onClickBTN_CADASTRO'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(168105289729396216)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(168136582808396340)
,p_event_id=>wwv_flow_imp.id(168136022784396338)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'pagina_modal( apex.item("P9004_TITULO_CADASTRO").getValue(), apex.item("P9004_URL_CADASTRO").getValue(),''#BTN_CADASTRO'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(168132470492396327)
,p_name=>'onClosedBTN_CADASTRO'
,p_event_sequence=>90
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#BTN_CADASTRO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(168132858873396330)
,p_event_id=>wwv_flow_imp.id(168132470492396327)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(719255354285836900)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(168136916855396341)
,p_name=>'onAfterRefresh'
,p_event_sequence=>100
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(719255354285836900)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(168137425687396343)
,p_event_id=>wwv_flow_imp.id(168136916855396341)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let noData = document.querySelector(".t-IRR-region .nodatafound"); ',
'',
'if (noData) {',
unistr('  // quando n\00E3o h\00E1 registros \2192 mostra'),
'    apex.item("BTN_FILTRAR").show();',
'} else {',
unistr('  // quando h\00E1 registros \2192 esconde'),
'    apex.item("BTN_FILTRAR").hide();',
'}'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(168130876426396322)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_01=>'P9004_SELECTED_ITEM_ID,P9004_SELECTED_ITEM_TEXT'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(168113859896396251)
,p_internal_uid=>62866170412897212
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(168131255210396324)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Seta Query'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--:P9004_QUERY := ''select * from ''||:P9004_BO||''.buscar_registros_zoom(:P9004_TABLE_NAME)'';',
':P9004_QUERY := ''select * from PK_UI_TESTE.buscar_registros_zoom(p_table_name => :P9004_TABLE_NAME)'';'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>62866549196897214
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(168131648415396325)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Limpa Filtros'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_region_id apex_application_page_regions.region_id%type;',
'begin',
'',
'   select aapr.region_id',
'     into l_region_id',
'     from apex_application_page_regions aapr',
'    where aapr.application_id = :app_id',
'      and aapr.page_id = :app_page_id',
'      and aapr.static_id = ''GRID'';          ',
'    ',
'    apex_ig.reset_report(',
'        p_page_id   => :app_page_id,',
'        p_region_id => l_region_id,',
'        p_report_id => null);',
'        ',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>62866942401897215
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(168122945507396299)
,p_process_sequence=>40
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'retorna_zoom_dinamico'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'RETORNA_ZOOM_DINAMICO'
,p_process_error_message=>'&P9004_RESULTADO_MENSAGEM.'
,p_process_when=>'P9004_CODIGO_ARTEFATO'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_process_success_message=>'&P9004_RESULTADO_MENSAGEM.'
,p_internal_uid=>62858239493897189
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(168123441682396301)
,p_page_process_id=>wwv_flow_imp.id(168122945507396299)
,p_page_id=>9004
,p_name=>'p_sql_consulta'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P9004_SQL_CONSULTA'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(168123913150396302)
,p_page_process_id=>wwv_flow_imp.id(168122945507396299)
,p_page_id=>9004
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P9004_CODIGO_ARTEFATO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(168124445428396304)
,p_page_process_id=>wwv_flow_imp.id(168122945507396299)
,p_page_id=>9004
,p_name=>'p_label1'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>50
,p_value_type=>'ITEM'
,p_value=>'P9004_NOME_COLUNA1'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(168124917907396305)
,p_page_process_id=>wwv_flow_imp.id(168122945507396299)
,p_page_id=>9004
,p_name=>'p_label2'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>60
,p_value_type=>'ITEM'
,p_value=>'P9004_NOME_COLUNA2'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(168125440895396306)
,p_page_process_id=>wwv_flow_imp.id(168122945507396299)
,p_page_id=>9004
,p_name=>'p_label3'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>70
,p_value_type=>'ITEM'
,p_value=>'P9004_NOME_COLUNA3'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(168125915874396307)
,p_page_process_id=>wwv_flow_imp.id(168122945507396299)
,p_page_id=>9004
,p_name=>'p_label4'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>80
,p_value_type=>'ITEM'
,p_value=>'P9004_NOME_COLUNA4'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(168126447074396308)
,p_page_process_id=>wwv_flow_imp.id(168122945507396299)
,p_page_id=>9004
,p_name=>'p_label5'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>90
,p_value_type=>'ITEM'
,p_value=>'P9004_NOME_COLUNA5'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(168126963641396309)
,p_page_process_id=>wwv_flow_imp.id(168122945507396299)
,p_page_id=>9004
,p_name=>'p_label6'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>100
,p_value_type=>'ITEM'
,p_value=>'P9004_NOME_COLUNA6'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(168127465948396310)
,p_page_process_id=>wwv_flow_imp.id(168122945507396299)
,p_page_id=>9004
,p_name=>'p_label7'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>110
,p_value_type=>'ITEM'
,p_value=>'P9004_NOME_COLUNA7'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(168127959349396312)
,p_page_process_id=>wwv_flow_imp.id(168122945507396299)
,p_page_id=>9004
,p_name=>'p_label8'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>120
,p_value_type=>'ITEM'
,p_value=>'P9004_NOME_COLUNA8'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(168128456376396314)
,p_page_process_id=>wwv_flow_imp.id(168122945507396299)
,p_page_id=>9004
,p_name=>'p_label9'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>130
,p_value_type=>'ITEM'
,p_value=>'P9004_NOME_COLUNA9'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(168128993057396315)
,p_page_process_id=>wwv_flow_imp.id(168122945507396299)
,p_page_id=>9004
,p_name=>'p_label10'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>140
,p_value_type=>'ITEM'
,p_value=>'P9004_NOME_COLUNA10'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(168129458109396318)
,p_page_process_id=>wwv_flow_imp.id(168122945507396299)
,p_page_id=>9004
,p_name=>'p_url'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>150
,p_value_type=>'ITEM'
,p_value=>'P9004_URL_CADASTRO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(168129973122396319)
,p_page_process_id=>wwv_flow_imp.id(168122945507396299)
,p_page_id=>9004
,p_name=>'p_titulo_consulta'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>160
,p_value_type=>'ITEM'
,p_value=>'P9004_TITULO_CONSULTA'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(168130419631396321)
,p_page_process_id=>wwv_flow_imp.id(168122945507396299)
,p_page_id=>9004
,p_name=>'p_titulo_cadastro'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>170
,p_value_type=>'ITEM'
,p_value=>'P9004_TITULO_CADASTRO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(168132018791396325)
,p_process_sequence=>50
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Limapa cache da Lista'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_region_id NUMBER;',
'BEGIN',
'    SELECT region_id',
'      INTO l_region_id',
'      FROM apex_application_page_regions',
'     WHERE application_id = :APP_ID',
'       AND page_id        = 9004',
'       AND static_id      = ''GRID'';',
'',
'    APEX_REGION.RESET (',
'        p_application_id => :APP_ID,',
'        p_page_id        => 9004,',
'        p_region_id      => l_region_id',
'    );',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>62867312777897215
,p_process_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('Limpa o cache da lista em rela\00E7\00E3o a defini\00E7\00E3o da ordena\00E7\00E3o das colunas'),
''))
);
wwv_flow_imp.component_end;
end;
/
