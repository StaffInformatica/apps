prompt --application/pages/page_00000
begin
--   Manifest
--     PAGE: 00000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_page.create_page(
 p_id=>0
,p_name=>'Global Page'
,p_step_title=>'Global Page'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'D'
,p_page_component_map=>'14'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(165297110610388420)
,p_plug_name=>'Titulo dinamico'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(489194609147697632)
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    -- htp.print(''<BR> &nbsp;&nbsp;  ''||:P0_BREADCRUMB||''<BR>'');',
'    htp.print(:P0_BREADCRUMB);',
'end;'))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'apex_page.get_page_mode(:APP_ID,:APP_PAGE_ID) = ''NORMAL'' AND :APP_PAGE_ID NOT IN (2,9999)'
,p_plug_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(166312169290903241)
,p_plug_name=>'Campos globais'
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(204130092890663954)
,p_plug_name=>'campo.selecionar-idioma.l'
,p_region_name=>'modal-selecionar-idioma'
,p_region_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_plug_template=>wwv_flow_imp.id(489175136164697621)
,p_plug_display_sequence=>40
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(211067619885647546)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(165297110610388420)
,p_button_name=>'back'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(489278989412697687)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'&P0_LABEL_VOLTAR.'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-chevron-circle-left'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(156813529132397913)
,p_name=>'P0_PROGRESSO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(166312169290903241)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(162913181311067533)
,p_name=>'P0_LABEL_SALVAR'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(166312169290903241)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(162913274856067534)
,p_name=>'P0_LABEL_OPCAO'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(166312169290903241)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(162913308229067535)
,p_name=>'P0_LABEL_MAIS_DETALHES'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(166312169290903241)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(162913494066067536)
,p_name=>'P0_LABEL_FILTRAR'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(166312169290903241)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(162913564765067537)
,p_name=>'P0_LABEL_ADICIONAR_FAV'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(166312169290903241)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(162913608772067538)
,p_name=>'P0_LABEL_REMOVER_FAV'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(166312169290903241)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(162913788394067539)
,p_name=>'P0_LABEL_FIXAR'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(166312169290903241)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(162913845009067540)
,p_name=>'P0_LABEL_VISAO_CARD'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(166312169290903241)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(162913956843067541)
,p_name=>'P0_LABEL_VISAO_LISTA'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(166312169290903241)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(162914047043067542)
,p_name=>'P0_LABEL_ESCONDER_MOSTRAR_PESQUISA'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(166312169290903241)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(162914205078067543)
,p_name=>'P0_LABEL_HISTORICO_EXCLUSAO'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(166312169290903241)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(162914300634067544)
,p_name=>'P0_LABEL_NOVO'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(166312169290903241)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(162914354057067545)
,p_name=>'P0_LABEL_VOLTAR'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(166312169290903241)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(162914502334067546)
,p_name=>'P0_LABEL_CONFIGURACAO_LISTA'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(166312169290903241)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(165297081825388419)
,p_name=>'P0_BREADCRUMB'
,p_item_sequence=>10
,p_item_display_point=>'REGION_POSITION_01'
,p_source=>'breadcrumb_pkg.get_breadcrumb(''BREADCRUMB''||:APP_ID,:APP_ID,APEX_CUSTOM_AUTH.GET_SESSION_ID)'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(165297312694388422)
,p_name=>'P0_TITULO_TELA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(166312169290903241)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(166313702211903256)
,p_name=>'P0_TENANT_INFORMADO'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(166312169290903241)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(175782004305630255)
,p_name=>'P0_HELP_TELA'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(166312169290903241)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(179312033466195413)
,p_name=>'P0_CODIGO_ARTEFATO_ANTERIOR'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(166312169290903241)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(183725802251923994)
,p_name=>'P0_CODIGO_ARTEFATO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(166312169290903241)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200825637293010951)
,p_name=>'P0_TAB_ID'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(166312169290903241)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(204130211552663955)
,p_name=>'P0_IDIOMA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(204130092890663954)
,p_item_default=>'IDIOMA_LOGADO'
,p_item_default_type=>'ITEM'
,p_prompt=>'Idioma'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'select descricao_idioma d, id r from srv_idioma'
,p_field_template=>wwv_flow_imp.id(489277194088697685)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'execute_validations', 'Y',
  'number_of_columns', '1',
  'page_action_on_selection', 'SUBMIT')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(484522700077012212)
,p_name=>'Page load'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(150245459703014755)
,p_event_id=>wwv_flow_imp.id(484522700077012212)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Grava LOG de performance'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_artifact VARCHAR2(100) := V(''P0_CODIGO_ARTEFATO'');',
'    v_page_view_id NUMBER;',
'BEGIN',
unistr('    -- Pega o \00FAltimo registro de log dessa sess\00E3o/p\00E1gina'),
'    SELECT MAX(id)',
'    INTO v_page_view_id',
'    FROM apex_workspace_activity_log',
'    WHERE application_id = :APP_ID',
'      AND page_id = :APP_PAGE_ID',
'      AND APEX_SESSION_ID = :APP_SESSION;',
'',
unistr('    -- Grava em tabela pr\00F3pria'),
'    INSERT INTO log_tempo_com_item (',
'        APEX_SESSION_ID,',
'        codigo_artefato',
'    )',
'    VALUES (',
'        v_page_view_id,',
'        v_artifact',
'    );',
'END;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(200825562393010950)
,p_event_id=>wwv_flow_imp.id(484522700077012212)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'window.tempoInicio = performance.now();',
'',
'if (!sessionStorage.getItem(''TAB_ID'')) {',
'  sessionStorage.setItem(''TAB_ID'', crypto.randomUUID());',
'}',
'',
'apex.server.process("CALL_PKG_PROCESS", {',
'    x01: sessionStorage.getItem(''TAB_ID''),',
'    dataType: "json"',
'}, {',
'    success: function (data) {',
'    },',
'    error: function (jqXHR, textStatus, errorThrown) {',
'',
'    }',
'});',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(211247427604961660)
,p_event_id=>wwv_flow_imp.id(484522700077012212)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("#exitpopup_bg").dialog({',
'    autoOpen: false,',
'    modal: false,',
'    dialogClass: ''PROF_DID''',
'});',
'',
'apex.jQuery(function() {',
'  apex.theme42.util.configAPEXMsgs({',
'    autoDismiss: true,',
'    duration: 1500  // duration is optional (Default is 3000 milliseconds)',
'  });',
'});',
'',
'/* Close when click Outside the Dialog*/',
'$(''html'')',
'    .bind(',
'        ''click'',',
'        function(e) {',
'            ',
'            if ($(''#exitpopup_bg'').dialog(''isOpen'') && !$(e.target).is(''.ui-dialog, a'') && !$(e.target).closest(''.ui-dialog'').length && !$(e.target).is(''.image_icon'') && !$(e.target).is(''.ui-dialog-titlebar-close'')) {',
'                $(''#exitpopup_bg'').dialog(''close'');',
'',
'                ',
'                $(''.image_icon'').removeClass(''et'');',
'                $(''.image_icon'').addClass(''st'');',
'            }',
'        }',
'    );',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(188100727644846923)
,p_event_id=>wwv_flow_imp.id(484522700077012212)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_idioma number;',
'begin',
'    select nvl(id_idioma, 1) into l_idioma from mpd_usuario where id = :ID_USUARIO_LOGADO;',
'    if :IDIOMA_LOGADO is null then',
'        apex_util.set_session_state(''IDIOMA_LOGADO'', l_idioma);',
'    end if;',
'end;'))
,p_attribute_02=>'ID_USUARIO_LOGADO,IDIOMA_LOGADO'
,p_attribute_03=>'IDIOMA_LOGADO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_server_condition_type=>'EXPRESSION'
,p_server_condition_expr1=>':IDIOMA_LOGADO is null and :APP_PAGE_ID not between 9990 and 9999'
,p_server_condition_expr2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(162915801092067559)
,p_event_id=>wwv_flow_imp.id(484522700077012212)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_name=>'Carrega o Labels Globais'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    select pkg_ui.retorna_label_tela(''filtrar-por''),',
'           pkg_ui.retorna_label_botao(''opcao''),',
'           pkg_ui.retorna_label_botao(''maisdetalhes''),',
'           pkg_ui.retorna_label_botao(''adicionar-favorito''),',
'           pkg_ui.retorna_label_botao(''remover-favorito''),',
'           pkg_ui.retorna_label_botao(''fixar-desfixar''),',
'           pkg_ui.retorna_label_botao(''visao-card''),',
'           pkg_ui.retorna_label_botao(''visao-lista''),',
'           pkg_ui.retorna_label_botao(''mostra-esconde-filtro''),',
'           pkg_ui.retorna_label_botao(''historico-exclusao''),',
'           pkg_ui.retorna_label_botao(''novo''),',
'           pkg_ui.retorna_label_botao(''voltar''),',
'           pkg_ui.retorna_label_botao(''configuracao-lista''),',
'           pkg_ui.retorna_label_botao(''gravar'')',
'    into :P0_LABEL_FILTRAR, :P0_LABEL_OPCAO, :P0_LABEL_MAIS_DETALHES,:P0_LABEL_ADICIONAR_FAV,:P0_LABEL_REMOVER_FAV,:P0_LABEL_FIXAR,:P0_LABEL_VISAO_CARD,',
'    :P0_LABEL_VISAO_LISTA,:P0_LABEL_ESCONDER_MOSTRAR_PESQUISA,:P0_LABEL_HISTORICO_EXCLUSAO,:P0_LABEL_NOVO,:P0_LABEL_VOLTAR, :P0_LABEL_CONFIGURACAO_LISTA,:P0_LABEL_SALVAR from dual;',
'end;'))
,p_attribute_03=>'P0_LABEL_FILTRAR,P0_LABEL_OPCAO,P0_LABEL_MAIS_DETALHES,P0_LABEL_ADICIONAR_FAV,P0_LABEL_REMOVER_FAV,P0_LABEL_FIXAR,P0_LABEL_VISAO_CARD,P0_LABEL_VISAO_LISTA,P0_LABEL_ESCONDER_MOSTRAR_PESQUISA,P0_LABEL_HISTORICO_EXCLUSAO,P0_LABEL_NOVO,P0_LABEL_VOLTAR,P0'
||'_LABEL_CONFIGURACAO_LISTA,P0_LABEL_SALVAR'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'NULL'
,p_client_condition_element=>'P0_LABEL_MAIS_DETALHES'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(457855536333236777)
,p_name=>unistr('Refresh notifica\00E7\00F5es')
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#notification-menu'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(457855655572236778)
,p_event_id=>wwv_flow_imp.id(457855536333236777)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'JQUERY_SELECTOR'
,p_affected_elements=>'#notification-menu'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(196813395758704976)
,p_name=>'onChangeTenant'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P0_TENANT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(196813433130704977)
,p_event_id=>wwv_flow_imp.id(196813395758704976)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':TENANT_LOGADO := :P0_TENANT;'
,p_attribute_02=>'P0_TENANT'
,p_attribute_03=>'TENANT_LOGADO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(200708007099834844)
,p_name=>'onChangeIdioma'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P0_IDIOMA'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(204130296160663956)
,p_event_id=>wwv_flow_imp.id(200708007099834844)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_codigo varchar2(5);',
'begin',
'    select codigo into l_codigo from srv_idioma where id = :P0_IDIOMA;',
'    :FSP_LANGUAGE_PREFERENCE := l_codigo;',
'    :IDIOMA_LOGADO := :P0_IDIOMA;',
'end;'))
,p_attribute_02=>'P0_IDIOMA'
,p_attribute_03=>'IDIOMA_LOGADO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(211067727328647547)
,p_name=>'onClickBack'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(211067619885647546)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(211067865402647548)
,p_event_id=>wwv_flow_imp.id(211067727328647547)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'//closePage();',
'history.back();',
''))
);
wwv_flow_imp.component_end;
end;
/
