prompt --application/pages/page_00300
begin
--   Manifest
--     PAGE: 00300
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_page.create_page(
 p_id=>300
,p_name=>'To do'
,p_alias=>'TO-DO'
,p_step_title=>'To do'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function atualizarSituacao(elemento) {',
'  var registroId = elemento.getAttribute("data-id");',
'  var registroSituacao = elemento.getAttribute("data-situacao");',
'  console.log(''registroId:''+registroId);',
'  console.log(''registroSituacao:''+registroSituacao);',
'  apex.server.process("ATUALIZAR_SITUACAO", {',
'    f01: registroId,',
'    f02: registroSituacao',
'  }, {',
'    success: function(pData) {',
unistr('      console.log("Situa\00E7\00E3o atualizado com sucesso:", pData);'),
'      apex.region("tarefa_p").refresh();',
'      apex.region("tarefa_c").refresh();',
'    },',
'    error: function(request, status, error) {',
unistr('      console.error("Erro ao atualizar situa\00E7\00E3o:", error);'),
'    }',
'  });',
'}',
'',
'function atualizarImportante(elemento) {',
'  var registroId = elemento.getAttribute("data-id");',
'  var registroImportante = elemento.getAttribute("data-importante");',
'  console.log(''registroId:''+registroId);',
'  console.log(''registroImportante:''+registroImportante);',
'  apex.server.process("ATUALIZAR_IMPORTANTE", {',
'    f01: registroId,',
'    f02: registroImportante',
'  }, {',
'    success: function(pData) {',
'      console.log("Imporntante atualizado com sucesso:", pData);',
'      apex.region("tarefa_p").refresh();',
'      apex.region("tarefa_c").refresh();',
'    },',
'    error: function(request, status, error) {',
unistr('      console.error("Erro ao atualizar situa\00E7\00E3o:", error);'),
'    }',
'  });',
'}'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    .tarefa {',
'      display: flex;',
'      align-items: center;',
'      /*border: 1px solid #ccc;',
'      border-radius: 8px;',
'      padding: 10px 15px;',
'      width: 600px;',
'      background-color: #f1f3f6;*/',
'    }',
'',
'    .icone-check,',
'    .icone-favorito {',
'      cursor: pointer;',
'      font-size: 20px;',
'      padding: 5px;',
'    }',
'',
'    .icone-check:hover,',
'    .icone-favorito:hover {',
'      background-color: #ddd;',
'      border-radius: 50%;',
'    }',
'',
'    .texto {',
'      flex: 1;',
'      margin: 0 15px;',
'      font-size: 16px;',
'    }',
'',
'    .favoritado {',
'      color: gold;',
'    }',
'',
'.t-HeroRegion-icon{',
'    background-color: var(--ut-hero-region-icon-background-color,var(--ut-component-icon-background-color));',
'}',
'',
'.t-Alert{',
'    background-color: transparent;',
'}',
'',
'.t-Form-fieldContainer--radioButtonGroup .apex-item-group--rc input+label{',
'	 background-color: transparent;',
'    border: none;',
'    box-shadow: none;',
'}',
'',
'/*.apex-item-radio input:checked+.u-radio, .apex-item-radio input:checked+label{',
'  --a-checkbox-text-color: var(--a-button-text-color);',
'}*/',
'',
'.t-Form-fieldContainer--radioButtonGroup .apex-item-group--rc input:checked + label{',
'    border-radius: 5px;',
'    background-color: var(--ut-palette-primary);',
'}',
'',
'.t-Alert-title{',
'    --ut-alert-title-text-color: var(--ut-palette-primary);',
'}'))
,p_step_template=>wwv_flow_imp.id(489113429970697586)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(311041863625299133)
,p_plug_name=>'Titulo Pendente'
,p_title=>'Pendente'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--noIcon:t-Alert--info'
,p_plug_template=>wwv_flow_imp.id(489141212303697602)
,p_plug_display_sequence=>50
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(311036345801290936)
,p_plug_name=>'Pendente'
,p_title=>'Pendente'
,p_region_name=>'tarefa_p'
,p_parent_plug_id=>wwv_flow_imp.id(311041863625299133)
,p_region_template_options=>'#DEFAULT#:margin-top-md'
,p_plug_template=>wwv_flow_imp.id(489146466586697607)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       DESCRICAO,',
'       ID_LISTA,',
'       ID_RESPONSAVEL,',
'       DATA_AGENDAMENTO,',
'       DATA_CONCLUSAO,',
'       nvl(SITUACAO,''P'') SITUACAO,',
'       nvl(IMPORTANTE,''N'') IMPORTANTE,',
'       case when nvl(situacao,''P'') = ''P'' then ''fa-circle-o'' else ''fa-check-circle'' end ICONE_SITUACAO,',
'       case when nvl(importante,''N'') = ''N'' then ''fa-star-o'' else ''fa-star'' end ICONE_IMPORTANTE,',
unistr('       (select descricao from MPD_LISTA_TODO where id = id_lista) || case when DATA_AGENDAMENTO is not null then '' \2022 Lembrar-me ''||DATA_AGENDAMENTO else '''' end as subtitulo,'),
'       APEX_PAGE.GET_URL (',
'            p_page   => 301,',
'            p_items  => ''P301_ID'',',
'            p_values => ID ) url',
'  from MPD_TAREFA_TODO',
'  where nvl(situacao,''P'') = ''P''',
'  and (  ',
'     (:P300_FILTRO = 9999 and upper(meudia) = ''Y'')',
'  or (:P300_FILTRO = 9998 and upper(importante) = ''Y'')',
'  or (:P300_FILTRO = 9997 and DATA_AGENDAMENTO is not null)',
'  or (:P300_FILTRO = 9996 and ID_RESPONSAVEL = :id_usuario_logado)',
'  or (:P300_FILTRO not in (9999,9998,9997,9996) and id_lista = :P300_FILTRO)',
'  ) and upper(descricao) like ''%''||upper(nvl(:P300_PESQUISAR,descricao)||''%'')',
'  ',
'  ',
'',
'',
' '))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P300_FILTRO,P300_PESQUISAR'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_no_data_found=>'Nenhuma tarefa pendente classificada para a lista selecionada.'
,p_no_data_found_icon_classes=>'fa-tasks'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(208390042542822283)
,p_region_id=>wwv_flow_imp.id(311036345801290936)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>true
,p_title_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="tarefa">',
unistr('    <!-- \00CDcone de check -->'),
'    <div class="fa &ICONE_SITUACAO." data-id=&ID. data-situacao=&SITUACAO. onclick="atualizarSituacao(this)"></div>',
'',
'    <!-- Texto -->',
'    <a href="&URL." class="texto">',
'      &DESCRICAO.',
'      <div class="a-CardView-subTitle ">&SUBTITULO.</div>',
'    </a>',
'',
unistr('    <!-- \00CDcone de favorito -->'),
'    <div class="fa &ICONE_IMPORTANTE." data-id=&ID. data-importante=&IMPORTANTE. onclick="atualizarImportante(this)"></div>',
'</div>'))
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(311042015877299134)
,p_plug_name=>unistr('Titulo Conclu\00EDda')
,p_title=>unistr('Conclu\00EDda')
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--noIcon:t-Alert--success'
,p_plug_template=>wwv_flow_imp.id(489141212303697602)
,p_plug_display_sequence=>60
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(311039936502299113)
,p_plug_name=>unistr('Conclu\00EDda')
,p_region_name=>'tarefa_c'
,p_parent_plug_id=>wwv_flow_imp.id(311042015877299134)
,p_icon_css_classes=>'fa-check-circle'
,p_region_template_options=>'#DEFAULT#:margin-top-md'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(489146466586697607)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       DESCRICAO,',
'       ID_LISTA,',
'       ID_RESPONSAVEL,',
'       DATA_AGENDAMENTO,',
'       DATA_CONCLUSAO,',
'       nvl(SITUACAO,''P'') SITUACAO,',
'       nvl(IMPORTANTE,''N'') IMPORTANTE,',
'       case when nvl(situacao,''p'') = ''p'' then ''fa-circle-o'' else ''fa-check-circle'' end ICONE_SITUACAO,',
'       case when nvl(importante,''N'') = ''N'' then ''fa-star-o'' else ''fa-star'' end ICONE_IMPORTANTE,',
unistr('       (select descricao from MPD_LISTA_TODO where id = id_lista) || case when DATA_AGENDAMENTO is not null then '' \2022 ''||DATA_AGENDAMENTO else '''' end as subtitulo,'),
'       APEX_PAGE.GET_URL (',
'            p_page   => 301,',
'            p_items  => ''P301_ID'',',
'            p_values => ID ) url',
'  from MPD_TAREFA_TODO',
'  where nvl(upper(situacao),''P'') = ''C''',
'  and (  ',
'     (:P300_FILTRO = 9999 and upper(meudia) = ''Y'')',
'  or (:P300_FILTRO = 9998 and upper(importante) = ''Y'')',
'  or (:P300_FILTRO = 9997 and DATA_AGENDAMENTO is not null)',
'  or (:P300_FILTRO = 9996 and ID_RESPONSAVEL = :id_usuario_logado)',
'  or (:P300_FILTRO not in (9999,9998,9997,9996) and id_lista = :P300_FILTRO)',
'  ) and upper(descricao) like ''%''||upper(nvl(:P300_PESQUISAR,descricao)||''%'')',
' '))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P300_FILTRO,P300_PESQUISAR'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_no_data_found=>unistr('Nenhuma tarefa conclu\00EDda classificada para a lista selecionada.')
,p_no_data_found_icon_classes=>'fa-check'
,p_show_total_row_count=>false
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(208387974964822272)
,p_region_id=>wwv_flow_imp.id(311039936502299113)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>true
,p_title_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="tarefa">',
unistr('    <!-- \00CDcone de check -->'),
'    <div class="fa &ICONE_SITUACAO." data-id=&ID. data-situacao=&SITUACAO. onclick="atualizarSituacao(this)"></div>',
'',
'    <!-- Texto -->',
'    <a href="&URL." class="texto" style="text-decoration: line-through;">',
'      &DESCRICAO.',
'      <div class="a-CardView-subTitle ">&SUBTITULO.</div>',
'    </a>',
'',
unistr('    <!-- \00CDcone de favorito -->'),
'    <div class="fa &ICONE_IMPORTANTE." data-id=&ID. data-importante=&IMPORTANTE. onclick="atualizarImportante(this)"></div>',
'</div>'))
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(311044340698299157)
,p_plug_name=>'Titulo'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(489146466586697607)
,p_plug_display_sequence=>40
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_html clob;',
'begin',
'    l_html := q''~',
'        <div class="t-HeroRegion t-HeroRegion--iconsCircle lto102656694174476921_0" id="R102656694174476921" role="region" aria-labelledby="R102656694174476921_heading">',
'          <div class="t-HeroRegion-top">',
'            <div class="t-HeroRegion-wrap">',
'              <div class="t-HeroRegion-col t-HeroRegion-col--beforeIcon"></div>',
'              <div class="t-HeroRegion-col t-HeroRegion-col--left"><span class="t-HeroRegion-icon t-Icon fa #ICONE#"></span></div>',
'              <div class="t-HeroRegion-col t-HeroRegion-col--content">',
'                <h1 id="R102656694174476921_heading" class="t-HeroRegion-title" data-apex-heading="">#TITULO#</h1>                ',
'              </div>',
'              <div class="t-HeroRegion-col t-HeroRegion-col--right"><div class="t-HeroRegion-form"></div><div class="t-HeroRegion-buttons"></div></div>',
'            </div>',
'          </div>',
'          <div class="t-HeroRegion-bottom"></div>',
'        </div>',
'    ~'';',
'    l_html := replace(l_html,''#TITULO#'',:P300_DESCRICAO);',
'    l_html := replace(l_html,''#ICONE#'',:P300_ICONE);',
'    return l_html;',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_required_patch=>wwv_flow_imp.id(489109181809697564)
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(596942658685841854)
,p_plug_name=>'Filtrar por Esquerda'
,p_title=>'&P9005_LABEL_FILTRAR.'
,p_region_name=>'PAINEL_LEFT'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(208432069146171592)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(596942658685841854)
,p_button_name=>'fixar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(489278989412697687)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'botao.fixar-desfixar.l'
,p_button_position=>'COPY'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-thumb-tack'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(208348174891433417)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(165297110610388420)
,p_button_name=>'New_1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(489278989412697687)
,p_button_image_alt=>'New 1'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:301:&SESSION.::&DEBUG.:301::'
,p_icon_css_classes=>'fa-plus-circle'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(177359200508447044)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(165297110610388420)
,p_button_name=>'Zoom'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(489278989412697687)
,p_button_image_alt=>'Zoom'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:9003:&SESSION.::&DEBUG.:9003:P9003_CODIGO_ARTEFATO,P9003_NOME_COLUNA1:TD755,Razao social'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(208347858183433414)
,p_name=>'P300_CODIGO_ARTEFATO'
,p_item_sequence=>100
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(208347993694433415)
,p_name=>'P300_ICONE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(596942658685841854)
,p_item_display_point=>'PREVIOUS'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(208348104169433416)
,p_name=>'P300_DESCRICAO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(596942658685841854)
,p_item_display_point=>'PREVIOUS'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(208348290447433418)
,p_name=>'P300_TELA_HELP'
,p_item_sequence=>50
,p_item_display_point=>'REGION_POSITION_01'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(208348326887433419)
,p_name=>'P300_TELA_TITULO'
,p_item_sequence=>60
,p_item_display_point=>'REGION_POSITION_01'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(311041374764299167)
,p_name=>'P300_FILTRO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(596942658685841854)
,p_item_display_point=>'PREVIOUS'
,p_item_default=>'9999'
,p_prompt=>'Filtro'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select d,r from (',
'select ''<span class="fa fa-sun-o" style="text-align: start;"><span style="padding-left: 15px;">Meu dia</span></span>'' d, 9999 r, 1 ordem from dual',
'union    ',
'select ''<span class="fa fa-star" style="text-align: start;"><span style="padding-left: 15px;">Importante</span></span>'' d, 9998 r, 2 ordem from dual',
'union',
'select ''<span class="fa fa-clock-o" style="text-align: start;"><span style="padding-left: 15px;">Planejado</span></span>'' d, 9997 r, 3 ordem from dual',
'union',
unistr('select ''<span class="fa fa-user" style="text-align: start;"><span style="padding-left: 15px;">Atribu\00EDdo a mim</span></span>'' d, 9996 r, 4 ordem from dual'),
'union',
'select ''<span class="fa ''||icone||''" style="text-align: start;"><span style="padding-left: 15px;">''||descricao||''</span></span>'' d, id r, null ordem from MPD_LISTA_TODO',
') order by ordem,d',
''))
,p_field_template=>wwv_flow_imp.id(489276919265697684)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--xlarge:margin-top-md:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'YES'
,p_escape_on_http_output=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(311041891227299172)
,p_name=>'P300_PESQUISAR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(596942658685841854)
,p_item_display_point=>'PREVIOUS'
,p_prompt=>'Pesquisar'
,p_placeholder=>'Pesquisar'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(489276919265697684)
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--large'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(208394850388822318)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(311036345801290936)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(208395390586822320)
,p_event_id=>wwv_flow_imp.id(208394850388822318)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(311036345801290936)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(208395854452822321)
,p_event_id=>wwv_flow_imp.id(208394850388822318)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(311039936502299113)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(208392090492822308)
,p_name=>'New_1'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(311039936502299113)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(208392555441822313)
,p_event_id=>wwv_flow_imp.id(208392090492822308)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(311036345801290936)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(208393057596822314)
,p_event_id=>wwv_flow_imp.id(208392090492822308)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(311039936502299113)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(208397676852822325)
,p_name=>'onChangeFiltro'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P300_FILTRO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(208398640888822328)
,p_event_id=>wwv_flow_imp.id(208397676852822325)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_descricao varchar2(256);',
'    l_icone varchar2(256);',
'begin',
'    if nvl(:P300_FILTRO,9999) = 9999 then',
'        l_descricao := ''Meu dia'';',
'        l_icone := ''fa-sun-o''; ',
'    elsif :P300_FILTRO = 9998 then',
'        l_descricao := ''Importante'';',
'        l_icone := ''fa-star-o''; ',
'    elsif :P300_FILTRO = 9997 then',
'        l_descricao := ''Planejado'';',
'        l_icone := ''fa-clock-o''; ',
'    elsif :P300_FILTRO = 9996 then',
unistr('        l_descricao := ''Atribu\00EDdo a mim'';'),
'        l_icone := ''fa-user-o''; ',
'    else',
'        select descricao, icone into l_descricao,l_icone from MPD_LISTA_TODO where id = :P300_FILTRO;',
'    end if;',
'    :P300_DESCRICAO := l_descricao;',
'    :P300_ICONE := l_icone;',
'end;'))
,p_attribute_02=>'P300_FILTRO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(208398122278822326)
,p_event_id=>wwv_flow_imp.id(208397676852822325)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(311044340698299157)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(208399144411822329)
,p_event_id=>wwv_flow_imp.id(208397676852822325)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(311036345801290936)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(208399663383822330)
,p_event_id=>wwv_flow_imp.id(208397676852822325)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(311039936502299113)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(208393442223822315)
,p_name=>'New_3'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P300_PESQUISAR'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(208393909418822316)
,p_event_id=>wwv_flow_imp.id(208393442223822315)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(311036345801290936)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(208394465296822317)
,p_event_id=>wwv_flow_imp.id(208393442223822315)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(311039936502299113)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(208504867011323621)
,p_name=>'onMouseEnterTooltip'
,p_event_sequence=>60
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'$("#icon_info")'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'mouseenter'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(208505234401323623)
,p_event_id=>wwv_flow_imp.id(208504867011323621)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'PLUGIN_COM.FOS.TOOLTIP'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'$("#icon_info")'
,p_attribute_01=>'static'
,p_attribute_05=>'&P300_TELA_HELP. (&P300_CODIGO_ARTEFATO.)'
,p_attribute_08=>'#007BFE'
,p_attribute_09=>'#FFFFFF'
,p_attribute_10=>'scale'
,p_attribute_11=>'500'
,p_attribute_12=>'hover'
,p_attribute_13=>'top'
,p_attribute_14=>'cache-result,escape-html'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(208502252050312392)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'retorna_titulo_tela'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'RETORNA_TITULO_TELA'
,p_internal_uid=>103237546036813282
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(208502648564312395)
,p_page_process_id=>wwv_flow_imp.id(208502252050312392)
,p_page_id=>300
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P300_CODIGO_ARTEFATO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(208503098990312397)
,p_page_process_id=>wwv_flow_imp.id(208502252050312392)
,p_page_id=>300
,p_name=>'p_titulo'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P0_TITULO_TELA'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(208503588715312399)
,p_page_process_id=>wwv_flow_imp.id(208502252050312392)
,p_page_id=>300
,p_name=>'p_help'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P300_TELA_HELP'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(208391244682822305)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ATUALIZAR_SITUACAO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  UPDATE MPD_TAREFA_TODO',
'     SET situacao = case when apex_application.g_f02(1) = ''C'' then ''P'' else ''C'' end',
'   WHERE id = to_number(apex_application.g_f01(1));',
'',
'    htp.prn(''{"result":"success"}'');',
'',
'    apex_json.open_object;  ',
'    apex_json.write(''success'', true);  ',
'    apex_json.close_object;',
'',
'exception',
'  when OTHERS then',
'    apex_json.open_object;',
'    apex_json.write(''success'', false);',
'    apex_json.write(''message'', sqlerrm);',
'    apex_json.close_object;',
'    htp.prn(''{"result":"ERROR"}'');',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>103126538669323195
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(208391639871822307)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ATUALIZAR_IMPORTANTE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  UPDATE MPD_TAREFA_TODO',
'     SET importante = case when apex_application.g_f02(1) = ''Y'' then ''N'' else ''Y'' end',
'   WHERE id = to_number(apex_application.g_f01(1));',
'',
'    htp.prn(''{"result":"success"}'');',
'',
'    apex_json.open_object;  ',
'    apex_json.write(''success'', true);  ',
'    apex_json.close_object;',
'',
'exception',
'  when OTHERS then',
'    apex_json.open_object;',
'    apex_json.write(''success'', false);',
'    apex_json.write(''message'', sqlerrm);',
'    apex_json.close_object;',
'    htp.prn(''{"result":"ERROR"}'');',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>103126933858323197
);
wwv_flow_imp.component_end;
end;
/
