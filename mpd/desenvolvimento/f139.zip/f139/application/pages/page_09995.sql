prompt --application/pages/page_09995
begin
--   Manifest
--     PAGE: 09995
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_page.create_page(
 p_id=>9995
,p_name=>'Recupera Senha'
,p_alias=>'RECUPERA-SENHA'
,p_step_title=>'Recupera Senha'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(370511843251763518)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Alert{',
'    background-color: transparent;',
'    border: none;',
'    box-shadow: none;',
'}'))
,p_step_template=>wwv_flow_imp.id(489135649323697598)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(647583738660281281)
,p_plug_name=>'MBP'
,p_region_template_options=>'#DEFAULT#:t-Login-region--headerHidden js-removeLandmark:t-Form--slimPadding'
,p_plug_template=>wwv_flow_imp.id(489224069757697646)
,p_plug_display_sequence=>10
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<img src="#APP_FILES#logo.png" style="height: 30px;" alt="Minha Figura"></img>',
'<div class="st-titulo-app">&APP_NAME.</div>',
'',
'',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(195301677632981560)
,p_plug_name=>'Senha'
,p_parent_plug_id=>wwv_flow_imp.id(647583738660281281)
,p_icon_css_classes=>'fa-lock-new'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--customIcons:t-Alert--success:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(489141212303697602)
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P9995_TOKEN_OK'
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="st-titulo-login">Redefinir Senha</div>',
unistr('<div class="st-detalhe-login">Crie uma nova senha e confirme-a para o usu\00E1rio &P9995_USERNAME.</div>')))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(542267994950769862)
,p_plug_name=>'Token'
,p_parent_plug_id=>wwv_flow_imp.id(647583738660281281)
,p_region_css_classes=>'color-text'
,p_icon_css_classes=>'fa-envelope-clock'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--customIcons:t-Alert--warning:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(489141212303697602)
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_display_condition_type=>'ITEM_IS_NULL'
,p_plug_display_when_condition=>'P9995_TOKEN_OK'
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<div class="st-titulo-login">Verifica\00E7\00E3o de C\00F3digo</div>'),
unistr('<div class="st-detalhe-login">Digite o c\00F3digo enviado para seu e-mail. &P9995_EMAIL.</div>')))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(195301786199981561)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(542267994950769862)
,p_button_name=>'verificar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--warning:t-Button--simple'
,p_button_template_id=>wwv_flow_imp.id(489279734794697688)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Validar c\00F3digo')
,p_button_position=>'PREVIOUS'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(419526717417249021)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(195301677632981560)
,p_button_name=>'REDEFINIR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--success:t-Button--simple'
,p_button_template_id=>wwv_flow_imp.id(489279734794697688)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Redefinir'
,p_button_position=>'PREVIOUS'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(196172219193830861)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(542267994950769862)
,p_button_name=>'cancel'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(489279734794697688)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'PREVIOUS'
,p_button_redirect_url=>'f?p=&APP_ID.:9999:&SESSION.::&DEBUG.:9999::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(196172563428830865)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(195301677632981560)
,p_button_name=>'cancel1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(489279734794697688)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'PREVIOUS'
,p_button_redirect_url=>'f?p=&APP_ID.:9999:&SESSION.::&DEBUG.:9999::'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(419532240305249025)
,p_branch_name=>'Go to 9995'
,p_branch_action=>'f?p=&APP_ID.:9995:&SESSION.::&DEBUG.:9995:P9995_USERNAME,P9995_TOKEN_OK:&P9995_USERNAME.,Ok&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(195301786199981561)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(195302262708981566)
,p_branch_name=>'Go to 9999'
,p_branch_action=>'f?p=&APP_ID.:9999:&SESSION.::&DEBUG.:9999:P9999_USERNAME:&P9995_USERNAME.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(419526717417249021)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(195301909117981562)
,p_name=>'P9995_TOKEN_OK'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(647583738660281281)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(419527097266249022)
,p_name=>'P9995_USERNAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(647583738660281281)
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(419527477820249022)
,p_name=>'P9995_TOKEN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(542267994950769862)
,p_prompt=>unistr('C\00F3digo de verifica\00E7\00E3o')
,p_placeholder=>unistr('C\00F3digo de verifica\00E7\00E3o')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(489276919265697684)
,p_item_icon_css_classes=>'fa-envelope-clock'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(419527867759249022)
,p_name=>'P9995_PASSWORD'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(195301677632981560)
,p_prompt=>'Senha'
,p_placeholder=>'Nova senha'
,p_display_as=>'PLUGIN_COM.FOS.ADVANCED_PASSWORD'
,p_cSize=>40
,p_cMaxlength=>100
,p_field_template=>wwv_flow_imp.id(489276919265697684)
,p_item_icon_css_classes=>'fa-lock-new'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'enabled-toggle',
  'attribute_02', 'collapsible',
  'attribute_03', 'Excelente',
  'attribute_04', 'require-min-length:require-number:require-spec-char:require-capital-letter:show-pwd-strength-bar:show-caps-lock-on:enable-inline-icons',
  'attribute_05', '7',
  'attribute_06', 'Deve conter pelo menos #MIN_LENGTH# caracteres.',
  'attribute_07', '1',
  'attribute_08', unistr('Pelo menos #MIN_NUMS# n\00FAmeros.'),
  'attribute_09', unistr('?><,./|}[]~\00A7@#$%'),
  'attribute_10', '2',
  'attribute_11', 'Pelo menos #MIN_SPEC_CHARS# da lista: #SPEC_CHARS_LIST#',
  'attribute_12', '1',
  'attribute_13', unistr('Deve conter pelo menos #MIN_CAPS# letras mai\00FAsculas'))).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(419528289043249022)
,p_name=>'P9995_C_PASSWORD'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(195301677632981560)
,p_prompt=>'Senha'
,p_placeholder=>'Confirme a senha'
,p_display_as=>'PLUGIN_COM.FOS.ADVANCED_PASSWORD'
,p_cSize=>40
,p_cMaxlength=>100
,p_field_template=>wwv_flow_imp.id(489276919265697684)
,p_item_icon_css_classes=>'fa-lock-new'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'enabled-toggle')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(419528655021249023)
,p_name=>'P9995_EMAIL'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(542267994950769862)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(195301566035981559)
,p_computation_sequence=>10
,p_computation_item=>'P9995_EMAIL'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>'select email from mpd_usuario where lower(login) = lower(:P9995_USERNAME);'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(419530418505249024)
,p_validation_name=>'P9995_SENHA_TEMPORARIA-Valid auth2'
,p_validation_sequence=>1
,p_validation=>'return PKG_API_SEGURANCA.valid_otp(:P9995_USERNAME,:P9995_TOKEN);'
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(195301786199981561)
,p_associated_item=>wwv_flow_imp.id(419527477820249022)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(419529186954249024)
,p_validation_name=>'P9995_C_PASSWORD-Valid'
,p_validation_sequence=>30
,p_validation=>'P9995_C_PASSWORD'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>unistr('Senhas n\00E3o conferem')
,p_when_button_pressed=>wwv_flow_imp.id(419526717417249021)
,p_associated_item=>wwv_flow_imp.id(419528289043249022)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(419529627063249024)
,p_validation_name=>'P9995_C_PASSWORD-Valid_1'
,p_validation_sequence=>40
,p_validation=>':P9995_PASSWORD = :P9995_C_PASSWORD'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Senhas n\00E3o conferem')
,p_when_button_pressed=>wwv_flow_imp.id(419526717417249021)
,p_associated_item=>wwv_flow_imp.id(419528289043249022)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(419529968500249024)
,p_validation_name=>'P9995_PASSWORD-Valid not null'
,p_validation_sequence=>50
,p_validation=>'P9995_PASSWORD'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Nova senha deve ser informada'
,p_when_button_pressed=>wwv_flow_imp.id(419526717417249021)
,p_associated_item=>wwv_flow_imp.id(419527867759249022)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(196172291903830862)
,p_name=>'onChangeToken is not null'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9995_TOKEN'
,p_condition_element=>'P9995_TOKEN'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keyup'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(196172382204830863)
,p_event_id=>wwv_flow_imp.id(196172291903830862)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(195301786199981561)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(196172477731830864)
,p_event_id=>wwv_flow_imp.id(196172291903830862)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(195301786199981561)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(419530700228249024)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Grava senha'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_API_SEGURANCA'
,p_attribute_04=>'SAVE_PASSWORD'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(419526717417249021)
,p_process_success_message=>'Senha redefinida com sucesso'
,p_internal_uid=>62048456819120047
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(419531193612249025)
,p_page_process_id=>wwv_flow_imp.id(419530700228249024)
,p_page_id=>9995
,p_name=>'p_user_name'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P9995_USERNAME'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(419531705687249025)
,p_page_process_id=>wwv_flow_imp.id(419530700228249024)
,p_page_id=>9995
,p_name=>'p_password'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P9995_PASSWORD'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(196365023887257648)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'altera_situacao_cadastral'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'BO_MPD_USUARIO'
,p_attribute_04=>'ALTERA_SITUACAO_CADASTRAL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(419526717417249021)
,p_internal_uid=>12850904202018120
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(196365137231257649)
,p_page_process_id=>wwv_flow_imp.id(196365023887257648)
,p_page_id=>9995
,p_name=>'p_situacao_cadastral'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'STATIC'
,p_value=>'3'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(196365228071257650)
,p_page_process_id=>wwv_flow_imp.id(196365023887257648)
,p_page_id=>9995
,p_name=>'p_id'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'SQL_QUERY'
,p_value=>'select id from mpd_usuario where lower(login) = lower(:P9995_USERNAME)'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(196365331118257651)
,p_page_process_id=>wwv_flow_imp.id(196365023887257648)
,p_page_id=>9995
,p_name=>'p_pagina'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>true
,p_display_sequence=>30
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(196365422265257652)
,p_page_process_id=>wwv_flow_imp.id(196365023887257648)
,p_page_id=>9995
,p_name=>'p_encadeado'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>40
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(196365600969257653)
,p_page_process_id=>wwv_flow_imp.id(196365023887257648)
,p_page_id=>9995
,p_name=>'p_resultado'
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>true
,p_display_sequence=>50
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(196365691828257654)
,p_page_process_id=>wwv_flow_imp.id(196365023887257648)
,p_page_id=>9995
,p_name=>'p_resultado_mensagem'
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>true
,p_display_sequence=>60
);
wwv_flow_imp.component_end;
end;
/
