prompt --application/pages/page_09997
begin
--   Manifest
--     PAGE: 09997
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_page.create_page(
 p_id=>9997
,p_name=>unistr('Sele\00E7\00E3o de MFA')
,p_alias=>unistr('SELE\00C7\00C3O-DE-MFA')
,p_step_title=>unistr('Sele\00E7\00E3o de MFA')
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(370511843251763518)
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("body").on("click", "#" + ''LIST'' + " " + ''.t-MediaList-itemWrap'', function (e) {',
'    e.preventDefault();',
'            var selectedID = $(this).data("id");',
'            Itemselect(''P9997_MODELO_MFA'',selectedID);',
'})'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'selectItemList(''LIST'',1);',
'Itemselect(''P9997_MODELO_MFA'',1);'))
,p_step_template=>wwv_flow_imp.id(489135649323697598)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(647315696784075546)
,p_plug_name=>'MBP'
,p_region_template_options=>'#DEFAULT#:t-Login-region--headerHidden js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(489224069757697646)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(542249983054765498)
,p_plug_name=>'Logo'
,p_parent_plug_id=>wwv_flow_imp.id(647315696784075546)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--hiddenOverflow'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>10
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<img src="#APP_FILES#logo.png" style="height: 30px;" alt="Minha Figura"></img>',
'<div class="st-titulo-app">&APP_NAME.</div>',
'<div style="font-size: 18px;">&P9997_USERNAME.</div>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(542250085088765499)
,p_plug_name=>'New'
,p_parent_plug_id=>wwv_flow_imp.id(647315696784075546)
,p_region_css_classes=>'st-back-transp'
,p_icon_css_classes=>'fa-lock-check'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--customIcons:t-Alert--info:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(489141212303697602)
,p_plug_display_sequence=>20
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(600234579918141153)
,p_plug_name=>'Selecione o modelo'
,p_region_name=>'LIST'
,p_parent_plug_id=>wwv_flow_imp.id(542250085088765499)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--scrollBody'
,p_component_template_options=>'t-MediaList--showIcons:t-MediaList--showDesc:u-colors'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>30
,p_list_id=>wwv_flow_imp.id(419513428102244664)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(489261137203697672)
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<div class="st-titulo-login">Selecione o modelo de autentica\00E7\00E3o</div>'),
'<br>'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(419508654315244660)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(647315696784075546)
,p_button_name=>'SEND'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--link:t-Button--stretch:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(489279734794697688)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Avan\00E7ar')
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(419513097769244663)
,p_branch_name=>'Go to 9996'
,p_branch_action=>'f?p=&APP_ID.:9996:&SESSION.::&DEBUG.:9996:P9996_USERNAME,P9996_MODELO_MFA:&P9997_USERNAME.,&P9997_MODELO_MFA.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(419508654315244660)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(419509111029244660)
,p_name=>'P9997_USERNAME'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(647315696784075546)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(419509537247244661)
,p_name=>'P9997_MENSAGEM'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(647315696784075546)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(419510795463244662)
,p_name=>'P9997_LIST_CONTROL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(600234579918141153)
,p_display_as=>'PLUGIN_APEXUX.MPORAN.LISTCONTROL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'circle-checked-single',
  'attribute_02', 'end',
  'attribute_03', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(419511232100244662)
,p_name=>'P9997_MODELO_MFA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(600234579918141153)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(419511593394244662)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Gerar token e-mail'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_API_SEGURANCA'
,p_attribute_04=>'SEND_OTP'
,p_process_error_message=>'&P9997_MENSAGEM.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P9997_MODELO_MFA'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'2'
,p_process_success_message=>'&P9997_MENSAGEM.'
,p_internal_uid=>62029349985115685
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(419512111109244663)
,p_page_process_id=>wwv_flow_imp.id(419511593394244662)
,p_page_id=>9997
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P9997_MENSAGEM'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(419512581171244663)
,p_page_process_id=>wwv_flow_imp.id(419511593394244662)
,p_page_id=>9997
,p_name=>'p_user_name'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P9997_USERNAME'
);
wwv_flow_imp.component_end;
end;
/
