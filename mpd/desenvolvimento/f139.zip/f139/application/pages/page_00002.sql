prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'Home'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function notificacaoLidaJS(pID_NOTIFICAO) {    ',
'    apex.server.process ( "NOTIFICAO_LIDA",',
'    {f01:pID_NOTIFICAO},',
'    {',
'      ',
'',
'      success: function (data) {',
'            var region = apex.region("notification-menu");',
'            region.refresh();',
'            apex.message.clearErrors();',
unistr('            //apex.message.showPageSuccess("Publica\00E7\00E3o realizada com sucesso!");'),
'        },',
'        error: function (jqXHR, textStatus, errorThrown) {',
'            apex.message.clearErrors();',
'',
'            apex.message.showErrors([',
'                {',
'                    type: apex.message.TYPE.ERROR,',
'                    location: ["page"],',
unistr('                    message: "Erro ao marcar notifica\00E7\00E3o como lida: " + errorThrown,'),
'                    unsafe: false',
'                }',
'            ]);',
'        }  ',
'    }',
'  );',
'}',
'',
'function notificacaoExcluirJS(pID_NOTIFICAO) {',
'    apex.server.process ( "NOTIFICAO_EXCLUIR",',
'    {f01:pID_NOTIFICAO},',
'    {',
'      success: function (data) {',
'            var region = apex.region("notification-menu");',
'            region.refresh();',
'            apex.message.clearErrors();',
unistr('            //apex.message.showPageSuccess("Publica\00E7\00E3o realizada com sucesso!");'),
'        },',
'        error: function (jqXHR, textStatus, errorThrown) {',
'            apex.message.clearErrors();',
'',
'            apex.message.showErrors([',
'                {',
'                    type: apex.message.TYPE.ERROR,',
'                    location: ["page"],',
unistr('                    message: "Erro ao excluir notifica\00E7\00E3o: " + errorThrown,'),
'                    unsafe: false',
'                }',
'            ]);',
'        }  ',
'    }',
'  );',
'}'))
,p_step_template=>wwv_flow_imp.id(340985230573556208)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(163395457788286483)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody:margin-left-md:margin-right-md'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--featured force-fa-lg:t-Cards--displayIcons:t-Cards--4cols:t-Cards--hideBody:t-Cards--animColorFill'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>20
,p_location=>null
,p_list_id=>wwv_flow_imp.id(63133626663172921)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(341119925336556286)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(415936628103287070)
,p_plug_name=>'&APP_NAME.'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--iconsCircle'
,p_plug_template=>wwv_flow_imp.id(341080849849556259)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(65449152675861843)
,p_button_sequence=>90
,p_button_name=>'New'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(341144157120556305)
,p_button_image_alt=>'Executar'
,p_button_condition=>'ID_USUARIO_LOGADO'
,p_button_condition2=>'124'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65448915097861840)
,p_name=>'P2_IDIOMA'
,p_item_sequence=>50
,p_prompt=>'Idioma'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select DESCRICAO_IDIOMA d, ID r from srv_idioma'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when=>'ID_USUARIO_LOGADO'
,p_display_when2=>'124'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65448946310861841)
,p_name=>'P2_TIPO'
,p_item_sequence=>60
,p_prompt=>'Idioma'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:tela.;tela,botao.;botao,menu.;menu,artefato.;artefato,msg.;msg,coluna.;coluna,dominio.;dominio,etapa.;etapa,grupofuncionalidades.;grupofuncionalidades'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when=>'ID_USUARIO_LOGADO'
,p_display_when2=>'124'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65449093777861842)
,p_name=>'P2_SUCESSO'
,p_item_sequence=>70
,p_prompt=>'Resultado'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when=>'ID_USUARIO_LOGADO'
,p_display_when2=>'124'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65449326756861844)
,p_name=>'P2_SUCESSO_1'
,p_item_sequence=>80
,p_prompt=>'Resultado'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when=>'ID_USUARIO_LOGADO'
,p_display_when2=>'124'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(109438669184363190)
,p_name=>unistr('Notifica\00E7\00F5es')
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(109439180336363191)
,p_event_id=>wwv_flow_imp.id(109438669184363190)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_APEX.NOTIFICATION'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'    "refresh": 0,',
'    "mainIcon": "fa-bell",',
'    "mainIconColor": "white",',
'    "mainIconBackgroundColor": "rgba(70,70,70,0.9)",',
'    "mainIconBlinking": false,',
'    "counterBackgroundColor": "rgb(232, 55, 55 )",',
'    "counterFontColor": "white",',
'    "linkTargetBlank": false,',
'    "showAlways": false,',
'    "browserNotifications": {',
'        "enabled": true,',
'        "cutBodyTextAfter": 100,',
'        "link": false',
'    },',
'    "accept": {',
'        "color": "#44e55c",',
'        "icon": "fa-check"',
'    },',
'    "decline": {',
'        "color": "#b73a21",',
'        "icon": "fa-close"',
'    },',
'    "hideOnRefresh": true',
'}'))
,p_attribute_02=>'notification-menu'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    ''fa-tasks'' AS NOTE_ICON, ',
'    ''var(--a-palette-success)'' AS NOTE_ICON_COLOR,     ',
unistr('    ''Movimenta\00E7\00E3o no chamado'' AS NOTE_HEADER,'),
'    CASE WHEN SUBSTR(A.DESCRICAO, 23) = C.NOME||'' ''||C.SOBRENOME THEN',
unistr('    ''Voc\00EA foi direcionado como analista no chamado ''||A.ID_CHAMADO'),
'    WHEN SUBSTR(A.DESCRICAO, 24) = C.NOME||'' ''||C.SOBRENOME THEN',
unistr('    ''Voc\00EA foi direcionado como atendente no chamado ''||A.ID_CHAMADO   '),
'    WHEN A.DESCRICAO LIKE ''CHAMADO CANCELADO%'' THEN',
'    ''Chamado ''||A.ID_CHAMADO||'' cancelado''     ',
'    END AS NOTE_TEXT, ',
'    APEX_UTIL.PREPARE_URL(',
'          p_url => ''f?p='' || :APP_ALIAS || '':178:'' || :APP_SESSION ||''::NO::P178_ID:'' || A.ID,',
'          p_checksum_type => ''SESSION'', p_triggering_element => ''apex.jQuery(''''#notification-menu'''')'') AS NOTE_LINK, ',
'    ''var(--a-palette-success)'' AS NOTE_COLOR,',
'    ''javascript:notificacaoLidaJS(''||A.id||'');'' AS NOTE_ACCEPT,',
'    ''javascript:notificacaoExcluirJS(''||A.id||'');'' AS NOTE_DECLINE,',
'    0 AS NO_BROWSER_NOTIFICATION',
'FROM',
'    ADM_CHAMADO_MOVIMENTACAO A',
'    JOIN ADM_CHAMADO B ON B.ID = A.ID_CHAMADO ',
'    JOIN ADM_USUARIO C ON C.ID = B.ID_ANALISTA OR C.ID = B.ID_ATENDENTE',
'WHERE ',
'NVL(A.NOTIFICACAO,''N'') = ''N''',
'AND',
'(UPPER( SUBSTR(A.DESCRICAO, 23)) IN (SELECT UPPER(NOME||'' ''||SOBRENOME) FROM ADM_USUARIO WHERE UPPER(USERNAME) = UPPER(V(''APP_USER'')))',
'OR ',
'UPPER( SUBSTR(A.DESCRICAO, 24)) IN (SELECT UPPER(NOME||'' ''||SOBRENOME) FROM ADM_USUARIO WHERE UPPER(USERNAME) = UPPER(V(''APP_USER'')))',
'OR',
'A.DESCRICAO IN (SELECT A.DESCRICAO FROM ADM_CHAMADO_MOVIMENTACAO A',
'JOIN ADM_CHAMADO B ON B.ID = A.ID_CHAMADO',
'JOIN ADM_USUARIO C ON C.ID = B.ID_ANALISTA OR C.ID = B.ID_ATENDENTE ',
'WHERE UPPER(C.USERNAME) = UPPER(V(''APP_USER'')) ',
'AND A.DESCRICAO LIKE ''CHAMADO CANCELADO%'')',
')',
'AND (A.DESCRICAO LIKE ''Direcionado%'' OR A.DESCRICAO LIKE ''CHAMADO CANCELADO%'')',
'ORDER BY A.ID_CHAMADO',
''))
,p_attribute_05=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(65448066533861832)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'New'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'P2_SUCESSO_1'
,p_attribute_04=>'IGNORE'
,p_attribute_09=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(65449152675861843)
,p_internal_uid=>108318938194504105
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(109437887067363188)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'NOTIFICAO_LIDA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'      ',
'      update ADM_CHAMADO_MOVIMENTACAO',
'         set NOTIFICACAO = ''S''',
'       where id = to_number(apex_application.g_f01(1));',
'',
'    htp.prn(''{"result":"success"}'');',
'',
'    apex_json.open_object;  ',
'    apex_json.write(''success'', true);  ',
'    apex_json.close_object;',
'',
'exception',
'  when OTHERS then',
'    apex_json.open_object;',
'    apex_json.write(''success'', false);',
'    apex_json.write(''message'', sqlerrm);',
'    apex_json.close_object;',
'    htp.prn(''{"result":"ERROR"}'');',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>74059345056265043
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(109438334955363189)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'NOTIFICAO_EXCLUIR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'      ',
'      update ADM_CHAMADO_MOVIMENTACAO',
'         set NOTIFICACAO = ''S''',
'       where id = to_number(apex_application.g_f01(1));',
'',
'    htp.prn(''{"result":"success"}'');',
'',
'    apex_json.open_object;  ',
'    apex_json.write(''success'', true);  ',
'    apex_json.close_object;',
'',
'exception',
'  when OTHERS then',
'    apex_json.open_object;',
'    apex_json.write(''success'', false);',
'    apex_json.write(''message'', sqlerrm);',
'    apex_json.close_object;',
'    htp.prn(''{"result":"ERROR"}'');',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'NEVER'
,p_internal_uid=>74059792944265044
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(65448140440861833)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(65448066533861832)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'New_1'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'BO_SRV_TEXTO_TRADUZIDO'
,p_attribute_04=>'TRADUZIR_TEXTO_API2'
,p_internal_uid=>108319012101504106
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(65448246585861834)
,p_page_process_id=>wwv_flow_imp.id(65448140440861833)
,p_page_id=>2
,p_name=>'p_id_idioma'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P2_IDIOMA'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(65448333616861835)
,p_page_process_id=>wwv_flow_imp.id(65448140440861833)
,p_page_id=>2
,p_name=>'p_filtro'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P2_TIPO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(65448527253861836)
,p_page_process_id=>wwv_flow_imp.id(65448140440861833)
,p_page_id=>2
,p_name=>'p_pagina'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>true
,p_display_sequence=>30
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(65448618324861837)
,p_page_process_id=>wwv_flow_imp.id(65448140440861833)
,p_page_id=>2
,p_name=>'p_encadeado'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>40
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(65448643628861838)
,p_page_process_id=>wwv_flow_imp.id(65448140440861833)
,p_page_id=>2
,p_name=>'p_sucesso'
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>false
,p_display_sequence=>50
,p_value_type=>'ITEM'
,p_value=>'P2_SUCESSO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(65448758030861839)
,p_page_process_id=>wwv_flow_imp.id(65448140440861833)
,p_page_id=>2
,p_name=>'p_messages'
,p_direction=>'OUT'
,p_data_type=>'pkg_mensagem.message_record_table'
,p_display_sequence=>60
);
wwv_flow_imp.component_end;
end;
/
