prompt --application/pages/page_00273
begin
--   Manifest
--     PAGE: 00273
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_page.create_page(
 p_id=>273
,p_name=>unistr('Usu\00E1rios - Lista de funcionalidades')
,p_alias=>unistr('USU\00C1RIOS-LISTA-DE-FUNCIONALIDADES')
,p_page_mode=>'MODAL'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function traverseTree(node) {',
'    if (!node || !(node instanceof HTMLElement)) {',
unistr('        console.error("N\00F3 inv\00E1lido ou n\00E3o \00E9 um elemento HTML:", node);'),
'        return;',
'    }',
'',
unistr('    console.log("Percorrendo subn\00F3s do n\00F3:", node);'),
'',
unistr('    // Encontra todos os n\00F3s <li> filhos do n\00F3 atual'),
'    let children = node.querySelectorAll('':scope > ul > li'');',
'',
'    if (children.length === 0) {',
unistr('        console.log("Nenhum subn\00F3 encontrado para o n\00F3:", node);'),
'    }',
'',
'    children.forEach(child => {',
unistr('        // Encontra o elemento <span> que cont\00E9m o r\00F3tulo do n\00F3'),
'        let label = child.querySelector(''.a-TreeView-label'');',
'        ',
'        if (label) {',
unistr('            // Realiza uma a\00E7\00E3o com o texto do n\00F3, neste caso, imprime no console'),
unistr('            console.log("Subn\00F3 encontrado:", label.innerText.trim());'),
'        }',
'',
unistr('        // Chama a fun\00E7\00E3o recursivamente para percorrer os subn\00F3s'),
'        traverseTree(child);',
'    });',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'tituloHelpTela($v("P273_TELA_TITULO"),$v("P273_TELA_HELP"));',
'',
'apex.jQuery(document).ready(function() {',
unistr('    // Fun\00E7\00E3o para inicializar o item P273_ID_FUNCIONALIDADE'),
'    function initializeSelectedNodes() {',
'        // Array para armazenar IDs',
'        var selectedIds = [];',
'',
unistr('        // Seleciona todos os n\00F3s marcados'),
'        apex.jQuery("#myTree div[role=''tree''] .fa-square-selected-o").each(function() {',
unistr('            // Acessa o n\00F3 a partir do DOM'),
'            var $node = apex.jQuery(this).closest(".a-TreeView-node");',
'',
unistr('            // Obt\00E9m o valor do n\00F3 a partir do atributo data'),
'            var nodeId = $node.data("node-id");  ',
'',
unistr('            // Adiciona o ID ao array se n\00E3o estiver j\00E1 presente'),
'            if (nodeId && selectedIds.indexOf(nodeId) === -1) {',
'                selectedIds.push(nodeId);',
'            }',
'        });',
'',
unistr('        // Define os valores do item como uma lista separada por v\00EDrgulas'),
'        apex.item("P273_ID_FUNCIONALIDADE").setValue(selectedIds.join(","));       ',
'    }',
'',
unistr('    // Chama a fun\00E7\00E3o de inicializa\00E7\00E3o quando a p\00E1gina \00E9 carregada'),
'    initializeSelectedNodes();',
'});',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.texto-info {',
'    font-style: italic;',
'    text-align: justify;',
'    margin: 0;',
'}',
''))
,p_step_template=>wwv_flow_imp.id(489110489949697573)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--md'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(214477472018275351)
,p_plug_name=>'Texto_Mais_Info'
,p_region_css_classes=>'texto-info'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>100
,p_location=>null
,p_plug_source=>'tela.273.info'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(283450977531117053)
,p_plug_name=>'Funcionalidades'
,p_region_name=>'myTree'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>140
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    id,',
'    parent,',
'    icon,',
'    rpad('' '', 2 * level, '' '')',
'    || name name',
'FROM',
'    (',
'        SELECT',
'            --titulo          name,',
'            pkg_ui.retorna_label_grupo_funcionalidade(id) as name,',
'            id,',
'            id_nivel_pai parent,',
'            null icon',
'        FROM',
'            mpd_grupo_funcionalidade',
'        where id_tenant = :P273_ID_TENANT',
'        UNION ALL',
'        SELECT',
'            --descricao                ename,',
'            pkg_ui.retorna_titulo_tela(codigo_artefato) as ename,',
'            a.id,',
'            id_grupo_funcionalidade  parent,   ',
'            case when c.id is not null then ''fa fa-square-selected-o'' else ''fa fa-square-o'' end as icon',
'        FROM',
'            mpd_funcionalidade a',
'        join mpd_grupo_funcionalidade_funcionalidade b on b.id_funcionalidade = a.id    ',
'        left join mpd_papel_funcionalidade c on c.id_funcionalidade = b.id_funcionalidade and c.id_papel = :P273_ID  ',
'    )',
'START WITH',
'    parent IS NULL',
'CONNECT BY',
'    PRIOR id = parent    ',
'        '))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_JSTREE'
,p_ajax_items_to_submit=>'P273_ID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'activate_node_link_with', 'D',
  'default_icon_css_class', 'icon-tree-folder',
  'icon_css_class_column', 'ICON',
  'icon_type_css_class', 'a-Icon',
  'node_id_column', 'ID',
  'node_label_column', 'NAME',
  'node_value_column', 'ID',
  'order_siblings_by', 'NAME',
  'parent_key_column', 'PARENT',
  'start_tree_with', 'NULL',
  'tree_hierarchy', 'SQL',
  'tree_tooltip', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(283452838545117072)
,p_plug_name=>unistr('Formul\00E1rio')
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>150
,p_query_type=>'TABLE'
,p_query_table=>'MPD_PAPEL'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(302701145009332166)
,p_plug_name=>'Wizard'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-WizardSteps--displayLabels'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_list_id=>wwv_flow_imp.id(302767135421465846)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(489271776772697681)
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P273_VISUALIZAR'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(305270098367879271)
,p_button_sequence=>110
,p_button_name=>'RETRAIR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(489279883613697688)
,p_button_image_alt=>'retrair_l'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-minus-square-o'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(305270357637879274)
,p_button_sequence=>120
,p_button_name=>'EXPANDIR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(489279883613697688)
,p_button_image_alt=>'expandir_l'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-plus-square-o'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(283451763543117061)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(283450977531117053)
,p_button_name=>'Save'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(489279734794697688)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'botao.salvar.l'
,p_button_position=>'CENTER_BOTTOM'
,p_button_condition=>'P273_ID_PAGINA_ANTERIOR'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_grid_new_row=>'Y'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(198203295084712037)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(283450977531117053)
,p_button_name=>'Create'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(489279734794697688)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'botao.gravar.l'
,p_button_position=>'CENTER_BOTTOM'
,p_button_condition=>'P273_ID_PAGINA_ANTERIOR'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_row=>'Y'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(198203618519712040)
,p_name=>'P273_ID_PAGINA_ANTERIOR'
,p_item_sequence=>210
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(283453038045117074)
,p_name=>'P273_DATA_ALTERACAO'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(283452838545117072)
,p_item_source_plug_id=>wwv_flow_imp.id(283452838545117072)
,p_format_mask=>'DD-MON-YYYY HH24:MI:SS'
,p_source=>'DATA_ALTERACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(283453205654117075)
,p_name=>'P273_ID_USUARIO_INCLUIU'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(283452838545117072)
,p_item_source_plug_id=>wwv_flow_imp.id(283452838545117072)
,p_source=>'ID_USUARIO_INCLUIU'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(283453398223117077)
,p_name=>'P273_ID_TENANT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(283452838545117072)
,p_item_source_plug_id=>wwv_flow_imp.id(283452838545117072)
,p_source=>'ID_TENANT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(283453516515117078)
,p_name=>'P273_DATA_INCLUSAO'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(283452838545117072)
,p_item_source_plug_id=>wwv_flow_imp.id(283452838545117072)
,p_source=>'DATA_INCLUSAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(283656666419923829)
,p_name=>'P273_ID_USUARIO_ALTEROU'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(283452838545117072)
,p_item_source_plug_id=>wwv_flow_imp.id(283452838545117072)
,p_source=>'ID_USUARIO_ALTEROU'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(283656958423923832)
,p_name=>'P273_NOME_PAPEL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(283452838545117072)
,p_item_source_plug_id=>wwv_flow_imp.id(283452838545117072)
,p_source=>'NOME_PAPEL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(283657110975923833)
,p_name=>'P273_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(283452838545117072)
,p_item_source_plug_id=>wwv_flow_imp.id(283452838545117072)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(283658290659923845)
,p_name=>'P273_SUCESSO'
,p_item_sequence=>160
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(283658320453923846)
,p_name=>'P273_ID_FUNCIONALIDADE'
,p_source_data_type=>'CLOB'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(283452838545117072)
,p_item_source_plug_id=>wwv_flow_imp.id(283452838545117072)
,p_prompt=>'Funcionalidade'
,p_source=>'ID_FUNCIONALIDADE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'select descricao, id from mpd_funcionalidade'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(489277194088697685)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(286266915924724150)
,p_name=>'P273_CODIGO_ARTEFATO'
,p_item_sequence=>170
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(302701312321332167)
,p_name=>'P273_VISUALIZAR'
,p_item_sequence=>180
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303181779285186330)
,p_name=>'P273_TELA_TITULO'
,p_item_sequence=>190
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303181908557186331)
,p_name=>'P273_TELA_HELP'
,p_item_sequence=>200
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(283660172203923864)
,p_name=>'onPageLoad'
,p_event_sequence=>120
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(287397140390809356)
,p_event_id=>wwv_flow_imp.id(283660172203923864)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P273_ID_FUNCIONALIDADE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(305269952077879270)
,p_event_id=>wwv_flow_imp.id(283660172203923864)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_TREE_EXPAND'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(283450977531117053)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(197296672086656351)
,p_event_id=>wwv_flow_imp.id(283660172203923864)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P273_ID_FUNCIONALIDADE'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(id_funcionalidade, '':'') within group (order by id_funcionalidade) as ids',
'from mpd_papel_funcionalidade a',
'join mpd_funcionalidade b on b.id = a.id_funcionalidade',
'where id_papel = :p273_id;',
''))
,p_attribute_07=>'P273_ID'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(287397009140809354)
,p_name=>'onClickFuncionalidades'
,p_event_sequence=>140
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(283450977531117053)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'dblclick'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(287397113160809355)
,p_event_id=>wwv_flow_imp.id(287397009140809354)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'ORIGINAL NORTHONN'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var node = apex.jQuery("#myTree div[role=''tree'']").treeView("getSelectedNodes")[0];',
'var $nodeSelecionado = apex.jQuery("#myTree div[role=''tree''] .is-selected");',
'var parentNode = $nodeSelecionado.closest(".a-TreeView-node");',
'',
unistr('// Fun\00E7\00E3o para percorrer todos os n\00F3s filhos recursivamente'),
'function traverseTree(node, $element) {',
'    if (!node || !$element) return;',
'',
'    var nodeId = node.id;',
'    elemento(nodeId, node, $element);',
'',
unistr('    // Obt\00E9m os n\00F3s filhos no modelo e no DOM'),
'    var childNodes = node.children;',
'    var childElements = $element.find("> ul > li.a-TreeView-node");',
'',
unistr('    // Verifica se h\00E1 n\00F3s filhos'),
'    if (childNodes && childNodes.length > 0) {',
'        for (var i = 0; i < childNodes.length; i++) {',
'            traverseTree(childNodes[i], apex.jQuery(childElements[i]));',
'        }',
'    }',
'}',
'',
'if (node) {',
'    traverseTree(node, parentNode);',
'}',
'',
'function elemento(Id, no, $elemento) {',
'',
'    if ( $elemento.find(".a-Icon").hasClass(''icon-tree-folder'') ) {',
unistr('        return; // Pula este n\00F3'),
'    }    ',
'    ',
'    var list = apex.item("P273_ID_FUNCIONALIDADE").value;',
'    if (list.includes(Id)) {',
'        apex.item("P273_ID_FUNCIONALIDADE").removeValue(Id);',
'        no.icon = "fa fa-square-o";',
'        $elemento.find(".a-Icon").removeClass("fa-square-selected-o").addClass("fa-square-o");',
'    } else {',
'        apex.item("P273_ID_FUNCIONALIDADE").addValue(Id);',
'        no.icon = "fa fa-square-selected-o";',
'        $elemento.find(".a-Icon").removeClass("fa-square-o").addClass("fa-square-selected-o");',
'    }',
'}',
'',
'',
'// -------------------------------------------------------------'))
,p_build_option_id=>wwv_flow_imp.id(489109181809697564)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(197297648075656361)
,p_event_id=>wwv_flow_imp.id(287397009140809354)
,p_event_result=>'TRUE'
,p_action_sequence=>100
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var node = apex.jQuery("#myTree div[role=''tree'']").treeView("getSelectedNodes")[0];',
'var $nodeSelecionado = apex.jQuery("#myTree div[role=''tree''] .is-selected");',
'var parentNode = $nodeSelecionado.closest(".a-TreeView-node");',
'',
'function traverseTree(node, $element, shouldSelect) {',
'    if (!node || !$element) return;',
'',
'    var nodeId = node.id;',
'    var list = apex.item("P273_ID_FUNCIONALIDADE").value;',
'',
'    if ($element.find(".a-Icon").hasClass("icon-tree-folder")) {',
'        node.icon = shouldSelect ? "fa fa-square-selected-o" : "fa fa-square-o";',
'        $element.find(".a-Icon").removeClass(shouldSelect ? "fa-square-o" : "fa-square-selected-o")',
'                                 .addClass(shouldSelect ? "fa-square-selected-o" : "fa-square-o");',
'    } else {',
'        if (shouldSelect || (!list.includes(nodeId) && $element.find(".a-Icon").hasClass("fa-square-o"))) {',
'            apex.item("P273_ID_FUNCIONALIDADE").addValue(nodeId);',
'            node.icon = "fa fa-square-selected-o";',
'            $element.find(".a-Icon").removeClass("fa-square-o").addClass("fa-square-selected-o");',
'        } else {',
'            apex.item("P273_ID_FUNCIONALIDADE").removeValue(nodeId);',
'            node.icon = "fa fa-square-o";',
'            $element.find(".a-Icon").removeClass("fa-square-selected-o").addClass("fa-square-o");',
'        }',
'    }',
'',
'    var childNodes = node.children;',
'    var childElements = $element.find("> ul > li.a-TreeView-node");',
'',
'    if (childNodes && childNodes.length > 0) {',
'        for (var i = 0; i < childNodes.length; i++) {',
'            traverseTree(childNodes[i], apex.jQuery(childElements[i]), shouldSelect);',
'        }',
'    }',
'}',
'',
'function hasAnyChildUnselected(node, $element) {',
'    var hasUnselected = false;',
'    var childNodes = node.children;',
'    var childElements = $element.find("> ul > li.a-TreeView-node");',
'',
'    if (childNodes && childNodes.length > 0) {',
'        for (var i = 0; i < childNodes.length; i++) {',
'            var childNode = childNodes[i];',
'            var childElement = apex.jQuery(childElements[i]);',
'',
'            if (childElement.find(".a-Icon").hasClass("icon-tree-folder")) {',
'                if (hasAnyChildUnselected(childNode, childElement)) {',
'                    hasUnselected = true;',
'                    break;',
'                }',
'            } else {',
'                if (childElement.find(".a-Icon").hasClass("fa-square-o")) {',
'                    hasUnselected = true;',
'                    break;',
'                }',
'            }',
'        }',
'    }',
'',
'    return hasUnselected;',
'}',
'',
'if (node) {',
'    var hasUnselectedChildren = hasAnyChildUnselected(node, parentNode);',
'    traverseTree(node, parentNode, hasUnselectedChildren);    ',
'}',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(305270216925879272)
,p_name=>'onClickRETRAIR'
,p_event_sequence=>150
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(305270098367879271)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(305270315694879273)
,p_event_id=>wwv_flow_imp.id(305270216925879272)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_COLLAPSE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(283450977531117053)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(305270448520879275)
,p_event_id=>wwv_flow_imp.id(305270216925879272)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(305270098367879271)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(305270549951879276)
,p_event_id=>wwv_flow_imp.id(305270216925879272)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(305270357637879274)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(305270701629879277)
,p_name=>'onClickEXPANDIR'
,p_event_sequence=>160
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(305270357637879274)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(305270797086879278)
,p_event_id=>wwv_flow_imp.id(305270701629879277)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_EXPAND'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(283450977531117053)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(305644318871761429)
,p_event_id=>wwv_flow_imp.id(305270701629879277)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(305270357637879274)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(305644396738761430)
,p_event_id=>wwv_flow_imp.id(305270701629879277)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(305270098367879271)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(283657158859923834)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'inclui_registros'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'BO_MPD_PAPEL_FUNCIONALIDADE'
,p_attribute_04=>'INCLUI_REGISTROS'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'&P273_SUCESSO.'
,p_internal_uid=>100143039174684306
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(205435905285463236)
,p_page_process_id=>wwv_flow_imp.id(283657158859923834)
,p_page_id=>273
,p_name=>'p_sucesso'
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>false
,p_display_sequence=>70
,p_value_type=>'ITEM'
,p_value=>'P273_SUCESSO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(205435969156463237)
,p_page_process_id=>wwv_flow_imp.id(283657158859923834)
,p_page_id=>273
,p_name=>'p_messages'
,p_direction=>'OUT'
,p_data_type=>'pkg_mensagem.message_record_table'
,p_display_sequence=>80
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(206658529496278139)
,p_page_process_id=>wwv_flow_imp.id(283657158859923834)
,p_page_id=>273
,p_name=>'p_apagar'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>90
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'true'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(283657298953923835)
,p_page_process_id=>wwv_flow_imp.id(283657158859923834)
,p_page_id=>273
,p_name=>'p_id_tenant'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P273_ID_TENANT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(283657375219923836)
,p_page_process_id=>wwv_flow_imp.id(283657158859923834)
,p_page_id=>273
,p_name=>'p_id_papel'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P273_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(283657460251923837)
,p_page_process_id=>wwv_flow_imp.id(283657158859923834)
,p_page_id=>273
,p_name=>'p_id_funcionalidade'
,p_direction=>'IN'
,p_data_type=>'CLOB'
,p_has_default=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P273_ID_FUNCIONALIDADE'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(283657579261923838)
,p_page_process_id=>wwv_flow_imp.id(283657158859923834)
,p_page_id=>273
,p_name=>'p_id'
,p_direction=>'OUT'
,p_data_type=>'NUMBER'
,p_ignore_output=>true
,p_display_sequence=>40
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(283657627796923839)
,p_page_process_id=>wwv_flow_imp.id(283657158859923834)
,p_page_id=>273
,p_name=>'p_pagina'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>true
,p_display_sequence=>50
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>':APP_PAGE_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(283657790430923840)
,p_page_process_id=>wwv_flow_imp.id(283657158859923834)
,p_page_id=>273
,p_name=>'p_encadeado'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>60
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'true'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(283658457455923847)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'exclui_registros'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'BO_MPD_PAPEL_FUNCIONALIDADE'
,p_attribute_04=>'EXCLUI_REGISTROS'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(283451763543117061)
,p_process_when_type=>'NEVER'
,p_process_success_message=>'&P273_SUCESSO.'
,p_internal_uid=>100144337770684319
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(198203066559712035)
,p_page_process_id=>wwv_flow_imp.id(283658457455923847)
,p_page_id=>273
,p_name=>'p_id_papel'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>100
,p_value_type=>'ITEM'
,p_value=>'P273_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(205436180117463239)
,p_page_process_id=>wwv_flow_imp.id(283658457455923847)
,p_page_id=>273
,p_name=>'p_sucesso'
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>false
,p_display_sequence=>120
,p_value_type=>'ITEM'
,p_value=>'P273_SUCESSO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(205436224612463240)
,p_page_process_id=>wwv_flow_imp.id(283658457455923847)
,p_page_id=>273
,p_name=>'p_messages'
,p_direction=>'OUT'
,p_data_type=>'pkg_mensagem.message_record_table'
,p_display_sequence=>130
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(283659128249923854)
,p_page_process_id=>wwv_flow_imp.id(283658457455923847)
,p_page_id=>273
,p_name=>'p_encadeado'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>70
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(287397287051809357)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_01=>'P273_SUCESSO'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>103883167366569829
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(304750745181936452)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(283452838545117072)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>unistr('Process form Formul\00E1rio')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_required_patch=>wwv_flow_imp.id(489109181809697564)
,p_internal_uid=>121236625496696924
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(283453018251117073)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(283452838545117072)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Form Initialization'
,p_internal_uid=>99938898565877545
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(302702193702332176)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'retorna_titulo_help'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'RETORNA_TITULO_TELA'
,p_internal_uid=>119188074017092648
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(302702304436332177)
,p_page_process_id=>wwv_flow_imp.id(302702193702332176)
,p_page_id=>273
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'nvl(:P273_CODIGO_ARTEFATO,:APP_PAGE_ID)'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(302702406449332178)
,p_page_process_id=>wwv_flow_imp.id(302702193702332176)
,p_page_id=>273
,p_name=>'p_titulo'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P273_TELA_TITULO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(303181716846186329)
,p_page_process_id=>wwv_flow_imp.id(302702193702332176)
,p_page_id=>273
,p_name=>'p_help'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P273_TELA_HELP'
);
wwv_flow_imp.component_end;
end;
/
