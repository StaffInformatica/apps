prompt --application/pages/page_00428
begin
--   Manifest
--     PAGE: 00428
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_page.create_page(
 p_id=>428
,p_name=>unistr('Configura\00E7\00E3o')
,p_alias=>unistr('CONFIGURA\00C7\00C3O1')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Configura\00E7\00E3o')
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function copiarValor(origemId, destinoId) {',
'    var datePicker = document.getElementById(origemId);',
'    var valorOrigem = datePicker ? datePicker.value : ''''; ',
'    document.getElementById(destinoId).value = valorOrigem;',
'    console.log(document.getElementById(destinoId).value);',
'}',
'',
'function logValor(item){',
'    console.log(item);',
'    console.log(item.value);',
'    console.log(apex.item( "P9010_FILE1" ).getValue()); ',
'}',
'',
'function enviarParametros(dynamicItem,extra) {',
'    if (dynamicItem) {',
'        var dynamicArtefato = apex.item(''P9012_CODIGO_ARTEFATO'').value;        ',
'        var dynamicValue = dynamicItem.value;',
'        var dynamicId = extra == null ? dynamicItem.id : extra;',
'        console.log(dynamicArtefato);',
'        console.log(dynamicValue);',
'        console.log(dynamicId);',
'    } else {',
unistr('        console.error("O elemento din\00E2mico n\00E3o foi encontrado.");'),
'    }',
'    apex.server.process(',
'    "enviarParamentros", // Nome do processo PL/SQL definido no APEX',
'    {',
unistr('      x01: dynamicArtefato, // Primeiro par\00E2metro'),
unistr('      x02: dynamicId, // Segundo par\00E2metro'),
unistr('      x03: dynamicValue  // Terceiro par\00E2metro'),
'    },',
'    {',
'      dataType: ''text'',',
'      success: function(pData) {',
'        console.log("Dados enviados com sucesso:", pData);',
'      }',
'    }',
'  );',
'}',
'',
'function checkInputAndToggleClass(inputElement) {',
unistr('    // Verificar se o campo de entrada est\00E1 preenchido'),
'    console.log(inputElement.value);',
'    if (inputElement.value.trim() !== "") {',
unistr('        // Localizar a div pai que cont\00E9m "CONTAINER" no ID'),
'        let parentDiv = inputElement.closest("div[id*=''CONTAINER'']");',
'        ',
'        // Se a div for encontrada, adicionar a classe js-show-label',
'        if (parentDiv) {',
'            parentDiv.classList.add("js-show-label");',
'        }',
'    } else {',
'        // Se o valor estiver vazio, remover a classe js-show-label',
'        let parentDiv = inputElement.closest("div[id*=''CONTAINER'']");',
'        ',
'        // Remover a classe js-show-label se ela existir',
'        if (parentDiv) {',
'            parentDiv.classList.remove("js-show-label");',
'        }',
'    }',
'}',
'',
'// function toggleFileUpload() {',
'//     // Seleciona o elemento <a-dynamic-content>',
'//     var dynamicContent = document.querySelector(''a-dynamic-content'');',
'//     console.log(dynamicContent);',
unistr('//     // Verifica se o elemento existe e se cont\00E9m a palavra "mostra_file"'),
'//     if (dynamicContent && dynamicContent.innerHTML.includes(''mostra_file'')) {',
'//         // Se encontrar, mostra o item de upload de arquivo',
'//         apex.item(''P9010_FILE1'').show();',
'//     } else {',
unistr('//         // Caso contr\00E1rio, oculta o item de upload de arquivo'),
'//         apex.item(''P9010_FILE1'').hide();',
'//     }',
'// }',
'',
'document.addEventListener("DOMContentLoaded", function() {',
'  //   toggleFileUpload();  ',
'  var windowWidth = 400;  // Largura da janela popup',
'  var windowHeight = 450;  // Altura da janela popup',
'',
'  // Calcula o centro da tela',
'  var left = (window.screen.width - windowWidth) / 2;',
'  var top = (window.screen.height - windowHeight) / 2;',
'',
unistr('  // Modifica os par\00E2metros de ''left'' e ''top'' no popup gerado'),
'  var originalOpen = window.open;',
'  window.open = function(url, name, specs) {',
unistr('    // Adiciona ou substitui os par\00E2metros ''left'' e ''top'''),
'    specs = specs.replace(/left=\d+/, ''left='' + left);',
'    specs = specs.replace(/top=\d+/, ''top='' + top);',
'',
unistr('    // Se ''left'' e ''top'' n\00E3o existirem, adiciona os par\00E2metros'),
'    if (!specs.includes(''left='')) specs += '',left='' + left;',
'    if (!specs.includes(''top='')) specs += '',top='' + top;',
'',
unistr('    // Chama a fun\00E7\00E3o window.open original com as modifica\00E7\00F5es'),
'    return originalOpen.call(window, url, name, specs);',
'  };',
'});',
'',
'function  disableRowSelector ( ) { ',
'  var records = $( ".a-GV" ). first (). find ( ".a-GV-w-scroll .a-GV-row" ); ',
'  for ( var i = 0 ; i < records. length ; i++) { ',
'    var isReadonly = records. eq (i)[ 0 ]. matches ( ''.is-readonly'' ); ',
'    if (isReadonly) { ',
'        var dataId = records. eq (i). attr ( "data-id" ); ',
unistr('        // Remove a caixa de sele\00E7\00E3o dessa linha'),
'         $( ".a-GV" ). first (). find ( ".a-GV-row[data-id=''" + dataId + "''] .u-selector" ). removeClass (); ',
'    } ',
'  } ',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'tituloTela($v("P428_TELA_TITULO")+'' (''+$v("P428_CODIGO_ARTEFATO")+'')'');',
'',
'// Intercepta o fechamento nativo do dialog',
'apex.jQuery(document).on("dialogclose", ".ui-dialog", function(event, ui){',
'    var dlg = $(this).closest(".ui-dialog-content");',
'    if(dlg.attr("id") === "PXX_MODAL_B") { // substitua PXX_MODAL_B pelo Static ID da Modal B',
'        event.stopImmediatePropagation(); // impede fechar todas as modais',
unistr('        apex.navigation.dialog.close(false); // fecha s\00F3 esta modal'),
'    }',
'});',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.centro{',
'    display: grid;',
'    justify-items: center;',
'}',
'',
'.select option.selected {',
'    color: #888; /* Cor mais clara para parecer um placeholder */',
'    opacity: 0.5; /* Reduz a opacidade */',
'}',
'',
'tr.linha-desabilitada {',
'    background-color: #f2f2f2;',
'    opacity: 0.6;',
'    cursor: not-allowed;',
'}',
'',
'.t-Region-title {    ',
'    word-break: break-word;',
'    -webkit-hyphens: auto;',
'    hyphens: auto;',
'    font-size: var(--a-cv-title-font-size, 16px);',
'    font-weight: var(--a-cv-title-font-weight, 700);',
'    line-height: var(--a-cv-title-line-height, 20px);',
'    color: var(--a-cv-title-text-color);',
'}',
'',
'.a-GV-footer {',
'    display: none;',
'}',
'',
'.a-GV-header.u-tS.is-required.is-readonly  {',
'    pointer-events: none !important;',
'}',
'',
'.a-GV-frozen--startLast{',
'    border-right-width: 1px !important;',
'}',
'',
'#ITENS_SALDO_ig col[data-idx="1"] {',
'  width: 20% !important;',
'}',
'',
'#ITENS_SALDO_ig col[data-idx="2"] {',
'  width: 80% !important;',
'}',
'',
'/* Garante que o texto da primeira coluna possa quebrar normalmente */',
'#ITENS_SALDO_ig td:nth-child(2),',
'#ITENS_SALDO_ig th:nth-child(2) {',
'  white-space: normal !important;',
'  word-break: break-word;',
'}',
'',
'.texto-cabecalho{    ',
'    font-size: var(--a-field-input-font-size, 0.75rem);    ',
'    font-weight: var(--a-field-input-font-weight, 400);',
'}',
'',
'.is-readonly.apex-item-wrapper--display-only.opacity_grupo_funcionalidade {',
'    opacity: 0.9; ',
'    color: #444 !important; /* muda a cor do texto */',
'}',
'.my-readonly-textarea .t-Form-inputContainer label {',
'    top: 0 !important;',
'    transform: none !important;',
'    position: relative !important;',
'}',
'',
'#P428_VALOR_STRING_CONTAINER .apex-item-group--textarea {',
'  border-radius: 15px;            /* arredonda os cantos */',
'}',
'',
'#P428_VALOR_STRING_CONTAINER textarea {',
'',
'  border-radius: 15px;            /* opcional: acompanha a borda externa */',
'}',
'.t-Form-label{',
'    padding-block-start: 5px!important;',
'}',
'',
'',
'',
'',
'.centro{',
'    display: grid;',
'    justify-items: center;',
'}',
'',
'.select option.selected {',
'    color: #888; /* Cor mais clara para parecer um placeholder */',
'    opacity: 0.5; /* Reduz a opacidade */',
'}',
'',
'tr.linha-desabilitada {',
'    background-color: #f2f2f2;',
'    opacity: 0.6;',
'    cursor: not-allowed;',
'}',
'',
'.t-Region-title {    ',
'    word-break: break-word;',
'    -webkit-hyphens: auto;',
'    hyphens: auto;',
'    font-size: var(--a-cv-title-font-size, 16px);',
'    font-weight: var(--a-cv-title-font-weight, 700);',
'    line-height: var(--a-cv-title-line-height, 20px);',
'    color: var(--a-cv-title-text-color);',
'}',
'',
'.a-GV-footer {',
'    display: none;',
'}',
'',
'.a-GV-header.u-tS.is-required.is-readonly  {',
'    pointer-events: none !important;',
'}',
'',
'.a-GV-frozen--startLast{',
'    border-right-width: 1px !important;',
'}',
'',
'#ITENS_SALDO_ig col[data-idx="1"] {',
'  width: 20% !important;',
'}',
'',
'#ITENS_SALDO_ig col[data-idx="2"] {',
'  width: 80% !important;',
'}',
'',
'/* Garante que o texto da primeira coluna possa quebrar normalmente */',
'#ITENS_SALDO_ig td:nth-child(2),',
'#ITENS_SALDO_ig th:nth-child(2) {',
'  white-space: normal !important;',
'  word-break: break-word;',
'}',
'',
'.texto-cabecalho{    ',
'    font-size: var(--a-field-input-font-size, 0.75rem);    ',
'    font-weight: var(--a-field-input-font-weight, 400);',
'}',
'',
'.is-readonly.apex-item-wrapper--display-only.opacity_grupo_funcionalidade {',
'    opacity: 0.9; ',
'    color: #444 !important; /* muda a cor do texto */',
'}',
'.my-readonly-textarea .t-Form-inputContainer label {',
'    top: 0 !important;',
'    transform: none !important;',
'    position: relative !important;',
'}',
'',
'#P428_VALOR_STRING_CONTAINER .apex-item-group--textarea {',
'  border-radius: 15px;            /* arredonda os cantos */',
'}',
'',
'#P428_VALOR_STRING_CONTAINER textarea {',
'',
'  border-radius: 15px;            /* opcional: acompanha a borda externa */',
'}',
'.t-Form-label{',
'    padding-block-start: 5px!important;',
'}',
''))
,p_step_template=>wwv_flow_imp.id(489110489949697573)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--lg'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(622237209740164391)
,p_plug_name=>'Alterar'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody:t-Form--large'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>70
,p_query_type=>'TABLE'
,p_query_table=>'MPD_CONFIGURACAO_NG'
,p_include_rowid_column=>true
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(372310544287902109)
,p_plug_name=>'teste'
,p_title=>'teste'
,p_parent_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_region_css_classes=>'is-readonly apex-item-wrapper--display-only'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(489179976861697624)
,p_plug_display_sequence=>290
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- DECLARE',
'--     l_sql VARCHAR2(4000);',
'--     l_colunas VARCHAR2(4000);',
'--     l_tabela  VARCHAR2(100);',
'-- BEGIN',
'--     -- Primeiro pega a tabela',
'--     SELECT B.NOME_ENTIDADE',
'--       INTO l_tabela',
'--       FROM SRV_ENTIDADE B',
'--      WHERE B.ID = :P428_ID_ENTIDADE;',
'',
'--     -- Pega as colunas que queremos concatenar',
'--     SELECT LISTAGG(A.NOME_COLUNA,'' || '''' - '''' ||'') WITHIN GROUP (ORDER BY A.NOME_COLUNA)',
'--       INTO l_colunas',
'--       FROM SRV_ENTIDADE_COLUNA A',
'--      WHERE A.ID_ENTIDADE = :P428_ID_ENTIDADE',
'--        AND A.REFERENCIA IS NOT NULL;',
'',
'--     -- Monta o SQL final',
'--     l_sql := ''SELECT '' || l_colunas || '' AS display_value FROM '' || l_tabela;',
'',
'--     RETURN l_sql;',
'',
'-- EXCEPTION',
'--     WHEN NO_DATA_FOUND THEN',
'--         RETURN ''SELECT ''''Nenhum registro'''' AS display_value FROM dual'';',
'--     WHEN OTHERS THEN',
unistr('--         RETURN ''SELECT ''''Erro ao gerar relat\00F3rio'''' AS display_value FROM dual'';'),
'-- END;',
'DECLARE',
'    l_sql VARCHAR2(4000);',
'    l_colunas VARCHAR2(4000);',
'    l_tabela  VARCHAR2(100);',
'BEGIN',
'    -- Pega a tabela da entidade',
'    SELECT B.NOME_ENTIDADE',
'      INTO l_tabela',
'      FROM SRV_ENTIDADE B',
'     WHERE B.ID = :P428_ID_ENTIDADE;',
'',
'    -- Pega as colunas que queremos concatenar',
'    SELECT LISTAGG(A.NOME_COLUNA,'' || '''' - '''' ||'') WITHIN GROUP (ORDER BY A.NOME_COLUNA)',
'      INTO l_colunas',
'      FROM SRV_ENTIDADE_COLUNA A',
'     WHERE A.ID_ENTIDADE = :P428_ID_ENTIDADE',
'       AND A.REFERENCIA IS NOT NULL;',
'',
'    -- Monta o SQL final filtrando pelos IDs do MPD_CONFIGURACAO_NG',
'    l_sql := ''',
'        SELECT '' || l_colunas || '' AS display_value',
'        FROM '' || l_tabela || '' T',
'        WHERE T.ID IN (',
'            SELECT TO_NUMBER(REGEXP_SUBSTR(NC.ID_REGISTRO, ''''[^:]+'''', 1, LEVEL))',
'            FROM MPD_CONFIGURACAO_NG NC',
'            WHERE NC.ID_ENTIDADE = :P428_ID_ENTIDADE',
'            CONNECT BY LEVEL <= REGEXP_COUNT(NC.ID_REGISTRO, '''':'''') + 1',
'            AND PRIOR NC.ID_REGISTRO = NC.ID_REGISTRO',
'            AND PRIOR SYS_GUID() IS NOT NULL',
'        )',
'        ORDER BY 1',
'    '';',
'',
'    RETURN l_sql;',
'',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'        RETURN ''SELECT ''''Nenhum registro'''' AS display_value FROM dual'';',
'    WHEN OTHERS THEN',
unistr('        RETURN ''SELECT ''''Erro ao gerar relat\00F3rio'''' AS display_value FROM dual'';'),
'END;',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P428_IND_TIPO_DADO'
,p_plug_display_when_cond2=>'IM'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'teste'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(372312831862902132)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'JONICLEI'
,p_internal_uid=>267048125849403022
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(375385037430674508)
,p_db_column_name=>'DISPLAY_VALUE'
,p_display_order=>10
,p_column_identifier=>'Z'
,p_column_label=>unistr('Identifica\00E7\00E3o')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(375411753294682792)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'748216'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(801741642576563061)
,p_plug_name=>'Steps'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#:t-WizardSteps--displayLabels'
,p_plug_template=>wwv_flow_imp.id(489194609147697632)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_list_id=>wwv_flow_imp.id(202941028788352728)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(489271776772697681)
,p_required_patch=>wwv_flow_imp.id(489109181809697564)
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(801742125008564708)
,p_plug_name=>'Footer'
,p_region_css_classes=>'u-margin-bottom-none'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(489149217063697608)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(202970478231038040)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(801742125008564708)
,p_button_name=>'inclui_e_fecha'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(489279734794697688)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Gravar'
,p_button_position=>'NEXT'
,p_icon_css_classes=>'fa-save'
,p_required_patch=>wwv_flow_imp.id(489109181809697564)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(202970057325038041)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(801742125008564708)
,p_button_name=>'inclui_e_fecha_1'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(489279734794697688)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Gravar'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-save'
,p_required_patch=>wwv_flow_imp.id(489109181809697564)
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(203023587230037851)
,p_branch_name=>'goto_anterior'
,p_branch_action=>'P428_URL_ANTERIOR'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'BRANCH_TO_URL_IDENT_BY_ITEM'
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(203023954915037850)
,p_branch_name=>'goto_proximo'
,p_branch_action=>'P428_URL_PROXIMO'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'BRANCH_TO_URL_IDENT_BY_ITEM'
,p_branch_sequence=>30
,p_branch_condition_type=>'REQUEST_IN_CONDITION'
,p_branch_condition=>'PROXIMO'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(203024321886037849)
,p_branch_name=>'Grava'
,p_branch_action=>unistr('f?p=&APP_ID.:9000:&SESSION.::&DEBUG.:CR,9000:P9000_LABEL_TELA,P9000_PAGINA,P9000_ID:Op\00E7\00F5es,TD882,&P428_PARAMETRO.&success_msg=#SUCCESS_MSG#')
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>40
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182505876439200057)
,p_name=>'P428_IND_GRUPO_FUNCIONALIDADE'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>320
,p_item_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_item_source_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_prompt=>'Ind Grupo Funcionalidade'
,p_source=>'IND_GRUPO_FUNCIONALIDADE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>20
,p_field_template=>wwv_flow_imp.id(489277194088697685)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_required_patch=>wwv_flow_imp.id(489109181809697564)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182505908773200058)
,p_name=>'P428_DESCRICAO_CONFIGURACAO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>330
,p_item_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_item_source_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_prompt=>'Descricao Configuracao'
,p_source=>'DESCRICAO_CONFIGURACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>200
,p_field_template=>wwv_flow_imp.id(489277194088697685)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_required_patch=>wwv_flow_imp.id(489109181809697564)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182506028991200059)
,p_name=>'P428_VALOR_DOMINIO_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>340
,p_item_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_item_source_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_prompt=>'Valor Dominio'
,p_source=>'VALOR_DOMINIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>40
,p_field_template=>wwv_flow_imp.id(489277194088697685)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_required_patch=>wwv_flow_imp.id(489109181809697564)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(204624877898589339)
,p_name=>'P427_ID_ENTIDADEE_L'
,p_item_sequence=>220
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(204624964410589340)
,p_name=>'P427_VALOR_STRINGG_L'
,p_item_sequence=>230
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(204625067429589341)
,p_name=>'P427_VALOR_DOMINIOO_L'
,p_item_sequence=>240
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(204625181095589342)
,p_name=>'P427_VALOR_INTEIROO_L'
,p_item_sequence=>250
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(204625240954589343)
,p_name=>'P427_VALOR_DATAA_L'
,p_item_sequence=>260
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(204625387093589344)
,p_name=>'P427_VALOR_DATA_HORAA_L'
,p_item_sequence=>270
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(204625483042589345)
,p_name=>'P427_DECIMALL_L'
,p_item_sequence=>280
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(204625507046589346)
,p_name=>'P427_ID_REGISTROO_L'
,p_item_sequence=>290
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(204625699338589347)
,p_name=>'P427_ID_USUARIO_ALTEROU_L'
,p_item_sequence=>300
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(204625802174589348)
,p_name=>'P427_DATA_ALTERACAO_L'
,p_item_sequence=>310
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(372314573786902083)
,p_name=>'P428_ENTIDADESS_1'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- -- -- select replace(',
'-- -- --          nvl(',
'-- -- --            (select id_registro',
'-- -- --               from MPD_CONFIGURACAO_NG',
'-- -- --              where id = :P327_PARAMETRO),',
'-- -- --            ''''',
'-- -- --          ),',
'-- -- --          '':'',',
'-- -- --          chr(10)',
'-- -- --        ) as display_value',
'-- -- -- from dual',
'',
'-- -- -- Passo 1: separar os IDs usando apex_string.split',
'-- -- WITH ids AS (',
'-- --     SELECT trim(column_value) AS id_val',
'-- --     FROM table(',
'-- --         apex_string.split(''32:33:44'', '':'')  -- aqui pode ser :P327_PARAMETRO',
'-- --     )',
'-- -- )',
'-- -- -- Passo 2: usar os IDs em um select',
'-- -- aqui eu preciso pegar assim : ',
'',
'-- -- select ',
'',
'-- -- SELECT t.nome_coluna',
'-- -- FROM ids i',
'-- -- JOIN sua_tabela t ON t.id = i.id_val;',
'',
'',
'',
'-- declare',
'--     l_sql    varchar2(4000);',
'--     l_tabela varchar2(30);',
'--     l_coluna varchar2(30);',
'-- begin',
unistr('--     tenta buscar a tabela da configura\00E7\00E3o'),
'--     begin',
'--         select b.nome_entidade',
'--           into l_tabela',
'--           from MPD_CONFIGURACAO_NG a',
'--           join srv_entidade b on b.id = a.id_entidade',
'--          where a.id = :P327_PARAMETRO;',
'--     exception',
'--         when no_data_found then',
unistr('--             l_tabela := null; -- n\00E3o achou nada'),
'--     end;',
'',
unistr('--     se n\00E3o encontrou a tabela, retorna SQL vazio'),
'--     if l_tabela is null then',
'--         return ''select null display_value, null return_value from dual where 1 = 0'';',
'--     end if;',
'',
unistr('--     tenta identificar uma coluna de nome ou descri\00E7\00E3o'),
'--     begin',
'--         select column_name',
'--           into l_coluna',
'--           from all_tab_columns',
'--          where table_name = upper(l_tabela)',
'--            and (column_name like ''%NOME%'' or column_name like ''%DESCRICAO%'')',
'--            and column_id = (',
'--                 select min(column_id)',
'--                   from all_tab_columns',
'--                  where table_name = upper(l_tabela)',
'--                    and (column_name like ''%NOME%'' or column_name like ''%DESCRICAO%'')',
'--            );',
'--     exception',
'--         when no_data_found then',
'--             l_coluna := ''ID''; -- fallback',
'--     end;',
'',
'--     monta SQL final',
'--     l_sql := ''select '' || l_coluna || '' as display_value, id as return_value from '' || l_tabela ;',
'',
'--     return l_sql;',
'-- end;',
'',
'',
'',
'declare',
'    l_sql    varchar2(4000);',
'    l_tabela varchar2(30);',
'    l_coluna varchar2(30);',
'begin',
unistr('    -- pega a tabela da configura\00E7\00E3o'),
'    begin',
'        select b.nome_entidade',
'          into l_tabela',
'          from MPD_CONFIGURACAO_NG a',
'          join srv_entidade b on b.id = a.id_entidade',
'         where a.id = :P327_PARAMETRO;',
'    exception',
'        when no_data_found then',
'            return ''select null display_value, null return_value from dual where 1=0'';',
'    end;',
'',
'    -- pega coluna de nome ou descricao',
'    begin',
'        select column_name',
'          into l_coluna',
'          from all_tab_columns',
'         where table_name = upper(l_tabela)',
'           and (column_name like ''%NOME%'' or column_name like ''%DESCRICAO%'')',
'           and column_id = (',
'                select min(column_id)',
'                  from all_tab_columns',
'                 where table_name = upper(l_tabela)',
'                   and (column_name like ''%NOME%'' or column_name like ''%DESCRICAO%'')',
'           );',
'    exception',
'        when no_data_found then',
'            l_coluna := ''ID'';',
'    end;',
'',
'    -- monta SQL final usando apex_string.split',
'    l_sql := ''select t.'' || l_coluna || '' as display_value, t.id as return_value '' ||',
'             ''from '' || l_tabela || '' t '' ||',
'             ''join table(apex_string.split('' ||',
'             ''    nvl((select id_registro from MPD_CONFIGURACAO_NG where id = :P327_PARAMETRO), ''''''''), '''':'''')'' ||',
'             '') s on to_number(trim(s.column_value)) = t.id'';',
'',
'    return l_sql;',
'end;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'PLUGIN_APEXUX.MPORAN.LISTCONTROL'
,p_display_when=>'P428_IND_TIPO_DADO'
,p_display_when2=>'IM'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_required_patch=>wwv_flow_imp.id(489109181809697564)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'radio',
  'attribute_02', 'start',
  'attribute_03', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(446262170404246799)
,p_name=>'P428_EMPRESA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_prompt=>'&P427_ID_TENANT_L.'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(489277194088697685)
,p_item_css_classes=>'is-readonly apex-item-wrapper--display-only '
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(446262406354246801)
,p_name=>'P428_DESCRICAO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_prompt=>'&P427_DESCRICAO_CONFIGURACAO_L.'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(489277194088697685)
,p_item_css_classes=>'is-readonly apex-item-wrapper--display-only'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(446340918427283499)
,p_name=>'P428_ROWID'
,p_source_data_type=>'ROWID'
,p_is_primary_key=>true
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_item_source_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_source=>'ROWID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(446341119812283501)
,p_name=>'P428_CODIGO_CONFIGURACAO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_item_source_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_source=>'CODIGO_CONFIGURACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(446422624242466953)
,p_name=>'P428_IND_TIPO_DADO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_item_source_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_source=>'IND_TIPO_DADO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(446422769789466954)
,p_name=>'P428_VALOR_INTEIRO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_item_source_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_prompt=>'&P427_VALOR_INTEIRO_L.'
,p_source=>'VALOR_INTEIRO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_display_when=>'P428_IND_TIPO_DADO'
,p_display_when2=>'IN'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(489277194088697685)
,p_item_css_classes=>'is-readonly apex-item-wrapper--display-only '
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(446422858221466955)
,p_name=>'P428_VALOR_DECIMAL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_item_source_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_prompt=>'&P427_VALOR_DECIMAL_L.'
,p_source=>'VALOR_DECIMAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_display_when=>'P428_IND_TIPO_DADO'
,p_display_when2=>'DE'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(489277194088697685)
,p_item_css_classes=>'is-readonly apex-item-wrapper--display-only '
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(446422944251466956)
,p_name=>'P428_QUANTIDADE_DECIMAL'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_item_source_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_source=>'QUANTIDADE_DECIMAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when=>'P428_IND_TIPO_DADO'
,p_display_when2=>'DE'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(446423084034466957)
,p_name=>'P428_VALOR_STRING'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_item_source_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_prompt=>'&P427_VALOR_STRING_L.'
,p_source=>'VALOR_STRING'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>400
,p_cHeight=>3
,p_display_when=>'P428_IND_TIPO_DADO'
,p_display_when2=>'ST'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(489277194088697685)
,p_item_css_classes=>'is-readonly apex-item-wrapper--display-only '
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(446423127804466958)
,p_name=>'P428_VALOR_DATA'
,p_source_data_type=>'DATE'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_item_source_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_prompt=>'&P427_VALOR_DATA_L.'
,p_source=>'VALOR_DATA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_display_when=>'P428_IND_TIPO_DADO'
,p_display_when2=>'DT'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(489277194088697685)
,p_item_css_classes=>'is-readonly apex-item-wrapper--display-only '
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(446423247138466959)
,p_name=>'P428_VALOR_DATA_HORA'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_item_source_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_prompt=>'&P427_VALOR_DATA_HORA_L.'
,p_source=>'VALOR_DATA_HORA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_display_when=>'P428_IND_TIPO_DADO'
,p_display_when2=>'DH'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(489277194088697685)
,p_item_css_classes=>'is-readonly apex-item-wrapper--display-only '
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'Y',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(446423310758466960)
,p_name=>'P428_ID_ENTIDADE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_item_source_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_source=>'ID_ENTIDADE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(446423468785466961)
,p_name=>'P428_ID_REGISTRO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_item_source_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_source=>'ID_REGISTRO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(446423531476466962)
,p_name=>'P428_VALOR_DOMINIO'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_prompt=>'&P427_VALOR_DOMINIO_L.'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- select id_registro',
'--   from MPD_CONFIGURACAO_NG',
'--  where id = :P428_PARAMETRO',
unistr('--    and instr(id_registro, '':'') = 0 -- s\00F3 traz se n\00E3o tiver '':'''),
'',
'',
'--   select',
'--     b.descricao_dominio as display_value,',
'--     b.id ',
'-- from MPD_CONFIGURACAO_NG a',
'-- join MPD_CONFIGURACAO_NG_dominio b on b.id_configuracao = a.id',
'-- where a.id = :P428_PARAMETRO',
'-- order by b.descricao_dominio',
'',
'',
'select valor_dominio',
'  from MPD_CONFIGURACAO_NG',
' where id = :P428_PARAMETRO'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    b.descricao_dominio as display_value,',
'    b.id as return_value',
'from MPD_CONFIGURACAO_NG a',
'join MPD_CONFIGURACAO_NG_DOMINIO b on b.id_configuracao = a.id',
'where a.id = :P428_PARAMETRO',
'order by b.descricao_dominio',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when=>'P428_IND_TIPO_DADO'
,p_display_when2=>'DO'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(489277194088697685)
,p_item_css_classes=>'is-readonly apex-item-wrapper--display-only '
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(446723611905299952)
,p_name=>'P428_ENTIDADESS'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_prompt=>unistr('Identifica\00E7\00E3o')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- -- -- select replace(',
'-- -- --          nvl(',
'-- -- --            (select id_registro',
'-- -- --               from MPD_CONFIGURACAO_NG',
'-- -- --              where id = :P327_PARAMETRO),',
'-- -- --            ''''',
'-- -- --          ),',
'-- -- --          '':'',',
'-- -- --          chr(10)',
'-- -- --        ) as display_value',
'-- -- -- from dual',
'',
'-- -- -- Passo 1: separar os IDs usando apex_string.split',
'-- -- WITH ids AS (',
'-- --     SELECT trim(column_value) AS id_val',
'-- --     FROM table(',
'-- --         apex_string.split(''32:33:44'', '':'')  -- aqui pode ser :P327_PARAMETRO',
'-- --     )',
'-- -- )',
'-- -- -- Passo 2: usar os IDs em um select',
'-- -- aqui eu preciso pegar assim : ',
'',
'-- -- select ',
'',
'-- -- SELECT t.nome_coluna',
'-- -- FROM ids i',
'-- -- JOIN sua_tabela t ON t.id = i.id_val;',
'',
'',
'',
'-- declare',
'--     l_sql    varchar2(4000);',
'--     l_tabela varchar2(30);',
'--     l_coluna varchar2(30);',
'-- begin',
unistr('--     tenta buscar a tabela da configura\00E7\00E3o'),
'--     begin',
'--         select b.nome_entidade',
'--           into l_tabela',
'--           from MPD_CONFIGURACAO_NG a',
'--           join srv_entidade b on b.id = a.id_entidade',
'--          where a.id = :P327_PARAMETRO;',
'--     exception',
'--         when no_data_found then',
unistr('--             l_tabela := null; -- n\00E3o achou nada'),
'--     end;',
'',
unistr('--     se n\00E3o encontrou a tabela, retorna SQL vazio'),
'--     if l_tabela is null then',
'--         return ''select null display_value, null return_value from dual where 1 = 0'';',
'--     end if;',
'',
unistr('--     tenta identificar uma coluna de nome ou descri\00E7\00E3o'),
'--     begin',
'--         select column_name',
'--           into l_coluna',
'--           from all_tab_columns',
'--          where table_name = upper(l_tabela)',
'--            and (column_name like ''%NOME%'' or column_name like ''%DESCRICAO%'')',
'--            and column_id = (',
'--                 select min(column_id)',
'--                   from all_tab_columns',
'--                  where table_name = upper(l_tabela)',
'--                    and (column_name like ''%NOME%'' or column_name like ''%DESCRICAO%'')',
'--            );',
'--     exception',
'--         when no_data_found then',
'--             l_coluna := ''ID''; -- fallback',
'--     end;',
'',
'--     monta SQL final',
'--     l_sql := ''select '' || l_coluna || '' as display_value, id as return_value from '' || l_tabela ;',
'',
'--     return l_sql;',
'-- end;',
'',
'',
'',
'declare',
'    l_sql    varchar2(4000);',
'    l_tabela varchar2(30);',
'    l_coluna varchar2(30);',
'begin',
unistr('    -- pega a tabela da configura\00E7\00E3o'),
'    begin',
'        select b.nome_entidade',
'          into l_tabela',
'          from MPD_CONFIGURACAO_NG a',
'          join srv_entidade b on b.id = a.id_entidade',
'         where a.id = :P327_PARAMETRO;',
'    exception',
'        when no_data_found then',
'            return ''select null display_value, null return_value from dual where 1=0'';',
'    end;',
'',
'    -- pega coluna de nome ou descricao',
'    begin',
'        select column_name',
'          into l_coluna',
'          from all_tab_columns',
'         where table_name = upper(l_tabela)',
'           and (column_name like ''%NOME%'' or column_name like ''%DESCRICAO%'')',
'           and column_id = (',
'                select min(column_id)',
'                  from all_tab_columns',
'                 where table_name = upper(l_tabela)',
'                   and (column_name like ''%NOME%'' or column_name like ''%DESCRICAO%'')',
'           );',
'    exception',
'        when no_data_found then',
'            l_coluna := ''ID'';',
'    end;',
'',
'    -- monta SQL final usando apex_string.split',
'    l_sql := ''select t.'' || l_coluna || '' as display_value, t.id as return_value '' ||',
'             ''from '' || l_tabela || '' t '' ||',
'             ''join table(apex_string.split('' ||',
'             ''    nvl((select id_registro from MPD_CONFIGURACAO_NG where id = :P327_PARAMETRO), ''''''''), '''':'''')'' ||',
'             '') s on to_number(trim(s.column_value)) = t.id'';',
'',
'    return l_sql;',
'end;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_display_when=>'P428_IND_TIPO_DADO'
,p_display_when2=>'IM'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(489277168096697685)
,p_item_css_classes=>'is-readonly apex-item-wrapper--display-only  my-readonly-textarea'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge'
,p_required_patch=>wwv_flow_imp.id(489109181809697564)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(446724064557299956)
,p_name=>'P428_ENTIDADE'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_prompt=>'&P427_ID_ENTIDADE_L.'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id_registro',
'  from MPD_CONFIGURACAO_NG',
' where id = :P428_PARAMETRO',
unistr('   and instr(id_registro, '':'') = 0 -- s\00F3 traz se n\00E3o tiver '':''')))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql      varchar2(4000);',
'    l_tabela   varchar2(30);',
'    l_coluna   varchar2(30);',
'begin',
'    -- tenta buscar a tabela',
'    begin',
'        select b.nome_entidade ',
'          into l_tabela',
'        from MPD_CONFIGURACAO_NG a',
'        join srv_entidade b on b.id = a.id_entidade',
'        where a.id = :P428_PARAMETRO;',
'    exception',
'        when no_data_found then',
'            l_tabela := null;',
'    end;',
'',
'    -- tenta buscar coluna',
'    if l_tabela is not null then',
'        begin',
'            select column_name',
'              into l_coluna',
'              from all_tab_columns',
'             where table_name = upper(l_tabela)',
'               and (column_name like ''%NOME%'' or column_name like ''%DESCRICAO%'')',
'               and column_id = (',
'                    select min(column_id)',
'                      from all_tab_columns',
'                     where table_name = upper(l_tabela)',
'                       and (column_name like ''%NOME%'' or column_name like ''%DESCRICAO%'')',
'               );',
'        exception',
'            when no_data_found then',
'                l_coluna := ''ID'';',
'        end;',
'',
'        l_sql := ''select ''||l_coluna||'' as display_value, id as return_value from '' || l_tabela;',
'    else',
unistr('        -- se n\00E3o achou nada, devolve query vazia'),
'        l_sql := ''select null as display_value, null as return_value from dual where 1=2'';',
'    end if;',
'',
'    return l_sql;',
'end;',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when=>'P428_IND_TIPO_DADO'
,p_display_when2=>'ID'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(489277194088697685)
,p_item_css_classes=>'is-readonly apex-item-wrapper--display-only '
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(446724182447299957)
,p_name=>'P428_VALOR_DOMINIOS1'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_prompt=>'DOMINIOS'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select trim(column_value)',
'  from table(',
'         apex_string.split(',
'             nvl(',
'                 (select valor_dominio',
'                    from MPD_CONFIGURACAO_NG',
'                   where id = :P428_PARAMETRO),',
'                 ''''',
'             ),',
'             '':''',
'         )',
'       )',
' where trim(column_value) is not null'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql varchar2(4000);',
'begin',
'    if :P428_PARAMETRO is not null then',
'        l_sql :=',
'            ''select',
'                 b.descricao_dominio as display_value,',
'                 b.id as return_value',
'             from MPD_CONFIGURACAO_NG a',
'             join MPD_CONFIGURACAO_NG_DOMINIO b on b.id_configuracao = a.id',
'             where a.id = '' || :P428_PARAMETRO || ''',
'             order by b.descricao_dominio'';',
'    else',
'        l_sql := ''select null as display_value, null as return_value from dual where 1=2'';',
'    end if;',
'',
'    return l_sql;',
'end;',
''))
,p_cHeight=>5
,p_display_when=>'P428_IND_TIPO_DADO'
,p_display_when2=>'DM'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(489277194088697685)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_required_patch=>wwv_flow_imp.id(489109181809697564)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_controls', 'ALL')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(446724682968299962)
,p_name=>'P428_VALOR_DOMINIOS'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_prompt=>'&P427_VALOR_DOMINIO_L.'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select trim(column_value)',
'  from table(',
'         apex_string.split(',
'             nvl(',
'                 (select valor_dominio',
'                    from MPD_CONFIGURACAO_NG',
'                   where id = :P428_PARAMETRO),',
'                 ''''',
'             ),',
'             '':''',
'         )',
'       )',
' where trim(column_value) is not null'))
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql varchar2(4000);',
'begin',
'    if :P428_PARAMETRO is not null then',
'        l_sql :=',
'            ''select',
'                 b.descricao_dominio as display_value,',
'                 b.id as return_value',
'             from MPD_CONFIGURACAO_NG a',
'             join MPD_CONFIGURACAO_NG_DOMINIO b on b.id_configuracao = a.id',
'             where a.id = '' || :P428_PARAMETRO || ''',
'             order by b.descricao_dominio'';',
'    else',
'        l_sql := ''select null as display_value, null as return_value from dual where 1=2'';',
'    end if;',
'',
'    return l_sql;',
'end;',
''))
,p_display_when=>'P428_IND_TIPO_DADO'
,p_display_when2=>'DM'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(489277194088697685)
,p_item_css_classes=>'is-readonly apex-item-wrapper--display-only '
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(622247262752164457)
,p_name=>'P428_ID_TENANT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_item_source_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_source=>'ID_TENANT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(622258615045260414)
,p_name=>'P428_GRUPO_FUNCIONALIDADE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_prompt=>'Grupo de funcionalidade'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.ind_grupo_funcionalidade',
'from MPD_CONFIGURACAO_NG a',
'where a.id = :P428_PARAMETRO;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'D_SRV_CONFIGURACAO.IND_GRUPO_FUNCIONALIDADE'
,p_lov=>'select * from pkg_util.dominio_retorna_lista(''srv_configuracao_ng'',''ind_grupo_funcionalidade'') order by 1'
,p_field_template=>wwv_flow_imp.id(489277194088697685)
,p_item_css_classes=>'is-readonly apex-item-wrapper--display-only opacity_grupo_funcionalidade'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(622259707582260425)
,p_name=>'P428_ID_USUARIO_INCLUIU'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_item_source_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_source=>'ID_USUARIO_INCLUIU'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(622259849752260426)
,p_name=>'P428_DATA_INCLUSAO'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_item_source_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_source=>'DATA_INCLUSAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(622259912191260427)
,p_name=>'P428_ID_USUARIO_ALTEROU'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_item_source_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_prompt=>'&P427_ID_USUARIO_ALTEROU_L.'
,p_source=>'ID_USUARIO_ALTEROU'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(489277194088697685)
,p_item_css_classes=>'is-readonly apex-item-wrapper--display-only'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(622260046108260428)
,p_name=>'P428_DATA_ALTERACAO'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_item_source_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_prompt=>'&P427_DATA_ALTERACAO_L.'
,p_source=>'DATA_ALTERACAO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(489277194088697685)
,p_item_css_classes=>'is-readonly apex-item-wrapper--display-only'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(622597922086586916)
,p_name=>'P428_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_item_source_plug_id=>wwv_flow_imp.id(622237209740164391)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(622703760461587147)
,p_name=>'P428_PARAMETRO'
,p_item_sequence=>100
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(626629860896671273)
,p_name=>'P428_INCREMENTA_ENTREGA_ATUAL_CONTADOR'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(626841557671954666)
,p_name=>'P428_REINICIAR_PAGAMENTOS'
,p_item_sequence=>210
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(659788834589053902)
,p_name=>'P428_CODIGO_WIZARD'
,p_item_sequence=>170
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(726542063631705884)
,p_name=>'P428_URL_PROXIMO'
,p_item_sequence=>180
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(726542160938705885)
,p_name=>'P428_URL_ANTERIOR'
,p_item_sequence=>190
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(752952287409827477)
,p_name=>'P428_ETAPA'
,p_item_sequence=>200
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(875571331744948109)
,p_name=>'P428_PARAMETRO2'
,p_item_sequence=>110
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(875571411826948110)
,p_name=>'P428_TELA_TITULO'
,p_item_sequence=>150
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(875571482056948111)
,p_name=>'P428_TELA_HELP'
,p_item_sequence=>160
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(955934670139576078)
,p_name=>'P428_CODIGO_ARTEFATO'
,p_item_sequence=>90
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(956015467136742362)
,p_name=>'P428_SUCESSO'
,p_item_sequence=>140
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(956166633826739342)
,p_name=>'P428_VISUALIZAR'
,p_item_sequence=>130
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(958418180349302861)
,p_name=>'P428_COPIA'
,p_item_sequence=>120
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(202991351611037940)
,p_computation_sequence=>130
,p_computation_item=>'P428_EMPRESA'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    b.nome_fantasia ',
'    from MPD_CONFIGURACAO_NG a',
'    JOIN mpd_tenant      b on a.id_tenant = b.id',
'where a.id = :P428_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(202991733278037939)
,p_computation_sequence=>140
,p_computation_item=>'P428_DESCRICAO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    pkg_traducao.get_traducao(a.descricao_configuracao) descricao',
'    from MPD_CONFIGURACAO_NG a',
'    JOIN mpd_tenant      b on a.id_tenant = b.id',
'where a.id = :P428_PARAMETRO',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(202992169808037938)
,p_computation_sequence=>150
,p_computation_item=>'P428_ID_TENANT'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>'select id_tenant from MPD_CONFIGURACAO_NG a where a.id = :P428_PARAMETRO'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(202992556885037937)
,p_computation_sequence=>160
,p_computation_item=>'P428_ID'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'ITEM_VALUE'
,p_computation=>'P428_PARAMETRO'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(202992980150037935)
,p_computation_sequence=>170
,p_computation_item=>'P428_ID_USUARIO_INCLUIU'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.ID_USUARIO_INCLUIU',
'    from MPD_CONFIGURACAO_NG a',
'where a.id = :P428_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(202993368958037934)
,p_computation_sequence=>180
,p_computation_item=>'P428_DATA_INCLUSAO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.DATA_INCLUSAO',
'    from MPD_CONFIGURACAO_NG a',
'where a.id = :P428_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(202993706516037933)
,p_computation_sequence=>190
,p_computation_item=>'P428_ID_USUARIO_ALTEROU'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.nome',
'from MPD_USUARIO a',
'JOIN MPD_CONFIGURACAO_NG b ON b.id_usuario_alterou = a.id',
'where b.id = :P428_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(202994127119037932)
,p_computation_sequence=>210
,p_computation_item=>'P428_CODIGO_CONFIGURACAO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.CODIGO_CONFIGURACAO',
'    from MPD_CONFIGURACAO_NG a',
'where a.id = :P428_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(202994546336037931)
,p_computation_sequence=>230
,p_computation_item=>'P428_IND_TIPO_DADO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.IND_TIPO_DADO',
'    from MPD_CONFIGURACAO_NG a',
'where a.id = :P428_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(202994919256037930)
,p_computation_sequence=>240
,p_computation_item=>'P428_VALOR_INTEIRO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.VALOR_INTEIRO',
'    from MPD_CONFIGURACAO_NG a',
'where a.id = :P428_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(202995367741037929)
,p_computation_sequence=>250
,p_computation_item=>'P428_VALOR_DECIMAL'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.VALOR_DECIMAL',
'    from MPD_CONFIGURACAO_NG a',
'where a.id = :P428_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(202995790657037928)
,p_computation_sequence=>260
,p_computation_item=>'P428_QUANTIDADE_DECIMAL'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.QUANTIDADE_DECIMAL',
'    from MPD_CONFIGURACAO_NG a ',
'where a.id = :P428_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(202996170133037926)
,p_computation_sequence=>270
,p_computation_item=>'P428_VALOR_STRING'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.VALOR_STRING',
'    from MPD_CONFIGURACAO_NG a ',
'where a.id = :P428_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(202996536287037925)
,p_computation_sequence=>280
,p_computation_item=>'P428_VALOR_DATA'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.VALOR_DATA',
'    from MPD_CONFIGURACAO_NG a ',
'where a.id = :P428_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(202996914373037924)
,p_computation_sequence=>290
,p_computation_item=>'P428_VALOR_DATA_HORA'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.VALOR_DATA_HORA',
'    from MPD_CONFIGURACAO_NG a ',
'where a.id = :P428_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(202997309765037923)
,p_computation_sequence=>300
,p_computation_item=>'P428_ID_ENTIDADE'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.ID_ENTIDADE',
'    from MPD_CONFIGURACAO_NG a ',
'where a.id = :P428_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(202997712174037921)
,p_computation_sequence=>310
,p_computation_item=>'P428_ID_REGISTRO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.ID_REGISTRO',
'    from MPD_CONFIGURACAO_NG a ',
'where a.id = :P428_PARAMETRO'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(202998577118037917)
,p_computation_sequence=>340
,p_computation_item=>'P428_DATA_ALTERACAO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT TO_CHAR(B.DATA_ALTERACAO, ''DD/MM/YYYY HH24:MI:SS'')',
'FROM MPD_CONFIGURACAO_NG B',
'WHERE B.ID = :P428_PARAMETRO',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(203022090430037855)
,p_name=>'onChangeP428_IND_MULTA_ATRASO_PAGAMENTO'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P428_IND_MULTA_ATRASO_PAGAMENTO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(203023007819037853)
,p_event_id=>wwv_flow_imp.id(203022090430037855)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P428_VALOR_MULTA,P428_PERCENTUAL_MULTA,P428_PERIODO_MULTA'
,p_client_condition_type=>'NOT_EQUALS'
,p_client_condition_element=>'P428_IND_MULTA_ATRASO_PAGAMENTO'
,p_client_condition_expression=>'S'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(203022566973037854)
,p_event_id=>wwv_flow_imp.id(203022090430037855)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P428_VALOR_MULTA,P428_PERCENTUAL_MULTA,P428_PERIODO_MULTA'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P428_IND_MULTA_ATRASO_PAGAMENTO'
,p_client_condition_expression=>'S'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(203016865980037869)
,p_name=>'onChangeP428_IND_BASE_CALCULO'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P428_IND_BASE_CALCULO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(203017372040037868)
,p_event_id=>wwv_flow_imp.id(203016865980037869)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_name=>'Hide P428_NUM_ENTREGA'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P428_NUM_ENTREGA'
,p_client_condition_type=>'NOT_EQUALS'
,p_client_condition_element=>'P428_IND_BASE_CALCULO'
,p_client_condition_expression=>'2'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(203017827223037866)
,p_event_id=>wwv_flow_imp.id(203016865980037869)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Show P428_NUL_ENTREGA'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P428_NUM_ENTREGA'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P428_IND_BASE_CALCULO'
,p_client_condition_expression=>'2'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(203018814120037863)
,p_event_id=>wwv_flow_imp.id(203016865980037869)
,p_event_result=>'TRUE'
,p_action_sequence=>90
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P428_ID_ENTREGA'
,p_client_condition_type=>'NOT_EQUALS'
,p_client_condition_element=>'P428_IND_BASE_CALCULO'
,p_client_condition_expression=>'2'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(203019854680037861)
,p_event_id=>wwv_flow_imp.id(203016865980037869)
,p_event_result=>'TRUE'
,p_action_sequence=>100
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P428_NUM_ENTREGA'
,p_client_condition_type=>'NOT_EQUALS'
,p_client_condition_element=>'P428_IND_BASE_CALCULO'
,p_client_condition_expression=>'2'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(203018381591037865)
,p_event_id=>wwv_flow_imp.id(203016865980037869)
,p_event_result=>'TRUE'
,p_action_sequence=>110
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P428_ID_ENTREGA'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    id    ',
'from imp_entrega',
'where id_pedidoimportacao = :P428_PARAMETRO',
'and id not in (',
'    select ',
'        id_entrega ',
'    from imp_pedidoimportacao_pagamento ',
'    where id_pedidoimportacao = :P428_PARAMETRO ',
'    and numero_parcela = :P428_PARCELA_ATUAL_CONTADOR',
') ',
'order by num_entrega',
'fetch first 1 row only;'))
,p_attribute_07=>'P428_PARAMETRO'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P428_IND_BASE_CALCULO'
,p_client_condition_expression=>'2'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(203019317654037862)
,p_event_id=>wwv_flow_imp.id(203016865980037869)
,p_event_result=>'TRUE'
,p_action_sequence=>120
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P428_NUM_ENTREGA'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    num_entrega',
'from imp_entrega',
'where id_pedidoimportacao = :P428_PARAMETRO',
'and id not in (',
'    select ',
'        id_entrega ',
'    from imp_pedidoimportacao_pagamento ',
'    where id_pedidoimportacao = :P428_PARAMETRO ',
'    and numero_parcela = :P428_PARCELA_ATUAL_CONTADOR',
') ',
'order by num_entrega',
'fetch first 1 row only;'))
,p_attribute_07=>'P428_PARAMETRO'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P428_IND_BASE_CALCULO'
,p_client_condition_expression=>'2'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(203021116182037858)
,p_name=>'onPageLoad'
,p_event_sequence=>120
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(203021632578037857)
,p_event_id=>wwv_flow_imp.id(203021116182037858)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ADD_CLASS'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P428_IND_BASE_CALCULO'
,p_attribute_01=>'is-readonly apex-item-wrapper--display-only'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P428_IND_BASE_CALCULO'
,p_client_condition_expression=>'2'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(203020286132037860)
,p_name=>'New'
,p_event_sequence=>130
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(202970478231038040)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(203020766219037859)
,p_event_id=>wwv_flow_imp.id(203020286132037860)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.navigation.dialog.close(true);',
''))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(203005105670037897)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'altera_registro'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'BO_MPD_CONFIGURACAO_NG'
,p_attribute_04=>'ALTERA_REGISTRO'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(202970478231038040)
,p_process_success_message=>'&P428_SUCESSO.'
,p_internal_uid=>97740399656538787
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(203005536585037896)
,p_page_process_id=>wwv_flow_imp.id(203005105670037897)
,p_page_id=>428
,p_name=>'p_id_tenant'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P428_ID_TENANT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(203006052590037895)
,p_page_process_id=>wwv_flow_imp.id(203005105670037897)
,p_page_id=>428
,p_name=>'p_id'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>190
,p_value_type=>'ITEM'
,p_value=>'P428_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(203006595801037894)
,p_page_process_id=>wwv_flow_imp.id(203005105670037897)
,p_page_id=>428
,p_name=>'p_pagina'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>true
,p_display_sequence=>200
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>':APP_PAGE_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(203007066652037892)
,p_page_process_id=>wwv_flow_imp.id(203005105670037897)
,p_page_id=>428
,p_name=>'p_encadeado'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>210
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(203007585659037891)
,p_page_process_id=>wwv_flow_imp.id(203005105670037897)
,p_page_id=>428
,p_name=>'p_sucesso'
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>false
,p_display_sequence=>220
,p_value_type=>'ITEM'
,p_value=>'P428_SUCESSO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(203008020499037890)
,p_page_process_id=>wwv_flow_imp.id(203005105670037897)
,p_page_id=>428
,p_name=>'p_messages'
,p_direction=>'OUT'
,p_data_type=>'pkg_mensagem.message_record_table'
,p_display_sequence=>230
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(203008580913037889)
,p_page_process_id=>wwv_flow_imp.id(203005105670037897)
,p_page_id=>428
,p_name=>'p_quantidade_decimal'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>240
,p_value_type=>'ITEM'
,p_value=>'P428_QUANTIDADE_DECIMAL'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(203009092018037887)
,p_page_process_id=>wwv_flow_imp.id(203005105670037897)
,p_page_id=>428
,p_name=>'p_valor_string'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>250
,p_value_type=>'ITEM'
,p_value=>'P428_VALOR_STRING'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(203009590556037886)
,p_page_process_id=>wwv_flow_imp.id(203005105670037897)
,p_page_id=>428
,p_name=>'p_valor_data'
,p_direction=>'IN'
,p_data_type=>'DATE'
,p_has_default=>false
,p_display_sequence=>260
,p_value_type=>'ITEM'
,p_value=>'P428_VALOR_DATA'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(203010086212037885)
,p_page_process_id=>wwv_flow_imp.id(203005105670037897)
,p_page_id=>428
,p_name=>'p_valor_data_hora'
,p_direction=>'IN'
,p_data_type=>'TIMESTAMP'
,p_has_default=>false
,p_display_sequence=>270
,p_value_type=>'ITEM'
,p_value=>'P428_VALOR_DATA_HORA'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(203010564304037884)
,p_page_process_id=>wwv_flow_imp.id(203005105670037897)
,p_page_id=>428
,p_name=>'p_id_entidade'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>280
,p_value_type=>'ITEM'
,p_value=>'P428_ID_ENTIDADE'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(203011044800037883)
,p_page_process_id=>wwv_flow_imp.id(203005105670037897)
,p_page_id=>428
,p_name=>'p_id_registro'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>290
,p_value_type=>'FUNCTION_BODY'
,p_value_language=>'PLSQL'
,p_value=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'    l_valor  varchar2(4000);',
'begin',
'    -- Escolhe de qual item vem o valor, dependendo do tipo de dado',
'    if :P428_IND_TIPO_DADO = ''ID'' then',
'        l_valor := :P428_ENTIDADE;',
'    else',
'        l_valor := :P428_ENTIDADESS;',
'    end if;',
'',
'    return l_valor;',
'end;',
''))
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(203011582167037881)
,p_page_process_id=>wwv_flow_imp.id(203005105670037897)
,p_page_id=>428
,p_name=>'p_valor_dominio'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>300
,p_value_type=>'FUNCTION_BODY'
,p_value_language=>'PLSQL'
,p_value=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'    l_valor  varchar2(4000);',
'begin',
'    -- Escolhe de qual item vem o valor, dependendo do tipo de dado',
'    if :P428_IND_TIPO_DADO = ''DO'' then',
'        l_valor := :P428_VALOR_DOMINIO;',
'    else',
'        l_valor := :P428_VALOR_DOMINIOS;',
'    end if;',
'',
'    return l_valor;',
'end;',
''))
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(203012565613037879)
,p_page_process_id=>wwv_flow_imp.id(203005105670037897)
,p_page_id=>428
,p_name=>'p_ind_grupo_funcionalidade'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>320
,p_value_type=>'ITEM'
,p_value=>'P428_GRUPO_FUNCIONALIDADE'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(203013010825037878)
,p_page_process_id=>wwv_flow_imp.id(203005105670037897)
,p_page_id=>428
,p_name=>'p_codigo_configuracao'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>330
,p_value_type=>'ITEM'
,p_value=>'P428_CODIGO_CONFIGURACAO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(203013547167037876)
,p_page_process_id=>wwv_flow_imp.id(203005105670037897)
,p_page_id=>428
,p_name=>'p_descricao_configuracao'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>340
,p_value_type=>'ITEM'
,p_value=>'P428_DESCRICAO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(203014068238037875)
,p_page_process_id=>wwv_flow_imp.id(203005105670037897)
,p_page_id=>428
,p_name=>'p_ind_tipo_dado'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>350
,p_value_type=>'ITEM'
,p_value=>'P428_IND_TIPO_DADO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(203014590577037874)
,p_page_process_id=>wwv_flow_imp.id(203005105670037897)
,p_page_id=>428
,p_name=>'p_valor_inteiro'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>360
,p_value_type=>'ITEM'
,p_value=>'P428_VALOR_INTEIRO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(203015101007037873)
,p_page_process_id=>wwv_flow_imp.id(203005105670037897)
,p_page_id=>428
,p_name=>'p_valor_decimal'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>370
,p_value_type=>'ITEM'
,p_value=>'P428_VALOR_DECIMAL'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(203015557451037872)
,p_page_process_id=>wwv_flow_imp.id(203005105670037897)
,p_page_id=>428
,p_name=>'p_data_alteracao'
,p_direction=>'IN'
,p_data_type=>'TIMESTAMP'
,p_has_default=>false
,p_display_sequence=>380
,p_value_type=>'ITEM'
,p_value=>'P428_DATA_ALTERACAO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(202999248025037914)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'retorna_titulo_help'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'RETORNA_TITULO_TELA'
,p_internal_uid=>97734542011538804
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(202999741090037913)
,p_page_process_id=>wwv_flow_imp.id(202999248025037914)
,p_page_id=>428
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'nvl(:P428_CODIGO_ARTEFATO,:APP_PAGE_ID)'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(203000246741037911)
,p_page_process_id=>wwv_flow_imp.id(202999248025037914)
,p_page_id=>428
,p_name=>'p_titulo'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P428_TELA_TITULO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(203000801110037910)
,p_page_process_id=>wwv_flow_imp.id(202999248025037914)
,p_page_id=>428
,p_name=>'p_help'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P428_TELA_HELP'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(203001188939037908)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'url_wizard'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'URL_WIZARD'
,p_process_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    1',
'from srv_artefato_wizard a',
'join srv_artefato_versionado b on b.id = a.id_artefato_versionado',
'join srv_artefato c on c.id = b.id_artefato',
'join srv_artefato_versionado b1 on b1.id = a.id_artefato_versionado_base',
'join srv_artefato c1 on c1.id = b1.id_artefato',
'where c.codigo_artefato = nvl( apex_util.get_session_state(''P''||:APP_PAGE_ID||''_CODIGO_WIZARD''),:p0_codigo_artefato)'))
,p_process_when_type=>'EXISTS'
,p_internal_uid=>97736482925538798
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(203001682224037907)
,p_page_process_id=>wwv_flow_imp.id(203001188939037908)
,p_page_id=>428
,p_name=>'p_codigo_artefato_base'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>20
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'case when :P428_CODIGO_WIZARD is null then :P428_CODIGO_ARTEFATO else :P428_CODIGO_WIZARD end'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(203002175376037905)
,p_page_process_id=>wwv_flow_imp.id(203001188939037908)
,p_page_id=>428
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'nvl(:P428_CODIGO_ARTEFATO,:APP_PAGE_ID)'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(203002621428037904)
,p_page_process_id=>wwv_flow_imp.id(203001188939037908)
,p_page_id=>428
,p_name=>'p_url_anterior'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P428_URL_ANTERIOR'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(203003185635037902)
,p_page_process_id=>wwv_flow_imp.id(203001188939037908)
,p_page_id=>428
,p_name=>'p_url_proximo'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>50
,p_value_type=>'ITEM'
,p_value=>'P428_URL_PROXIMO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(203003630202037901)
,p_page_process_id=>wwv_flow_imp.id(203001188939037908)
,p_page_id=>428
,p_name=>'p_param1'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>60
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(203004187519037899)
,p_page_process_id=>wwv_flow_imp.id(203001188939037908)
,p_page_id=>428
,p_name=>'p_param2'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>70
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(203004635562037898)
,p_page_process_id=>wwv_flow_imp.id(203001188939037908)
,p_page_id=>428
,p_name=>'p_etapa'
,p_direction=>'OUT'
,p_data_type=>'NUMBER'
,p_ignore_output=>false
,p_display_sequence=>80
,p_value_type=>'ITEM'
,p_value=>'P428_ETAPA'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(202984824124037975)
,p_process_sequence=>80
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(622237209740164391)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Gerar parceladas de pagamento'
,p_internal_uid=>97720118110538865
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(203015951670037871)
,p_process_sequence=>90
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'reinicia_pagamentos'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'BO_IMP_PEDIDOIMPORTACAO_PAGAMENTO'
,p_attribute_04=>'REINICIA_PAGAMENTOS'
,p_process_when=>'P428_REINICIAR_PAGAMENTOS'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_internal_uid=>97751245656538761
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(203016492977037870)
,p_page_process_id=>wwv_flow_imp.id(203015951670037871)
,p_page_id=>428
,p_name=>'p_id_pedidoimportacao'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P428_PARAMETRO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(224474791602223660)
,p_process_sequence=>100
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Labels'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'    l_i varchar2(4000);',
'    l_h varchar2(4000);',
'',
'    l_IND_GRUPO_FUNCIONALIDADE_l varchar2(4000);',
'    l_id_tenant_l varchar2(4000);',
'    l_DESCRICAO_CONFIGURACAO_l varchar2(4000);',
'    l_ID_ENTIDADE_l varchar2(4000);',
'    l_VALOR_STRING_l varchar2(4000);',
'    l_VALOR_DECIMAL_l varchar2(4000);',
'    l_VALOR_INTEIRO_l varchar2(4000);',
'    l_VALOR_DOMINIO_l varchar2(4000);',
'    l_VALOR_DATA_l varchar2(4000);',
'    l_VALOR_DATA_HORA_l varchar2(4000);',
'    l_ID_REGISTRO_l varchar2(4000);',
'    l_ID_USUARIO_ALTEROU_l varchar2(4000);',
'    l_DATA_ALTERACAO_l varchar2(4000);',
'',
'begin',
'  ',
'    pkg_ui.retorna_coluna(''MPD_CONFIGURACAO_NG.IND_GRUPO_FUNCIONALIDADE'', l_IND_GRUPO_FUNCIONALIDADE_l, l_i, l_h);',
'    pkg_ui.retorna_coluna(''MPD_CONFIGURACAO_NG.ID_TENANT'', l_id_tenant_l, l_i, l_h);',
'    pkg_ui.retorna_coluna(''MPD_CONFIGURACAO_NG.DESCRICAO_CONFIGURACAO'', l_DESCRICAO_CONFIGURACAO_l, l_i, l_h);',
'    pkg_ui.retorna_coluna(''MPD_CONFIGURACAO_NG.ID_ENTIDADE'', l_ID_ENTIDADE_l, l_i, l_h);',
'',
'    pkg_ui.retorna_coluna(''MPD_CONFIGURACAO_NG.VALOR_STRING'', l_VALOR_STRING_l, l_i, l_h);',
'    pkg_ui.retorna_coluna(''MPD_CONFIGURACAO_NG.VALOR_DECIMAL'', l_VALOR_DECIMAL_l, l_i, l_h);',
'    pkg_ui.retorna_coluna(''MPD_CONFIGURACAO_NG.VALOR_INTEIRO'', l_VALOR_INTEIRO_l, l_i, l_h);',
'    pkg_ui.retorna_coluna(''MPD_CONFIGURACAO_NG.VALOR_DOMINIO'', l_VALOR_DOMINIO_l, l_i, l_h);',
'    pkg_ui.retorna_coluna(''MPD_CONFIGURACAO_NG.VALOR_DATA'', l_VALOR_DATA_l, l_i, l_h);',
'    pkg_ui.retorna_coluna(''MPD_CONFIGURACAO_NG.VALOR_DATA_HORA'', l_VALOR_DATA_HORA_l, l_i, l_h);',
'    pkg_ui.retorna_coluna(''MPD_CONFIGURACAO_NG.ID_REGISTRO'', l_ID_REGISTRO_l, l_i, l_h);',
'    pkg_ui.retorna_coluna(''MPD_CONFIGURACAO_NG.ID_USUARIO_ALTEROU'', l_ID_USUARIO_ALTEROU_l, l_i, l_h);',
'    pkg_ui.retorna_coluna(''MPD_CONFIGURACAO_NG.DATA_ALTERACAO'', l_DATA_ALTERACAO_l, l_i, l_h);',
'',
'    :P427_IND_GRUPO_FUNCIONALIDADE_L := l_IND_GRUPO_FUNCIONALIDADE_l;',
'    :P427_ID_TENANT_L := l_id_tenant_l;',
'    :P427_DESCRICAO_CONFIGURACAO_L := l_DESCRICAO_CONFIGURACAO_l;',
'    :P427_ID_ENTIDADE_L := l_ID_ENTIDADE_l;',
'',
'    :P427_VALOR_STRING_L := l_VALOR_STRING_l;',
'    :P427_DECIMAL_L := l_VALOR_DECIMAL_l;',
'    :P427_VALOR_INTEIRO_L := l_VALOR_INTEIRO_l;',
'    :P427_VALOR_DOMINIO_L := l_VALOR_DOMINIO_l;',
'    :P427_VALOR_DATA_L := l_VALOR_DATA_l;',
'    :P427_VALOR_DATA_HORA_L := l_VALOR_DATA_HORA_l;',
'    :P427_ID_REGISTRO_L := l_ID_REGISTRO_l;',
'    :P427_ID_USUARIO_ALTEROU_L := l_ID_USUARIO_ALTEROU_l;',
'    :P427_DATA_ALTERACAO_L := l_DATA_ALTERACAO_l;',
'',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>119210085588724550
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(202998849792037916)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'enviarParamentros'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_param1 varchar2(100) := apex_application.g_x01||''_''||APEX_CUSTOM_AUTH.GET_SESSION_ID;',
'    v_param2 varchar2(100) := apex_application.g_x02;',
'    v_param3 varchar2(100) := apex_application.g_x03;',
'    v_existe number;',
'    v_id number;',
'begin',
unistr('    -- verifica se a cole\00E7\00E3o j\00E1 existe e a exclui para evitar duplica\00E7\00F5es'),
'    apex_debug.enable(apex_debug.c_log_level_info);',
'    apex_debug.info(''info enviarparamentros v_param1:%s'',v_param1); ',
'    apex_debug.info(''info enviarparamentros v_param2:%s'',v_param2); ',
'    apex_debug.info(''info enviarparamentros v_param3:%s'',v_param3); ',
'    apex_debug.info(''info enviarparamentros APEX_CUSTOM_AUTH.GET_SESSION_ID:%s'',APEX_CUSTOM_AUTH.GET_SESSION_ID); ',
'',
'    if not apex_collection.collection_exists(v_param1) then',
'        -- apex_collection.delete_collection(v_param1);',
'        apex_collection.create_collection(v_param1);',
'    end if;',
'',
'    select count(1) into v_existe ',
'    from apex_collections',
'    where collection_name = v_param1',
'      and c001 = v_param2;',
'    if v_existe > 0 then',
'        select seq_id into v_id ',
'        from apex_collections',
'        where collection_name = v_param1',
'          and c001 = v_param2;',
'',
'        apex_collection.update_member (',
'            p_collection_name => v_param1,',
'            p_seq => v_id,',
'            p_c001 => v_param2,',
'            p_c002 => v_param3);      ',
'    else',
'        apex_collection.add_member(',
'            p_collection_name => v_param1,',
'            p_c001 => v_param2,',
'            p_c002 => v_param3',
'        );',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>97734143778538806
);
wwv_flow_imp.component_end;
end;
/
