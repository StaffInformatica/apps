prompt --application/pages/page_09010
begin
--   Manifest
--     PAGE: 09010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_page.create_page(
 p_id=>9010
,p_name=>'Template - Formulario - Teste'
,p_alias=>'TEMPLATE-FORMULARIO-TESTE'
,p_page_mode=>'MODAL'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/5.0.9/jquery.inputmask.min.js'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'tituloTela($v("P9010_TELA_TITULO")+'' (''+$v("P9010_CODIGO_ARTEFATO")+'')'');',
'',
'setTimeout(function() {',
'  window.history.replaceState(null, '''', window.location.href);',
'}, 100);'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.centro{',
'    display: grid;',
'    justify-items: center;',
'}',
'',
'.select option.selected {',
'    color: #888; /* Cor mais clara para parecer um placeholder */',
'    opacity: 0.5; /* Reduz a opacidade */',
'}',
'',
unistr('/* Limita expans\00E3o da janela modal */'),
'.ui-dialog.ui-widget.ui-widget-content {',
'  max-width: 90vw !important;',
'  width: auto !important;',
'  overflow-x: hidden !important;',
'}',
'',
unistr('/* Permite scroll interno na regi\00E3o de relat\00F3rio */'),
'.t-Report-tableWrap {',
'  overflow-x: auto !important;',
'  max-width: 100%;',
'}',
'',
unistr('/* Evita que a tabela ultrapasse a largura da regi\00E3o */'),
'.t-Report-report {',
'  width: max-content;',
'  max-width: 100%;',
'}',
'',
''))
,p_step_template=>wwv_flow_imp.id(489110489949697573)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'27'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(149732263513823141)
,p_plug_name=>'Footer'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(489149217063697608)
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(274749703987994477)
,p_plug_name=>unistr('Formul\00E1rio')
,p_region_name=>'FORM'
,p_region_template_options=>'#DEFAULT#:t-Form--large'
,p_plug_template=>wwv_flow_imp.id(489146466586697607)
,p_plug_display_sequence=>70
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_html clob;        ',
'    l_codigo_artefato varchar2(128) := nvl(:P9010_CODIGO_ARTEFATO,100);',
'begin',
'    pkg_ui.gerar_formulario(l_codigo_artefato,nvl(:P9010_ID,:P9010_COPIA),:P9010_VISUALIZAR,l_html,:P9010_PARAMETRO,:P9010_PARAMETRO2); ',
'    return l_html;',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P9010_CODIGO_ARTEFATO,P9010_COPIA,P9010_PARAMETRO,P9010_PARAMETRO2,P9010_VISUALIZAR'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(432238473187929050)
,p_plug_name=>unistr('Opera\00E7\00F5es')
,p_parent_plug_id=>wwv_flow_imp.id(274749703987994477)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(489147839586697607)
,p_plug_display_sequence=>80
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return PKG_UI.buscar_acoes(:P9010_ID,:P9010_CODIGO_ARTEFATO,''E'',false,:P9010_PARAMETRO);',
''))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_BOT_ES_A__ES'
,p_ajax_items_to_submit=>'P9010_ID,P9010_PAGINA'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_plug_query_no_data_found=>unistr('Nenhuma opera\00E7\00E3o dispon\00EDvel')
,p_no_data_found_icon_classes=>'fa-robot'
,p_show_total_row_count=>false
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'PKG_UI.verifica_se_tem_linhas(PKG_UI.buscar_acoes(:P9010_ID,:P9010_CODIGO_ARTEFATO,''E'',false,:P9010_PARAMETRO)) = true'
,p_plug_display_when_cond2=>'PLSQL'
,p_required_patch=>wwv_flow_imp.id(489109181809697564)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'ICON', 'ICON',
  'LABEL', 'LABEL',
  'LINK', 'LINK',
  'MY_SECOND_PLACEHOLDER', 'HELP')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(165296880021388417)
,p_name=>'SQL_VALIDACAO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SQL_VALIDACAO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(275686589913699372)
,p_name=>'LABEL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LABEL'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(275686655029699373)
,p_name=>'HELP'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'HELP'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(432435066446136919)
,p_name=>'LINK'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LINK'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(432435145014136920)
,p_name=>'ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(149843876709876150)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(149732263513823141)
,p_button_name=>'inclui'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(489279883613697688)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Salvar'
,p_button_position=>'CREATE'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P9010_VISUALIZAR is null ',
'-- and :P9010_SEGUNDO_PLANO = ''false'''))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(153406899601187053)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(149732263513823141)
,p_button_name=>'inclui_segundo_plano'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(489279883613697688)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Salvar segundo plano'
,p_button_position=>'CREATE'
,p_button_condition=>':P9010_VISUALIZAR is null and :P9010_SEGUNDO_PLANO = ''true'''
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-save'
,p_required_patch=>wwv_flow_imp.id(489109181809697564)
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(149906575820026421)
,p_name=>'P9010_ID'
,p_item_sequence=>140
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(153406766826187052)
,p_name=>'P9010_SEGUNDO_PLANO'
,p_item_sequence=>170
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(162914676389067548)
,p_name=>'P9010_ESCONDE_OPCAO'
,p_item_sequence=>240
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(166312633824903246)
,p_name=>'P9010_SELECTED_ITEM_ID'
,p_item_sequence=>250
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(166312788173903247)
,p_name=>'P9010_SELECTED_ITEM_TEXT'
,p_item_sequence=>260
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(194313444058200167)
,p_name=>'P9010_PARAMETRO'
,p_item_sequence=>120
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(194313539077200168)
,p_name=>'P9010_PARAMETRO2'
,p_item_sequence=>130
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(194313619159200169)
,p_name=>'P9010_TELA_TITULO'
,p_item_sequence=>150
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(194313689389200170)
,p_name=>'P9010_TELA_HELP'
,p_item_sequence=>160
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(274676877471828137)
,p_name=>'P9010_CODIGO_ARTEFATO'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(274757674468994421)
,p_name=>'P9010_SUCESSO'
,p_item_sequence=>100
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(274908841158991401)
,p_name=>'P9010_VISUALIZAR'
,p_item_sequence=>90
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(277160387681554920)
,p_name=>'P9010_COPIA'
,p_item_sequence=>110
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(153407101593187055)
,p_computation_sequence=>10
,p_computation_item=>'P9010_SEGUNDO_PLANO'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_label clob;',
'    l_pagina varchar2(256) := nvl(:p9010_codigo_artefato,''td452'');',
'begin',
'    execute immediate',
'        ''begin :l_label := ui_mpd_''||l_pagina||''.segundo_plano; end;''',
'        using out l_label;',
'',
'    return l_label;       ',
'',
'    exception',
'        when others then',
'            return ''false'';       ',
'    ',
'end;',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(166312236546903242)
,p_name=>'onClickjs-dlg-setvalue'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.js-dlg-setvalue'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(166312325843903243)
,p_event_id=>wwv_flow_imp.id(166312236546903242)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'window._lastDlgLinkZoom = $(this.triggeringElement)',
'    .closest(''span.lov'')   // sobe para o container',
'    .find(''input[coluna], textarea[coluna]'') // pega input OU textarea com atributo ''coluna''',
'    .attr(''coluna'');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(166312436320903244)
,p_name=>'onClosejs-dlg-setvalue'
,p_event_sequence=>20
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'document'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'!!window._lastDlgLinkZoom'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(166312528656903245)
,p_event_id=>wwv_flow_imp.id(166312436320903244)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9010_SELECTED_ITEM_ID'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P9004_SELECTED_ITEM_ID'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(166312811917903248)
,p_event_id=>wwv_flow_imp.id(166312436320903244)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9010_SELECTED_ITEM_TEXT'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P9004_SELECTED_ITEM_TEXT'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(166312918640903249)
,p_event_id=>wwv_flow_imp.id(166312436320903244)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'window._lastDlgLinkZoom = null;'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(166313081499903250)
,p_name=>'onChangeSelectItemId'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9010_SELECTED_ITEM_ID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(166313176915903251)
,p_event_id=>wwv_flow_imp.id(166313081499903250)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''input[coluna="'' + window._lastDlgLinkZoom + ''"], textarea[coluna="'' + window._lastDlgLinkZoom + ''"]'')',
'  .closest(''span.lov'')',
'  .find(''input[type=hidden]'');'))
,p_attribute_01=>'PLSQL_EXPRESSION'
,p_attribute_04=>':P9010_SELECTED_ITEM_ID'
,p_attribute_07=>'P9010_SELECTED_ITEM_ID'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(166313257944903252)
,p_name=>'onChangeSelectItemText'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9010_SELECTED_ITEM_TEXT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(166313360074903253)
,p_event_id=>wwv_flow_imp.id(166313257944903252)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$('':is(input, textarea)[coluna="'' + window._lastDlgLinkZoom + ''"]'')',
'  .closest(''span.lov'')',
'  .find('':is(input[type=text], textarea)'');'))
,p_attribute_01=>'PLSQL_EXPRESSION'
,p_attribute_04=>':P9010_SELECTED_ITEM_TEXT'
,p_attribute_07=>'P9010_SELECTED_ITEM_TEXT'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(167914174245720859)
,p_name=>'onChangeIdTenant'
,p_event_sequence=>50
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#id_tenant'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(167914228040720860)
,p_event_id=>wwv_flow_imp.id(167914174245720859)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var value = apex.item("id_tenant").getValue();',
'apex.item("id_idioma_empresa").setValue(value)',
'',
'',
'var tenantValue = apex.item("id_tenant").getValue();',
'',
'apex.server.process(',
'    "SET_TENANT_GLOBAL",           // Nome do processo AJAX',
'    { x01: tenantValue },     // Passando o valor do item',
'    {',
'        success: function(pData) {',
unistr('            console.log("Sess\00E3o atualizada com sucesso:", tenantValue);'),
'        },',
'        error: function(err) {',
unistr('            console.error("Erro ao atualizar sess\00E3o:", err);'),
'        }',
'    }',
');'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(153405123956187036)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Segundo_plano'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'P0_PROGRESSO'
,p_attribute_04=>'IGNORE'
,p_attribute_09=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Segundo plano'
,p_required_patch=>wwv_flow_imp.id(489109181809697564)
,p_internal_uid=>48140417942687926
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(158666847288657616)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Sincroniza execu\00E7\00F5es em segundo plano')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_start_date timestamp with time zone;',
'    l_job_name VARCHAR2(128);',
'begin',
'    l_start_date := current_timestamp at time zone ''America/Sao_Paulo'' + interval ''5'' second;',
'    SELECT DBMS_SCHEDULER.GENERATE_JOB_NAME(''APEX_JOB_'') INTO l_job_name FROM DUAL;',
'',
'    dbms_scheduler.create_job (',
'        job_name        => l_job_name,',
'        program_name    => ''PROGRAM_BG_PROC_STATUS'',',
'        start_date      => l_start_date,',
'        repeat_interval => null,',
'        auto_drop       => true,',
unistr('        comments        => ''Job \00FAnico para rodar sync 5s ap\00F3s post'''),
'    );',
'',
'    -- define o argumento',
'    dbms_scheduler.set_job_argument_value(',
'        job_name      => l_job_name,',
'        argument_name => ''P_CODIGO_ARTEFATO'',',
'        argument_value => :P9010_CODIGO_ARTEFATO',
'    );',
'',
'    dbms_scheduler.enable(l_job_name);    ',
'end;',
'',
'',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(153406899601187053)
,p_required_patch=>wwv_flow_imp.id(489109181809697564)
,p_internal_uid=>53402141275158506
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(149849340741876129)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Post'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_messages pkg_mensagem.message_record_table;',
'    l_pagina varchar2(256) := nvl(:P9010_CODIGO_ARTEFATO,266);',
'BEGIN',
'    v_messages := pkg_mensagem.message_record_table();',
'    EXECUTE IMMEDIATE',
'        ''BEGIN UI_MPD_''|| l_pagina ||''.post''||',
'        ''(p_id => :P9010_ID, p_sucesso => :P9010_SUCESSO, p_messages => :v_messages); END;''',
'        USING :P9010_ID, OUT :P9010_SUCESSO, OUT v_messages;',
'       ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(149843876709876150)
,p_process_success_message=>'&P9010_SUCESSO.'
,p_internal_uid=>44584634728377019
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(149849778829876128)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'ClosedDialog'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>44585072816377018
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(149850544153876126)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'retorna_titulo_help'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'RETORNA_TITULO_TELA'
,p_internal_uid=>44585838140377016
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(149851046618876125)
,p_page_process_id=>wwv_flow_imp.id(149850544153876126)
,p_page_id=>9010
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'nvl(:P9010_CODIGO_ARTEFATO,:APP_PAGE_ID)'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(149851562108876124)
,p_page_process_id=>wwv_flow_imp.id(149850544153876126)
,p_page_id=>9010
,p_name=>'p_titulo'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P9010_TELA_TITULO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(149852058001876121)
,p_page_process_id=>wwv_flow_imp.id(149850544153876126)
,p_page_id=>9010
,p_name=>'p_help'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P9010_TELA_HELP'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(149850109021876127)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'enviarParamentros'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    prc_enviar_parametros(',
'        apex_application.g_x01,',
'        apex_application.g_x02,',
'        apex_application.g_x03,',
'        apex_application.g_x04',
'    );',
'    if apex_application.g_x01 is not null then',
'        if upper(apex_application.g_x02) = upper(''id_tenant'') and :P9013_ID is null then',
'            :P0_TENANT_INFORMADO := apex_application.g_x03;',
'        end if;',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>44585403008377017
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(168947451076401433)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'atribuiValorAJAX'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_json CLOB;',
'BEGIN',
'    l_json := pkg_formulario_dinamico.executa_sql_parametrizado(',
'        p_param1 => apex_application.g_x01,',
'        p_sql    => apex_application.g_x02',
'    );',
'    htp.p(l_json); -- resposta para o JavaScript',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>22058998258382223
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(153406914541187054)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(153405123956187036)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Post_Segundo_plano'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_messages pkg_mensagem.message_record_table;',
'    l_pagina varchar2(256) := nvl(:P9010_CODIGO_ARTEFATO,266);',
'    l_start_date timestamp with time zone;',
'    l_job_name VARCHAR2(128);',
'BEGIN',
'    v_messages := pkg_mensagem.message_record_table();',
'    apex_background_process.set_status(',
'        pkg_ui.retorna_titulo_tela(:P9010_CODIGO_ARTEFATO)',
'    );    ',
'    EXECUTE IMMEDIATE',
'        ''BEGIN UI_MPD_''|| l_pagina ||''.post''||',
'        ''(p_id => :P9010_ID, p_sucesso => :P9010_SUCESSO, p_messages => :v_messages); END;''',
'        USING :P9010_ID, OUT :P9010_SUCESSO, OUT v_messages;',
'',
'    l_start_date := current_timestamp at time zone ''America/Sao_Paulo'' + interval ''5'' second;',
'    SELECT DBMS_SCHEDULER.GENERATE_JOB_NAME(''APEX_JOB_'') INTO l_job_name FROM DUAL;',
'',
'    dbms_scheduler.create_job (',
'        job_name        => l_job_name,',
'        program_name    => ''PROGRAM_BG_PROC_STATUS'',',
'        start_date      => l_start_date,',
'        repeat_interval => null,',
'        auto_drop       => true,',
unistr('        comments        => ''Job \00FAnico para rodar sync 5s ap\00F3s post'''),
'    );',
'',
'    -- define o argumento',
'    dbms_scheduler.set_job_argument_value(',
'        job_name      => l_job_name,',
'        argument_name => ''P_CODIGO_ARTEFATO'',',
'        argument_value => :P9010_CODIGO_ARTEFATO',
'    );',
'',
'    dbms_scheduler.enable(l_job_name);    ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_success_message=>'&P9010_SUCESSO.'
,p_required_patch=>wwv_flow_imp.id(489109181809697564)
,p_internal_uid=>48142208527687944
);
wwv_flow_imp.component_end;
end;
/
