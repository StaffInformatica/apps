prompt --application/pages/page_09007
begin
--   Manifest
--     PAGE: 09007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>9007
,p_name=>'Template - Grid'
,p_alias=>'TEMPLATE-GRID'
,p_step_title=>'Template - Grid'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-button--actions{',
'    display: none;',
'}',
'',
'.ocultar{',
'    display: none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'22'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(35405938442021829)
,p_name=>'Lista Oculta'
,p_region_name=>'LISTA_CR'
,p_template=>wwv_flow_imp.id(341010888912556224)
,p_display_sequence=>20
,p_region_css_classes=>'ocultar'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9007_CODIGO_ARTEFATO,''TD257'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_card(:param1); END;''',
'        USING OUT l_sql, IN :P9007_PARAMETRO;',
'',
'    return l_sql;       ',
'end;'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P9007_PARAMETRO'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(341097593039556273)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(35526593180476317)
,p_query_column_id=>1
,p_column_alias=>'CAMPO1'
,p_column_display_sequence=>10
,p_column_heading=>'Campo1'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(35526606070476318)
,p_query_column_id=>2
,p_column_alias=>'CAMPO2'
,p_column_display_sequence=>20
,p_column_heading=>'Campo2'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(35526853815476320)
,p_query_column_id=>3
,p_column_alias=>'CAMPO3'
,p_column_display_sequence=>30
,p_column_heading=>'Campo3'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(35591010866782619)
,p_query_column_id=>4
,p_column_alias=>'CAMPO4'
,p_column_display_sequence=>40
,p_column_heading=>'Campo4'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(35591110812782620)
,p_query_column_id=>5
,p_column_alias=>'CAMPO5'
,p_column_display_sequence=>50
,p_column_heading=>'Campo5'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(35591282006782621)
,p_query_column_id=>6
,p_column_alias=>'CAMPO6'
,p_column_display_sequence=>60
,p_column_heading=>'Campo6'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(35591326940782622)
,p_query_column_id=>7
,p_column_alias=>'CAMPO7'
,p_column_display_sequence=>70
,p_column_heading=>'Campo7'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(35591463417782623)
,p_query_column_id=>8
,p_column_alias=>'CAMPO8'
,p_column_display_sequence=>80
,p_column_heading=>'Campo8'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(35591528330782624)
,p_query_column_id=>9
,p_column_alias=>'CAMPO9'
,p_column_display_sequence=>90
,p_column_heading=>'Campo9'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(35591636843782625)
,p_query_column_id=>10
,p_column_alias=>'CAMPO10'
,p_column_display_sequence=>100
,p_column_heading=>'Campo10'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7765370542681050)
,p_query_column_id=>11
,p_column_alias=>'QTD_CASAS_DECIMAIS'
,p_column_display_sequence=>110
,p_column_heading=>'Qtd Casas Decimais'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7765459862681051)
,p_query_column_id=>12
,p_column_alias=>'EDICAO'
,p_column_display_sequence=>120
,p_column_heading=>'Edicao'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7765551349681052)
,p_query_column_id=>13
,p_column_alias=>'VALOR_DEFAULT'
,p_column_display_sequence=>130
,p_column_heading=>'Valor Default'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7765630161681053)
,p_query_column_id=>14
,p_column_alias=>'EH_COLUNA_OBRIGATORIA'
,p_column_display_sequence=>140
,p_column_heading=>'Eh Coluna Obrigatoria'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7765748400681054)
,p_query_column_id=>15
,p_column_alias=>'CHAVE_PRIMARIA'
,p_column_display_sequence=>150
,p_column_heading=>'Chave Primaria'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7765857087681055)
,p_query_column_id=>16
,p_column_alias=>'LABEL'
,p_column_display_sequence=>160
,p_column_heading=>'Label'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7766020284681056)
,p_query_column_id=>17
,p_column_alias=>'INSTRUCAO'
,p_column_display_sequence=>170
,p_column_heading=>'Instrucao'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7766077259681057)
,p_query_column_id=>18
,p_column_alias=>'HELP'
,p_column_display_sequence=>180
,p_column_heading=>'Help'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7766139020681058)
,p_query_column_id=>19
,p_column_alias=>'TIPO_INTERACAO'
,p_column_display_sequence=>190
,p_column_heading=>'Tipo Interacao'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7766237663681059)
,p_query_column_id=>20
,p_column_alias=>'DESCRICAO_COMPLEMENTAR'
,p_column_display_sequence=>200
,p_column_heading=>'Descricao Complementar'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7766427708681060)
,p_query_column_id=>21
,p_column_alias=>'ID_DOMINIO'
,p_column_display_sequence=>210
,p_column_heading=>'Id Dominio'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7766447268681061)
,p_query_column_id=>22
,p_column_alias=>'DES_DOMINIO'
,p_column_display_sequence=>220
,p_column_heading=>'Des Dominio'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7766586365681062)
,p_query_column_id=>23
,p_column_alias=>'OPCAO'
,p_column_display_sequence=>230
,p_column_heading=>'Opcao'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(35407558303021845)
,p_plug_name=>'Lista'
,p_region_name=>'LISTA'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(341044399187556241)
,p_plug_display_sequence=>30
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9007_CODIGO_ARTEFATO,''TD257'');',
'begin',
'    begin',
'        EXECUTE IMMEDIATE ',
'            ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_report; END;''',
'            -- ''BEGIN :l_sql := UI_MPD_100.sql_report; END;''',
'            USING OUT l_sql; ',
'        exception ',
'            when others then',
'                return ''select 1 from dual'';',
'    end;',
'    return l_sql;       ',
'end;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(35407653153021846)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_textbox=>'N'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'NTO'
,p_internal_uid=>35407653153021846
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7764297729681039)
,p_db_column_name=>'CAMPO1'
,p_display_order=>10
,p_column_identifier=>'T'
,p_column_label=>'&P9007_LABEL_COLUNA1.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7764427360681040)
,p_db_column_name=>'CAMPO2'
,p_display_order=>20
,p_column_identifier=>'U'
,p_column_label=>'&P9007_LABEL_COLUNA2.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7764457146681041)
,p_db_column_name=>'CAMPO3'
,p_display_order=>30
,p_column_identifier=>'V'
,p_column_label=>'&P9007_LABEL_COLUNA3.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7764540672681042)
,p_db_column_name=>'CAMPO4'
,p_display_order=>40
,p_column_identifier=>'W'
,p_column_label=>'&P9007_LABEL_COLUNA4.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7764629865681043)
,p_db_column_name=>'CAMPO5'
,p_display_order=>50
,p_column_identifier=>'X'
,p_column_label=>'&P9007_LABEL_COLUNA5.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7764790038681044)
,p_db_column_name=>'CAMPO6'
,p_display_order=>60
,p_column_identifier=>'Y'
,p_column_label=>'&P9007_LABEL_COLUNA6.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7764853373681045)
,p_db_column_name=>'CAMPO7'
,p_display_order=>70
,p_column_identifier=>'Z'
,p_column_label=>'&P9007_LABEL_COLUNA7.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7764974085681046)
,p_db_column_name=>'CAMPO8'
,p_display_order=>80
,p_column_identifier=>'AA'
,p_column_label=>'&P9007_LABEL_COLUNA8.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7765073761681047)
,p_db_column_name=>'CAMPO9'
,p_display_order=>90
,p_column_identifier=>'AB'
,p_column_label=>'&P9007_LABEL_COLUNA9.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7765160845681048)
,p_db_column_name=>'CAMPO10'
,p_display_order=>100
,p_column_identifier=>'AC'
,p_column_label=>'&P9007_LABEL_COLUNA10.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7765263287681049)
,p_db_column_name=>'OPCAO'
,p_display_order=>120
,p_column_identifier=>'AD'
,p_column_label=>'&P0_LABEL_OPCAO.'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div style="display: flex; align-items: center; justify-content: center; flex-grow: 1;">',
'    <span #OPCAO# style="cursor: pointer; color: var(--a-button-state-text-color, var(--a-button-type-text-color, var(--a-button-text-color, inherit)));" ',
'        class="fa fa-ellipsis-v js-dlg-refresh" title="&P0_LABEL_OPCAO!RAW.">',
'    </span>',
'</div>',
'    '))
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(35533044119475300)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'355331'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CAMPO1:CAMPO2:CAMPO3:CAMPO4:CAMPO5:CAMPO6:CAMPO7:CAMPO8:OPCAO:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(35527997095476331)
,p_plug_name=>unistr('Defini\00E7\00F5es do relat\00F3rio')
,p_region_name=>'ACTION'
,p_region_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--sm'
,p_component_template_options=>'t-MediaList--showIcons:t-MediaList--showDesc:u-colors'
,p_plug_template=>wwv_flow_imp.id(341039558490556238)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_04'
,p_location=>null
,p_list_id=>wwv_flow_imp.id(222272585216222758)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(341125559529556289)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(104424021732058268)
,p_plug_name=>'Filtrar por Esquerda'
,p_title=>'tela.filtrar-por.l'
,p_region_name=>'PAINEL_LEFT'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_02'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(35527258838476324)
,p_plug_name=>'Pesquisa'
,p_region_name=>'PESQUISA'
,p_parent_plug_id=>wwv_flow_imp.id(104424021732058268)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(35405938442021829)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'batch_facet_search', 'N',
  'compact_numbers_threshold', '10000',
  'display_chart_for_top_n_values', '10',
  'show_charts', 'Y',
  'show_current_facets', 'N',
  'show_total_row_count', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(104424946707058277)
,p_plug_name=>'Filtrar por Modal'
,p_title=>'tela.filtrar-por.l'
,p_region_name=>'PAINEL_MODAL'
,p_region_template_options=>'#DEFAULT#:t-DialogRegion--noPadding:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--md'
,p_plug_template=>wwv_flow_imp.id(341039558490556238)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_04'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(35501306180654398)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(104424021732058268)
,p_button_name=>'fixar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'botao.fixar-desfixar.l'
,p_button_position=>'COPY'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-thumb-tack'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3082555673632157)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(17161532936247037)
,p_button_name=>'filter'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Filter'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-filter'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(35504687507654385)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(17161532936247037)
,p_button_name=>'New'
,p_button_static_id=>'NEW'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'New'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'&P9007_URL_NEW.'
,p_button_condition=>'P9007_URL_NEW'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-plus-circle'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(35500590083654400)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(104424946707058277)
,p_button_name=>'desfixar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'botao.fixar-desfixar.l'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-thumb-tack'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(35528018242476332)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(35407558303021845)
,p_button_name=>'Opcoes'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Opcoes'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-gear'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3082043161632152)
,p_name=>'P9007_PARAMETRO'
,p_item_sequence=>100
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3083336942632165)
,p_name=>'P9007_LABEL_COLUNA3'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(35407558303021845)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3083518853632166)
,p_name=>'P9007_LABEL_COLUNA4'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(35407558303021845)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3083586317632167)
,p_name=>'P9007_LABEL_COLUNA5'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(35407558303021845)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3083717388632168)
,p_name=>'P9007_LABEL_COLUNA6'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(35407558303021845)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3083823256632169)
,p_name=>'P9007_LABEL_COLUNA7'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(35407558303021845)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3083833363632170)
,p_name=>'P9007_LABEL_COLUNA8'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(35407558303021845)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3083998355632171)
,p_name=>'P9007_LABEL_COLUNA9'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(35407558303021845)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3084125385632172)
,p_name=>'P9007_LABEL_COLUNA10'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(35407558303021845)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7806284373774842)
,p_name=>'P9007_FILTRO7'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(35527258838476324)
,p_prompt=>'&P9007_NOME_FILTRO7.'
,p_source=>'CAMPO7'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9007_CODIGO_ARTEFATO,''TD257'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(7); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9007_CODIGO_ARTEFATO,''TD257'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(7); END;''',
'        USING OUT l_true;',
'',
'    return l_true;       ',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7806383850774843)
,p_name=>'P9007_NOME_FILTRO7'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(35527258838476324)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9007_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_filtro(7); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7806980045774849)
,p_name=>'P9007_NOME_FILTRO10'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(35527258838476324)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9007_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_filtro(10); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10921221063114228)
,p_name=>'P9007_FILTRO10'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(35527258838476324)
,p_prompt=>'&P9007_NOME_FILTRO10.'
,p_source=>'CAMPO10'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9007_CODIGO_ARTEFATO,''TD257'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(10); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9007_CODIGO_ARTEFATO,''TD257'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(10); END;''',
'        USING OUT l_true;',
'',
'    return l_true;       ',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35527555381476327)
,p_name=>'P9007_FILTRO2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(35527258838476324)
,p_prompt=>'Filtro2'
,p_source=>'CAMPO1,CAMPO2,CAMPO3,CAMPO4'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'input_field', 'FACET',
  'search_type', 'ROW')).to_clob
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35590333990782612)
,p_name=>'P9007_AVANCADO'
,p_item_sequence=>110
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35590892368782617)
,p_name=>'P9007_FILTRO8'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(35527258838476324)
,p_prompt=>'&P9007_NOME_FILTRO8.'
,p_source=>'CAMPO8'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9007_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(8); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9007_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(8); END;''',
'        USING OUT l_true;',
'',
'    return l_true;       ',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35590904067782618)
,p_name=>'P9007_NOME_FILTRO8'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(35527258838476324)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9007_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_filtro(8); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35592449018782633)
,p_name=>'P9007_FILTRO9'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(35527258838476324)
,p_prompt=>'&P9007_NOME_FILTRO9.'
,p_source=>'CAMPO9'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9007_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_filtro(9); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_true boolean;',
'    l_pagina varchar2(256) := nvl(:P9007_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_true := UI_MPD_''||l_pagina||''.sql_verifica_filtro(9); END;''',
'        USING OUT l_true;',
'',
'    return l_true;       ',
'end;',
''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>','
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35592540706782634)
,p_name=>'P9007_NOME_FILTRO9'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(35527258838476324)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9007_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_filtro(9); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35785800872045805)
,p_name=>'P9007_LABEL_COLUNA1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(35407558303021845)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35785952675045806)
,p_name=>'P9007_LABEL_COLUNA2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(35407558303021845)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(70910426905676207)
,p_name=>'P9007_TELA_TITULO'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(70910865657676212)
,p_name=>'P9007_TELA_HELP'
,p_item_sequence=>90
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(104434390649058210)
,p_name=>'P9007_TIPO_PESQUISA'
,p_item_sequence=>60
,p_item_default=>'1'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(106395763581412474)
,p_name=>'P9007_CODIGO_ARTEFATO'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(106396685496412483)
,p_name=>'P9007_URL_NEW'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(35786082385045807)
,p_computation_sequence=>10
,p_computation_item=>'P9007_LABEL_COLUNA1'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9007_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(1); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(35786192783045808)
,p_computation_sequence=>20
,p_computation_item=>'P9007_LABEL_COLUNA2'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9007_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(2); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(3084196393632173)
,p_computation_sequence=>30
,p_computation_item=>'P9007_LABEL_COLUNA3'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9007_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(3); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(3084236297632174)
,p_computation_sequence=>40
,p_computation_item=>'P9007_LABEL_COLUNA4'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9007_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(4); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(3084397118632175)
,p_computation_sequence=>50
,p_computation_item=>'P9007_LABEL_COLUNA5'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9007_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(5); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(3084433994632176)
,p_computation_sequence=>60
,p_computation_item=>'P9007_LABEL_COLUNA6'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9007_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(6); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(3084545592632177)
,p_computation_sequence=>70
,p_computation_item=>'P9007_LABEL_COLUNA7'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9007_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(7); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(7804880066774828)
,p_computation_sequence=>80
,p_computation_item=>'P9007_LABEL_COLUNA8'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9007_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(8); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(7804967387774829)
,p_computation_sequence=>90
,p_computation_item=>'P9007_LABEL_COLUNA9'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9007_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(9); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(7805039596774830)
,p_computation_sequence=>100
,p_computation_item=>'P9007_LABEL_COLUNA10'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9007_CODIGO_ARTEFATO,100);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(10); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(35511313233654368)
,p_name=>'onClickFixar'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(35501306180654398)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35511851741654367)
,p_event_id=>wwv_flow_imp.id(35511313233654368)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (apex.item( "P9007_TIPO_PESQUISA" ).getValue() == 1){',
'    apex.item( "P9007_TIPO_PESQUISA" ).setValue( 2 );',
'} else {',
'    apex.item( "P9007_TIPO_PESQUISA" ).setValue( 1 );',
'}',
'    '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(35509993094654371)
,p_name=>'onChangeTipoPesquisa = Esquerda'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9007_TIPO_PESQUISA'
,p_condition_element=>'P9007_TIPO_PESQUISA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35510426990654370)
,p_event_id=>wwv_flow_imp.id(35509993094654371)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// $(''#PESQUISA'').appendTo(''#PAINEL_LEFT .t-Region-body'');',
'$(''#PESQUISA'').appendTo(''#PAINEL_LEFT'');',
'$(''#t_Body_side'').show();'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35510991047654369)
,p_event_id=>wwv_flow_imp.id(35509993094654371)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(104424946707058277)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(35512274797654366)
,p_name=>'onChangeTipoPesquisa = Modal'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9007_TIPO_PESQUISA'
,p_condition_element=>'P9007_TIPO_PESQUISA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35512739435654365)
,p_event_id=>wwv_flow_imp.id(35512274797654366)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// $(''#PESQUISA'').appendTo(''#PAINEL_MODAL .t-DrawerRegion-body'');    ',
'$(''#PESQUISA'').appendTo(''#PAINEL_MODAL .t-DrawerRegion-body'');    ',
'$(''#t_Body_side'').hide();'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35513212096654364)
,p_event_id=>wwv_flow_imp.id(35512274797654366)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(104424946707058277)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(35513642927654363)
,p_name=>'onClickDesfixar'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(35500590083654400)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35514110930654362)
,p_event_id=>wwv_flow_imp.id(35513642927654363)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (apex.item( "P9007_TIPO_PESQUISA" ).getValue() == 1){',
'    apex.item( "P9007_TIPO_PESQUISA" ).setValue( 2 );',
'} else {',
'    apex.item( "P9007_TIPO_PESQUISA" ).setValue( 1 );',
'}',
'    '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(35526330944476315)
,p_name=>'New'
,p_event_sequence=>50
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(35405938442021829)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35526406591476316)
,p_event_id=>wwv_flow_imp.id(35526330944476315)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(35407558303021845)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(35527756763476329)
,p_name=>'New_1'
,p_event_sequence=>60
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(35527258838476324)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35527887914476330)
,p_event_id=>wwv_flow_imp.id(35527756763476329)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(35407558303021845)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(35528130048476333)
,p_name=>'onClickOpcoes'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(35528018242476332)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35528224160476334)
,p_event_id=>wwv_flow_imp.id(35528130048476333)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(35527997095476331)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(35528388744476335)
,p_name=>unistr('onClickDefini\00E7\00F5es')
,p_event_sequence=>80
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(35527997095476331)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35528454357476336)
,p_event_id=>wwv_flow_imp.id(35528388744476335)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(35527997095476331)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3082655851632158)
,p_name=>'onClickFilter = Esquerda'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(3082555673632157)
,p_condition_element=>'P9007_TIPO_PESQUISA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3082759160632159)
,p_event_id=>wwv_flow_imp.id(3082655851632158)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#t_Body_side'').is('':visible'')) {',
'    $(''#t_Body_side'').hide();',
'} else {',
'    $(''#t_Body_side'').show();',
'}',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3082872295632160)
,p_name=>'onClickFilter = Modal'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(3082555673632157)
,p_condition_element=>'P9007_TIPO_PESQUISA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3082974696632161)
,p_event_id=>wwv_flow_imp.id(3082872295632160)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(104424946707058277)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(7805276488774832)
,p_name=>'onDialogCloseNew'
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(35504687507654385)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7805367054774833)
,p_event_id=>wwv_flow_imp.id(7805276488774832)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(35407558303021845)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7805434817774834)
,p_event_id=>wwv_flow_imp.id(7805276488774832)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(35527258838476324)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(7805559556774835)
,p_name=>'onDialogCloseLista'
,p_event_sequence=>120
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(35407558303021845)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7805664076774836)
,p_event_id=>wwv_flow_imp.id(7805559556774835)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(35407558303021845)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7805759071774837)
,p_event_id=>wwv_flow_imp.id(7805559556774835)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(35527258838476324)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(7806085928774840)
,p_name=>'onMoudeEnterTooltip'
,p_event_sequence=>130
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'$("#icon_info")'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'mouseenter'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7806131218774841)
,p_event_id=>wwv_flow_imp.id(7806085928774840)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'PLUGIN_COM.FOS.TOOLTIP'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'$("#icon_info")'
,p_attribute_01=>'static'
,p_attribute_05=>'&P9007_TELA_HELP. (&P9007_CODIGO_ARTEFATO.)'
,p_attribute_08=>'#007BFE'
,p_attribute_09=>'#FFFFFF'
,p_attribute_10=>'scale'
,p_attribute_11=>'500'
,p_attribute_12=>'hover'
,p_attribute_13=>'top'
,p_attribute_14=>'cache-result,escape-html'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(35508595348654374)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'url_new'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'URL_NEW'
,p_internal_uid=>35508595348654374
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(3082178114632153)
,p_page_process_id=>wwv_flow_imp.id(35508595348654374)
,p_page_id=>9007
,p_name=>'p_param1'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>60
,p_value_type=>'ITEM'
,p_value=>'P9007_PARAMETRO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(35509085385654373)
,p_page_process_id=>wwv_flow_imp.id(35508595348654374)
,p_page_id=>9007
,p_name=>'p_url'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>40
,p_value_type=>'ITEM'
,p_value=>'P9007_URL_NEW'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(35509569448654372)
,p_page_process_id=>wwv_flow_imp.id(35508595348654374)
,p_page_id=>9007
,p_name=>'p_codigo_arfato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>50
,p_value_type=>'ITEM'
,p_value=>'P9007_CODIGO_ARTEFATO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(35506619855654379)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'retorna_titulo_tela'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'RETORNA_TITULO_TELA'
,p_internal_uid=>35506619855654379
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(35507162349654377)
,p_page_process_id=>wwv_flow_imp.id(35506619855654379)
,p_page_id=>9007
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P9007_CODIGO_ARTEFATO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(35507621483654376)
,p_page_process_id=>wwv_flow_imp.id(35506619855654379)
,p_page_id=>9007
,p_name=>'p_titulo'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P0_TITULO_TELA'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(35508170728654375)
,p_page_process_id=>wwv_flow_imp.id(35506619855654379)
,p_page_id=>9007
,p_name=>'p_help'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P9007_TELA_HELP'
);
wwv_flow_imp.component_end;
end;
/
