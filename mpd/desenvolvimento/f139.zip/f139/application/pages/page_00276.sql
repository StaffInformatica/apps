prompt --application/pages/page_00276
begin
--   Manifest
--     PAGE: 00276
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_page.create_page(
 p_id=>276
,p_name=>unistr('Usu\00E1rios - Funcionalidades do usu\00E1rio')
,p_alias=>unistr('USU\00C1RIOS-FUNCIONALIDADES-DO-USU\00C1RIO')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Funcionalidades do usu\00E1rio')
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function goto_modal(p1)',
'{',
' var url = "f?p=&APP_ID.:455:&SESSION.";',
' var url1 = ''::NO::P455_METADATA_ENTIDADE_ID:''+p1',
' var l = ("javascript:apex.navigation.dialog(''f?p=&APP_ID.:455:&SESSION.").length;',
' var f = url.slice(0,l) + url.slice(l) + url1 ;',
' f = f.replace(":::::",":");',
' console.log(f);',
' window.location.href = f;',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'tituloHelpTela($v("P276_TELA_TITULO"),$v("P276_TELA_HELP"));',
'',
'$("h1").append($("#icon_info"));',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-actions{',
'    display: none;',
'}',
'',
'.a-CardView-header{',
'    background-color: aliceblue;',
'    border-top-left-radius: 5px;',
'    border-top-right-radius: 5px;',
'}',
'',
'.a-CardView-actions{',
'    padding: 0px;',
'}',
'',
'.a-CardView-items{',
'    grid-gap: 5px;',
'}',
'',
'.texto-info {',
'    font-style: italic;',
'    text-align: justify;',
'    margin: 0;',
'}'))
,p_step_template=>wwv_flow_imp.id(489110489949697573)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--md'
,p_page_component_map=>'24'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(214479546608275372)
,p_plug_name=>'Texto_Mais_Info'
,p_region_css_classes=>'texto-info'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>60
,p_location=>null
,p_plug_source=>'tela.273.info'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(284678725114293631)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>20
,p_location=>null
,p_required_patch=>wwv_flow_imp.id(489109181809697564)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(420514760565886738)
,p_plug_name=>'Pesquisa'
,p_parent_plug_id=>wwv_flow_imp.id(284678725114293631)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_source_type=>'NATIVE_SMART_FILTERS'
,p_filtered_region_id=>wwv_flow_imp.id(420514824965886739)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'compact_numbers_threshold', '10000',
  'more_filters_suggestion_chip', 'N',
  'show_total_row_count', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(420514824965886739)
,p_plug_name=>'Lista'
,p_region_name=>'LISTA'
,p_parent_plug_id=>wwv_flow_imp.id(284678725114293631)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(489153535293697610)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select     ',
'       A.ID,',
'       A.ID_TENANT,',
'       A.ID_USUARIO,',
'       C.DESCRICAO,',
'       pkg_componentes.html_botao_opcao(a.id,276) as opcao',
'  from MPD_USUARIO_FUNCIONALIDADE A',
'  join MPD_USUARIO B on B.ID = A.ID_USUARIO',
'  join MPD_funcionalidade c on c.ID = A.ID_funcionalidade',
'  where A.ID_USUARIO = :P276_ID'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P276_ID'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(263153685774631258)
,p_region_id=>wwv_flow_imp.id(420514824965886739)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>false
,p_title_column_name=>'DESCRICAO'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="row" style="display: flex; flex-wrap: wrap; justify-content: space-between;" >',
'    &OPCAO!RAW.',
'</div>',
'',
'',
'',
'',
'',
'',
'',
''))
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(263154171166631259)
,p_card_id=>wwv_flow_imp.id(263153685774631258)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'mais_detalhes_l'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:277:&SESSION.::&DEBUG.:277:P277_ID,P277_VISUALIZAR:&ID.,1'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'t-Button--link'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(303846344058251353)
,p_plug_name=>'Funcionalidades'
,p_region_name=>'myTree'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(489182013666697625)
,p_plug_display_sequence=>70
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*SELECT',
'    id,',
'    parent,',
'    icon,',
'    rpad('' '', 2 * level, '' '')',
'    || name name',
'FROM',
'    (',
'        SELECT',
'            titulo          name,',
'            id,',
'            id_nivel_pai parent,',
'            null icon',
'        FROM',
'            mpd_grupo_funcionalidade',
'        UNION ALL',
'        SELECT',
'            descricao                ename,',
'            a.id,',
'            id_grupo_funcionalidade  parent,   ',
'            case when c.id is not null then ''fa fa-square-selected-o'' else ''fa fa-square-o'' end as icon',
'        FROM',
'            mpd_funcionalidade a',
'        join mpd_grupo_funcionalidade_funcionalidade b on b.id_funcionalidade = a.id    ',
'        left join mpd_papel_funcionalidade c on c.id_funcionalidade = b.id_funcionalidade',
'        left join mpd_usuario_papel d on d.id_usuario = :P273_ID  ',
'    )',
'START WITH',
'    parent IS NULL',
'CONNECT BY',
'    PRIOR id = parent */',
'',
'',
'SELECT distinct',
'    id,',
'    parent,',
'    icon,',
'    rpad('' '', 2 * level, '' '') || name AS name',
'FROM (',
'    SELECT',
'        titulo AS name,',
'        id,',
'        id_nivel_pai AS parent,',
'        null AS icon',
'    FROM',
'        mpd_grupo_funcionalidade',
'    UNION ALL',
'    SELECT',
'        descricao AS name,',
'        a.id,',
'        id_grupo_funcionalidade AS parent,',
'        CASE',
unistr('            -- Usu\00E1rio master e funcionalidades n\00E3o s\00E3o de adm'),
'            WHEN u.usuario_eh_master = ''S'' AND nvl(a.eh_funcao_de_administrador, ''N'') = ''N'' THEN ''fa fa-square-selected-o''',
unistr('            -- Usu\00E1rio administrador e funcionalidades de adm'),
'            WHEN u.usuario_eh_administrador = ''S'' AND a.eh_funcao_de_administrador = ''S'' THEN ''fa fa-square-selected-o''',
unistr('            -- N\00E3o \00E9 adm e Funcionalidade vinculada papel do usu\00E1rio'),
'            WHEN u.usuario_eh_administrador = ''N'' AND  c.id IS NOT NULL THEN ''fa fa-square-selected-o''',
'            ELSE ''fa fa-square-o''',
'        END AS icon',
'    FROM',
'        mpd_funcionalidade a',
'        JOIN mpd_grupo_funcionalidade_funcionalidade b ON b.id_funcionalidade = a.id',
'        LEFT JOIN mpd_papel_funcionalidade c ON c.id_funcionalidade = a.id',
'        LEFT JOIN mpd_usuario_papel d ON d.id_usuario = :P276_ID',
'        LEFT JOIN mpd_usuario u ON u.id = :P276_ID',
')',
'START WITH',
'    parent IS NULL',
'CONNECT BY',
'    PRIOR id = parent;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_JSTREE'
,p_ajax_items_to_submit=>'P276_ID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'activate_node_link_with', 'D',
  'default_icon_css_class', 'icon-tree-folder',
  'icon_css_class_column', 'ICON',
  'icon_type_css_class', 'a-Icon',
  'node_id_column', 'ID',
  'node_label_column', 'NAME',
  'node_value_column', 'ID',
  'order_siblings_by', 'NAME',
  'parent_key_column', 'PARENT',
  'start_tree_with', 'NULL',
  'tree_hierarchy', 'SQL',
  'tree_tooltip', 'N')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(263156390471631268)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(284678725114293631)
,p_button_name=>'Novo'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(489279734794697688)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'novo_l'
,p_button_redirect_url=>'f?p=&APP_ID.:277:&SESSION.::&DEBUG.:277:P277_ID_USUARIO:&P276_ID.'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>2
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(305644475493761431)
,p_button_sequence=>70
,p_button_name=>'RETRAIR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(489279883613697688)
,p_button_image_alt=>'retrair_l'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-angle-right'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(305644580863761432)
,p_button_sequence=>80
,p_button_name=>'EXPANDIR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(489279883613697688)
,p_button_image_alt=>'expandir_l'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-angle-down'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(214479395471275370)
,p_name=>'P276_TELA_TITULO'
,p_item_sequence=>110
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(214479429654275371)
,p_name=>'P276_TELA_HELP'
,p_item_sequence=>120
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(286267219813724154)
,p_name=>'P276_CODIGO_ARTEFATO'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(420522436541886801)
,p_name=>'P276_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(420514760565886738)
,p_prompt=>'Search'
,p_placeholder=>'Busca por mpd_funcionalidade.descricao_l'
,p_source=>'DESCRICAO'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'collapsed_search_field', 'N',
  'search_type', 'ROW')).to_clob
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(420522861681886805)
,p_name=>'P276_NOME_MENU'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(284678725114293631)
,p_item_display_point=>'ORDER_BY_ITEM'
,p_prompt=>'mpd_usuario.nome_l'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(284517659487063759)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(673114489349282759)
,p_name=>'P276_ID'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(263161774043631289)
,p_computation_sequence=>20
,p_computation_item=>'P276_NOME_MENU'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>'select nome from mpd_usuario a where id = :P276_ID'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(263169368884631308)
,p_name=>'INFO-Mouse enter'
,p_event_sequence=>100
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'$("#icon_info")'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'mouseenter'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(263169912308631310)
,p_event_id=>wwv_flow_imp.id(263169368884631308)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.FOS.TOOLTIP'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'$("#icon_info")'
,p_attribute_01=>'plsql'
,p_attribute_07=>'return PKG_UTIL.retorna_descricao_artefato(:APP_PAGE_ID);'
,p_attribute_08=>'#ffffff'
,p_attribute_09=>'#1a457e'
,p_attribute_10=>'scale'
,p_attribute_11=>'500'
,p_attribute_12=>'hover'
,p_attribute_13=>'right'
,p_attribute_14=>'cache-result:interactive-text'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(263167074796631303)
,p_name=>'onDialogClosedBTN_NOVO'
,p_event_sequence=>350
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(263156390471631268)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(263168037082631305)
,p_event_id=>wwv_flow_imp.id(263167074796631303)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(420514824965886739)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(263329360085750569)
,p_name=>'onDialogClosedLISTA'
,p_event_sequence=>360
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(420514824965886739)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(263329428294750570)
,p_event_id=>wwv_flow_imp.id(263329360085750569)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(420514824965886739)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(305515732166297934)
,p_name=>'onPageLoad'
,p_event_sequence=>370
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(305515832754297935)
,p_event_id=>wwv_flow_imp.id(305515732166297934)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_EXPAND'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(303846344058251353)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(305644709497761433)
,p_name=>'onClickRETRAIR'
,p_event_sequence=>380
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(305644475493761431)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(305644743371761434)
,p_event_id=>wwv_flow_imp.id(305644709497761433)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_COLLAPSE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(303846344058251353)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(305644871078761435)
,p_event_id=>wwv_flow_imp.id(305644709497761433)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(305644475493761431)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(305644942773761436)
,p_event_id=>wwv_flow_imp.id(305644709497761433)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(305644580863761432)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(305645029030761437)
,p_name=>'onClickEXPANDIR'
,p_event_sequence=>390
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(305644580863761432)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(305645211369761438)
,p_event_id=>wwv_flow_imp.id(305645029030761437)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_EXPAND'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(303846344058251353)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(305645253875761439)
,p_event_id=>wwv_flow_imp.id(305645029030761437)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(305644580863761432)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(305645331383761440)
,p_event_id=>wwv_flow_imp.id(305645029030761437)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(305644475493761431)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(214478984989275366)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'retorna_titulo_help'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'RETORNA_TITULO_TELA'
,p_internal_uid=>30964865304035838
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(214479085701275367)
,p_page_process_id=>wwv_flow_imp.id(214478984989275366)
,p_page_id=>276
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'nvl(:P276_CODIGO_ARTEFATO,:APP_PAGE_ID)'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(214479121090275368)
,p_page_process_id=>wwv_flow_imp.id(214478984989275366)
,p_page_id=>276
,p_name=>'p_titulo'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P276_TELA_TITULO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(214479259174275369)
,p_page_process_id=>wwv_flow_imp.id(214478984989275366)
,p_page_id=>276
,p_name=>'p_help'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P276_TELA_HELP'
);
wwv_flow_imp.component_end;
end;
/
