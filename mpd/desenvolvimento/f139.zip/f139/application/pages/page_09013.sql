prompt --application/pages/page_09013
begin
--   Manifest
--     PAGE: 09013
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>9013
,p_name=>'Template - Formulario com lista Wizard'
,p_alias=>'TEMPLATE-FORMULARIO-COM-LISTA-WIZARD'
,p_page_mode=>'MODAL'
,p_step_title=>'Template - Formulario com lista Wizard'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function copiarValor(origemId, destinoId) {',
'    var datePicker = document.getElementById(origemId);',
'    var valorOrigem = datePicker ? datePicker.value : ''''; ',
'    document.getElementById(destinoId).value = valorOrigem;',
'    //console.log(document.getElementById(destinoId).value);',
'}',
'',
'function checkInputAndToggleClass(inputElement) {',
unistr('    // Verificar se o campo de entrada est\00E1 preenchido'),
'    //console.log(inputElement.value);',
'    if (inputElement.value.trim() !== "") {',
unistr('        // Localizar a div pai que cont\00E9m "CONTAINER" no ID'),
'        let parentDiv = inputElement.closest("div[id*=''CONTAINER'']");',
'        ',
'        // Se a div for encontrada, adicionar a classe js-show-label',
'        if (parentDiv) {',
'            parentDiv.classList.add("js-show-label");',
'        }',
'    } else {',
'        // Se o valor estiver vazio, remover a classe js-show-label',
'        let parentDiv = inputElement.closest("div[id*=''CONTAINER'']");',
'        ',
'        // Remover a classe js-show-label se ela existir',
'        if (parentDiv) {',
'            parentDiv.classList.remove("js-show-label");',
'        }',
'    }',
'}',
'',
'// function toggleFileUpload() {',
'//     // Seleciona o elemento <a-dynamic-content>',
'//     var dynamicContent = document.querySelector(''a-dynamic-content'');',
'//     console.log(dynamicContent);',
unistr('//     // Verifica se o elemento existe e se cont\00E9m a palavra "mostra_file"'),
'//     if (dynamicContent && dynamicContent.innerHTML.includes(''mostra_file'')) {',
'//         // Se encontrar, mostra o item de upload de arquivo',
'//         apex.item(''P9010_FILE1'').show();',
'//     } else {',
unistr('//         // Caso contr\00E1rio, oculta o item de upload de arquivo'),
'//         apex.item(''P9010_FILE1'').hide();',
'//     }',
'// }',
'',
'document.addEventListener("DOMContentLoaded", function() {',
'  //   toggleFileUpload();  ',
'  var windowWidth = 400;  // Largura da janela popup',
'  var windowHeight = 450;  // Altura da janela popup',
'',
'  // Calcula o centro da tela',
'  var left = (window.screen.width - windowWidth) / 2;',
'  var top = (window.screen.height - windowHeight) / 2;',
'',
unistr('  // Modifica os par\00E2metros de ''left'' e ''top'' no popup gerado'),
'  var originalOpen = window.open;',
'  window.open = function(url, name, specs) {',
unistr('    // Adiciona ou substitui os par\00E2metros ''left'' e ''top'''),
'    specs = specs.replace(/left=\d+/, ''left='' + left);',
'    specs = specs.replace(/top=\d+/, ''top='' + top);',
'',
unistr('    // Se ''left'' e ''top'' n\00E3o existirem, adiciona os par\00E2metros'),
'    if (!specs.includes(''left='')) specs += '',left='' + left;',
'    if (!specs.includes(''top='')) specs += '',top='' + top;',
'',
unistr('    // Chama a fun\00E7\00E3o window.open original com as modifica\00E7\00F5es'),
'    return originalOpen.call(window, url, name, specs);',
'  };',
'});'))
,p_javascript_code_onload=>'tituloTela($v("P9013_TELA_TITULO")+'' (''+$v("P9013_CODIGO_ARTEFATO")+'')'');'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.centro{',
'    display: grid;',
'    justify-items: center;',
'}',
'',
'.select option.selected {',
'    color: #888; /* Cor mais clara para parecer um placeholder */',
'    opacity: 0.5; /* Reduz a opacidade */',
'}',
'',
'.t-Region-body{',
'    padding: 8px;',
'}'))
,p_step_template=>wwv_flow_imp.id(340974912275556190)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_protection_level=>'C'
,p_page_component_map=>'25'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(98415560714002587)
,p_plug_name=>'List'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--textContent:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>200
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9013_CODIGO_ARTEFATO,''TD452'');',
'begin',
'    begin',
'        EXECUTE IMMEDIATE ',
'            ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_report(:param1); END;''',
'            -- ''BEGIN :l_sql := UI_MPD_100.sql_report; END;''',
'            USING OUT l_sql, IN :P9013_PARAMETRO; ',
'        exception ',
'            when others then',
'                return ''select 1 from dual'';',
'    end;',
'    return l_sql;       ',
'end;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P9013_PARAMETRO'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(98415675705002588)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'Nenhum registro adicionado ainda.'
,p_show_actions_menu=>'N'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'TESTE'
,p_internal_uid=>141286547365644861
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(99480385374440672)
,p_db_column_name=>'CAMPO1'
,p_display_order=>20
,p_column_identifier=>'N'
,p_column_label=>'&P9013_LABEL_CAMPO1.'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P9013_LABEL_CAMPO1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(98415953862002591)
,p_db_column_name=>'CAMPO2'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'&P9013_LABEL_CAMPO2.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P9013_LABEL_CAMPO2'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(98416047556002592)
,p_db_column_name=>'CAMPO3'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'&P9013_LABEL_CAMPO3.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P9013_LABEL_CAMPO3'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(98416115519002593)
,p_db_column_name=>'CAMPO4'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'&P9013_LABEL_CAMPO4.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P9013_LABEL_CAMPO4'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(98416270216002594)
,p_db_column_name=>'CAMPO5'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'&P9013_LABEL_CAMPO5.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P9013_LABEL_CAMPO5'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(98416316516002595)
,p_db_column_name=>'CAMPO6'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'&P9013_LABEL_CAMPO6.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P9013_LABEL_CAMPO6'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(98416405602002596)
,p_db_column_name=>'CAMPO7'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'&P9013_LABEL_CAMPO7.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P9013_LABEL_CAMPO7'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(98416550009002597)
,p_db_column_name=>'CAMPO8'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'&P9013_LABEL_CAMPO8.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P9013_LABEL_CAMPO8'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(98416629373002598)
,p_db_column_name=>'CAMPO9'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'&P9013_LABEL_CAMPO9.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P9013_LABEL_CAMPO9'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(98416751450002599)
,p_db_column_name=>'CAMPO10'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'&P9013_LABEL_CAMPO10.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P9013_LABEL_CAMPO10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(98416804882002600)
,p_db_column_name=>'OPCAO'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'&P9013_LABEL_OPCAO.'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div style="display: flex; align-items: center; justify-content: center; flex-grow: 1;">',
'    <span #OPCAO# style="cursor: pointer; color: var(--a-button-state-text-color, var(--a-button-type-text-color, var(--a-button-text-color, inherit)));" ',
'        class="fa fa-ellipsis-v js-dlg-refresh" title="&P0_LABEL_OPCAO!RAW.">',
'    </span>',
'</div>'))
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(98418944026002621)
,p_db_column_name=>'ID'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(99463248705292211)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'796391'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CAMPO2:CAMPO3:CAMPO4:CAMPO5:CAMPO6:CAMPO7:OPCAO:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(99480915010440678)
,p_plug_name=>'Header'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(341013639389556225)
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9013_CODIGO_ARTEFATO,''TD452'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_cabecalho(:param1,:param2,:param3); END;''',
'        USING OUT l_sql, IN nvl(:P9013_ID,:P9013_PARAMETRO),nvl(:P9013_PARAMETRO2,:P9013_PARAMETRO),:P9013_PARAMETRO3;',
'',
'    return l_sql;       ',
'end;',
''))
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P9013_ID,P9013_PARAMETRO,P9013_PARAMETRO2,P9013_PARAMETRO3'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from all_procedures',
'where upper(object_name) = upper(''ui_mpd_''||:p9013_codigo_artefato)',
'and upper(procedure_name) = upper(''sql_cabecalho'')',
'and upper(object_type) = upper(''package'');'))
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(253274378328915089)
,p_plug_name=>'Steps'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#:t-WizardSteps--displayLabels'
,p_plug_template=>wwv_flow_imp.id(341059031473556249)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_list_id=>wwv_flow_imp.id(19819704559765699)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(341136199098556298)
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    1',
'from srv_artefato_wizard a',
'join srv_artefato_versionado b on b.id = a.id_artefato_versionado',
'join srv_artefato c on c.id = b.id_artefato',
'join srv_artefato_versionado b1 on b1.id = a.id_artefato_versionado_base',
'join srv_artefato c1 on c1.id = b1.id_artefato',
'where c.codigo_artefato = nvl( apex_util.get_session_state(''P''||:APP_PAGE_ID||''_CODIGO_WIZARD''),:p0_codigo_artefato)'))
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(253274860760916736)
,p_plug_name=>'Footer'
,p_region_css_classes=>'u-margin-bottom-none'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(341013639389556225)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(407342637247093522)
,p_plug_name=>unistr('Formul\00E1rio')
,p_title=>'Informe'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody:t-Form--large'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>60
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_html clob;        ',
'    l_codigo_artefato varchar2(128) := nvl(:P9013_CODIGO_ARTEFATO,100);',
'begin',
'    pkg_ui.gerar_formulario(l_codigo_artefato,nvl(:P9013_ID,:P9013_COPIA),:P9013_VISUALIZAR,l_html,:P9013_PARAMETRO,:P9013_PARAMETRO2); ',
'    return l_html;',
'end;'))
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P9013_CODIGO_ARTEFATO,P9013_COPIA,P9013_PARAMETRO,P9013_PARAMETRO2,P9013_VISUALIZAR'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(19824441685769373)
,p_button_sequence=>30
,p_button_name=>'opcao'
,p_button_static_id=>'BOTAO_OPCAO'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_image_alt=>'Opcao'
,p_button_redirect_url=>'&P9013_URL_OPCAO.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from all_procedures',
'where upper(object_name) = upper(''ui_mpd_''||:p9013_codigo_artefato)',
'and upper(procedure_name) = upper(''mostra_opcao'')',
'and upper(object_type) = upper(''package'');'))
,p_button_condition_type=>'EXISTS'
,p_button_css_classes=>'color-text'
,p_icon_css_classes=>'fa-ellipsis-v-o'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>1
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(19833187117769431)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(407342637247093522)
,p_button_name=>'Create'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--success'
,p_button_template_id=>wwv_flow_imp.id(341144157120556305)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Incluir'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from all_procedures',
'where upper(object_name) = upper(''ui_mpd_''||:p9013_codigo_artefato)',
'and upper(procedure_name) = upper(''esconde_incluir'')',
'and upper(object_type) = upper(''package'');'))
,p_button_condition_type=>'NOT_EXISTS'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(19834340658769436)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(253274860760916736)
,p_button_name=>'Proximo'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(341144305939556305)
,p_button_image_alt=>'Proximo'
,p_button_position=>'NEXT'
,p_button_condition=>'P9013_URL_PROXIMO'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-angle-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(19833963311769434)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(253274860760916736)
,p_button_name=>'DoneC'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(341144305939556305)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Concluir'
,p_button_position=>'NEXT'
,p_button_condition=>':P9013_ID is null and :P9013_URL_PROXIMO is null'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-check-circle'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(19834782924769437)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(253274860760916736)
,p_button_name=>'Voltar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(341144305939556305)
,p_button_image_alt=>'Voltar'
,p_button_position=>'PREVIOUS'
,p_button_condition=>'P9013_URL_ANTERIOR'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-angle-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(19866044201769548)
,p_branch_name=>'goto_anterior'
,p_branch_action=>'P9013_URL_ANTERIOR'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'BRANCH_TO_URL_IDENT_BY_ITEM'
,p_branch_when_button_id=>wwv_flow_imp.id(19834782924769437)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(19866501613769549)
,p_branch_name=>'goto_proximo'
,p_branch_action=>'P9013_URL_PROXIMO'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'BRANCH_TO_URL_IDENT_BY_ITEM'
,p_branch_when_button_id=>wwv_flow_imp.id(19834340658769436)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(19866859221769550)
,p_branch_name=>'goto_atual'
,p_branch_action=>'f?p=&APP_ID.:9013:&SESSION.::&DEBUG.:9013:P9013_PARAMETRO,P9013_CODIGO_ARTEFATO,P0_CODIGO_ARTEFATO,P9013_PARAMETRO2,P9013_CODIGO_WIZARD:&P9013_PARAMETRO.,&P9013_CODIGO_ARTEFATO.,&P0_CODIGO_ARTEFATO.,&P9013_PARAMETRO2.,&P9013_CODIGO_WIZARD.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(19833187117769431)
,p_branch_sequence=>30
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29834500712827742)
,p_name=>'P9013_PARAMETRO3'
,p_item_sequence=>140
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29835749699827754)
,p_name=>'P9013_LABEL_OPCAO'
,p_item_sequence=>220
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31529293067357676)
,p_name=>'P9013_CODIGO_WIZARD'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35063964158922880)
,p_name=>'P9013_PODE_AVANCAR'
,p_item_sequence=>230
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(51717993963864379)
,p_name=>'P9013_URL_OPCAO'
,p_item_sequence=>50
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_url clob;',
'    l_pagina varchar2(256) := nvl(:P9013_CODIGO_ARTEFATO,''TD452'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :url := UI_MPD_''||l_pagina||''.mostra_opcao(:param1,:param2,:param3); END;''',
'        USING OUT l_url, IN nvl(:P9013_ID,:P9013_PARAMETRO),nvl(:P9013_PARAMETRO2,:P9013_PARAMETRO),:P9013_PARAMETRO3;',
'',
'    return l_url;       ',
'end;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from all_procedures',
'where upper(object_name) = upper(''ui_mpd_''||:p9013_codigo_artefato)',
'and upper(procedure_name) = upper(''mostra_opcao'')',
'and upper(object_type) = upper(''package'');'))
,p_display_when_type=>'EXISTS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77485762431337880)
,p_name=>'P9013_SELECTED_ITEM_ID'
,p_item_sequence=>240
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77485822898337881)
,p_name=>'P9013_SELECTED_ITEM_TEXT'
,p_item_sequence=>250
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98422105795002640)
,p_name=>'P9013_LABEL_CAMPO1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(98415560714002587)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98422215021002641)
,p_name=>'P9013_LABEL_CAMPO7'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(98415560714002587)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98422284693002642)
,p_name=>'P9013_LABEL_CAMPO2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(98415560714002587)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98422375994002643)
,p_name=>'P9013_LABEL_CAMPO8'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(98415560714002587)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98422480892002644)
,p_name=>'P9013_LABEL_CAMPO6'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(98415560714002587)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98422599133002645)
,p_name=>'P9013_LABEL_CAMPO5'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(98415560714002587)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98422715963002646)
,p_name=>'P9013_LABEL_CAMPO3'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(98415560714002587)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98422816185002647)
,p_name=>'P9013_LABEL_CAMPO4'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(98415560714002587)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98422876341002648)
,p_name=>'P9013_LABEL_CAMPO9'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(98415560714002587)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98422967980002649)
,p_name=>'P9013_LABEL_CAMPO10'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(98415560714002587)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(124692921076131253)
,p_name=>'P9013_ETAPA'
,p_item_sequence=>210
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(177898511411057275)
,p_name=>'P9013_URL_PROXIMO'
,p_item_sequence=>180
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(177898608718057276)
,p_name=>'P9013_URL_ANTERIOR'
,p_item_sequence=>190
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(282520816267125753)
,p_name=>'P9013_ID'
,p_item_sequence=>150
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(326927684505299499)
,p_name=>'P9013_PARAMETRO'
,p_item_sequence=>120
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(326927779524299500)
,p_name=>'P9013_PARAMETRO2'
,p_item_sequence=>130
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(326927859606299501)
,p_name=>'P9013_TELA_TITULO'
,p_item_sequence=>160
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(326927929836299502)
,p_name=>'P9013_TELA_HELP'
,p_item_sequence=>170
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(407291117918927469)
,p_name=>'P9013_CODIGO_ARTEFATO'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(407371914916093753)
,p_name=>'P9013_SUCESSO'
,p_item_sequence=>100
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(407523081606090733)
,p_name=>'P9013_VISUALIZAR'
,p_item_sequence=>90
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(409774628128654252)
,p_name=>'P9013_COPIA'
,p_item_sequence=>110
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(19841866579769473)
,p_computation_sequence=>10
,p_computation_item=>'P9013_LABEL_CAMPO1'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9013_CODIGO_ARTEFATO,''TD452'');',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(1); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(19842251445769474)
,p_computation_sequence=>20
,p_computation_item=>'P9013_LABEL_CAMPO2'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9013_CODIGO_ARTEFATO,452);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(2); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(19842703453769475)
,p_computation_sequence=>30
,p_computation_item=>'P9013_LABEL_CAMPO3'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9013_CODIGO_ARTEFATO,452);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(3); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(19843034789769477)
,p_computation_sequence=>40
,p_computation_item=>'P9013_LABEL_CAMPO4'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9013_CODIGO_ARTEFATO,452);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(4); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(19843500013769478)
,p_computation_sequence=>50
,p_computation_item=>'P9013_LABEL_CAMPO5'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9013_CODIGO_ARTEFATO,452);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(5); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(19843855869769479)
,p_computation_sequence=>60
,p_computation_item=>'P9013_LABEL_CAMPO6'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9013_CODIGO_ARTEFATO,452);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(6); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(19844244958769480)
,p_computation_sequence=>70
,p_computation_item=>'P9013_LABEL_CAMPO7'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9013_CODIGO_ARTEFATO,452);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(7); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(19844633710769482)
,p_computation_sequence=>80
,p_computation_item=>'P9013_LABEL_CAMPO8'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9013_CODIGO_ARTEFATO,452);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(8); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(19845080791769483)
,p_computation_sequence=>90
,p_computation_item=>'P9013_LABEL_CAMPO9'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9013_CODIGO_ARTEFATO,452);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(9); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(19845458696769485)
,p_computation_sequence=>100
,p_computation_item=>'P9013_LABEL_CAMPO10'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9013_CODIGO_ARTEFATO,452);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.label_coluna(10); END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(19841505324769472)
,p_computation_sequence=>110
,p_computation_item=>'P9013_PODE_AVANCAR'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9013_CODIGO_ARTEFATO,''TD452'');',
'    l_log_1 boolean;',
'    l_log_2 boolean;',
'begin',
'    --l_log_1 := :P9013_ID is null and :P9013_URL_PROXIMO is null;',
'    begin',
'        EXECUTE IMMEDIATE ',
'            ''BEGIN :l_log_2 := UI_MPD_''||l_pagina||''.condicao_proximo(:param1); END;''',
'            USING OUT l_log_2, IN :P9013_PARAMETRO; ',
'        exception ',
'            when others then',
'                l_log_2 := true;',
'    end;',
'    if l_log_2 then    ',
'        return ''true'';',
'    else',
'        return ''false'';',
'    end if;',
'end;'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19854016465769511)
,p_name=>'onCloseOpcao'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(98415560714002587)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19854941967769515)
,p_event_id=>wwv_flow_imp.id(19854016465769511)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(98415560714002587)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19854445130769513)
,p_event_id=>wwv_flow_imp.id(19854016465769511)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(99480915010440678)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19857754397769523)
,p_name=>'onCloseBotaoOpcao'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#BOTAO_OPCAO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19858234736769524)
,p_event_id=>wwv_flow_imp.id(19857754397769523)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(98415560714002587)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19858737283769526)
,p_event_id=>wwv_flow_imp.id(19857754397769523)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(99480915010440678)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19855353078769516)
,p_name=>'onChangePodeAvancar'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9013_PODE_AVANCAR'
,p_condition_element=>'P9013_PODE_AVANCAR'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'true'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19855837655769518)
,p_event_id=>wwv_flow_imp.id(19855353078769516)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(19833963311769434)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19857347062769522)
,p_event_id=>wwv_flow_imp.id(19855353078769516)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(19833963311769434)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19856364902769520)
,p_event_id=>wwv_flow_imp.id(19855353078769516)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(19834340658769436)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19856870234769521)
,p_event_id=>wwv_flow_imp.id(19855353078769516)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(19834340658769436)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19859159259769527)
,p_name=>'onClickjs-dlg-setvalue'
,p_event_sequence=>40
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.js-dlg-setvalue'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19859705746769528)
,p_event_id=>wwv_flow_imp.id(19859159259769527)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'window._lastDlgLinkZoom = $(this.triggeringElement)',
'    .closest(''span.lov'')   // sobe para o container',
'    .find(''input[coluna], textarea[coluna]'') // pega input OU textarea com atributo ''coluna''',
'    .attr(''coluna'');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19860067953769529)
,p_name=>'onClosejs-dlg-setvalue'
,p_event_sequence=>50
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'document'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'!!window._lastDlgLinkZoom'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19861098743769532)
,p_event_id=>wwv_flow_imp.id(19860067953769529)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9013_SELECTED_ITEM_ID'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P9004_SELECTED_ITEM_ID'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19861553271769534)
,p_event_id=>wwv_flow_imp.id(19860067953769529)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P9013_SELECTED_ITEM_TEXT'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P9004_SELECTED_ITEM_TEXT'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19860560708769531)
,p_event_id=>wwv_flow_imp.id(19860067953769529)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'window._lastDlgLinkZoom = null;'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19865169096769546)
,p_name=>'onChangeSelectItemId'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9013_SELECTED_ITEM_ID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19865569581769547)
,p_event_id=>wwv_flow_imp.id(19865169096769546)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''input[coluna="'' + window._lastDlgLinkZoom + ''"], textarea[coluna="'' + window._lastDlgLinkZoom + ''"]'')',
'  .closest(''span.lov'')',
'  .find(''input[type=hidden]'');'))
,p_attribute_01=>'PLSQL_EXPRESSION'
,p_attribute_04=>':P9013_SELECTED_ITEM_ID'
,p_attribute_07=>'P9013_SELECTED_ITEM_ID'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19864285477769543)
,p_name=>'onChangeSelectItemText'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9013_SELECTED_ITEM_TEXT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19864817701769545)
,p_event_id=>wwv_flow_imp.id(19864285477769543)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$('':is(input, textarea)[coluna="'' + window._lastDlgLinkZoom + ''"]'')',
'  .closest(''span.lov'')',
'  .find('':is(input[type=text], textarea)'');'))
,p_attribute_01=>'PLSQL_EXPRESSION'
,p_attribute_04=>':P9013_SELECTED_ITEM_TEXT'
,p_attribute_07=>'P9013_SELECTED_ITEM_TEXT'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19861993110769536)
,p_name=>'onClickCreate'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(19833187117769431)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19862476913769537)
,p_event_id=>wwv_flow_imp.id(19861993110769536)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.server.process(',
'    "VALIDAR",',
'    { x01: $v("P9013_ID") },',
'    {',
'        dataType: ''json'',',
'        success: function(pData) {',
'            if (pData.length > 0) {',
'',
unistr('                // Se houver sem valida\00E7\00E3o, segue direto'),
'                if (pData[0].hasOwnProperty(''semValidacao'')) {',
unistr('                    console.info("Sem valida\00E7\00E3o ao gravar");'),
'                    apex.submit({ request: "Create" });',
'                    return;',
'                }',
'',
unistr('                // Fun\00E7\00E3o recursiva para exibir mensagens em sequ\00EAncia'),
'                function exibirConfirmacoes(index) {',
'                    if (index >= pData.length) {',
unistr('                        // Terminou todas as confirma\00E7\00F5es, agora pode submeter'),
'                        apex.submit({ request: "Create" });',
'                        return;',
'                    }',
'',
'                    var msg = pData[index];',
'                    apex.message.confirm(',
'                        msg.mensagem,',
'                        function(okPressed) {',
'                            if (okPressed) {',
unistr('                                // Usu\00E1rio confirmou \2192 mostra a pr\00F3xima'),
'                                exibirConfirmacoes(index + 1);',
'                            } else {',
unistr('                                // Usu\00E1rio cancelou \2192 aborta'),
unistr('                                console.warn("Usu\00E1rio cancelou na etapa " + index);'),
'                                return;',
'                            }',
'                        },',
'                        {',
'                            title: msg.help,',
'                            style: "information",',
'                            dialogClasses: "minha-modal-customizada",',
'                            iconClasses: "fa fa-question-circle fa-2x text-warning",',
'                            confirmLabel: $v("P0_LABEL_SALVAR")',
'                        }',
'                    );',
'                }',
'',
'                // Inicia exibindo a primeira',
'                exibirConfirmacoes(0);',
'',
'            } else {',
unistr('                // Nenhuma mensagem \2192 segue normal'),
'                apex.submit({ request: "Create" });',
'            }',
'        }',
'    }',
');',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19862883651769539)
,p_name=>'New'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(19824441685769373)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19863341021769540)
,p_event_id=>wwv_flow_imp.id(19862883651769539)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(98415560714002587)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19863886158769542)
,p_event_id=>wwv_flow_imp.id(19862883651769539)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(407342637247093522)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(19847009725769490)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Post-create'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_messages pkg_mensagem.message_record_table;',
'    l_pagina varchar2(256) := nvl(:P9013_CODIGO_ARTEFATO,325);',
'BEGIN',
'    v_messages := pkg_mensagem.message_record_table();',
'    EXECUTE IMMEDIATE',
'        ''BEGIN UI_MPD_''|| l_pagina ||''.post_create''||',
'        ''(p_id => :P9013_ID, p_sucesso => :P9013_SUCESSO, p_messages => :v_messages); END;''',
'        USING OUT :P9013_ID, OUT :P9013_SUCESSO, OUT v_messages;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'Create'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_process_success_message=>'&P9013_SUCESSO.'
,p_internal_uid=>62717881386411763
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(19853563548769510)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'DoneC'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>62724435209411783
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(19847742528769493)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'retorna_titulo_help'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'RETORNA_TITULO_TELA'
,p_internal_uid=>62718614189411766
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19848297134769494)
,p_page_process_id=>wwv_flow_imp.id(19847742528769493)
,p_page_id=>9013
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'nvl(:P9013_CODIGO_ARTEFATO,:APP_PAGE_ID)'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19848792227769496)
,p_page_process_id=>wwv_flow_imp.id(19847742528769493)
,p_page_id=>9013
,p_name=>'p_titulo'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P9013_TELA_TITULO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19849262596769497)
,p_page_process_id=>wwv_flow_imp.id(19847742528769493)
,p_page_id=>9013
,p_name=>'p_help'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P9013_TELA_HELP'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(19849705431769499)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'url_wizard'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'URL_WIZARD'
,p_process_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    1',
'from srv_artefato_wizard a',
'join srv_artefato_versionado b on b.id = a.id_artefato_versionado',
'join srv_artefato c on c.id = b.id_artefato',
'join srv_artefato_versionado b1 on b1.id = a.id_artefato_versionado_base',
'join srv_artefato c1 on c1.id = b1.id_artefato',
'where c.codigo_artefato = nvl( apex_util.get_session_state(''P''||:APP_PAGE_ID||''_CODIGO_WIZARD''),:p0_codigo_artefato)'))
,p_process_when_type=>'EXISTS'
,p_internal_uid=>62720577092411772
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19850162896769500)
,p_page_process_id=>wwv_flow_imp.id(19849705431769499)
,p_page_id=>9013
,p_name=>'p_codigo_artefato_base'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>20
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'case when :P9013_CODIGO_WIZARD is null then :P9013_CODIGO_ARTEFATO else :P9013_CODIGO_WIZARD end'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19850633059769502)
,p_page_process_id=>wwv_flow_imp.id(19849705431769499)
,p_page_id=>9013
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P9013_CODIGO_ARTEFATO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19851182322769503)
,p_page_process_id=>wwv_flow_imp.id(19849705431769499)
,p_page_id=>9013
,p_name=>'p_url_anterior'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P9013_URL_ANTERIOR'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19851707968769505)
,p_page_process_id=>wwv_flow_imp.id(19849705431769499)
,p_page_id=>9013
,p_name=>'p_url_proximo'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>40
,p_value_type=>'ITEM'
,p_value=>'P9013_URL_PROXIMO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19852181731769506)
,p_page_process_id=>wwv_flow_imp.id(19849705431769499)
,p_page_id=>9013
,p_name=>'p_param1'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>50
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'nvl(:P9013_ID,:P9013_PARAMETRO)'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19852686477769507)
,p_page_process_id=>wwv_flow_imp.id(19849705431769499)
,p_page_id=>9013
,p_name=>'p_param2'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>60
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(19853220047769509)
,p_page_process_id=>wwv_flow_imp.id(19849705431769499)
,p_page_id=>9013
,p_name=>'p_etapa'
,p_direction=>'OUT'
,p_data_type=>'NUMBER'
,p_ignore_output=>false
,p_display_sequence=>70
,p_value_type=>'ITEM'
,p_value=>'P9013_ETAPA'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(19845772969769485)
,p_process_sequence=>40
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare    ',
'    l_label_opcao varchar2(256);',
'begin    ',
'    select pkg_ui.retorna_label_botao(''opcao'') into l_label_opcao from dual;    ',
'    :P9013_LABEL_OPCAO := l_label_opcao;    ',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>62716644630411758
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(19847410080769491)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'enviarParamentros'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    prc_enviar_parametros(',
'        apex_application.g_x01,',
'        apex_application.g_x02,',
'        apex_application.g_x03,',
'        apex_application.g_x04',
'    );',
'    if apex_application.g_x01 is not null then',
'        if upper(apex_application.g_x02) = upper(''id_tenant'') and :P9013_ID is null then',
'            :P0_TENANT_INFORMADO := apex_application.g_x03;',
'        end if;',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>62718281741411764
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(19846150632769487)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'atribuiValorAJAX'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_json CLOB;',
'BEGIN',
'    l_json := pkg_formulario_dinamico.executa_sql_parametrizado(',
'        p_param1 => apex_application.g_x01,',
'        p_sql    => apex_application.g_x02',
'    );',
'    sys.htp.init;   -- limpa buffer anterior',
'    owa_util.mime_header(''application/json'', FALSE);',
'    htp.p(''Cache-Control: no-cache'');',
'    owa_util.http_header_close;',
'    htp.prn(l_json); -- imprime exatamente o JSON',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>62717022293411760
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(19846625496769488)
,p_process_sequence=>30
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'VALIDAR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_clob clob;',
'    v_messages pkg_mensagem.message_record_table;',
'    l_pagina varchar2(256) := nvl(:p9013_codigo_artefato,''td452'');',
'begin',
'    execute immediate',
'        ''begin :v_messages := ui_mpd_''||l_pagina||''.valida(:p_id); end;''',
'        using out v_messages, in apex_application.g_x01;',
'',
'    -- Monta JSON de retorno',
'    apex_json.initialize_clob_output;',
'    apex_json.open_array;',
'',
'    if v_messages.count > 0 then',
'        for i in 1 .. v_messages.count loop',
'            apex_json.open_object;',
'            apex_json.write(''mensagem'',       v_messages(i).mensagem);',
'            apex_json.write(''instrucao'',      v_messages(i).instrucao);',
'            apex_json.write(''help'',           v_messages(i).help);',
'            apex_json.write(''local_exibicao'', v_messages(i).local_exibicao);',
'            apex_json.write(''nome_item'',      v_messages(i).nome_item);',
'            apex_json.write(''tipo'',           v_messages(i).tipo);',
'            apex_json.close_object;',
'        end loop;',
'    end if;',
'',
'    apex_json.close_array;',
'    l_clob := apex_json.get_clob_output;',
'    apex_json.free_output;    ',
'    sys.htp.prn(l_clob);     ',
'',
'    exception',
'        when others then',
'        -- Monta JSON de erro consistente',
'        apex_json.initialize_clob_output;',
'        apex_json.open_array;',
'        apex_json.open_object;',
'        apex_json.write(''semValidacao'', ''sim'');',
'        apex_json.close_object;',
'        apex_json.close_array;',
'',
'        l_clob := apex_json.get_clob_output;',
'        apex_json.free_output;    ',
'        sys.htp.prn(l_clob);     ',
'    ',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>62717497157411761
);
wwv_flow_imp.component_end;
end;
/
