prompt --application/pages/page_09008
begin
--   Manifest
--     PAGE: 09008
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_page.create_page(
 p_id=>9008
,p_name=>'Template - List'
,p_alias=>'TEMPLATE-LIST'
,p_step_title=>'Template - List'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(104494299375215143)
,p_plug_name=>'Filtrar por Esquerda'
,p_title=>'tela.filtrar-por.l'
,p_region_name=>'PAINEL_LEFT'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(341046435992556242)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_02'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(104495224350215152)
,p_plug_name=>'Filtrar por Modal'
,p_title=>'tela.filtrar-por.l'
,p_region_name=>'PAINEL_MODAL'
,p_region_template_options=>'#DEFAULT#:t-DialogRegion--noPadding:js-dialog-class-t-Drawer--pullOutEnd:js-dialog-class-t-Drawer--md'
,p_plug_template=>wwv_flow_imp.id(341039558490556238)
,p_plug_display_sequence=>120
,p_plug_display_point=>'REGION_POSITION_04'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(106455966028569409)
,p_plug_name=>'List'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(341017957619556227)
,p_plug_display_sequence=>70
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9008_CODIGO_ARTEFATO,266);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.sql_card; END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'link_target', 'f?p=&APP_ID.:9000:&SESSION.::&DEBUG.:9000:P9000_ID,P9000_PAGINA:&ID.,&P9008_CODIGO_ARTEFATO.',
  'text_column', 'LIST_TITLE')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(35571673764811269)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(104494299375215143)
,p_button_name=>'fixar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'botao.fixar-desfixar.l'
,p_button_position=>'COPY'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-thumb-tack'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(35570840401811272)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(104495224350215152)
,p_button_name=>'desfixar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(341143411738556304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'botao.fixar-desfixar.l'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-thumb-tack'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(70980765005833077)
,p_name=>'P9008_TELA_TITULO'
,p_item_sequence=>90
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(70981203757833082)
,p_name=>'P9008_TELA_HELP'
,p_item_sequence=>100
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(104504728749215080)
,p_name=>'P9008_TIPO_PESQUISA'
,p_item_sequence=>60
,p_item_default=>'1'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(106462376696569391)
,p_name=>'P9008_ORDER_BY'
,p_is_required=>true
,p_item_sequence=>10
,p_item_default=>'1'
,p_prompt=>'tela.ordenar.l'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9008_CODIGO_ARTEFATO,105);',
'begin',
'    EXECUTE IMMEDIATE',
'        ''BEGIN :l_sql := UI_MPD_''||l_pagina||''.colunas_ordenar; END;''',
'        USING OUT l_sql;',
'',
'    return l_sql;       ',
'end;',
''))
,p_field_template=>wwv_flow_imp.id(341141616414556302)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '999',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(106466101681569344)
,p_name=>'P9008_CODIGO_ARTEFATO'
,p_item_sequence=>50
,p_item_default=>'266'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(106467023596569353)
,p_name=>'P9008_URL_NEW'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(35581517763811236)
,p_name=>'onClickFixar'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(35571673764811269)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35582055011811234)
,p_event_id=>wwv_flow_imp.id(35581517763811236)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (apex.item( "P9008_TIPO_PESQUISA" ).getValue() == 1){',
'    apex.item( "P9008_TIPO_PESQUISA" ).setValue( 2 );',
'} else {',
'    apex.item( "P9008_TIPO_PESQUISA" ).setValue( 1 );',
'}',
'    '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(35580157260811241)
,p_name=>'onChangeTipoPesquisa = Esquerda'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9008_TIPO_PESQUISA'
,p_condition_element=>'P9008_TIPO_PESQUISA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35580680185811239)
,p_event_id=>wwv_flow_imp.id(35580157260811241)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// $(''#PESQUISA'').appendTo(''#PAINEL_LEFT .t-Region-body'');',
'$(''#PESQUISA'').appendTo(''#PAINEL_LEFT'');',
'$(''#t_Body_side'').show();'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35581162346811237)
,p_event_id=>wwv_flow_imp.id(35580157260811241)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(104495224350215152)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(35582414110811233)
,p_name=>'onChangeTipoPesquisa = Modal'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9008_TIPO_PESQUISA'
,p_condition_element=>'P9008_TIPO_PESQUISA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35582907326811232)
,p_event_id=>wwv_flow_imp.id(35582414110811233)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// $(''#PESQUISA'').appendTo(''#PAINEL_MODAL .t-DrawerRegion-body'');    ',
'$(''#PESQUISA'').appendTo(''#PAINEL_MODAL .t-DrawerRegion-body'');    ',
'$(''#t_Body_side'').hide();'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35583495525811231)
,p_event_id=>wwv_flow_imp.id(35582414110811233)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(104495224350215152)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(35583801553811230)
,p_name=>'onClickDesfixar'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(35570840401811272)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(35584394639811229)
,p_event_id=>wwv_flow_imp.id(35583801553811230)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (apex.item( "P9008_TIPO_PESQUISA" ).getValue() == 1){',
'    apex.item( "P9008_TIPO_PESQUISA" ).setValue( 2 );',
'} else {',
'    apex.item( "P9008_TIPO_PESQUISA" ).setValue( 1 );',
'}',
'    '))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(35578769215811244)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'url_new'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'URL_NEW'
,p_internal_uid=>35578769215811244
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(35579289256811243)
,p_page_process_id=>wwv_flow_imp.id(35578769215811244)
,p_page_id=>9008
,p_name=>'p_url'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>40
,p_value_type=>'ITEM'
,p_value=>'P9008_URL_NEW'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(35579780483811242)
,p_page_process_id=>wwv_flow_imp.id(35578769215811244)
,p_page_id=>9008
,p_name=>'p_codigo_arfato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>50
,p_value_type=>'ITEM'
,p_value=>'P9008_CODIGO_ARTEFATO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(35576958759811249)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'retorna_titulo_tela'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'PKG_UI'
,p_attribute_04=>'RETORNA_TITULO_TELA'
,p_internal_uid=>35576958759811249
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(35577481212811247)
,p_page_process_id=>wwv_flow_imp.id(35576958759811249)
,p_page_id=>9008
,p_name=>'p_codigo_artefato'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P9008_CODIGO_ARTEFATO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(35577953288811246)
,p_page_process_id=>wwv_flow_imp.id(35576958759811249)
,p_page_id=>9008
,p_name=>'p_titulo'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P9008_TELA_TITULO'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(35578393575811245)
,p_page_process_id=>wwv_flow_imp.id(35576958759811249)
,p_page_id=>9008
,p_name=>'p_help'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P9008_TELA_HELP'
);
wwv_flow_imp.component_end;
end;
/
