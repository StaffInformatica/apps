prompt --application/user_interfaces
begin
--   Manifest
--     USER INTERFACES: 139
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_user_interface(
 p_id=>wwv_flow_imp.id(148135577674141244)
,p_theme_id=>42
,p_home_url=>'f?p=&APP_ID.:2:&SESSION.'
,p_login_url=>'f?p=&APP_ID.:9999:&APP_SESSION.::&DEBUG.:::'
,p_theme_style_by_user_pref=>false
,p_built_with_love=>false
,p_global_page_id=>0
,p_navigation_list_id=>wwv_flow_imp.id(35471786940971281)
,p_navigation_list_position=>'TOP'
,p_navigation_list_template_id=>wwv_flow_imp.id(341140323617556300)
,p_nav_list_template_options=>'#DEFAULT#:js-tabLike'
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APP_FILES#staff.css',
'#APP_FILES#icons.css',
'#APP_FILES#css-round.css'))
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APP_FILES#javascript#MIN#.js',
'#APP_FILES#TransformaModal#MIN#.js'))
,p_nav_bar_type=>'LIST'
,p_nav_bar_list_id=>wwv_flow_imp.id(341168729634556333)
,p_nav_bar_list_template_id=>wwv_flow_imp.id(341138145861556299)
,p_nav_bar_template_options=>'#DEFAULT#'
);
wwv_flow_imp.component_end;
end;
/
