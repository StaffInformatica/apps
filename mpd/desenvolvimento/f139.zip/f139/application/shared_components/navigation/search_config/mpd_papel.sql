prompt --application/shared_components/navigation/search_config/mpd_papel
begin
--   Manifest
--     SEARCH CONFIG: Mpd_Papel
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(283459605802220286)
,p_label=>'Mpd_Papel'
,p_static_id=>'mpd_papel'
,p_search_type=>'SIMPLE'
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_query_table=>'MPD_PAPEL'
,p_searchable_columns=>'NOME_PAPEL'
,p_pk_column_name=>'ID'
,p_title_column_name=>'NOME_PAPEL'
,p_icon_source_type=>'INITIALS'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
