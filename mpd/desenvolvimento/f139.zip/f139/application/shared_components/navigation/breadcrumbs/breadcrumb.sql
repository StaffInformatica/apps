prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(489109691639697566)
,p_name=>'Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(160132903145444535)
,p_short_name=>'&P134_TELA_TITULO.'
,p_link=>'f?p=&APP_ID.:134:&SESSION.::&DEBUG.:134::'
,p_page_id=>134
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(183640040045795768)
,p_short_name=>'&P9007_TELA_TITULO.'
,p_link=>'f?p=&APP_ID.:9007:&SESSION.::&DEBUG.:::'
,p_page_id=>9007
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(183710332223952639)
,p_short_name=>'Template - List'
,p_link=>'f?p=&APP_ID.:9008:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>9008
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(303635919336269735)
,p_short_name=>'&P133_TELA_TITULO.'
,p_link=>'f?p=&APP_ID.:133:&SESSION.::&DEBUG.:::'
,p_page_id=>133
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(306725065565679118)
,p_short_name=>'Mais detalhes do tenant'
,p_link=>'f?p=&APP_ID.:103:&SESSION.::&DEBUG.:::'
,p_page_id=>103
);
wwv_flow_imp.component_end;
end;
/
