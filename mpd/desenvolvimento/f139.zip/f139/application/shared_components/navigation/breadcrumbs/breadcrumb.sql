prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(340974113965556183)
,p_name=>'Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(11997325471303152)
,p_short_name=>'&P134_TELA_TITULO.'
,p_link=>'f?p=&APP_ID.:134:&SESSION.::&DEBUG.:134::'
,p_page_id=>134
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(35504462371654385)
,p_short_name=>'&P9007_TELA_TITULO.'
,p_link=>'f?p=&APP_ID.:9007:&SESSION.::&DEBUG.:::'
,p_page_id=>9007
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(35574754549811256)
,p_short_name=>'Template - List'
,p_link=>'f?p=&APP_ID.:9008:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>9008
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(155500341662128352)
,p_short_name=>'&P133_TELA_TITULO.'
,p_link=>'f?p=&APP_ID.:133:&SESSION.::&DEBUG.:::'
,p_page_id=>133
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(158589487891537735)
,p_short_name=>'Mais detalhes do tenant'
,p_link=>'f?p=&APP_ID.:103:&SESSION.::&DEBUG.:::'
,p_page_id=>103
);
wwv_flow_imp.component_end;
end;
/
