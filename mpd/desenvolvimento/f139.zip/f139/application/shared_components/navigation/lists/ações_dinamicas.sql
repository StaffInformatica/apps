prompt --application/shared_components/navigation/lists/ações_dinamicas
begin
--   Manifest
--     LIST: Ações dinamicas
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(135196722379769951)
,p_name=>unistr('A\00E7\00F5es dinamicas')
,p_list_type=>'FUNCTION_RETURNING_SQL_QUERY'
,p_list_language=>'PLSQL'
,p_list_query=>'return PKG_UI.buscar_acoes(:P9000_ID,:P9000_PAGINA,''W'',false,:P9000_PARAMETRO);'
,p_list_status=>'PUBLIC'
,p_version_scn=>42067731437598
);
wwv_flow_imp.component_end;
end;
/
