prompt --application/shared_components/navigation/lists/etapas_wizard_dinamico
begin
--   Manifest
--     LIST: Etapas wizard dinamico
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(167955282233907082)
,p_name=>'Etapas wizard dinamico'
,p_list_type=>'FUNCTION_RETURNING_SQL_QUERY'
,p_list_language=>'PLSQL'
,p_list_query=>'return pkg_ui.lista_etapa_wizard;'
,p_list_status=>'PUBLIC'
,p_version_scn=>45596407507375
);
wwv_flow_imp.component_end;
end;
/
