prompt --application/shared_components/navigation/lists/navegação_dinamicas
begin
--   Manifest
--     LIST: Navegação dinamicas
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(205324859061159097)
,p_name=>unistr('Navega\00E7\00E3o dinamicas')
,p_list_type=>'FUNCTION_RETURNING_SQL_QUERY'
,p_list_language=>'PLSQL'
,p_list_query=>'return PKG_UI.buscar_acoes(:P9000_ID,:P9000_PAGINA,''N'');'
,p_list_status=>'PUBLIC'
,p_version_scn=>41838683624907
);
wwv_flow_imp.component_end;
end;
/
