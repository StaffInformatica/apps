prompt --application/shared_components/navigation/lists/action_list_interactive_report
begin
--   Manifest
--     LIST: Action list interactive report
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(222272585216222758)
,p_name=>'Action list interactive report'
,p_list_status=>'PUBLIC'
,p_version_scn=>44435033146932
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(222279815680327199)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Salvar dados'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-download'
,p_list_text_01=>unistr('Permite salvar o relat\00F3rio em diversos formatos')
,p_list_text_03=>unistr('data-id="irDownload" title="Permite salvar o relat\00F3rio em diversos formatos"')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(222285508578497463)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Ordenar'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-sort-amount-asc-alt'
,p_list_text_01=>'Permite ordenar a consulta por diversas colunas ao mesmo tempo'
,p_list_text_03=>'data-id="irOrdering" title="Permite ordenar a consulta por diversas colunas ao mesmo tempo"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(222272759954222758)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Colunas'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-columns'
,p_list_text_01=>'Permitir ocultar, mostrar colunas'
,p_list_text_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'onclick="apex.theme.openRegion(''COLUNAS'');"',
''))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(222286228184497464)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Destacar'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-star-o'
,p_list_text_01=>unistr('Permite aplicar destaque as linhas de acordo com defini\00E7\00F5es realizadas pelo usu\00E1rio')
,p_list_text_03=>unistr('data-id="irHighlight" title="Permite aplicar destaque as linhas de acordo com defini\00E7\00F5es realizadas pelo usu\00E1rio"')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(222285821933497463)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>unistr('Linhas por p\00E1gina')
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-layout-3row'
,p_list_text_01=>'Permite informar a quantidade de linhas que deseja apresentar na consulta'
,p_list_text_03=>'id="irRowsPerPage" title="Permite informar a quantidade de linhas que deseja apresentar na consulta"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
