prompt --application/shared_components/navigation/lists/navigation_bar
begin
--   Manifest
--     LIST: Navigation Bar
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(489304307308697716)
,p_name=>'Navigation Bar'
,p_list_status=>'PUBLIC'
,p_version_scn=>45418974681724
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(489313849940697763)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'&APP_USER.',
''))
,p_list_item_link_target=>'#'
,p_list_text_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<img style="width:25px;height:25px;border-radius:50%;" src="f?p=&APP_ID.:0:&APP_SESSION.:APPLICATION_PROCESS=GET_IMAGE_USER:::IMAGE_USER_ID:&APP_USER." alt=" "></img>',
''))
,p_list_text_02=>wwv_flow_string.join(wwv_flow_t_varchar2(
'has-username image_icon st',
''))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(158057052399682636)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'Tarefas em segundo plano'
,p_list_item_link_target=>'f?p=&APP_ID.:9005:&SESSION.::&DEBUG.::P9005_CODIGO_ARTEFATO,P0_CODIGO_ARTEFATO:TD812,TD812:'
,p_list_item_icon=>'fa-cloud-clock'
,p_parent_list_item_id=>wwv_flow_imp.id(489313849940697763)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(489314298901697763)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'---'
,p_list_item_link_target=>'separator'
,p_list_item_disp_cond_type=>'NEVER'
,p_parent_list_item_id=>wwv_flow_imp.id(489313849940697763)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(308060704672343220)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Meu Perfil'
,p_list_item_link_target=>'f?p=&APP_ID.:133:&SESSION.::&DEBUG.:133:P133_ID:&ID_USUARIO_LOGADO.:'
,p_list_item_icon=>'fa-user'
,p_parent_list_item_id=>wwv_flow_imp.id(489313849940697763)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(204189177997160259)
,p_list_item_display_sequence=>45
,p_list_item_link_text=>'campo.selecionar-idioma.l'
,p_list_item_link_target=>'javascript:openModal(''modal-selecionar-idioma'');'
,p_list_item_icon=>'fa-language'
,p_parent_list_item_id=>wwv_flow_imp.id(489313849940697763)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(150183364703822256)
,p_list_item_display_sequence=>47
,p_list_item_link_text=>'Politica de privacidade'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-user-lock'
,p_parent_list_item_id=>wwv_flow_imp.id(489313849940697763)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(489314714874697763)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Sair'
,p_list_item_link_target=>'&LOGOUT_URL.'
,p_list_item_icon=>'fa-sign-out'
,p_parent_list_item_id=>wwv_flow_imp.id(489313849940697763)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
