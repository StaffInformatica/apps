prompt --application/shared_components/navigation/lists/template_lista_ordenação_9005
begin
--   Manifest
--     LIST: Template Lista Ordenação 9005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(48779525508152471)
,p_name=>unistr('Template Lista Ordena\00E7\00E3o 9005')
,p_list_type=>'FUNCTION_RETURNING_SQL_QUERY'
,p_list_language=>'PLSQL'
,p_list_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_campos clob;',
'    l_labels clob;',
'    l_sql clob;',
'    l_pagina varchar2(256) := nvl(:P9005_CODIGO_ARTEFATO,''TD150'');',
'begin',
'    execute immediate ''begin ui_mpd_''||l_pagina||''.campos_ordenacao(:card_ou_grid,:campos,:labels); end;'' using in :P9005_CARD_OU_LISTA, out l_campos, out l_labels;',
'    execute immediate ''begin :sql := gerar_comando_sql(:campos,:labels); end;'' using out l_sql, in l_campos, l_labels;',
'    dbms_output.put_line(l_campos);',
'    dbms_output.put_line(l_sql);',
'    return l_sql;',
'    exception',
'        when others then',
'        return q''~ ',
'        select null as level_value ',
unistr('           , ''Sem defini\00E7\00E3o de colunas para ordena\00E7\00E3o'' as label_value '),
'           , null as target_value',
'           , null as is_current ',
'           , null as image_value ',
'           , null as image_attr_value ',
'           , null as image_alt_value ',
'        from dual    ',
'        ~'';',
unistr('        --RAISE_APPLICATION_ERROR(-20002, ''Necess\00E1rio adicionar a fun\00E7\00E3o campos_ordenacao na UI do artefato conforme exemplo da UI_MDP_TD150'');  '),
unistr('        --raise_application_error(SQLCODE, ''Necess\00E1rio adicionar a fun\00E7\00E3o campos_ordenacao na UI do artefato conforme exemplo da UI_MDP_TD150 '' || SQLERRM, false);'),
'end;',
''))
,p_list_status=>'PUBLIC'
,p_version_scn=>44512832213229
);
wwv_flow_imp.component_end;
end;
/
