prompt --application/shared_components/navigation/lists/wizard_incluir_papel_e_funcionalidades
begin
--   Manifest
--     LIST: Wizard incluir papel e funcionalidades
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(154631557747324463)
,p_name=>'Wizard incluir papel e funcionalidades'
,p_list_status=>'PUBLIC'
,p_version_scn=>42176084412351
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(154632157650324465)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Funcionalidades'
,p_list_item_link_target=>'f?p=&APP_ID.:273:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
