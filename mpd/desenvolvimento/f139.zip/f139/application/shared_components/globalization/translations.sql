prompt --application/shared_components/globalization/translations
begin
--   Manifest
--     TRANSLATIONS: 139
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
null;
wwv_flow_imp.component_end;
end;
/
