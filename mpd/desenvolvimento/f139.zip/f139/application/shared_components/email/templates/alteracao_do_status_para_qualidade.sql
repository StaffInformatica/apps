prompt --application/shared_components/email/templates/alteracao_do_status_para_qualidade
begin
--   Manifest
--     EMAIL TEMPLATE: Alteracao do status para qualidade
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_email_template(
 p_id=>wwv_flow_imp.id(458503744943270474)
,p_name=>'Alteracao do status para qualidade'
,p_static_id=>'ALTERACAO_DO_STATUS_PARA_QUALIDADE'
,p_version_number=>2
,p_subject=>'Chamado encaminhado para qualidade'
,p_html_body=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>Chamado encaminhado para o setor de qualidade</strong><br>',
'<br>',
unistr('<strong>Em breve, voc\00EA receber\00E1 um e-mail de confirma\00E7\00E3o para realizar testes e finalizar seu chamado</strong><br>'),
'<strong>Solicitante:</strong> #USUARIO_NOME#<br>',
unistr('<strong>N\00FAmero do chamado:</strong> #ID_CHAMADO#<br>'),
'<br>',
'<a href="https://geae26552a5af32-dbng.adb.sa-vinhedo-1.oraclecloudapps.com/ords/r/srvdev/ng-srv/sup-consulta-chamado?session=704047012200768&P140_ABRE_CHAT=#ID_CHAMADO#" style="font-size: 14px;">Visite o SRV para acompanhar o progresso do seu chamado'
||'</a>.'))
,p_html_header=>'<b style="font-size: 24px;">Chamado encaminhado para qualidade</b>'
,p_html_footer=>unistr('N\00E3o responder esse e-mail')
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
