prompt --application/shared_components/email/templates/nova_informacao
begin
--   Manifest
--     EMAIL TEMPLATE: Nova informacao
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_email_template(
 p_id=>wwv_flow_imp.id(288008783826798810)
,p_name=>'Nova informacao'
,p_static_id=>'NOVA_INFORMACAO'
,p_version_number=>2
,p_subject=>unistr('Novas informa\00E7\00F5es no chamado NG')
,p_html_body=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<strong>Confirma\00E7\00E3o de novas informa\00E7\00F5es no chamado para o sistema NG</strong><br>'),
'<br>',
unistr('<strong>N\00FAmero do chamado:</strong> #ID_CHAMADO#<br>'),
unistr('<strong>Usu\00E1rio que enviou as novas informa\00E7\00F5es:</strong> #USUARIO_NOME#<br>'),
unistr('<strong>T\00EDtulo:</strong> #TITULO#<br>'),
unistr('<strong>Descri\00E7\00E3o:</strong> #DESCRICAO#<br>'),
'<br>',
'<a href="https://geae26552a5af32-dbng.adb.sa-vinhedo-1.oraclecloudapps.com/ords/r/srvdev/ng-srv/sup-consulta-chamado?session=704047012200768&P140_ABRE_CHAT=#ID_CHAMADO#" style="font-size: 14px;">Visite o SRV para acompanhar o progresso do seu chamado'
||'</a>.'))
,p_html_header=>unistr('<b style="font-size: 24px;">Novas informa\00E7\00F5es no chamado NG</b>')
,p_html_footer=>unistr('N\00E3o responder esse e-mail')
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
