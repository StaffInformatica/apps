prompt --application/shared_components/email/templates/alteracao_do_status_para_finalizado
begin
--   Manifest
--     EMAIL TEMPLATE: Alteracao do status para finalizado
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_email_template(
 p_id=>wwv_flow_imp.id(310382328003561555)
,p_name=>'Alteracao do status para finalizado'
,p_static_id=>'ALTERACAO_DO_STATUS_PARA_FINALIZADO'
,p_version_number=>2
,p_subject=>'Chamado finalizado'
,p_html_body=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<strong>Confirma\00E7\00E3o da finaliza\00E7\00E3o do chamado para o sistema NG</strong><br>'),
'<br>',
unistr('<strong>Agradecemos pela colabora\00E7\00E3o durante o processo deste chamado </strong><br>'),
'<strong>Solicitante:</strong> #USUARIO_NOME#<br>',
unistr('<strong>N\00FAmero do chamado:</strong> #ID_CHAMADO#<br>'),
'<br>',
'<a href="https://geae26552a5af32-dbng.adb.sa-vinhedo-1.oraclecloudapps.com/ords/r/srvdev/ng-srv/sup-consulta-chamado?session=704047012200768&P140_ABRE_CHAT=#ID_CHAMADO#" style="font-size: 14px;">Visite o SRV para verificar mais detalhes do chamado e '
||unistr('hist\00F3rico de movimenta\00E7\00F5es</a>.')))
,p_html_header=>'<b style="font-size: 24px;">Chamado finalizado</b>'
,p_html_footer=>unistr('N\00E3o responder esse e-mail')
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
