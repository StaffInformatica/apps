prompt --application/shared_components/logic/application_computations/menu_state
begin
--   Manifest
--     APPLICATION COMPUTATION: MENU_STATE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(214892715882266851)
,p_computation_sequence=>10
,p_computation_item=>'MENU_STATE'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>'return nvl(apex_util.get_preference(''menu_state'', :APP_USER), 0);'
,p_version_scn=>41887409006186
);
wwv_flow_imp.component_end;
end;
/
