prompt --application/shared_components/logic/application_processes/call_pkg_process
begin
--   Manifest
--     APPLICATION PROCESS: CALL_PKG_PROCESS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(203328674815454101)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CALL_PKG_PROCESS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    if apex_application.G_X01 is not null then',
'      APEX_UTIL.SET_SESSION_STATE(''P0_TAB_ID'',APEX_APPLICATION.G_X01);',
'    end if;',
'',
'    apex_json.open_object;  ',
'    apex_json.write(''success'', true);  ',
'    apex_json.close_object; ',
'    exception',
'        when others then',
'            apex_json.open_object;',
'            apex_json.write(''success'', false);',
'            apex_json.write(''message'', sqlerrm);',
'            apex_json.close_object;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>44560990284541
);
wwv_flow_imp.component_end;
end;
/
