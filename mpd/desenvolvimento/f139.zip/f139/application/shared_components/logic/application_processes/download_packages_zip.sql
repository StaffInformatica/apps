prompt --application/shared_components/logic/application_processes/download_packages_zip
begin
--   Manifest
--     APPLICATION PROCESS: DOWNLOAD_PACKAGES_ZIP
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(27605308204951778)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DOWNLOAD_PACKAGES_ZIP'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  l_zip_blob     blob;',
'  l_file_blob    blob;',
'  l_clob         clob;',
'  l_file_name    varchar2(255);  ',
'  v_raw          raw(32767);',
'  v_offset       pls_integer;',
'  v_chunk        varchar2(32767);',
'  v_clob_len     integer;',
'  v_step         integer := 32767;',
'  cursor c_packages is',
'    select name, type',
'    from all_source',
'    where owner = ''WKSP_TESTE''',
'      and type in (''PACKAGE'', ''PACKAGE BODY'')',
'    group by name, type',
'    order by name, type;',
'begin',
'  for rec in c_packages loop',
unistr('    -- Montar o conte\00FAdo como CLOB'),
'    l_clob := empty_clob();',
'',
'    for src in (',
'      select text',
'      from all_source',
'      where owner = ''WKSP_TESTE''',
'        and name = rec.name',
'        and type = rec.type',
'      order by line',
'    ) loop',
'      l_clob := l_clob || src.text;',
'    end loop;',
'',
'    -- Inicializa o BLOB',
'    dbms_lob.createtemporary(l_file_blob, true);',
'',
'    -- Converte o CLOB para BLOB de forma segura',
'    v_offset := 1;',
'    v_clob_len := dbms_lob.getlength(l_clob);',
'',
'    while v_offset <= v_clob_len loop',
'      v_chunk := dbms_lob.substr(l_clob, v_step, v_offset);',
'      v_raw := utl_raw.cast_to_raw(v_chunk);',
'      dbms_lob.writeappend(l_file_blob, utl_raw.length(v_raw), v_raw);',
'      v_offset := v_offset + v_step;',
'    end loop;',
'',
unistr('    -- Definir o nome do arquivo com extens\00E3o apropriada'),
'    l_file_name := rec.name ||',
'                   case rec.type',
'                     when ''PACKAGE'' then ''.sql''',
'                     when ''PACKAGE BODY'' then ''.pbl''',
'                   end;',
'',
'    -- Adicionar ao ZIP',
'    apex_zip.add_file(',
'      p_zipped_blob => l_zip_blob,',
'      p_file_name   => lower(l_file_name),',
'      p_content     => l_file_blob',
'    );',
'  end loop;',
'',
'  apex_zip.finish(p_zipped_blob => l_zip_blob);',
'',
'  -- Retornar o ZIP como download',
'  owa_util.mime_header(''application/zip'', false);',
'  htp.p(''Content-Disposition: attachment; filename="packages.zip"'');',
'  htp.p(''Content-Length: '' || dbms_lob.getlength(l_zip_blob));',
'  htp.p(''Cache-Control: no-cache'');',
'  owa_util.http_header_close;',
'  wpg_docload.download_file(l_zip_blob);  ',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>44797587945050
);
wwv_flow_imp.component_end;
end;
/
