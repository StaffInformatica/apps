prompt --application/shared_components/logic/application_processes/download_diagram
begin
--   Manifest
--     APPLICATION PROCESS: DOWNLOAD_DIAGRAM
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(391879803500525969)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DOWNLOAD_DIAGRAM'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_blob         blob;',
'    l_clob         clob;',
'    l_dest_offset  integer := 1;',
'    l_src_offset   integer := 1;',
'    l_lang_context integer := dbms_lob.default_lang_ctx;',
'    l_warning      integer;',
'    l_length       integer;',
'begin',
'    -- create new temporary BLOB',
'    dbms_lob.Createtemporary(l_blob, false);',
'',
'    --get CLOB',
'    PKG_METADATA.export_diagram_metadata(l_clob);',
'',
'    -- tranform the input CLOB into a BLOB of the desired charset',
'    dbms_lob.Converttoblob(dest_lob => l_blob, src_clob => l_clob,',
'    amount => dbms_lob.lobmaxsize, dest_offset => l_dest_offset,',
'    src_offset => l_src_offset, blob_csid => Nls_charset_id(''WE8MSWIN1252''),',
'    lang_context => l_lang_context, warning => l_warning);',
'',
'    -- determine length for header',
'    l_length := dbms_lob.Getlength(l_blob);',
'',
'    -- first clear the header',
'    htp.flush;',
'',
'    htp.init;',
'',
'    -- create response header',
'    owa_util.Mime_header(''text/plain'', false);',
'',
'    htp.P(''Content-length: ''',
'          || l_length);',
'',
'    htp.P(''Content-Disposition: attachment; filename="Diagrama_metadata.txt"'');',
'    htp.P(''Set-Cookie: fileDownload=true; path=/'');',
'',
'    owa_util.http_header_close;',
'',
'    -- download the BLOB',
'    wpg_docload.Download_file(l_blob);',
'-- stop APEX',
'-- APEX_APPLICATION.STOP_APEX_ENGINE;',
'exception',
'    when others then',
'      dbms_lob.Freetemporary(l_blob);',
'',
'      raise;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
