prompt --application/shared_components/logic/application_processes/set_null_p0_url_new
begin
--   Manifest
--     APPLICATION PROCESS: set null P0_URL_NEW
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(211213767885887900)
,p_process_sequence=>1
,p_process_point=>'AFTER_FOOTER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'set null P0_URL_NEW'
,p_process_sql_clob=>':P0_URL_NEW := null;'
,p_process_clob_language=>'PLSQL'
,p_version_scn=>41862946154982
);
wwv_flow_imp.component_end;
end;
/
