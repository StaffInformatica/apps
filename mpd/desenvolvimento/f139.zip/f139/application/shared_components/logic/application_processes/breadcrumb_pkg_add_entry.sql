prompt --application/shared_components/logic/application_processes/breadcrumb_pkg_add_entry
begin
--   Manifest
--     APPLICATION PROCESS: breadcrumb_pkg.add_entry
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(30139158953193617)
,p_process_sequence=>1
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'breadcrumb_pkg.add_entry'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_codigo_artefato varchar2(256);',
'begin',
'    v_codigo_artefato := apex_util.get_session_state(''P''||:APP_PAGE_ID||''_CODIGO_ARTEFATO'');',
'    breadcrumb_pkg.add_entry(''BREADCRUMB''||:APP_ID,v_codigo_artefato,:APP_PAGE_ID,:A_RESET_BREADCRUMB,:P0_TITULO_TELA,:P0_HELP_TELA||'' (''||:P0_CODIGO_ARTEFATO||'')'', /*OWA_UTIL.GET_CGI_ENV(''HTTP_HOST'') ||*/ OWA_UTIL.GET_CGI_ENV(''SCRIPT_NAME'') ||  OWA_'
||'UTIL.GET_CGI_ENV(''PATH_INFO'') ||''?''|| OWA_UTIL.GET_CGI_ENV(''QUERY_STRING'') );',
'    if(:A_RESET_BREADCRUMB = ''Y'') then',
'        :A_RESET_BREADCRUMB :=''N'';',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'apex_page.get_page_mode(:APP_ID,:APP_PAGE_ID) = ''NORMAL'' '
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_version_scn=>45419281218759
);
wwv_flow_imp.component_end;
end;
/
