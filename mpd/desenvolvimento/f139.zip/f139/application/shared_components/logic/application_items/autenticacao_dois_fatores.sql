prompt --application/shared_components/logic/application_items/autenticacao_dois_fatores
begin
--   Manifest
--     APPLICATION ITEM: AUTENTICACAO_DOIS_FATORES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(281043292167109094)
,p_name=>'AUTENTICACAO_DOIS_FATORES'
,p_protection_level=>'I'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
