prompt --application/shared_components/logic/application_items/filtro_global
begin
--   Manifest
--     APPLICATION ITEM: FILTRO_GLOBAL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(42719549926699344)
,p_name=>'FILTRO_GLOBAL'
,p_protection_level=>'I'
,p_version_scn=>42050779948120
);
wwv_flow_imp.component_end;
end;
/
