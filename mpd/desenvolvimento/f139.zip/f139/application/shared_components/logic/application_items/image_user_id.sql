prompt --application/shared_components/logic/application_items/image_user_id
begin
--   Manifest
--     APPLICATION ITEM: IMAGE_USER_ID
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(363362705566754199)
,p_name=>'IMAGE_USER_ID'
,p_scope=>'GLOBAL'
,p_protection_level=>'N'
,p_version_scn=>41595926183658
);
wwv_flow_imp.component_end;
end;
/
