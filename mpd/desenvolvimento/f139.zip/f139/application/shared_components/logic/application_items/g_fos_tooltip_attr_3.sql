prompt --application/shared_components/logic/application_items/g_fos_tooltip_attr_3
begin
--   Manifest
--     APPLICATION ITEM: G_FOS_TOOLTIP_ATTR_3
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(52668041310675384)
,p_name=>'G_FOS_TOOLTIP_ATTR_3'
,p_protection_level=>'I'
,p_item_comment=>'This item is used for the FOS - Tooltip Plug-in'
,p_version_scn=>41786857280730
);
wwv_flow_imp.component_end;
end;
/
