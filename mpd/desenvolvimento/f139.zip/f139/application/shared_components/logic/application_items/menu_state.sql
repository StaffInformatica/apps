prompt --application/shared_components/logic/application_items/menu_state
begin
--   Manifest
--     APPLICATION ITEM: MENU_STATE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(214870632604896947)
,p_name=>'MENU_STATE'
,p_protection_level=>'I'
,p_version_scn=>41886980157040
);
wwv_flow_imp.component_end;
end;
/
