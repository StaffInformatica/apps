prompt --application/shared_components/logic/build_options
begin
--   Manifest
--     BUILD OPTIONS: 139
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(357506361090200154)
,p_build_option_name=>'Chamados'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>1
,p_build_option_comment=>'Build para o projeto de chamados.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(489109181809697564)
,p_build_option_name=>'Commented Out'
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
