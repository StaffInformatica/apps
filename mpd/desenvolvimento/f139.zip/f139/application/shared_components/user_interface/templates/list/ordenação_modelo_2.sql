prompt --application/shared_components/user_interface/templates/list/ordenação_modelo_2
begin
--   Manifest
--     REGION TEMPLATE: ORDENAÇÃO_MODELO_2
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_template(
 p_id=>wwv_flow_imp.id(33657881927818217)
,p_list_template_current=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<button class="t-Button t-Button--icon t-Button--link botao" style="#A04#" onclick="handleClick(''order_#A01#'',''#A02#'',''#A01#'')"  type="button" id="order_#A01#" aria-haspopup="menu">',
'    <span class="ordenacao t-Icon t-Icon--left fa" aria-hidden="true"></span>',
'    <span class="t-Button-label">#TEXT#</span>',
'    <span class="close t-Icon t-Icon--right fa" style="margin-left:4px;" aria-hidden="true"></span>',
'</button>',
''))
,p_list_template_noncurrent=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<button class="t-Button t-Button--icon t-Button--link botao" style="#A04#" onclick="handleClick(''order_#A01#'',''#A02#'',''#A01#'')"  type="button" id="order_#A01#" aria-haspopup="menu">',
'    <span class="ordenacao t-Icon t-Icon--left fa" aria-hidden="true"></span>',
'    <span class="t-Button-label">#TEXT#</span>',
'    <span class="close t-Icon t-Icon--right fa" style="margin-left:4px;" aria-hidden="true"></span>',
'</button>',
''))
,p_list_template_name=>unistr('Ordena\00E7\00E3o modelo 2')
,p_internal_name=>unistr('ORDENA\00C7\00C3O_MODELO_2')
,p_javascript_file_urls=>'#APP_FILES#ordenacao2.js'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Base container */',
'.ui-search-view-options__group {',
'    display: flex;',
'    align-items: center;',
'    font-family: "Proxima Nova", -apple-system, "Helvetica Neue", Helvetica, Roboto, Arial, sans-serif;',
'    font-size: 14px;',
'    color: rgba(0,0,0,.9);',
'}',
'',
'.ui-search-view-options__title {',
'    margin-right: 4px;',
'    font-weight: 400;',
'}',
'',
'.andes-dropdown {',
'    position: relative;',
'    display: inline-block;',
'}',
'',
'.andes-dropdown__trigger {',
'    background: transparent;',
'    border: none;',
'    cursor: pointer;',
'    display: flex;',
'    align-items: center;',
'    padding: 0;',
'    color: #3483fa; /* ML Blue */',
'    font-weight: 600;',
'    font-family: inherit;',
'    font-size: 14px;',
'}',
'',
'.andes-dropdown__arrow {',
'    display: flex;',
'    align-items: center;',
'    margin-left: 2px;',
'    transition: transform 0.2s ease-in-out;',
'}',
'',
'.andes-dropdown--open .andes-dropdown__arrow {',
'    transform: rotate(180deg);',
'}',
'',
'/* Floating Menu Container */',
'.ml-dropdown-menu-container {',
'    background: #fff;',
'    border-radius: 4px;',
'    box-shadow: 0 1px 2px 0 rgba(0,0,0,.15);',
'    min-width: 170px;',
'    border: 1px solid rgba(0,0,0,.1);',
'}',
'',
'.andes-list {',
'    list-style: none;',
'    margin: 0;',
'    padding: 0;',
'}',
'',
'.andes-list__item {',
'    padding: 12px 16px;',
'    cursor: pointer;',
'    background-color: #fff;',
'    transition: background-color 0.1s;',
'    border-left: 3px solid transparent;',
'}',
'',
'.andes-list__item:hover {',
'    background-color: rgba(0,0,0,.04);',
'}',
'',
'.andes-list__item--selected {',
'    border-left: 3px solid #3483fa;',
'}',
'',
'.andes-list__item--selected .andes-list__item-primary {',
'    color: #3483fa;',
'    font-weight: 600;',
'}',
'',
'.andes-list__item-primary {',
'    color: rgba(0,0,0,.9);',
'    font-size: 14px;',
'}',
'',
'.customTooltip {',
'  min-width: 500px !important;',
'}',
''))
,p_theme_id=>42
,p_theme_class_id=>6
,p_preset_template_options=>'t-BadgeList--circular:t-BadgeList--fixed:t-BadgeList--large'
,p_list_template_before_rows=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="ui-search-view-options" style="display: flex; align-items: center; gap: 8px;">',
'  <div class="ui-search-view-options__content">',
'    <div class="ui-search-view-options__group">',
'      <div class="ui-search-view-options__title">Ordenar por</div>',
'      <div class="ui-search-sort-filter">',
'        <div id="ml_dropdown"',
'          class="andes-dropdown andes-dropdown--standalone ui-search-sort-filter__dropdown andes-dropdown--small andes-dropdown--bottom"',
'          data-andes-dropdown="true" data-andes-dropdown-type="standalone">',
'          <div class="andes-floating-menu">',
'            <button aria-label="Mais relevantes" class="andes-dropdown__trigger" type="button" id="ml_dropdown_trigger"',
'              onclick="toggleMlDropdown(event)">',
'              <span class="andes-dropdown__display-values" id="ml_dropdown_display">Mais relevantes</span>',
'              <span class="andes-dropdown__arrow" aria-hidden="true" id="ml_dropdown_arrow">',
'                <svg aria-hidden="true" color="currentColor" width="12" height="12" viewBox="0 0 12 12"',
'                  fill="currentColor">',
'                  <path',
'                    d="M9.35229 3.70447L6.00004 7.05672L2.64779 3.70447L1.85229 4.49996L6.00004 8.64771L10.1478 4.49996L9.35229 3.70447Z"',
'                    fill="currentColor"></path>',
'                </svg>',
'              </span>',
'            </button>',
'            <div id="ml_dropdown_menu" class="ml-dropdown-menu-container"',
'              style="display: none; z-index: 9999; position: absolute; inset: 0px auto auto 0px; margin: 0px; transform: translate(-9px, 24px);">',
'              <div class="andes-popper andes-popper--padding-0" style="width: auto;">',
'                <div class="andes-popper__content andes-floating-menu__popper-content">',
'                  <ul class="andes-list andes-floating-menu andes-list--default andes-list--selectable" role="listbox">',
'',
''))
,p_list_template_after_rows=>wwv_flow_string.join(wwv_flow_t_varchar2(
'                  </ul>',
'                </div>',
'              </div>',
'            </div>',
'          </div>',
'        </div>',
'      </div>',
'    </div>',
'  </div>'))
,p_a01_label=>'Nome da coluna'
,p_a02_label=>'Icone da ordenacao'
,p_a03_label=>'Icone de close'
,p_list_template_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Desenvolvido por Northonn Oliveira',
'Em testes no aplicativo 124 na tela 9005',
'',
'A01: Nome da coluna',
'A02: Icone da ordenacao',
'A03: Icone de close',
'',
unistr('<div class="texto-aviso" style="font-weight: bold;margin-top: 5px;">Situa\00E7\00E3o do componente: <span class="teste">Em teste</span></div>'),
'<details>',
unistr('  <summary class="texto-aviso" style="font-weight: bold;">Clique aqui para ver as Instru\00E7\00F5es para os Desenvolvedores</summary>'),
unistr('<div class="texto-aviso" style="font-weight: 100;">*Adicionar a fun\00E7\00E3o campos_ordenacao na UI da tela conforme UI_MPD_TD150</div>'),
unistr('<div class="texto-aviso" style="font-weight: 100;">*Adicionar a cl\00E1usula "order by #ORDER#" no comando SQL das fun\00E7\00F5es sql_card e sql_report na UI da tela conforme UI_MPD_TD150</div>'),
'</details>',
'',
unistr('<div class="texto-aviso" style="font-weight: bold;margin-top: 5px;">Situa\00E7\00E3o do componente: <span class="teste">Em teste</span></div>'),
'<details>',
unistr('  <summary class="texto-aviso" style="font-weight: bold;">Instru\00E7\00F5es para os Desenvolvedores</summary>'),
'<div class="texto-aviso" style="font-weight: 100;">*Desenvolvido por: Northonn Oliveira</div>',
'<div class="texto-aviso" style="font-weight: 100;">*Data: 12/03/2025</div>',
unistr('<div class="texto-aviso" style="font-weight: 100;">*Adicionar a fun\00E7\00E3o campos_ordenacao na UI da tela conforme UI_MPD_TD150</div>'),
unistr('<div class="texto-aviso" style="font-weight: 100;">*Adicionar a cl\00E1usula "order by #ORDER#" no comando SQL das fun\00E7\00F5es sql_card e sql_report na UI da tela conforme UI_MPD_TD150</div>'),
'<div class="texto-aviso" style="font-weight: 100;">procedure campos_ordenacao(p_card_ou_grid in varchar2,campos out varchar2,labels out varchar2) is',
'    begin',
'        if p_card_ou_grid = ''CARD'' then',
'            campos := ''login,nome,email'';',
'        else',
'            campos := ''campo4,campo1,campo2'';',
'        end if;',
'        labels := label_coluna(''4'')||'',''||label_coluna(''1'')||'',''||label_coluna(''3'');',
'    end campos_ordenacao;  ',
'</div>',
'</details>'))
);
wwv_flow_imp.component_end;
end;
/
