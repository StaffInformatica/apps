prompt --application/shared_components/user_interface/templates/report/comments_chat_prototype_diff
begin
--   Manifest
--     ROW TEMPLATE: COMMENTS_CHAT_PROTOTYPE_DIFF
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_row_template(
 p_id=>wwv_flow_imp.id(328847496036296016)
,p_row_template_name=>'Comments chat prototype diff'
,p_internal_name=>'COMMENTS_CHAT_PROTOTYPE_DIFF'
,p_row_template1=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<li class="t-Comments-item #COMMENT_MODIFIERS#">',
'  <div class="t-Comments-icon">',
'    <div class="t-Comments-userIcon #ICON_MODIFIER#" aria-hidden="true" style="#ICON_HIDE#" title="#ICONE_NOME#">#USER_ICON#</div>',
'  </div>',
'  <div class="t-Comments-body #MARGIN_TOP_COMMENT# #MARGIN_BOTTOM_COMMENT#">',
'    <div class="t-Comments-info">',
'      <span class="t-Comments-actions">#ACTIONS#</span>',
'    </div> ',
'    <div class="#MESSAGETEAM# #M_CHAT#" style="display: flex; flex-direction: column; max-width: 65%; #MARGIN_TOP#">            ',
'        <div data-id="#ID_TEXT#" class="t-Comments-comment #MENSAGEM_CALDA#" style="#COLOR_OWN# display: flex; flex-direction: column;">',
'            <div id="display-image" class="#H_IMAGEM#"><a href="#URL#" class="link-imagem">#IMAGE#</a></div>                          ',
'                <div id="messagesDivT" class="msg-text" style="float: left; margin-right: 1.45em; padding: 0;">',
'                    <div style="margin-bottom: 0.1em;">',
'                        <span class="username-sender" style="font-weight: 500; color: var(--ut-comment-icon-background-color,var(--ut-component-icon-background-color));">#USER_NAME#</span>',
'                    </div>',
'                    <div data-id="#ID_RESPOSTA#" class="Comment_answer" title="Em resposta" style=''border-radius: var(--ut-comment-chat-border-radius); #COLOR_ANSWER# #COMMENT_ANSWER# #USER_ANSWER#''>',
'                        <span class="usuario-mensagem-selecionada">#USER_ANSWER#</span><br>',
'                        #COMMENT_ANSWER#',
'                    </div>                ',
'                    <p class="#NO_ANSWER#">#COMMENT_TEXT##ATTRIBUTE_2##ATTRIBUTE_3##ATTRIBUTE_4#</p>                ',
'                    <button type="button" id="btn-acao-mensagem" class="t-Button--link no-display" aria-hidden="true" style=''color: var(--ut-comment-info-color,var(--ut-component-text-muted-color)); position: absolute; top: 0; right: 0; background-co'
||unistr('lor: #DBDFE2; border-radius: 50%; #ATTRIBUTE_1#'' title="Op\00E7\00F5es" data-menu="actions_menu" aria-haspopup="menu" data-id="#ID_TEXT#">#ATTRIBUTE_1#</button>           '),
'            </div>  ',
'                <span class="" style="display: flex; justify-content: right; color: var(--ut-comment-info-color,var(--ut-component-text-muted-color)); font-size: 0.8em; margin-bottom: -0.3em">#COMMENT_DATE#</span>',
'        </div>',
'    </div>',
'  </div>',
'</li> ',
'',
''))
,p_row_template_before_rows=>'<ul class="t-Comments #COMPONENT_CSS_CLASSES#" #REPORT_ATTRIBUTES# id="#REGION_STATIC_ID#_report" data-region-id="#REGION_STATIC_ID#">'
,p_row_template_after_rows=>wwv_flow_string.join(wwv_flow_t_varchar2(
'</ul>',
'<table class="t-Report-pagination" role="presentation">#PAGINATION#</table>'))
,p_row_template_type=>'NAMED_COLUMNS'
,p_row_template_display_cond1=>'0'
,p_row_template_display_cond2=>'NOT_CONDITIONAL'
,p_row_template_display_cond3=>'0'
,p_row_template_display_cond4=>'0'
,p_pagination_template=>'<span class="t-Report-paginationText">#TEXT#</span>'
,p_next_page_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<a href="#LINK#" class="t-Button t-Button--small t-Button--noUI t-Report-paginationLink t-Report-paginationLink--next">',
'  #PAGINATION_NEXT#<span class="a-Icon icon-right-arrow" aria-hidden="true"></span>',
'</a>'))
,p_previous_page_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<a href="#LINK#" class="t-Button t-Button--small t-Button--noUI t-Report-paginationLink t-Report-paginationLink--prev">',
'  <span class="a-Icon icon-left-arrow" aria-hidden="true"></span>#PAGINATION_PREVIOUS#',
'</a>'))
,p_next_set_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<a href="#LINK#" class="t-Button t-Button--small t-Button--noUI t-Report-paginationLink t-Report-paginationLink--next">',
'  #PAGINATION_NEXT_SET#<span class="a-Icon icon-right-arrow" aria-hidden="true"></span>',
'</a>',
''))
,p_previous_set_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<a href="#LINK#" class="t-Button t-Button--small t-Button--noUI t-Report-paginationLink t-Report-paginationLink--prev">',
'  <span class="a-Icon icon-left-arrow" aria-hidden="true"></span>#PAGINATION_PREVIOUS_SET#',
'</a>'))
,p_theme_id=>42
,p_theme_class_id=>7
,p_preset_template_options=>'t-Comments--chat'
,p_translate_this_template=>'N'
);
wwv_flow_imp.component_end;
end;
/
