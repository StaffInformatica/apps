prompt --application/shared_components/user_interface/templates/list/badge_list
begin
--   Manifest
--     REGION TEMPLATE: BADGE_LIST
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_template(
 p_id=>wwv_flow_imp.id(32769056017603992)
,p_list_template_current=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<button class="t-Button t-Button--icon t-Button--link botao" style="#A04#" onclick="handleClick(''order_#A01#'',''#A02#'',''#A01#'')"  type="button" id="order_#A01#" aria-haspopup="menu">',
'    <span class="ordenacao t-Icon t-Icon--left fa" aria-hidden="true"></span>',
'    <span class="t-Button-label">#TEXT#</span>',
'    <span class="close t-Icon t-Icon--right fa" style="margin-left:4px;" aria-hidden="true"></span>',
'</button>',
''))
,p_list_template_noncurrent=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<button class="t-Button t-Button--icon t-Button--link botao" style="#A04#" onclick="handleClick(''order_#A01#'',''#A02#'',''#A01#'')"  type="button" id="order_#A01#" aria-haspopup="menu">',
'    <span class="ordenacao t-Icon t-Icon--left fa" aria-hidden="true"></span>',
'    <span class="t-Button-label">#TEXT#</span>',
'    <span class="close t-Icon t-Icon--right fa" style="margin-left:4px;" aria-hidden="true"></span>',
'</button>',
''))
,p_list_template_name=>unistr('Ordena\00E7\00E3o')
,p_internal_name=>'BADGE_LIST'
,p_javascript_file_urls=>'#APP_FILES#ordenacao#MIN#.js'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.button-container- {',
'    width: fit-content;',
'    display: inline-flex;',
'    transition: max-width 0.4s ease, opacity 0.3s ease, margin 0.3s ease, border-width 0.3s ease;',
'    max-width: 2000px;',
'    opacity: 1;',
'    overflow: hidden;',
'    white-space: nowrap;',
'}',
'',
'',
'.button-container {',
'    box-shadow: var(--a-cv-state-shadow, var(--a-cv-type-shadow, var(--a-cv-shadow, none)));',
unistr('    border: 1px solid #ccc; /* Contorno dos bot\00F5es */'),
'    width: fit-content;',
'    border-radius: 4px; /* Bordas arredondadas */',
'    display: inline-flex;',
'    transition: max-width 0.4s ease, opacity 0.3s ease, margin 0.3s ease, border-width 0.3s ease;',
'    max-width: 2000px;',
'    opacity: 1;',
'    overflow: hidden;',
'    white-space: nowrap;',
'}',
'',
'.button-container-.collapsed {',
'    max-width: 0;',
'    opacity: 0;',
'    border-width: 0;',
'    margin: 0;',
'    pointer-events: none;',
'}',
'.separator{',
unistr('  border: 1px solid #ccc; /* Contorno dos bot\00F5es */'),
'}',
'',
'.text-color{',
'    color: var(--ut-region-text-color);',
'}',
'',
'.botao{',
'    margin-inline-start: -4px;',
'    border-right: 1px solid #ccc;',
'    border-top: 0;',
'    border-radius: 0;',
'    border-bottom: 0;',
'    border-left: 0;',
'}',
'',
'.texto-aviso{',
'    font-size: x-small;',
'    font-style: italic;',
'    color: darkgray;',
'}',
'',
'.teste {',
'    color: white;',
'    background-color: orange;',
'    padding: 3px;',
'    display: inline-block;',
'    border-radius: 4px; /* Bordas arredondadas */',
'}',
'',
'.customTooltip {',
'  min-width: 500px !IMPORTANT;',
'}',
''))
,p_theme_id=>42
,p_theme_class_id=>6
,p_preset_template_options=>'t-BadgeList--circular:t-BadgeList--fixed:t-BadgeList--large'
,p_list_template_before_rows=>'<h3 class="a-FS-label">Ordenar por    '
,p_list_template_after_rows=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<button class="t-Button t-Button--noLabel t-Button--icon t-Button--link t-Button--hot" onclick="void(0);" type="button" title="Exibir tutorial" aria-label="Exibir tutorial">',
'        <span class="t-Icon fa fa-question-circle-o" onclick="tutorialOrdenacao()" aria-hidden="true"></span>',
'</button>',
'</h3>'))
,p_a01_label=>'Nome da coluna'
,p_a02_label=>'Icone da ordenacao'
,p_a03_label=>'Icone de close'
,p_list_template_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Desenvolvido por Northonn Oliveira',
'Em testes no aplicativo 124 na tela 9005',
'',
'A01: Nome da coluna',
'A02: Icone da ordenacao',
'A03: Icone de close',
'',
unistr('<div class="texto-aviso" style="font-weight: bold;margin-top: 5px;">Situa\00E7\00E3o do componente: <span class="teste">Em teste</span></div>'),
'<details>',
unistr('  <summary class="texto-aviso" style="font-weight: bold;">Clique aqui para ver as Instru\00E7\00F5es para os Desenvolvedores</summary>'),
unistr('<div class="texto-aviso" style="font-weight: 100;">*Adicionar a fun\00E7\00E3o campos_ordenacao na UI da tela conforme UI_MPD_TD150</div>'),
unistr('<div class="texto-aviso" style="font-weight: 100;">*Adicionar a cl\00E1usula "order by #ORDER#" no comando SQL das fun\00E7\00F5es sql_card e sql_report na UI da tela conforme UI_MPD_TD150</div>'),
'</details>',
'',
unistr('<div class="texto-aviso" style="font-weight: bold;margin-top: 5px;">Situa\00E7\00E3o do componente: <span class="teste">Em teste</span></div>'),
'<details>',
unistr('  <summary class="texto-aviso" style="font-weight: bold;">Instru\00E7\00F5es para os Desenvolvedores</summary>'),
'<div class="texto-aviso" style="font-weight: 100;">*Desenvolvido por: Northonn Oliveira</div>',
'<div class="texto-aviso" style="font-weight: 100;">*Data: 12/03/2025</div>',
unistr('<div class="texto-aviso" style="font-weight: 100;">*Adicionar a fun\00E7\00E3o campos_ordenacao na UI da tela conforme UI_MPD_TD150</div>'),
unistr('<div class="texto-aviso" style="font-weight: 100;">*Adicionar a cl\00E1usula "order by #ORDER#" no comando SQL das fun\00E7\00F5es sql_card e sql_report na UI da tela conforme UI_MPD_TD150</div>'),
'<div class="texto-aviso" style="font-weight: 100;">procedure campos_ordenacao(p_card_ou_grid in varchar2,campos out varchar2,labels out varchar2) is',
'    begin',
'        if p_card_ou_grid = ''CARD'' then',
'            campos := ''login,nome,email'';',
'        else',
'            campos := ''campo4,campo1,campo2'';',
'        end if;',
'        labels := label_coluna(''4'')||'',''||label_coluna(''1'')||'',''||label_coluna(''3'');',
'    end campos_ordenacao;  ',
'</div>',
'</details>'))
);
wwv_flow_imp.component_end;
end;
/
