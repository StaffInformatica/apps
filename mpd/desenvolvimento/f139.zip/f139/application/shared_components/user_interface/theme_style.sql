prompt --application/shared_components/user_interface/theme_style
begin
--   Manifest
--     THEME STYLE: 139
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(341146183031556311)
,p_theme_id=>42
,p_name=>'Redwood Light'
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/oracle-fonts/oraclesans-apex#MIN#.css?v=#APEX_VERSION#',
'#THEME_FILES#css/Redwood#MIN#.css?v=#APEX_VERSION#'))
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Redwood-Theme.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Redwood-Theme#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(341146406382556311)
,p_theme_id=>42
,p_name=>'Vita'
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(341146607026556311)
,p_theme_id=>42
,p_name=>'Vita - Dark'
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita-Dark.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita-Dark#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(341146746374556311)
,p_theme_id=>42
,p_name=>'Vita - Red'
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita-Red.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita-Red#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(341146933847556311)
,p_theme_id=>42
,p_name=>'Vita - Slate'
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita-Slate.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita-Slate#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(341180690523578522)
,p_theme_id=>42
,p_name=>'NG Light'
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita.less'
,p_theme_roller_config=>'{"classes":[],"vars":{"@g_Accent-BG":"#1a457e","@g_Body-Title-BG":"#f0f8ff","@g_Body-Title-FG":"#1a457e","@g_Body-BG":"#f0f8ff","@g_Body-Text":"#1a457e","@g_Actions-Col-BG":"#e7ebee","@g_Actions-Col-Text":"#1a457e","@g_Nav_Style":"light","@g_Nav-BG":'
||'"#f0f8ff","@g_Nav-FG":"#1a457e","@g_Nav-Active-BG":"#e1f1ff","@g_Nav-Active-FG":"#1a457e","@g_NavBarMenu-BG":"#ffffff","@g_NavBarMenu-FG":"#1a457e","@g_Region-Header-BG":"#ffffff","@g_Region-Header-FG":"#1a457e","@g_Region-BG":"#ffffff","@g_Region-FG'
||'":"#1a457e","@g_Disabled-BG":"#1a457e","@g_Disabled-FG":"#ffffff","@g_Form-Item-BG":"#ffffff","@g_Form-Item-FG":"#1a457e","@irrBg":"#ffffff","@l_Left-Col-BG":"#f0f8ff","@l_Left-Col-Text":"#1a457e","@g_Accent-OG":"#fdfdfd","@g_Header-BG":"#1a457e","@g'
||'_Header-FG":"#ffffff","@g_Form-BorderRadius":"0px","@g_Focus":"#1a457e","@g_Link-Base":"#2b9ecc","@l_Button-Success-BG":"#278701","@l_Button-Success-Text":"#ffffff","@l_Button-Primary-BG":"#7fabe5","@l_Button-Primary-Text":"#1a457e","@l_Button-Simple'
||'-BG":"#ffffff","@l_Button-Simple-Text":"#1a457e","@g_Button-BG":"#f8f8f8","@g_Button-Text":"#1a457e","@l_Button-Danger-BG":"#cb1100","@l_Button-Danger-Text":"#ffffff","@g_Danger-BG":"#cb1100","@g_Danger-FG":"#ffffff"},"customCSS":":root {\n    /* Pal'
||'eta de Cores */\n    --a-cv-header-background-color: #f9fafb;\n}","useCustomLess":"N"}'
,p_theme_roller_output_file_url=>'#THEME_DB_FILES#384051562184220795.css'
,p_theme_roller_read_only=>false
);
wwv_flow_imp.component_end;
end;
/
