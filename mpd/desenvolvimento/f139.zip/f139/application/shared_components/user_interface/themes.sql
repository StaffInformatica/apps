prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 139
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_theme(
 p_id=>wwv_flow_imp.id(489282744602697698)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_version_identifier=>'22.1'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_is_locked=>false
,p_current_theme_style_id=>wwv_flow_imp.id(489316268197719905)
,p_default_page_template=>wwv_flow_imp.id(489113429970697586)
,p_default_dialog_template=>wwv_flow_imp.id(489110489949697573)
,p_error_template=>wwv_flow_imp.id(489135649323697598)
,p_printer_friendly_template=>wwv_flow_imp.id(489120808247697591)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_imp.id(489135649323697598)
,p_default_button_template=>wwv_flow_imp.id(489279734794697688)
,p_default_region_template=>wwv_flow_imp.id(489182013666697625)
,p_default_chart_template=>wwv_flow_imp.id(489182013666697625)
,p_default_form_template=>wwv_flow_imp.id(489182013666697625)
,p_default_reportr_template=>wwv_flow_imp.id(489182013666697625)
,p_default_tabform_template=>wwv_flow_imp.id(489182013666697625)
,p_default_wizard_template=>wwv_flow_imp.id(489182013666697625)
,p_default_menur_template=>wwv_flow_imp.id(489194609147697632)
,p_default_listr_template=>wwv_flow_imp.id(489182013666697625)
,p_default_irr_template=>wwv_flow_imp.id(489179976861697624)
,p_default_report_template=>wwv_flow_imp.id(489233170713697656)
,p_default_label_template=>wwv_flow_imp.id(489277194088697685)
,p_default_menu_template=>wwv_flow_imp.id(489281376410697690)
,p_default_calendar_template=>wwv_flow_imp.id(489281453688697691)
,p_default_list_template=>wwv_flow_imp.id(489267107775697677)
,p_default_nav_list_template=>wwv_flow_imp.id(489275901291697683)
,p_default_top_nav_list_temp=>wwv_flow_imp.id(489275901291697683)
,p_default_side_nav_list_temp=>wwv_flow_imp.id(489274133860697682)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_imp.id(489149217063697608)
,p_default_dialogr_template=>wwv_flow_imp.id(489146466586697607)
,p_default_option_label=>wwv_flow_imp.id(489277194088697685)
,p_default_required_label=>wwv_flow_imp.id(489278509475697686)
,p_default_navbar_list_template=>wwv_flow_imp.id(489273723535697682)
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#APEX_FILES#themes/theme_42/22.1/')
,p_files_version=>717
,p_icon_library=>'FONTAPEX_LATEST'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_FILES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>'#THEME_FILES#css/Core#MIN#.css?v=#APEX_VERSION#'
);
wwv_flow_imp.component_end;
end;
/
