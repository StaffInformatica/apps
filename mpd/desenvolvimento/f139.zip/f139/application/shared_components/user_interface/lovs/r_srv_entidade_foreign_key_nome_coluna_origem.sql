prompt --application/shared_components/user_interface/lovs/r_srv_entidade_foreign_key_nome_coluna_origem
begin
--   Manifest
--     R_SRV_ENTIDADE_FOREIGN_KEY.NOME_COLUNA_ORIGEM
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(198089294478691543)
,p_lov_name=>'R_SRV_ENTIDADE_FOREIGN_KEY.NOME_COLUNA_ORIGEM'
,p_lov_query=>'select a.nome_coluna d, a.id r from srv_entidade_coluna a left join srv_entidade_foreign_key b on b.id_entidade = a.id_entidade where b.id = :P9010_ID order by a.ordenacao'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>44456355699442
);
wwv_flow_imp.component_end;
end;
/
