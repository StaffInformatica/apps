prompt --application/shared_components/user_interface/lovs/r_srv_entidade_nome_entidade
begin
--   Manifest
--     R_SRV_ENTIDADE.NOME_ENTIDADE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(4111698533349663)
,p_lov_name=>'R_SRV_ENTIDADE.NOME_ENTIDADE'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'SRV_ENTIDADE'
,p_return_column_name=>'ID'
,p_display_column_name=>'NOME_ENTIDADE'
,p_default_sort_column_name=>'NOME_ENTIDADE'
,p_default_sort_direction=>'ASC'
,p_version_scn=>42100067494030
);
wwv_flow_imp.component_end;
end;
/
