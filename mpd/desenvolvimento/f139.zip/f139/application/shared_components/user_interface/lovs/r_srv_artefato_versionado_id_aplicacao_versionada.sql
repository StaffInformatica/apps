prompt --application/shared_components/user_interface/lovs/r_srv_artefato_versionado_id_aplicacao_versionada
begin
--   Manifest
--     R_SRV_ARTEFATO_VERSIONADO.ID_APLICACAO_VERSIONADA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(152728340994212593)
,p_lov_name=>'R_SRV_ARTEFATO_VERSIONADO.ID_APLICACAO_VERSIONADA'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ap.NOME_APLICACAO || '' - '' || b.versao AS display_value,',
'       av.id AS return_value',
'FROM SRV_APLICACAO_VERSIONADA av',
'LEFT JOIN SRV_APLICACAO ap ON  ap.id = av.ID_APLICACAO',
'LEFT JOIN SRV_SISTEMA_VERSIONADO b ON b.id = av.ID_SISTEMA_VERSIONADO ;'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'RETURN_VALUE'
,p_display_column_name=>'DISPLAY_VALUE'
,p_default_sort_column_name=>'DISPLAY_VALUE'
,p_default_sort_direction=>'ASC'
,p_version_scn=>42105008854153
);
wwv_flow_imp.component_end;
end;
/
