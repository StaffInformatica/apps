prompt --application/shared_components/user_interface/lovs/r_tut_aparencia_nm_aparencia
begin
--   Manifest
--     R_TUT_APARENCIA.NM_APARENCIA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(131369807860808090)
,p_lov_name=>'R_TUT_APARENCIA.NM_APARENCIA'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'TUT_APARENCIA'
,p_return_column_name=>'ID'
,p_display_column_name=>'NM_APARENCIA'
,p_default_sort_column_name=>'NM_APARENCIA'
,p_default_sort_direction=>'ASC'
,p_version_scn=>50253847131778
);
wwv_flow_imp.component_end;
end;
/
