prompt --application/shared_components/user_interface/lovs/artefatos
begin
--   Manifest
--     ARTEFATOS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(225538853001003911)
,p_lov_name=>'ARTEFATOS'
,p_lov_query=>'select id r, nome_artefato||'' (''||codigo_artefato||'')'' d from SRV_ARTEFATO'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_query_table=>'SRV_ARTEFATO'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>46490210544063
);
wwv_flow_imp.component_end;
end;
/
