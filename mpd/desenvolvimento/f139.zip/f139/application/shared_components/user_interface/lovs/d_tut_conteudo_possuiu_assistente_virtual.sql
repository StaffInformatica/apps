prompt --application/shared_components/user_interface/lovs/d_tut_conteudo_possuiu_assistente_virtual
begin
--   Manifest
--     D_TUT_CONTEUDO.POSSUIU_ASSISTENTE_VIRTUAL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(128845297083078778)
,p_lov_name=>'D_TUT_CONTEUDO.POSSUIU_ASSISTENTE_VIRTUAL'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''tut_conteudo'',''possuiu_assistente_virtual'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>50243185126978
);
wwv_flow_imp.component_end;
end;
/
