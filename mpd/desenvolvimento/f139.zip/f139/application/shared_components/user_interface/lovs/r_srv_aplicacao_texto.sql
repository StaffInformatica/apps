prompt --application/shared_components/user_interface/lovs/r_srv_aplicacao_texto
begin
--   Manifest
--     R_SRV_APLICACAO_TEXTO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(154656404749709393)
,p_lov_name=>'R_SRV_APLICACAO_TEXTO'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'SRV_APLICACAO_TEXTO'
,p_return_column_name=>'ID'
,p_display_column_name=>'TAG'
,p_default_sort_column_name=>'TAG'
,p_default_sort_direction=>'ASC'
,p_version_scn=>45364483906138
);
wwv_flow_imp.component_end;
end;
/
