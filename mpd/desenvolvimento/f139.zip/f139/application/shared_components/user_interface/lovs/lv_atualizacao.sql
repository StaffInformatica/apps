prompt --application/shared_components/user_interface/lovs/lv_atualizacao
begin
--   Manifest
--     LV_ATUALIZACAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(241341538544904094)
,p_lov_name=>'LV_ATUALIZACAO'
,p_lov_query=>'.'||wwv_flow_imp.id(241341538544904094)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(241341876619904095)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Manualmente'
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(241342264557904095)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'A partir da Staff'
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(241342675364904095)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'A partir de outra fonte'
,p_lov_return_value=>'3'
);
wwv_flow_imp.component_end;
end;
/
