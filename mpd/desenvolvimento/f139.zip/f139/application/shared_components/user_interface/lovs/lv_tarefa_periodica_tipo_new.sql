prompt --application/shared_components/user_interface/lovs/lv_tarefa_periodica_tipo_new
begin
--   Manifest
--     LV_TAREFA_PERIODICA_TIPO_NEW
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(313342812540370301)
,p_lov_name=>'LV_TAREFA_PERIODICA_TIPO_NEW'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'ADM_FUNCAO_PERIODICA'
,p_return_column_name=>'ID'
,p_display_column_name=>'NOME'
,p_default_sort_column_name=>'NOME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
