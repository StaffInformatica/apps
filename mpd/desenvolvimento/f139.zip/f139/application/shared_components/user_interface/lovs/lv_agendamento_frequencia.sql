prompt --application/shared_components/user_interface/lovs/lv_agendamento_frequencia
begin
--   Manifest
--     LV_AGENDAMENTO_FREQUENCIA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(461535005318524615)
,p_lov_name=>'LV_AGENDAMENTO_FREQUENCIA'
,p_lov_query=>'.'||wwv_flow_imp.id(461535005318524615)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(461535431523524615)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Diariamente'
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(461535825041524615)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Semanalmente'
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(461536211489524616)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Mensalmente'
,p_lov_return_value=>'3'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(461536597880524616)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Anualmente'
,p_lov_return_value=>'4'
);
wwv_flow_imp.component_end;
end;
/
