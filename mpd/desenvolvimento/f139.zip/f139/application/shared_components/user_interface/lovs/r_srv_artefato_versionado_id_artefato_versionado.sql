prompt --application/shared_components/user_interface/lovs/r_srv_artefato_versionado_id_artefato_versionado
begin
--   Manifest
--     R_SRV_ARTEFATO_VERSIONADO.ID_ARTEFATO_VERSIONADO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(5756015919779648)
,p_lov_name=>'R_SRV_ARTEFATO_VERSIONADO.ID_ARTEFATO_VERSIONADO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select b.nome_artefato||'' (''||b.codigo_artefato||'')'' as display_value,',
'       d.versao, ',
'       b.descricao_artefato,',
'       a.id as return_value',
'from srv_artefato_versionado a',
'left join srv_artefato b on  b.id = a.id_artefato',
'left join srv_aplicacao_versionada c on c.id = a.id_aplicacao_versionada',
'left join srv_sistema_versionado d on d.id = c.id_sistema_versionado'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'RETURN_VALUE'
,p_display_column_name=>'DISPLAY_VALUE'
,p_default_sort_column_name=>'DISPLAY_VALUE'
,p_default_sort_direction=>'ASC'
,p_version_scn=>42120200925624
);
wwv_flow_imp.component_end;
end;
/
