prompt --application/shared_components/user_interface/lovs/r_srv_aplicacao_nome_aplicacao
begin
--   Manifest
--     R_SRV_APLICACAO.NOME_APLICACAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(3394505514969912)
,p_lov_name=>'R_SRV_APLICACAO.NOME_APLICACAO'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'SRV_APLICACAO'
,p_return_column_name=>'ID'
,p_display_column_name=>'NOME_APLICACAO'
,p_default_sort_column_name=>'NOME_APLICACAO'
,p_default_sort_direction=>'ASC'
,p_version_scn=>42098859482769
);
wwv_flow_imp.component_end;
end;
/
