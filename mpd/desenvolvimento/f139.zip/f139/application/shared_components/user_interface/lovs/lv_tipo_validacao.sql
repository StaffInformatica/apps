prompt --application/shared_components/user_interface/lovs/lv_tipo_validacao
begin
--   Manifest
--     LV_TIPO_VALIDACAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(241574249252537483)
,p_lov_name=>'LV_TIPO_VALIDACAO'
,p_lov_query=>'.'||wwv_flow_imp.id(241574249252537483)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(241574537638537497)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('Chave prim\00E1ria')
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(241574935241537497)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('Valor obrigat\00F3rio')
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(241575360592537497)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>unistr('Valor \00FAnico')
,p_lov_return_value=>'3'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(241575787018537498)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>unistr('Verfica\00E7\00E3o de valores')
,p_lov_return_value=>'4'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(243521529615484375)
,p_lov_disp_sequence=>5
,p_lov_disp_value=>unistr('Verfica\00E7\00E3o de exclus\00E3o')
,p_lov_return_value=>'5'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(243645865263549864)
,p_lov_disp_sequence=>6
,p_lov_disp_value=>'Livre'
,p_lov_return_value=>'6'
);
wwv_flow_imp.component_end;
end;
/
