prompt --application/shared_components/user_interface/lovs/grupo_funcionalidade_pasta_nome
begin
--   Manifest
--     GRUPO_FUNCIONALIDADE_PASTA.NOME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(223313929008168076)
,p_lov_name=>'GRUPO_FUNCIONALIDADE_PASTA.NOME'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'GRUPO_FUNCIONALIDADE_PASTA'
,p_return_column_name=>'ID'
,p_display_column_name=>'NOME'
,p_default_sort_column_name=>'NOME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
