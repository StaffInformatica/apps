prompt --application/shared_components/user_interface/lovs/r_codigo_idioma_apex
begin
--   Manifest
--     R_CODIGO_IDIOMA_APEX
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(70639834034931701)
,p_lov_name=>'R_CODIGO_IDIOMA_APEX'
,p_lov_query=>'select language_id || '' (''||language_label||'')'' d, language_id r from apex_dg_builtin_languages order by language_label'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>46237294708658
);
wwv_flow_imp.component_end;
end;
/
