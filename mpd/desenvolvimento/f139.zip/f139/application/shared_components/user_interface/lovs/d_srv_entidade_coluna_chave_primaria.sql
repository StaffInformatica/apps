prompt --application/shared_components/user_interface/lovs/d_srv_entidade_coluna_chave_primaria
begin
--   Manifest
--     D_SRV_ENTIDADE_COLUNA.CHAVE_PRIMARIA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(7952620680316028)
,p_lov_name=>'D_SRV_ENTIDADE_COLUNA.CHAVE_PRIMARIA'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''srv_entidade_coluna'',''chave_primaria'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>42135467719881
);
wwv_flow_imp.component_end;
end;
/
