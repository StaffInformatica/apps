prompt --application/shared_components/user_interface/lovs/lv_situacao_convite
begin
--   Manifest
--     LV_SITUACAO_CONVITE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(359426690810628605)
,p_lov_name=>'LV_SITUACAO_CONVITE'
,p_lov_query=>'.'||wwv_flow_imp.id(359426690810628605)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(359426965890628605)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Convite pendente'
,p_lov_return_value=>'0'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(359427385885628607)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Convite enviado'
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(359427695293628608)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>unistr('Aguardando confirma\00E7\00E3o')
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(359428132363628608)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>unistr('Usu\00E1rio criado')
,p_lov_return_value=>'3'
);
wwv_flow_imp.component_end;
end;
/
