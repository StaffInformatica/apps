prompt --application/shared_components/user_interface/lovs/vl_funcao_periodica_tipo
begin
--   Manifest
--     VL_FUNCAO_PERIODICA_TIPO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(209413892819784936)
,p_lov_name=>'VL_FUNCAO_PERIODICA_TIPO'
,p_lov_query=>'.'||wwv_flow_imp.id(209413892819784936)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(209414235347784937)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('Fun\00E7\00E3o predefinida ')
,p_lov_return_value=>'STORED_PROCEDURE'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(209414710846784938)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('Bloco de programa\00E7\00E3o')
,p_lov_return_value=>'PLSQL_BLOCK'
);
wwv_flow_imp.component_end;
end;
/
