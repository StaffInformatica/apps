prompt --application/shared_components/user_interface/lovs/r_mpd_grupo_nome_grupo
begin
--   Manifest
--     R_MPD_GRUPO.NOME_GRUPO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(20796222399079559)
,p_lov_name=>'R_MPD_GRUPO.NOME_GRUPO'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_table=>'MPD_GRUPO'
,p_return_column_name=>'ID'
,p_display_column_name=>'NOME_GRUPO'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>45612500286437
);
wwv_flow_imp.component_end;
end;
/
