prompt --application/shared_components/user_interface/lovs/d_mpd_tenant_autenticacao_mfa_ativa
begin
--   Manifest
--     D_MPD_TENANT.AUTENTICACAO_MFA_ATIVA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(40076487617645918)
,p_lov_name=>'D_MPD_TENANT.AUTENTICACAO_MFA_ATIVA'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''mpd_tenant'',''autenticacao_mfa_ativa'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>41985122600415
);
wwv_flow_imp.component_end;
end;
/
