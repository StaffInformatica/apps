prompt --application/shared_components/user_interface/lovs/r_mpd_tenant_razao_social_geral
begin
--   Manifest
--     R_MPD_TENANT.RAZAO_SOCIAL(GERAL)
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(48338269217144516)
,p_lov_name=>'R_MPD_TENANT.RAZAO_SOCIAL(GERAL)'
,p_lov_query=>'select * from MPD_TENANT '
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'ID'
,p_display_column_name=>'RAZAO_SOCIAL'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'RAZAO_SOCIAL'
,p_default_sort_direction=>'ASC'
,p_version_scn=>41746634976702
);
wwv_flow_imp.component_end;
end;
/
