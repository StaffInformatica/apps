prompt --application/shared_components/user_interface/lovs/d_srv_entidade_permite_de_para
begin
--   Manifest
--     D_SRV_ENTIDADE.PERMITE_DE_PARA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(172173707758243163)
,p_lov_name=>'D_SRV_ENTIDADE.PERMITE_DE_PARA'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''srv_entidade'',''permite_de_para'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>44870453994198
);
wwv_flow_imp.component_end;
end;
/
