prompt --application/shared_components/user_interface/lovs/r_srv_tenant_descricao_idioma
begin
--   Manifest
--     R_SRV_TENANT.DESCRICAO_IDIOMA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(53776744131167407)
,p_lov_name=>'R_SRV_TENANT.DESCRICAO_IDIOMA'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    chamar_webservice_traducao(',
'        p_esquema           => ''wksp_teste'',',
'        p_entidade          => ''srv_idioma'',',
'        p_campo             => ''descricao_idioma'',',
'        p_id_idioma_usuario => apex_util.get_session_state(''IDIOMA_LOGADO''),',
'        p_id_registro       => a.id_idioma           ',
'    ) d,',
'    a.id r',
'from mpd_tenant a'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>45912292947512
);
wwv_flow_imp.component_end;
end;
/
