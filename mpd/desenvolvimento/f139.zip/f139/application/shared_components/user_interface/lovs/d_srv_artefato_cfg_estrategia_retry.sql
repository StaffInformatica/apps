prompt --application/shared_components/user_interface/lovs/d_srv_artefato_cfg_estrategia_retry
begin
--   Manifest
--     D_SRV_ARTEFATO_CFG.ESTRATEGIA_RETRY
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(232602493763376517)
,p_lov_name=>'D_SRV_ARTEFATO_CFG.ESTRATEGIA_RETRY'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''srv_artefato_cfg'',''estrategia_retry'') order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>46489021444047
);
wwv_flow_imp.component_end;
end;
/
