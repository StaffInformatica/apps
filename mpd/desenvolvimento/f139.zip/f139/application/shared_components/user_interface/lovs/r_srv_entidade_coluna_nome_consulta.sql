prompt --application/shared_components/user_interface/lovs/r_srv_entidade_coluna_nome_consulta
begin
--   Manifest
--     R_SRV_ENTIDADE_COLUNA.NOME_CONSULTA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(7946434721135878)
,p_lov_name=>'R_SRV_ENTIDADE_COLUNA.NOME_CONSULTA'
,p_lov_query=>'select distinct LIST_OF_VALUES_NAME d, LIST_OF_VALUES_NAME r from apex_application_lovs where WORKSPACE in (SELECT WORKSPACE from APEX_WORKSPACES WHERE workspace_id = SYS_CONTEXT(''APEX$SESSION'', ''WORKSPACE_ID'')) order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>42135380215876
);
wwv_flow_imp.component_end;
end;
/
