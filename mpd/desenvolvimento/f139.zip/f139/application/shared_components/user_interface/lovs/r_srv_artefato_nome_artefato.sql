prompt --application/shared_components/user_interface/lovs/r_srv_artefato_nome_artefato
begin
--   Manifest
--     R_SRV_ARTEFATO.NOME_ARTEFATO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(84504019144838407)
,p_lov_name=>'R_SRV_ARTEFATO.NOME_ARTEFATO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.nome_artefato||'' (''||a.codigo_artefato||'')'' as d,',
'       a.id as r',
'from srv_artefato a',
'join srv_artefato_cfg b on b.id_artefato = a.id',
'where ind_execucao_assincrona = ''S'''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>46490333640010
);
wwv_flow_imp.component_end;
end;
/
