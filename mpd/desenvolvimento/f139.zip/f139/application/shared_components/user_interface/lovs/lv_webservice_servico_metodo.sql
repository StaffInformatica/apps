prompt --application/shared_components/user_interface/lovs/lv_webservice_servico_metodo
begin
--   Manifest
--     LV_WEBSERVICE_SERVICO_METODO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(317932348981793409)
,p_lov_name=>'LV_WEBSERVICE_SERVICO_METODO'
,p_lov_query=>'.'||wwv_flow_imp.id(317932348981793409)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(317932614960793409)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'GET'
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(317933078916793410)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'POST'
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(317933438277793410)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'PUT'
,p_lov_return_value=>'3'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(317933820928793410)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'DELETE'
,p_lov_return_value=>'4'
);
wwv_flow_imp.component_end;
end;
/
