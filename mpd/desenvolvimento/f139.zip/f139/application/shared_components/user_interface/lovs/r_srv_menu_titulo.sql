prompt --application/shared_components/user_interface/lovs/r_srv_menu_titulo
begin
--   Manifest
--     R_SRV_MENU.TITULO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(155534609112219410)
,p_lov_name=>'R_SRV_MENU.TITULO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.id r, a.titulo||'' (''||b.titulo||'')'' d from SRV_MENU a left join SRV_MENU b on b.id = a.id_menu_pai',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>45364269967922
);
wwv_flow_imp.component_end;
end;
/
