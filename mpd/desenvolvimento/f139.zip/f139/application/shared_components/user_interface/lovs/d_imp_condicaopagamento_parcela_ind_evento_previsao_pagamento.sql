prompt --application/shared_components/user_interface/lovs/d_imp_condicaopagamento_parcela_ind_evento_previsao_pagamento
begin
--   Manifest
--     D_IMP_CONDICAOPAGAMENTO_PARCELA.IND_EVENTO_PREVISAO_PAGAMENTO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(17551116167789000)
,p_lov_name=>'D_IMP_CONDICAOPAGAMENTO_PARCELA.IND_EVENTO_PREVISAO_PAGAMENTO'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''imp_condicaopagamento_parcela'',''ind_evento_previsao_pagamento'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>42209363805707
);
wwv_flow_imp.component_end;
end;
/
