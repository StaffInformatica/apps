prompt --application/shared_components/user_interface/lovs/r_srv_grupo_funcionalidade_titulo
begin
--   Manifest
--     R_SRV_GRUPO_FUNCIONALIDADE.TITULO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(6392850784141980)
,p_lov_name=>'R_SRV_GRUPO_FUNCIONALIDADE.TITULO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.id, razao_social ||'' - ''|| titulo as titulo from SRV_GRUPO_FUNCIONALIDADE a ',
'join mpd_tenant b on b.id = a.id_tenant'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'ID'
,p_display_column_name=>'TITULO'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'TITULO'
,p_default_sort_direction=>'ASC'
,p_version_scn=>44887067536039
);
wwv_flow_imp.component_end;
end;
/
