prompt --application/shared_components/user_interface/lovs/r_srv_sistema_nome_sistema
begin
--   Manifest
--     R_SRV_SISTEMA.NOME_SISTEMA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(151255801252030114)
,p_lov_name=>'R_SRV_SISTEMA.NOME_SISTEMA'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'SRV_SISTEMA'
,p_return_column_name=>'ID'
,p_display_column_name=>'NOME_SISTEMA'
,p_default_sort_column_name=>'NOME_SISTEMA'
,p_default_sort_direction=>'ASC'
,p_version_scn=>42095819910423
);
wwv_flow_imp.component_end;
end;
/
