prompt --application/shared_components/user_interface/lovs/r_srv_entidade_coluna_nome_entidade_nome_coluna
begin
--   Manifest
--     R_SRV_ENTIDADE_COLUNA.NOME_ENTIDADE_NOME_COLUNA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(54326241764567744)
,p_lov_name=>'R_SRV_ENTIDADE_COLUNA.NOME_ENTIDADE_NOME_COLUNA'
,p_lov_query=>'select nome_entidade||'' - ''||nome_coluna d, a.id r from srv_entidade_coluna a join srv_entidade b on b.id = a.id_entidade'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>44545904940818
);
wwv_flow_imp.component_end;
end;
/
