prompt --application/shared_components/user_interface/lovs/d_srv_entidade_ng_permite_anexo_lista_referencia_documento
begin
--   Manifest
--     D_SRV_ENTIDADE_NG_PERMITE_ANEXO.LISTA_REFERENCIA_DOCUMENTO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(203163988618574619)
,p_lov_name=>'D_SRV_ENTIDADE_NG_PERMITE_ANEXO.LISTA_REFERENCIA_DOCUMENTO'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''srv_entidade_ng_permite_anexo'',''lista_referencia_documento'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>45923268365693
);
wwv_flow_imp.component_end;
end;
/
