prompt --application/shared_components/user_interface/lovs/teste_tenant
begin
--   Manifest
--     TESTE_TENANT
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(378881143334421474)
,p_lov_name=>'TESTE_TENANT'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_table=>'TESTE_TENANT'
,p_return_column_name=>'ID_USER'
,p_display_column_name=>'NOME'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'DATA_NASCIMENTO'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(378881697565426969)
,p_query_column_name=>'ID_USER'
,p_display_sequence=>10
,p_data_type=>'NUMBER'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(378882096033426970)
,p_query_column_name=>'NOME'
,p_heading=>'Nome'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(378882571707426970)
,p_query_column_name=>'DATA_NASCIMENTO'
,p_heading=>'Data Nascimento'
,p_display_sequence=>30
,p_data_type=>'DATE'
);
wwv_flow_imp.component_end;
end;
/
