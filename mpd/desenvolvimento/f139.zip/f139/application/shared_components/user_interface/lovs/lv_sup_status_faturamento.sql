prompt --application/shared_components/user_interface/lovs/lv_sup_status_faturamento
begin
--   Manifest
--     LV_SUP_STATUS_FATURAMENTO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(319262248869644682)
,p_lov_name=>'LV_SUP_STATUS_FATURAMENTO'
,p_lov_query=>'.'||wwv_flow_imp.id(319262248869644682)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(319262544710644702)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('Boleto n\00E3o emitido')
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(319262954976644703)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Boleto emitido'
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(319263319963644703)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Faturado'
,p_lov_return_value=>'3'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(319263727492644704)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Atrasado'
,p_lov_return_value=>'4'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(319264167259644704)
,p_lov_disp_sequence=>5
,p_lov_disp_value=>unistr('Em negocia\00E7\00E3o')
,p_lov_return_value=>'5'
);
wwv_flow_imp.component_end;
end;
/
