prompt --application/shared_components/user_interface/lovs/r_ng_pessoa_id_exportador
begin
--   Manifest
--     R_NG_PESSOA.ID_EXPORTADOR
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(98890287073763463)
,p_lov_name=>'R_NG_PESSOA.ID_EXPORTADOR'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "D","R"',
'from(SELECT ',
'    a.num_processoimportacao d,',
'    a.id r',
'FROM ',
'    imp_processoimportacao a',
'    JOIN imp_entrega b ',
'        ON b.id_exportador = a.id_embarcador',
'       AND b.id_importador = a.id_importador',
'       AND b.id = :P9012_ID',
'WHERE ',
'    a.ind_status IN (1,2,3,4)',
'ORDER BY ',
'    d',
' )i '))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>46695348575198
);
wwv_flow_imp.component_end;
end;
/
