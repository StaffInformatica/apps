prompt --application/shared_components/user_interface/lovs/lv_sup_tp_chamado
begin
--   Manifest
--     LV_SUP_TP_CHAMADO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(342439491673325723)
,p_lov_name=>'LV_SUP_TP_CHAMADO'
,p_lov_query=>'.'||wwv_flow_imp.id(342439491673325723)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(342439879953325725)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Problema'
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(342440231329325725)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('Sugest\00E3o')
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(342440619038325725)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>unistr('D\00FAvida')
,p_lov_return_value=>'3'
);
wwv_flow_imp.component_end;
end;
/
