prompt --application/shared_components/user_interface/lovs/lv_automatico_manual
begin
--   Manifest
--     LV_AUTOMATICO_MANUAL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(391587902203792517)
,p_lov_name=>'LV_AUTOMATICO_MANUAL'
,p_lov_query=>'.'||wwv_flow_imp.id(391587902203792517)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(391588244653792518)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('Autom\00E1tico')
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(391588630999792519)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Manual'
,p_lov_return_value=>'2'
);
wwv_flow_imp.component_end;
end;
/
