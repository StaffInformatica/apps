prompt --application/shared_components/user_interface/lovs/r_srv_configuracao_ind_tipo_dado
begin
--   Manifest
--     R_SRV_CONFIGURACAO.IND_TIPO_DADO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(201913622846285952)
,p_lov_name=>'R_SRV_CONFIGURACAO.IND_TIPO_DADO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.titulo D, a.id  R',
'from SRV_DOMINIO_VALOR a ',
'where  id_dominio = 4305',
'ORDER BY a.titulo'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>45912309604646
);
wwv_flow_imp.component_end;
end;
/
