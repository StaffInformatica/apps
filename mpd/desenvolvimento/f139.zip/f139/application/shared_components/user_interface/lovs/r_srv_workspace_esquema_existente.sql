prompt --application/shared_components/user_interface/lovs/r_srv_workspace_esquema_existente
begin
--   Manifest
--     R_SRV_WORKSPACE.ESQUEMA_EXISTENTE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(52555788277349550)
,p_lov_name=>'R_SRV_WORKSPACE.ESQUEMA_EXISTENTE'
,p_lov_query=>'select USERNAME AS ID, USERNAME AS DESCRICAO from all_users where username like ''WKSP_%'';'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'ID'
,p_display_column_name=>'DESCRICAO'
,p_default_sort_column_name=>'DESCRICAO'
,p_default_sort_direction=>'ASC'
,p_version_scn=>44515737257514
);
wwv_flow_imp.component_end;
end;
/
