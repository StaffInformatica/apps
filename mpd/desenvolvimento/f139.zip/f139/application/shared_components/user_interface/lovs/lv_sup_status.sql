prompt --application/shared_components/user_interface/lovs/lv_sup_status
begin
--   Manifest
--     LV_SUP_STATUS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(341203554542675800)
,p_lov_name=>'LV_SUP_STATUS'
,p_lov_query=>'.'||wwv_flow_imp.id(341203554542675800)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(341203934854675801)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Aberto'
,p_lov_return_value=>'A'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(341204402614675801)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('Em an\00E1lise')
,p_lov_return_value=>'B'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(341204729613675801)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Aguardando retorno'
,p_lov_return_value=>'C'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(341205173552675801)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Cancelado'
,p_lov_return_value=>'D'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(341205534678675802)
,p_lov_disp_sequence=>5
,p_lov_disp_value=>'Encerrado'
,p_lov_return_value=>'E'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(341205961398675802)
,p_lov_disp_sequence=>6
,p_lov_disp_value=>'Finalizado'
,p_lov_return_value=>'F'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(341206403773675802)
,p_lov_disp_sequence=>7
,p_lov_disp_value=>unistr('Em digita\00E7\00E3o')
,p_lov_return_value=>'G'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(309957872262558826)
,p_lov_disp_sequence=>8
,p_lov_disp_value=>'Qualidade'
,p_lov_return_value=>'H'
);
wwv_flow_imp.component_end;
end;
/
