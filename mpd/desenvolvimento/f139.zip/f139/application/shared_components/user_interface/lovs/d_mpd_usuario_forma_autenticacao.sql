prompt --application/shared_components/user_interface/lovs/d_mpd_usuario_forma_autenticacao
begin
--   Manifest
--     D_MPD_USUARIO.FORMA_AUTENTICACAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(136464357393932627)
,p_lov_name=>'D_MPD_USUARIO.FORMA_AUTENTICACAO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from pkg_ui.retorna_lista_dominio(586)',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>41856874994422
);
wwv_flow_imp.component_end;
end;
/
