prompt --application/shared_components/user_interface/lovs/d_mae_sched_cfg_ind_paralelo
begin
--   Manifest
--     D_MAE_SCHED_CFG.IND_PARALELO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(232636385749246007)
,p_lov_name=>'D_MAE_SCHED_CFG.IND_PARALELO'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''mae_sched_cfg'',''ind_paralelo'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>46489986623530
);
wwv_flow_imp.component_end;
end;
/
