prompt --application/shared_components/user_interface/lovs/lv_sup_envolvidos
begin
--   Manifest
--     LV_SUP_ENVOLVIDOS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(341200804909675793)
,p_lov_name=>'LV_SUP_ENVOLVIDOS'
,p_lov_query=>'.'||wwv_flow_imp.id(341200804909675793)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(341201533416675796)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Meus chamados'
,p_lov_return_value=>'S'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(341201174189675796)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Chamados como convidado'
,p_lov_return_value=>'N'
);
wwv_flow_imp.component_end;
end;
/
