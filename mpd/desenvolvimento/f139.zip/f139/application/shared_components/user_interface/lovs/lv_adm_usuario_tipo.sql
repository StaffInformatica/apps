prompt --application/shared_components/user_interface/lovs/lv_adm_usuario_tipo
begin
--   Manifest
--     LV_ADM_USUARIO_TIPO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(341422043960919087)
,p_lov_name=>'LV_ADM_USUARIO_TIPO'
,p_lov_query=>'.'||wwv_flow_imp.id(341422043960919087)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(341422451017919088)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Administrador'
,p_lov_return_value=>'ADMIN:CREATE:DATA_LOADER:EDIT:HELP:MONITOR:SQL'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(341422815674919088)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Desenvolvedor'
,p_lov_return_value=>'CREATE:DATA_LOADER:EDIT:HELP:MONITOR:SQL'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(341423266229919088)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>unistr('Usu\00E1rio final')
,p_lov_return_value=>'NULL'
);
wwv_flow_imp.component_end;
end;
/
