prompt --application/shared_components/user_interface/lovs/d_srv_entidade_nome_leitura
begin
--   Manifest
--     D_SRV_ENTIDADE.NOME_LEITURA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(55029685733406179)
,p_lov_name=>'D_SRV_ENTIDADE.NOME_LEITURA'
,p_lov_query=>'select nome_leitura d, id r from srv_entidade'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>45923313071454
);
wwv_flow_imp.component_end;
end;
/
