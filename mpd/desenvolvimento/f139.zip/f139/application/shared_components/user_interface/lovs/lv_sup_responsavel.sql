prompt --application/shared_components/user_interface/lovs/lv_sup_responsavel
begin
--   Manifest
--     LV_SUP_RESPONSAVEL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(312454210791758545)
,p_lov_name=>'LV_SUP_RESPONSAVEL'
,p_lov_query=>'.'||wwv_flow_imp.id(312454210791758545)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(312454502616758546)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Meus chamados'
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(312454850795758546)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('Analista respons\00E1vel')
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(312455269481758546)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>unistr('Atendente respons\00E1vel ')
,p_lov_return_value=>'3'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(313175446020158410)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Outros chamados'
,p_lov_return_value=>'4'
);
wwv_flow_imp.component_end;
end;
/
