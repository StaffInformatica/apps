prompt --application/shared_components/user_interface/lovs/d_mpd_traducaopadrao_ind_texto_original
begin
--   Manifest
--     D_MPD_TRADUCAOPADRAO.IND_TEXTO_ORIGINAL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(213381244548757988)
,p_lov_name=>'D_MPD_TRADUCAOPADRAO.IND_TEXTO_ORIGINAL'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''mpd_traducaotextopadrao'',''ind_texto_original'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>46142336825578
);
wwv_flow_imp.component_end;
end;
/
