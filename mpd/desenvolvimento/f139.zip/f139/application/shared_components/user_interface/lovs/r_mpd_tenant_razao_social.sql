prompt --application/shared_components/user_interface/lovs/r_mpd_tenant_razao_social
begin
--   Manifest
--     R_MPD_TENANT.RAZAO_SOCIAL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(105595274343125641)
,p_lov_name=>'R_MPD_TENANT.RAZAO_SOCIAL'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select razao_social d, id r from MPD_TENANT ',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>41960638295877
);
wwv_flow_imp.component_end;
end;
/
