prompt --application/shared_components/user_interface/lovs/lv_carga
begin
--   Manifest
--     LV_CARGA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(241339787906899434)
,p_lov_name=>'LV_CARGA'
,p_lov_query=>'.'||wwv_flow_imp.id(241339787906899434)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(241340017724899434)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('N\00E3o h\00E1')
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(241340469082899435)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Iniciada pela staff'
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(241340902794899435)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Iniciada pelo cliente'
,p_lov_return_value=>'3'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(241341311915899435)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Iniciada por outra fonte'
,p_lov_return_value=>'4'
);
wwv_flow_imp.component_end;
end;
/
