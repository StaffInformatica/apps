prompt --application/shared_components/user_interface/lovs/d_tkt_execucao_status_execucao
begin
--   Manifest
--     D_TKT_EXECUCAO.STATUS_EXECUCAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(107613857833025866)
,p_lov_name=>'D_TKT_EXECUCAO.STATUS_EXECUCAO'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''tkt_execucao'',''status_execucao'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>50084669529414
);
wwv_flow_imp.component_end;
end;
/
