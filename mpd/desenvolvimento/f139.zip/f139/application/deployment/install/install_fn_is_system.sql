prompt --application/deployment/install/install_fn_is_system
begin
--   Manifest
--     INSTALL: INSTALL-FN_IS_SYSTEM
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(48253066453617828)
,p_install_id=>wwv_flow_imp.id(216780107998249685)
,p_name=>'FN_IS_SYSTEM'
,p_sequence=>3
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace FUNCTION FN_IS_SYSTEM',
'RETURN boolean',
'IS',
'    v_count NUMBER;',
'BEGIN',
'    SELECT COUNT(1)',
'      INTO v_count',
'      FROM MPD_USUARIO_PAPEL a',
'      JOIN MPD_PAPEL b',
'        ON b.ID = a.ID_PAPEL_USUARIO',
'     WHERE a.ID_USUARIO = pkg_util.retorna_id_usuario_logado',
'       AND b.SYSTEM = ''S'';',
'',
'    RETURN v_count > 0;',
'END;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
