prompt --application/deployment/install/install_ui_mpd_td1039
begin
--   Manifest
--     INSTALL: INSTALL-UI_MPD_TD1039
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(164397718274100236)
,p_install_id=>wwv_flow_imp.id(364915685672391068)
,p_name=>'UI_MPD_TD1039'
,p_sequence=>80
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace package "UI_MPD_TD1039" as',
'',
'    procedure formulario(p_codigo_artefato in varchar2, p_param1 in varchar2 default null, p_param2 in varchar2 default null);',
'',
'    procedure post(',
'        p_id in number default null,',
'        p_sucesso out clob,',
'        p_messages out pkg_mensagem.message_record_table     ',
'    );',
'    ',
'end "UI_MPD_TD1039";',
'/',
'create or replace package body "UI_MPD_TD1039" as',
'',
'    procedure formulario(p_codigo_artefato in varchar2, p_param1 in varchar2 default null, p_param2 in varchar2 default null) is ',
'        l_ind_tipo_movimento imp_processoimportacao_numerario.ind_tipo_movimento%type; ',
'        l_id_tenant number;',
'        l_id_moeda_nacional number;',
'    begin ',
'        MERGE INTO temp_formulario tf',
'        USING (SELECT p_codigo_artefato AS codigo_artefato, ''id_tenant'' AS nome_coluna, 1 AS indice, '''' AS tipo_interacao, ''R_MPD_TENANT.RAZAO_SOCIAL'' AS nome_consulta, ''N'' AS somente_leitura, ''S'' as coluna_tabela, null valor, null dependencia, null '
||'atribuir_valor, null executa_js from dual union all',
'               SELECT p_codigo_artefato, ''id_artefato'',                         3, '''',null, '''', '''', null valor, null dependencia, null atribuir_valor, null executa_js from dual UNION ALL',
'               SELECT p_codigo_artefato, ''id_negocio'',                          5, '''',null, '''', '''', null valor, null dependencia, null atribuir_valor, null executa_js from dual UNION ALL',
'               SELECT p_codigo_artefato, ''parametros'',                          6, '''',null, '''', '''', null valor, null dependencia, null atribuir_valor, null executa_js from dual UNION ALL',
'               SELECT p_codigo_artefato, ''prioridade'',                          7, '''',null, '''', '''', null valor, null dependencia, null atribuir_valor, null executa_js from dual UNION ALL',
'               SELECT p_codigo_artefato, ''tipo_acao'',                           8, '''',null, '''', '''', null valor, null dependencia, null atribuir_valor, null executa_js from dual ',
'               ) new_data',
unistr('        ON (tf.codigo_artefato = new_data.codigo_artefato AND tf.nome_coluna = new_data.nome_coluna)  -- Condi\00E7\00E3o de correspond\00EAncia'),
'        WHEN NOT MATCHED THEN',
'            INSERT (codigo_artefato, nome_coluna, indice, tipo_interacao, nome_consulta, somente_leitura, coluna_tabela,valor, dependencia,atribuir_valor,executa_js)',
'            VALUES (new_data.codigo_artefato, new_data.nome_coluna, new_data.indice, new_data.tipo_interacao, new_data.nome_consulta, new_data.somente_leitura, new_data.coluna_tabela,new_data.valor, new_data.dependencia, new_data.atribuir_valor, new_'
||'data.executa_js);',
'    end formulario;',
'    ',
'    procedure post(',
'        p_id in number default null,',
'        p_sucesso out clob,',
'        p_messages out pkg_mensagem.message_record_table',
'    )',
'    is',
'        l_id number;',
'    begin',
'        l_id := pkg_maestro_api.postar_requisicao(',
'            p_id_artefato       => apex_application.g_f03(1),',
'            p_id_tenant         => apex_application.g_f01(1),',
'            p_id_usuario        => apex_util.get_session_state(''ID_USUARIO_LOGADO''),',
'            p_id_negocio        => apex_application.g_f05(1),',
'            p_payload           => apex_application.g_f06(1),',
'            p_prioridade        => apex_application.g_f07(1),',
'            p_tipo_acao         => apex_application.g_f08(1)',
'        );',
'    end;',
'',
'end "UI_MPD_TD1039";',
'/'))
);
wwv_flow_imp.component_end;
end;
/
