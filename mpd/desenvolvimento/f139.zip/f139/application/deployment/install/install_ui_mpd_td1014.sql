prompt --application/deployment/install/install_ui_mpd_td1014
begin
--   Manifest
--     INSTALL: INSTALL-UI_MPD_TD1014
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(164397282817115964)
,p_install_id=>wwv_flow_imp.id(364915685672391068)
,p_name=>'UI_MPD_TD1014'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace package "UI_MPD_TD1014" as',
'',
'    procedure formulario(p_codigo_artefato in varchar2, p_param1 in varchar2 default null, p_param2 in varchar2 default null);',
'',
'    procedure post(',
'        p_id in number default null,',
'        p_sucesso out clob,',
'        p_messages out pkg_mensagem.message_record_table     ',
'    );',
'',
'',
'end "UI_MPD_TD1014";',
'/',
'create or replace package body "UI_MPD_TD1014" as',
'',
'    procedure formulario(p_codigo_artefato in varchar2, p_param1 in varchar2 default null, p_param2 in varchar2 default null) is    ',
'    begin',
'        null;',
'    end formulario;',
'',
'    procedure post(',
'        p_id in number default null,        ',
'        p_sucesso out clob,',
'        p_messages out pkg_mensagem.message_record_table         ',
'    )',
'    is',
'        l_id number;',
'    begin',
'        bo_mae_sched_cfg.inclui_registro(',
'            p_id_artefato => apex_application.g_f02(1),',
'            p_intervalo_segundos => apex_application.g_f03(2),',
'            p_ind_paralelo => apex_application.g_f04(1),',
'            p_ativo => apex_application.g_f05(1),',
'            p_id => l_id, ',
'            p_sucesso => p_sucesso,',
'            p_messages => p_messages',
'        );',
'    end;',
'',
'end "UI_MPD_TD1014";',
'/'))
);
wwv_flow_imp.component_end;
end;
/
