prompt --application/deployment/install/install_valor_client_identifier
begin
--   Manifest
--     INSTALL: INSTALL-valor_client_identifier
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(48252845360613265)
,p_install_id=>wwv_flow_imp.id(216780107998249685)
,p_name=>'valor_client_identifier'
,p_sequence=>2
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace function valor_client_identifier(',
'    p_chave in varchar2',
') return varchar2',
'is',
'    l_client_identifier varchar2(4000);',
'    l_chave             varchar2(100);',
'    l_valor             varchar2(4000);',
'begin',
'    l_client_identifier := sys_context(''USERENV'', ''CLIENT_IDENTIFIER'');',
'',
'    if l_client_identifier is null or p_chave is null then',
'        return null;',
'    end if;',
'',
'    l_chave := upper(trim(p_chave));',
'',
'    l_valor := regexp_substr(',
'        l_client_identifier,',
'        ''(^|;)'' || l_chave || '':([^;]+)'',',
'        1,',
'        1,',
'        ''i'',',
'        2',
'    );',
'',
'    return l_valor;',
'',
'exception',
'    when others then',
'        return null;',
'end valor_client_identifier;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
