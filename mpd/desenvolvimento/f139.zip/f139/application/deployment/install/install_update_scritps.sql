prompt --application/deployment/install/install_update_scritps
begin
--   Manifest
--     INSTALL: INSTALL-Update Scritps
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(112995859122066806)
,p_install_id=>wwv_flow_imp.id(216780107998249685)
,p_name=>'Update Scritps'
,p_sequence=>11
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    esquema varchar2(256);',
'begin',
'    SELECT SYS_CONTEXT(''USERENV'', ''CURRENT_SCHEMA'') into esquema FROM DUAL;',
'    pkg_ticket_deploy.executar_pendentes(',
'        p_codigo_ambiente => esquema,',
'        p_id_usuario      => 124',
'    );    ',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
