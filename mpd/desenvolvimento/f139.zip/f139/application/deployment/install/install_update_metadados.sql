prompt --application/deployment/install/install_update_metadados
begin
--   Manifest
--     INSTALL: INSTALL-Update Metadados
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16273260007778631)
,p_install_id=>wwv_flow_imp.id(216780107998249685)
,p_name=>'Update Metadados'
,p_sequence=>1
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    pkg_metadata_deploy.sync_all_disable_fks(''WKSP_DESENVOLVIMENTO'');',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
