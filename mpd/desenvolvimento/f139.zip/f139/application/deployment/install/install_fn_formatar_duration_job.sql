prompt --application/deployment/install/install_fn_formatar_duration_job
begin
--   Manifest
--     INSTALL: INSTALL-fn_formatar_duration_job
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16272311145814519)
,p_install_id=>wwv_flow_imp.id(216780107998249685)
,p_name=>'fn_formatar_duration_job'
,p_sequence=>250
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace function fn_formatar_duration_job (',
'    p_duration in interval day to second',
') return varchar2',
'is',
'    l_days         number;',
'    l_hours        number;',
'    l_minutes      number;',
'    l_seconds      number;',
'    l_milliseconds number;',
'begin',
'    if p_duration is null then',
'        return null;',
'    end if;',
'',
'    l_days         := extract(day    from p_duration);',
'    l_hours        := extract(hour   from p_duration);',
'    l_minutes      := extract(minute from p_duration);',
'    l_seconds      := trunc(extract(second from p_duration));',
'    l_milliseconds := trunc(extract(second from p_duration) * 1000);',
'',
'    if l_days > 0 then',
'        return l_days || '' dia(s) ''',
'            || lpad(l_hours, 2, ''0'') || ''h ''',
'            || lpad(l_minutes, 2, ''0'') || ''min ''',
'            || lpad(l_seconds, 2, ''0'') || ''s'';',
'',
'    elsif l_hours > 0 then',
'        return lpad(l_hours, 2, ''0'') || ''h ''',
'            || lpad(l_minutes, 2, ''0'') || ''min ''',
'            || lpad(l_seconds, 2, ''0'') || ''s'';',
'',
'    elsif l_minutes > 0 then',
'        return lpad(l_minutes, 2, ''0'') || ''min ''',
'            || lpad(l_seconds, 2, ''0'') || ''s'';',
'',
'    elsif l_seconds > 0 then',
'        return l_seconds || '' s'';',
'',
'    else',
'        return l_milliseconds || '' ms'';',
'    end if;',
'end fn_formatar_duration_job;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
