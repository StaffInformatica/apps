prompt --application/deployment/install/install_update_ddl
begin
--   Manifest
--     INSTALL: INSTALL-Update DDL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>72627210696879169
,p_default_application_id=>9000
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16263609898879637)
,p_install_id=>wwv_flow_imp.id(216780107998249685)
,p_name=>'Update DDL'
,p_sequence=>0
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_count NUMBER;',
'BEGIN',
'    SELECT COUNT(*)',
'      INTO v_count',
'      FROM ALL_TAB_COLUMNS',
'     WHERE OWNER       = SYS_CONTEXT(''USERENV'', ''CURRENT_SCHEMA'')',
'       AND TABLE_NAME  = ''MAE_AGENDA_CFG''',
'       AND COLUMN_NAME = ''CODIGO_ARTEFATO'';',
' ',
'    IF v_count > 0 THEN',
'        EXECUTE IMMEDIATE ''ALTER TABLE MAE_AGENDA_CFG DROP COLUMN CODIGO_ARTEFATO'';',
'        DBMS_OUTPUT.PUT_LINE(''[OK] Coluna CODIGO_ARTEFATO removida da tabela MAE_AGENDA_CFG.'');',
'    ELSE',
'        DBMS_OUTPUT.PUT_LINE(''[SKIP] Coluna CODIGO_ARTEFATO nao encontrada em MAE_AGENDA_CFG. Nenhuma acao necessaria.'');',
'    END IF;',
'END;',
'/',
'DECLARE',
'    v_count NUMBER;',
'BEGIN',
'    SELECT COUNT(*)',
'      INTO v_count',
'      FROM ALL_TAB_COLUMNS',
'     WHERE OWNER       = SYS_CONTEXT(''USERENV'', ''CURRENT_SCHEMA'')',
'       AND TABLE_NAME  = ''MAE_SCHED_CFG''',
'       AND COLUMN_NAME = ''IND_SINCRONIZAR'';',
' ',
'    IF v_count = 0 THEN',
'        EXECUTE IMMEDIATE ''ALTER TABLE MAE_SCHED_CFG ADD IND_SINCRONIZAR VARCHAR2(1) DEFAULT ''''N'''' NOT NULL'';',
'        DBMS_OUTPUT.PUT_LINE(''[OK] Coluna IND_SINCRONIZAR criada na tabela MAE_SCHED_CFG.'');',
'    ELSE',
'        DBMS_OUTPUT.PUT_LINE(''[SKIP] Coluna IND_SINCRONIZAR ja existe em MAE_SCHED_CFG. Nenhuma acao necessaria.'');',
'    END IF;',
'END;',
''))
);
wwv_flow_imp.component_end;
end;
/
