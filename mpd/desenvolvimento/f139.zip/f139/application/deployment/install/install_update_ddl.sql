prompt --application/deployment/install/install_update_ddl
begin
--   Manifest
--     INSTALL: INSTALL-Update DDL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(164399187573021020)
,p_install_id=>wwv_flow_imp.id(364915685672391068)
,p_name=>'Update DDL'
,p_sequence=>0
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_count NUMBER;',
'BEGIN',
'    SELECT COUNT(*)',
'      INTO v_count',
'      FROM ALL_TAB_COLUMNS',
'     WHERE OWNER       = SYS_CONTEXT(''USERENV'', ''CURRENT_SCHEMA'')',
'       AND TABLE_NAME  = ''MAE_AGENDA_CFG''',
'       AND COLUMN_NAME = ''CODIGO_ARTEFATO'';',
' ',
'    IF v_count > 0 THEN',
'        EXECUTE IMMEDIATE ''ALTER TABLE MAE_AGENDA_CFG DROP COLUMN CODIGO_ARTEFATO'';',
'        DBMS_OUTPUT.PUT_LINE(''[OK] Coluna CODIGO_ARTEFATO removida da tabela MAE_AGENDA_CFG.'');',
'    ELSE',
'        DBMS_OUTPUT.PUT_LINE(''[SKIP] Coluna CODIGO_ARTEFATO nao encontrada em MAE_AGENDA_CFG. Nenhuma acao necessaria.'');',
'    END IF;',
'END;',
'',
''))
);
wwv_flow_imp.component_end;
end;
/
