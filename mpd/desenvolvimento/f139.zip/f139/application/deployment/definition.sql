prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 139
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>139
,p_default_id_offset=>148135577674141383
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(364915685672391068)
);
wwv_flow_imp.component_end;
end;
/
