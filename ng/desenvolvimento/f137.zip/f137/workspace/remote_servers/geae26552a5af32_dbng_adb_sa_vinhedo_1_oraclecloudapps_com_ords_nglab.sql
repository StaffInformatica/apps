prompt --workspace/remote_servers/geae26552a5af32_dbng_adb_sa_vinhedo_1_oraclecloudapps_com_ords_nglab
begin
--   Manifest
--     REMOTE SERVER: geae26552a5af32-dbng-adb-sa-vinhedo-1-oraclecloudapps-com-ords-nglab
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_imp_workspace.create_remote_server(
 p_id=>253246641666247773
,p_name=>'geae26552a5af32-dbng-adb-sa-vinhedo-1-oraclecloudapps-com-ords-nglab'
,p_static_id=>'geae26552a5af32_dbng_adb_sa_vinhedo_1_oraclecloudapps_com_ords_nglab'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('geae26552a5af32_dbng_adb_sa_vinhedo_1_oraclecloudapps_com_ords_nglab'),'https://geae26552a5af32-dbng.adb.sa-vinhedo-1.oraclecloudapps.com/ords/nglab/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('geae26552a5af32_dbng_adb_sa_vinhedo_1_oraclecloudapps_com_ords_nglab'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('geae26552a5af32_dbng_adb_sa_vinhedo_1_oraclecloudapps_com_ords_nglab'),'')
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
