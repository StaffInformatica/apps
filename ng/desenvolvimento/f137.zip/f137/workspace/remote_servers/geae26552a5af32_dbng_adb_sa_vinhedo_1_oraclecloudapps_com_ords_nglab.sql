prompt --workspace/remote_servers/geae26552a5af32_dbng_adb_sa_vinhedo_1_oraclecloudapps_com_ords_nglab
begin
--   Manifest
--     REMOTE SERVER: geae26552a5af32-dbng-adb-sa-vinhedo-1-oraclecloudapps-com-ords-nglab
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(107540240437459291)
,p_name=>'geae26552a5af32-dbng-adb-sa-vinhedo-1-oraclecloudapps-com-ords-nglab'
,p_static_id=>'geae26552a5af32_dbng_adb_sa_vinhedo_1_oraclecloudapps_com_ords_nglab'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('geae26552a5af32_dbng_adb_sa_vinhedo_1_oraclecloudapps_com_ords_nglab'),'https://geae26552a5af32-dbng.adb.sa-vinhedo-1.oraclecloudapps.com/ords/nglab/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('geae26552a5af32_dbng_adb_sa_vinhedo_1_oraclecloudapps_com_ords_nglab'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('geae26552a5af32_dbng_adb_sa_vinhedo_1_oraclecloudapps_com_ords_nglab'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('geae26552a5af32_dbng_adb_sa_vinhedo_1_oraclecloudapps_com_ords_nglab'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('geae26552a5af32_dbng_adb_sa_vinhedo_1_oraclecloudapps_com_ords_nglab'),'')
,p_prompt_on_install=>false
,p_ai_is_builder_service=>false
,p_ai_model_name=>nvl(wwv_flow_application_install.get_remote_server_ai_model('geae26552a5af32_dbng_adb_sa_vinhedo_1_oraclecloudapps_com_ords_nglab'),'')
,p_ai_http_headers=>nvl(wwv_flow_application_install.get_remote_server_ai_headers('geae26552a5af32_dbng_adb_sa_vinhedo_1_oraclecloudapps_com_ords_nglab'),'')
,p_ai_attributes=>nvl(wwv_flow_application_install.get_remote_server_ai_attrs('geae26552a5af32_dbng_adb_sa_vinhedo_1_oraclecloudapps_com_ords_nglab'),'')
);
wwv_flow_imp.component_end;
end;
/
