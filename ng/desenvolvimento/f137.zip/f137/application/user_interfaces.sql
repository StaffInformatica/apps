prompt --application/user_interfaces
begin
--   Manifest
--     USER INTERFACES: 137
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_user_interface(
 p_id=>wwv_flow_imp.id(137)
,p_theme_id=>42
,p_home_url=>'f?p=&APP_ID.:2:&SESSION.:::2:P2_ITEM_PAI:'
,p_login_url=>'f?p=&APP_ID.:9999:&APP_SESSION.::&DEBUG.:::'
,p_theme_style_by_user_pref=>false
,p_built_with_love=>false
,p_global_page_id=>0
,p_navigation_list_id=>wwv_flow_imp.id(224049059830402036)
,p_navigation_list_position=>'TOP'
,p_navigation_list_template_id=>wwv_flow_imp.id(529717596506987055)
,p_nav_list_template_options=>'#DEFAULT#:js-tabLike'
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APP_FILES#staff.css',
'#APP_FILES#icons.css',
'#APP_FILES#css-round.css'))
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APP_FILES#javascript#MIN#.js',
'#APP_FILES#TransformaModal#MIN#.js',
'https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/5.0.9/jquery.inputmask.min.js',
'',
'https://cdn.jsdelivr.net/npm/autonumeric@4.10.9/dist/autoNumeric.min.js',
'#APP_FILES#AutoNumeric.js',
'#APP_FILES#breadcrumb-dinamico#MIN#.js',
'#APP_FILES#autorefresh#MIN#.js'))
,p_nav_bar_type=>'LIST'
,p_nav_bar_list_id=>wwv_flow_imp.id(529746002523987088)
,p_nav_bar_list_template_id=>wwv_flow_imp.id(529715418750987054)
,p_nav_bar_template_options=>'#DEFAULT#'
);
wwv_flow_imp.component_end;
end;
/
