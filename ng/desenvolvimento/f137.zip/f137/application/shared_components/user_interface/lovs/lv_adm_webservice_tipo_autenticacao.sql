prompt --application/shared_components/user_interface/lovs/lv_adm_webservice_tipo_autenticacao
begin
--   Manifest
--     LV_ADM_WEBSERVICE_TIPO_AUTENTICACAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(506332310318863941)
,p_lov_name=>'LV_ADM_WEBSERVICE_TIPO_AUTENTICACAO'
,p_lov_query=>'.'||wwv_flow_imp.id(506332310318863941)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(506332746041863945)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('Sem autentica\00E7\00E3o')
,p_lov_return_value=>'0'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(506333134981863946)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('Autentica\00E7\00E3o b\00E1sica')
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(506333565747863946)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>unistr('Autentica\00E7\00E3o Oauth 2.0')
,p_lov_return_value=>'2'
);
wwv_flow_imp.component_end;
end;
/
