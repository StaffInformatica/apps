prompt --application/shared_components/user_interface/lovs/d_srv_entidade_coluna_dependencia_tipo_comportamento
begin
--   Manifest
--     D_SRV_ENTIDADE_COLUNA_DEPENDENCIA.TIPO_COMPORTAMENTO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(142753382167938348)
,p_lov_name=>'D_SRV_ENTIDADE_COLUNA_DEPENDENCIA.TIPO_COMPORTAMENTO'
,p_static_id=>'d-srv-entidade-coluna-dependencia-tipo-comportamento'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''srv_entidade_coluna_dependencia'',''tipo_comportamento'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'50342193215331'
,p_created_on=>wwv_flow_imp.dz('20260820134538Z')
,p_updated_on=>wwv_flow_imp.dz('20260820134538Z')
,p_created_by=>'DEVNORTHONN'
,p_updated_by=>'DEVNORTHONN'
);
wwv_flow_imp.component_end;
end;
/
