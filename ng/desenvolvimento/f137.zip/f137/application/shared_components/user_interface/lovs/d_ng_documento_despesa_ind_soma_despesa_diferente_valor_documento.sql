prompt --application/shared_components/user_interface/lovs/d_ng_documento_despesa_ind_soma_despesa_diferente_valor_documento
begin
--   Manifest
--     D_NG_DOCUMENTO_DESPESA.IND_SOMA_DESPESA_DIFERENTE_VALOR_DOCUMENTO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(253719722107122050)
,p_lov_name=>'D_NG_DOCUMENTO_DESPESA.IND_SOMA_DESPESA_DIFERENTE_VALOR_DOCUMENTO'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''ng_documento_despesa'',''ind_soma_despesa_diferente_valor_documento'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>50062698479091
);
wwv_flow_imp.component_end;
end;
/
