prompt --application/shared_components/user_interface/lovs/d_imp_minutanotafiscal_entrada_transporte_movimento_unico
begin
--   Manifest
--     D_IMP_MINUTANOTAFISCAL_ENTRADA_TRANSPORTE.MOVIMENTO_UNICO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(264345724793134298)
,p_lov_name=>'D_IMP_MINUTANOTAFISCAL_ENTRADA_TRANSPORTE.MOVIMENTO_UNICO'
,p_static_id=>'d-imp-minutanotafiscal-entrada-transporte-movimento-unico'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select d, r from (',
'    select ''Sim'' d, ''S'' r, 1 ordem from dual',
'    union all',
unistr('    select ''N\00E3o'' d, ''N'' r, 2 ordem from dual'),
')',
'order by ordem',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>'50138148822219'
,p_created_on=>wwv_flow_imp.dz('20260730133120Z')
,p_updated_on=>wwv_flow_imp.dz('20260730133120Z')
,p_created_by=>'DEVJONICLEI'
,p_updated_by=>'DEVJONICLEI'
);
wwv_flow_imp.component_end;
end;
/
