prompt --application/shared_components/user_interface/lovs/r_imp_processoimportacao_num_processoimportacao
begin
--   Manifest
--     R_IMP_PROCESSOIMPORTACAO.NUM_PROCESSOIMPORTACAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(131810484794328468)
,p_lov_name=>'R_IMP_PROCESSOIMPORTACAO.NUM_PROCESSOIMPORTACAO'
,p_static_id=>'r-imp-processoimportacao-num-processoimportacao'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'IMP_PROCESSOIMPORTACAO'
,p_return_column_name=>'ID'
,p_display_column_name=>'NUM_PROCESSOIMPORTACAO'
,p_default_sort_column_name=>'NUM_PROCESSOIMPORTACAO'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'SH256:f0NpPqqZ8C3rpURYQtyIxQMBWmN_ghWD4DkPpu5FC1s'
);
wwv_flow_imp.component_end;
end;
/
