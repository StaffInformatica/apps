prompt --application/shared_components/user_interface/lovs/lv_situacao_convite
begin
--   Manifest
--     LV_SITUACAO_CONVITE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(254161984797129495)
,p_lov_name=>'LV_SITUACAO_CONVITE'
,p_lov_query=>'.'||wwv_flow_imp.id(254161984797129495)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(254162259877129495)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Convite pendente'
,p_lov_return_value=>'0'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(254162679872129497)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Convite enviado'
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(254162989280129498)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>unistr('Aguardando confirma\00E7\00E3o')
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(254163426350129498)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>unistr('Usu\00E1rio criado')
,p_lov_return_value=>'3'
);
wwv_flow_imp.component_end;
end;
/
