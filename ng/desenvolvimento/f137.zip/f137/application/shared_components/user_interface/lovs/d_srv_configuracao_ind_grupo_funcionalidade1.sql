prompt --application/shared_components/user_interface/lovs/d_srv_configuracao_ind_grupo_funcionalidade1
begin
--   Manifest
--     D_SRV_CONFIGURACAO.IND_GRUPO_FUNCIONALIDADE1
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(136777318848987547)
,p_lov_name=>'D_SRV_CONFIGURACAO.IND_GRUPO_FUNCIONALIDADE1'
,p_static_id=>'d-srv-configuracao-ind-grupo-funcionalidade1'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''srv_configuracao_ng'',''ind_grupo_funcionalidade'') order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>'SH256:TqBAE6XlUNORKYZ0RDHxcnPoWN429yx3EG54WzIgnzk'
,p_created_on=>wwv_flow_imp.dz('20260910122355Z')
,p_updated_on=>wwv_flow_imp.dz('20260910122355Z')
,p_created_by=>'DEVJONICLEI'
,p_updated_by=>'DEVJONICLEI'
);
wwv_flow_imp.component_end;
end;
/
