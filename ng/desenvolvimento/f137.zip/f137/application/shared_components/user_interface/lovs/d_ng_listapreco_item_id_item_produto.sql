prompt --application/shared_components/user_interface/lovs/d_ng_listapreco_item_id_item_produto
begin
--   Manifest
--     D_NG_LISTAPRECO_ITEM.ID_ITEM_PRODUTO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(46017257814598813)
,p_lov_name=>'D_NG_LISTAPRECO_ITEM.ID_ITEM_PRODUTO'
,p_static_id=>'d-ng-listapreco-item-id-item-produto'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    b.codigo_item as d,  ',
'    a.id as r                       ',
'from ng_item_produto a',
'join ng_item b on b.id = a.id_item',
'where b.ind_tipo_item = ''P''',
'order by 1',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'44840237039599'
);
wwv_flow_imp.component_end;
end;
/
