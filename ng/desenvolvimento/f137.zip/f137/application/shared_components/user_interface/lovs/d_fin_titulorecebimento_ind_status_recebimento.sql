prompt --application/shared_components/user_interface/lovs/d_fin_titulorecebimento_ind_status_recebimento
begin
--   Manifest
--     D_FIN_TITULORECEBIMENTO.IND_STATUS_RECEBIMENTO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(104351349633681770)
,p_lov_name=>'D_FIN_TITULORECEBIMENTO.IND_STATUS_RECEBIMENTO'
,p_static_id=>'d-fin-titulorecebimento-ind-status-recebimento'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''fin_titulorecebimento'',''ind_status_recebimento'') order by r'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'50005169034969'
,p_created_on=>wwv_flow_imp.dz('20260716011358Z')
,p_updated_on=>wwv_flow_imp.dz('20260716011619Z')
,p_created_by=>'DEVJONATHAN'
,p_updated_by=>'DEVJONATHAN'
);
wwv_flow_imp.component_end;
end;
/
