prompt --application/shared_components/user_interface/lovs/r_ng_pessoa_id
begin
--   Manifest
--     R_NG_PESSOA.ID
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(195981333273898273)
,p_lov_name=>'R_NG_PESSOA.ID'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select d, r from (',
'    select null d, null r, 0 ordem from dual',
'    union all',
'select ',
'    case    ',
'        when nome_abreviado is not null then',
'            nome_abreviado',
'        when nome_fantasia is not null then',
'            nome_fantasia || '' - '' || razao_social',
'    end d, a.id r, 1 ',
'from ng_pessoa a',
'left join ng_pessoa_fisica b on b.id_pessoa = a.id',
'left join ng_pessoa_juridica c on c.id_pessoa = a.id',
'where a.data_fim_vigencia is null ',
'or to_date(a.data_fim_vigencia) >= to_date(current_date))',
'order by 1'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>44887038710846
);
wwv_flow_imp.component_end;
end;
/
