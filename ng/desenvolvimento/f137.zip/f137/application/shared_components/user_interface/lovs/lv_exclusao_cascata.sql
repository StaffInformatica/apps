prompt --application/shared_components/user_interface/lovs/lv_exclusao_cascata
begin
--   Manifest
--     LV_EXCLUSAO_CASCATA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.16'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(284406136832019163)
,p_lov_name=>'LV_EXCLUSAO_CASCATA'
,p_lov_query=>'.'||wwv_flow_imp.id(284406136832019163)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(284406404681019178)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('N\00E3o permitir excluir')
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(284406852487019179)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Excluir o registro da tabela estrageira e o registro da tabela associada'
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(284407267987019179)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>unistr('Excluir o registro da tabela estrageira e manter registro da tabela associada (somente se a associa\00E7\00E3o n\00E3o for obrgat\00F3ria')
,p_lov_return_value=>'3'
);
wwv_flow_imp.component_end;
end;
/
