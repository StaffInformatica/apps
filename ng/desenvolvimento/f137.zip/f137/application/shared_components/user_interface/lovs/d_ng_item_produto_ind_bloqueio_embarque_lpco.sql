prompt --application/shared_components/user_interface/lovs/d_ng_item_produto_ind_bloqueio_embarque_lpco
begin
--   Manifest
--     D_NG_ITEM_PRODUTO.IND_BLOQUEIO_EMBARQUE_LPCO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(4535792309172467)
,p_lov_name=>'D_NG_ITEM_PRODUTO.IND_BLOQUEIO_EMBARQUE_LPCO'
,p_static_id=>'d-ng-item-produto-ind-bloqueio-embarque-lpco'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from pkg_util.dominio_retorna_lista(''ng_item_produto'', ''ind_bloqueio_embarque_ate_deferimento_li'') order by 1',
'',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'46489064231442'
);
wwv_flow_imp.component_end;
end;
/
