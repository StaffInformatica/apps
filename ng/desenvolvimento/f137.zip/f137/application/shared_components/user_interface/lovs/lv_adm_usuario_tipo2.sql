prompt --application/shared_components/user_interface/lovs/lv_adm_usuario_tipo2
begin
--   Manifest
--     LV_ADM_USUARIO_TIPO2
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(254178159073146828)
,p_lov_name=>'LV_ADM_USUARIO_TIPO2'
,p_static_id=>'lv-adm-usuario-tipo'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select 1 as value, ''Administrador'' as Descricao, ''Acesso ilimitado aos recursos do sistema'' as Complemento from dual ',
'union ',
unistr('Select 2 as value, ''Usu\00E1rio final'' as Descricao, ''Considera as atribui\00E7\00F5es do controle de acesso'' as Complemento from dual')))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'VALUE'
,p_display_column_name=>'DESCRICAO'
,p_default_sort_column_name=>'DESCRICAO'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'1'
);
wwv_flow_imp.component_end;
end;
/
