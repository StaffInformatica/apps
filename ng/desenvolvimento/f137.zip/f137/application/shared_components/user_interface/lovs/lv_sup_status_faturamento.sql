prompt --application/shared_components/user_interface/lovs/lv_sup_status_faturamento
begin
--   Manifest
--     LV_SUP_STATUS_FATURAMENTO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.16'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(362133120530286955)
,p_lov_name=>'LV_SUP_STATUS_FATURAMENTO'
,p_lov_query=>'.'||wwv_flow_imp.id(362133120530286955)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(362133416371286975)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('Boleto n\00E3o emitido')
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(362133826637286976)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Boleto emitido'
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(362134191624286976)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Faturado'
,p_lov_return_value=>'3'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(362134599153286977)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Atrasado'
,p_lov_return_value=>'4'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(362135038920286977)
,p_lov_disp_sequence=>5
,p_lov_disp_value=>unistr('Em negocia\00E7\00E3o')
,p_lov_return_value=>'5'
);
wwv_flow_imp.component_end;
end;
/
