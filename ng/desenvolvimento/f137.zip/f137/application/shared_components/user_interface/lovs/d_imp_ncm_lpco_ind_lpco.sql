prompt --application/shared_components/user_interface/lovs/d_imp_ncm_lpco_ind_lpco
begin
--   Manifest
--     D_IMP_NCM_LPCO.IND_LPCO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(155982322255004225)
,p_lov_name=>'D_IMP_NCM_LPCO.IND_LPCO'
,p_static_id=>'d-imp-ncm-lpco-ind-lpco'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Sim'' d, ''S'' r from dual',
'union all',
unistr('select ''N\00E3o'' d, ''N'' r from dual')))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'45512072596178'
);
wwv_flow_imp.component_end;
end;
/
