prompt --application/shared_components/user_interface/lovs/r_imp_processoimportacao_numerario_despesa_id_despesa
begin
--   Manifest
--     R_IMP_PROCESSOIMPORTACAO_NUMERARIO_DESPESA.ID_DESPESA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(59393700749346626)
,p_lov_name=>'R_IMP_PROCESSOIMPORTACAO_NUMERARIO_DESPESA.ID_DESPESA'
,p_static_id=>'r-imp-processoimportacao-numerario-despesa-id-despesa'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    pkg_traducao.get_traducao(a.descricao_despesa) d,',
'    c.id as r',
'from ng_despesa a',
'join imp_processoimportacao_despesa c on c.id_despesa = a.id',
'where (',
'    data_fim_vigencia is null',
'        or to_date(to_char(a.data_fim_vigencia, ''dd/mm/yyyy''), ''dd/mm/yyyy'') >= to_date(to_char(current_date, ''dd/mm/yyyy''), ''dd/mm/yyyy'')',
'    )',
'order by 1'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'46326129160272'
);
wwv_flow_imp.component_end;
end;
/
