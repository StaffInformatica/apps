prompt --application/shared_components/user_interface/lovs/r_ng_listapreco_id_exportador
begin
--   Manifest
--     R_NG_LISTAPRECO.ID_EXPORTADOR
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(191920968561973536)
,p_lov_name=>'R_NG_LISTAPRECO.ID_EXPORTADOR'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.nome_fantasia || '' - ''|| a.razao_social as d,',
'    b.id as r',
'from ng_pessoa_juridica a',
'join ng_pessoa b on b.id = a.id_pessoa',
'where '':'' || a.ind_perfil || '':'' like ''%:E:%''',
'order by 1'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>44956222375834
);
wwv_flow_imp.component_end;
end;
/
