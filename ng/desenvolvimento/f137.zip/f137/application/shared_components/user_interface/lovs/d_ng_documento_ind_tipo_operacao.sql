prompt --application/shared_components/user_interface/lovs/d_ng_documento_ind_tipo_operacao
begin
--   Manifest
--     D_NG_DOCUMENTO.IND_TIPO_OPERACAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.16'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(188894486279456211)
,p_lov_name=>'D_NG_DOCUMENTO.IND_TIPO_OPERACAO'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''ng_documento'', ''ind_tipo_operacao'') order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>44836007388881
);
wwv_flow_imp.component_end;
end;
/
