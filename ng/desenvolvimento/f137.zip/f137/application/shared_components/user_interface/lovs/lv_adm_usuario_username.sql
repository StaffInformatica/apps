prompt --application/shared_components/user_interface/lovs/lv_adm_usuario_username
begin
--   Manifest
--     LV_ADM_USUARIO_USERNAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(360062509195398240)
,p_lov_name=>'LV_ADM_USUARIO_USERNAME'
,p_static_id=>'lv-adm-usuario-username'
,p_lov_query=>'select USERNAME AS ID, NOME from ADM_USUARIO'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_table=>'ADM_USUARIO'
,p_return_column_name=>'ID'
,p_display_column_name=>'NOME'
,p_default_sort_column_name=>'NOME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'1'
);
wwv_flow_imp.component_end;
end;
/
