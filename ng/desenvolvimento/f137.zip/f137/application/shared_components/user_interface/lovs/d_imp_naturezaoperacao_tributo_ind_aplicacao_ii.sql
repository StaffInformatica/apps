prompt --application/shared_components/user_interface/lovs/d_imp_naturezaoperacao_tributo_ind_aplicacao_ii
begin
--   Manifest
--     D_IMP_NATUREZAOPERACAO_TRIBUTO.IND_APLICACAO_II
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(15079337754340171)
,p_lov_name=>'D_IMP_NATUREZAOPERACAO_TRIBUTO.IND_APLICACAO_II'
,p_static_id=>'d-imp-naturezaoperacao-tributo-ind-aplicacao-ii'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''imp_naturezaoperacao_tributo'',''ind_aplicacao_ii'') order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'45384194810504'
);
wwv_flow_imp.component_end;
end;
/
