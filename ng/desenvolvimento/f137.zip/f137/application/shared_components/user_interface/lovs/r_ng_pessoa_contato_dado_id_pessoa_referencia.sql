prompt --application/shared_components/user_interface/lovs/r_ng_pessoa_contato_dado_id_pessoa_referencia
begin
--   Manifest
--     R_NG_PESSOA_CONTATO_DADO.ID_PESSOA_REFERENCIA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(183057864852182135)
,p_lov_name=>'R_NG_PESSOA_CONTATO_DADO.ID_PESSOA_REFERENCIA'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    bo_ng_pessoa.retorna_pessoa(a.id) as display_value, ',
'    a.id as return_value ',
'from ng_pessoa a ',
'left join ng_pessoa_fisica b on b.id_pessoa = a.id',
'left join ng_pessoa_juridica c on c.id_pessoa = a.id',
'where b.id = :P9010_PARAMETRO',
'or c.id_pessoa = :P9010_PARAMETRO2'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'RETURN_VALUE'
,p_display_column_name=>'DISPLAY_VALUE'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>44989143559721
);
wwv_flow_imp.component_end;
end;
/
