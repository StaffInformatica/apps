prompt --application/shared_components/user_interface/lovs/lv_sup_responsavel
begin
--   Manifest
--     LV_SUP_RESPONSAVEL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(355325082452400818)
,p_lov_name=>'LV_SUP_RESPONSAVEL'
,p_lov_query=>'.'||wwv_flow_imp.id(355325082452400818)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(355325374277400819)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Meus chamados'
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(355325722456400819)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('Analista respons\00E1vel')
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(355326141142400819)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>unistr('Atendente respons\00E1vel ')
,p_lov_return_value=>'3'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(356046317680800683)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Outros chamados'
,p_lov_return_value=>'4'
);
wwv_flow_imp.component_end;
end;
/
