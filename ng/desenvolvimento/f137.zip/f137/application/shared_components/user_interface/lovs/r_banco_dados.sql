prompt --application/shared_components/user_interface/lovs/r_banco_dados
begin
--   Manifest
--     R_BANCO_DADOS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(49247756005605334)
,p_lov_name=>'R_BANCO_DADOS'
,p_static_id=>'r-banco-dados'
,p_lov_query=>'select USERNAME AS ID, USERNAME AS DESCRICAO from all_users where username like ''WKSP_%'';'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'ID'
,p_display_column_name=>'DESCRICAO'
,p_default_sort_column_name=>'DESCRICAO'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'42124598457991'
);
wwv_flow_imp.component_end;
end;
/
