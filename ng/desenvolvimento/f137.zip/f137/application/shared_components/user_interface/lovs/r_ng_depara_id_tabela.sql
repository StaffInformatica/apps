prompt --application/shared_components/user_interface/lovs/r_ng_depara_id_tabela
begin
--   Manifest
--     R_NG_DEPARA.ID_TABELA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(192956948994706346)
,p_lov_name=>'R_NG_DEPARA.ID_TABELA'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    e.nome_leitura d, ',
'    e.id r',
'from srv_entidade e',
'where lower(permite_de_para) = ''s''',
'order by e.nome_leitura'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>44870796579041
);
wwv_flow_imp.component_end;
end;
/
