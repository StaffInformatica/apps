prompt --application/shared_components/user_interface/lovs/r_ng_pessoa_juridica_id_pessoa
begin
--   Manifest
--     R_NG_PESSOA_JURIDICA.ID_PESSOA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(194113415283471478)
,p_lov_name=>'R_NG_PESSOA_JURIDICA.ID_PESSOA'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    b.nome_fantasia d,',
'    a.id r ',
'from ng_pessoa a',
'join ng_pessoa_juridica b on b.id_pessoa = a.id',
'where a.data_fim_vigencia is null',
'or to_date(a.data_fim_vigencia) >= to_date(current_date)',
'order by 1'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>44716291962583
);
wwv_flow_imp.component_end;
end;
/
