prompt --application/shared_components/user_interface/lovs/d_srv_aplicacao_mensagem_tipo_mensagem
begin
--   Manifest
--     D_SRV_APLICACAO_MENSAGEM.TIPO_MENSAGEM
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(193173176719111592)
,p_lov_name=>'D_SRV_APLICACAO_MENSAGEM.TIPO_MENSAGEM'
,p_static_id=>'d-srv-aplicacao-mensagem-tipo-mensagem'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''srv_aplicacao_mensagem'',''tipo_mensagem'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'42119743588391'
);
wwv_flow_imp.component_end;
end;
/
