prompt --application/shared_components/user_interface/lovs/lv_sup_funcionario
begin
--   Manifest
--     LV_SUP_FUNCIONARIO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(344802921148038626)
,p_lov_name=>'LV_SUP_FUNCIONARIO'
,p_static_id=>'lv-sup-funcionario'
,p_lov_query=>'SELECT ID, NOME||'' ''||SOBRENOME||'' (''||USERNAME||'')'' AS FUNCIONARIO FROM ADM_USUARIO '
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'ID'
,p_display_column_name=>'FUNCIONARIO'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'1'
);
wwv_flow_imp.component_end;
end;
/
