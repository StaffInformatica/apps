prompt --application/shared_components/user_interface/lovs/d_srv_contrato_empresa_ind_tipo_inscricao_federal
begin
--   Manifest
--     D_SRV_CONTRATO_EMPRESA.IND_TIPO_INSCRICAO_FEDERAL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(104187160362427717)
,p_lov_name=>'D_SRV_CONTRATO_EMPRESA.IND_TIPO_INSCRICAO_FEDERAL'
,p_static_id=>'d-srv-contrato-empresa-ind-tipo-inscricao-federal'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''srv_contrato_empresa'',''ind_tipo_inscricao_federal'') order by to_number(r)'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>'SH256:rlBB7HLL-79DN_M1GRh9BOesGP4a0fUy9RPKcwloyeA'
);
wwv_flow_imp.component_end;
end;
/
