prompt --application/shared_components/user_interface/lovs/d_ng_viatransporte_descricao_viatransporte_sem_nulo
begin
--   Manifest
--     D_NG_VIATRANSPORTE.DESCRICAO_VIATRANSPORTE_-_SEM_NULO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(46515433238374447)
,p_lov_name=>'D_NG_VIATRANSPORTE.DESCRICAO_VIATRANSPORTE_-_SEM_NULO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    t.d as d,',
'    a.id as r',
'from ng_viatransporte a',
'join table(pkg_util.dominio_retorna_lista(''ng_viatransporte'', ''descricao_viatransporte'')) t',
'       on t.r = to_number(a.descricao_viatransporte)',
'order by d'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>45892868591266
);
wwv_flow_imp.component_end;
end;
/
