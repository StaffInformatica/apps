prompt --application/shared_components/user_interface/lovs/d_imp_processoimportacao_numerario_ind_status_2_ou_3
begin
--   Manifest
--     D_IMP_PROCESSOIMPORTACAO_NUMERARIO.IND_STATUS_2_OU_3
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(200808968671470757)
,p_lov_name=>'D_IMP_PROCESSOIMPORTACAO_NUMERARIO.IND_STATUS_2_OU_3'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''IMP_PROCESSOIMPORTACAO_NUMERARIO'',''ind_status'') where r in (2,3) order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>46266075159081
);
wwv_flow_imp.component_end;
end;
/
