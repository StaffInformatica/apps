prompt --application/shared_components/user_interface/lovs/lv_evento
begin
--   Manifest
--     LV_EVENTO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(430970765082714427)
,p_lov_name=>'LV_EVENTO'
,p_static_id=>'lv-evento'
,p_lov_query=>'.'||wwv_flow_imp.id(430970765082714427)||'.'
,p_location=>'STATIC'
,p_version_scn=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(430971074962714427)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Incluir'
,p_lov_return_value=>'1'
,p_static_id=>'lov_data'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(430971473988714427)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Alterar'
,p_lov_return_value=>'2'
,p_static_id=>'lov_data-2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(430971841551714428)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Excluir'
,p_lov_return_value=>'3'
,p_static_id=>'lov_data-3'
);
wwv_flow_imp.component_end;
end;
/
