prompt --application/shared_components/user_interface/lovs/d_ng_pessoa_juridica_atributo_ind_exportador
begin
--   Manifest
--     D_NG_PESSOA_JURIDICA_ATRIBUTO.IND_EXPORTADOR
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(48796955289199962)
,p_lov_name=>'D_NG_PESSOA_JURIDICA_ATRIBUTO.IND_EXPORTADOR'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''ng_pessoa_juridica_atributo'',''ind_exportador'') order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>44712538794957
);
wwv_flow_imp.component_end;
end;
/
