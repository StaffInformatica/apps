prompt --application/shared_components/user_interface/lovs/d_ng_documento_nome_documento_ind_referencia_documento_14
begin
--   Manifest
--     D_NG_DOCUMENTO.NOME_DOCUMENTO_IND_REFERENCIA_DOCUMENTO_14
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(132217277777044127)
,p_lov_name=>'D_NG_DOCUMENTO.NOME_DOCUMENTO_IND_REFERENCIA_DOCUMENTO_14'
,p_static_id=>'d-ng-documento-nome-documento-ind-referencia-documento-14'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.nome_documento, a.id',
'from ng_documento a ',
'where (a.data_fim_vigencia is null or to_date(a.data_fim_vigencia) >= to_date(current_date))',
'and a.ind_referencia_documento = 14 order by 1'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'ID'
,p_display_column_name=>'NOME_DOCUMENTO'
,p_version_scn=>'SH256:BxxcriooH6b0gHjKewRJ_JDT3cmZIsYPf22GwU1L-qk'
,p_created_on=>wwv_flow_imp.dz('20260915114109Z')
,p_updated_on=>wwv_flow_imp.dz('20260915114610Z')
,p_created_by=>'DEVJONATHAN'
,p_updated_by=>'DEVJONATHAN'
);
wwv_flow_imp.component_end;
end;
/
