prompt --application/shared_components/user_interface/lovs/lv_compartilhamento
begin
--   Manifest
--     LV_COMPARTILHAMENTO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(284208810447535562)
,p_lov_name=>'LV_COMPARTILHAMENTO'
,p_lov_query=>'.'||wwv_flow_imp.id(284208810447535562)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(284209181304535571)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Uso do sistema'
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(284209521166535572)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Uso global'
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(284209979170535572)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Privativo da empresa'
,p_lov_return_value=>'3'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(284210367303535573)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>unistr('Comum ao grupo econ\00F4mico')
,p_lov_return_value=>'4'
);
wwv_flow_imp.component_end;
end;
/
