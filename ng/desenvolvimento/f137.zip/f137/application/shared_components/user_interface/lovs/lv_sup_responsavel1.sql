prompt --application/shared_components/user_interface/lovs/lv_sup_responsavel1
begin
--   Manifest
--     LV_SUP_RESPONSAVEL1
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(501076036395428877)
,p_lov_name=>'LV_SUP_RESPONSAVEL1'
,p_static_id=>'lv-sup-responsavel-2'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT A.ID, ',
'       CASE WHEN A.ID IN (SELECT DISTINCT A.ID FROM ADM_CHAMADO A ',
'                              JOIN ADM_CHAMADO_ENVOLVIDOS B ON B.ID_CHAMADO = A.ID',
'                              JOIN ADM_USUARIO C ON C.ID = B.ID_USUARIO ',
'                              WHERE UPPER(C.USERNAME) = UPPER(V(''APP_USER''))) THEN',
'          ''Meus chamados'' ',
'          WHEN A.ID IN (SELECT DISTINCT A.ID FROM ADM_CHAMADO A ',
'                        JOIN ADM_USUARIO B ON B.ID = A.ID_ANALISTA ',
'                        WHERE UPPER(B.USERNAME) = UPPER(V(''APP_USER''))) THEN',
unistr('          ''Analista respons\00E1vel'''),
'          WHEN A.ID IN (SELECT DISTINCT A.ID FROM ADM_CHAMADO A ',
'                        JOIN ADM_USUARIO B ON B.ID = A.ID_ATENDENTE ',
'                        WHERE UPPER(B.USERNAME) = UPPER(V(''APP_USER''))) THEN',
unistr('          ''Atendente respons\00E1vel'''),
'          ELSE ''''',
'       END AS MCHAMADO ',
'FROM ADM_CHAMADO A'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'ID'
,p_display_column_name=>'MCHAMADO'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'1'
);
wwv_flow_imp.component_end;
end;
/
