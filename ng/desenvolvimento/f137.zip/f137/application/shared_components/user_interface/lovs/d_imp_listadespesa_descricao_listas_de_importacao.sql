prompt --application/shared_components/user_interface/lovs/d_imp_listadespesa_descricao_listas_de_importacao
begin
--   Manifest
--     D_IMP_LISTADESPESA.DESCRICAO_(LISTAS_DE_IMPORTACAO)
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(169340261249477490)
,p_lov_name=>'D_IMP_LISTADESPESA.DESCRICAO_(LISTAS_DE_IMPORTACAO)'
,p_static_id=>'d-imp-listadespesa-descricao-listas-de-importacao'
,p_lov_query=>'select descricao as d, id as r from imp_listadespesa where ind_origem_despesa = 2'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'45821273260449'
);
wwv_flow_imp.component_end;
end;
/
