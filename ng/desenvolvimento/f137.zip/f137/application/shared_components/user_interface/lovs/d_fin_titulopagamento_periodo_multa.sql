prompt --application/shared_components/user_interface/lovs/d_fin_titulopagamento_periodo_multa
begin
--   Manifest
--     D_FIN_TITULOPAGAMENTO.PERIODO_MULTA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(36396986905257137)
,p_lov_name=>'D_FIN_TITULOPAGAMENTO.PERIODO_MULTA'
,p_static_id=>'d-fin-titulopagamento-periodo-multa'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''fin_titulopagamento'',''periodo_multa'') order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>'45909240148037'
);
wwv_flow_imp.component_end;
end;
/
