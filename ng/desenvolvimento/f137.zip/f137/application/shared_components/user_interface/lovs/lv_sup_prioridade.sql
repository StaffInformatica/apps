prompt --application/shared_components/user_interface/lovs/lv_sup_prioridade
begin
--   Manifest
--     LV_SUP_PRIORIDADE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(487617075423635670)
,p_lov_name=>'LV_SUP_PRIORIDADE'
,p_static_id=>'lv-sup-prioridade'
,p_lov_query=>'SELECT ID, NOME FROM ADM_CHAMADO_PRIORIDADE'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'ID'
,p_display_column_name=>'NOME'
,p_default_sort_column_name=>'ID'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'1'
);
wwv_flow_imp.component_end;
end;
/
