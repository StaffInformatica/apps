prompt --application/shared_components/user_interface/lovs/r_codigo_idioma_apex
begin
--   Manifest
--     R_CODIGO_IDIOMA_APEX
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.16'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(18254521507856517)
,p_lov_name=>'R_CODIGO_IDIOMA_APEX'
,p_lov_query=>'select language_id || '' (''||language_label||'')'' d, language_id r from apex_dg_builtin_languages order by language_label'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>44869008689359
);
wwv_flow_imp.component_end;
end;
/
