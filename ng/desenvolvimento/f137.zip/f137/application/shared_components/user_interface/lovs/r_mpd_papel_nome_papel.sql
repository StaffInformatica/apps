prompt --application/shared_components/user_interface/lovs/r_mpd_papel_nome_papel
begin
--   Manifest
--     R_MPD_PAPEL.NOME_PAPEL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(303173780680865074)
,p_lov_name=>'R_MPD_PAPEL.NOME_PAPEL'
,p_static_id=>'r-mpd-papel-nome-papel'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_table=>'MPD_PAPEL'
,p_return_column_name=>'ID'
,p_display_column_name=>'NOME_PAPEL'
,p_default_sort_column_name=>'NOME_PAPEL'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'41742047830766'
);
wwv_flow_imp.component_end;
end;
/
