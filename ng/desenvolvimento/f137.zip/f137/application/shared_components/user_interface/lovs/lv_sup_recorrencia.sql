prompt --application/shared_components/user_interface/lovs/lv_sup_recorrencia
begin
--   Manifest
--     LV_SUP_RECORRENCIA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(529897356643247038)
,p_lov_name=>'LV_SUP_RECORRENCIA'
,p_static_id=>'lv-sup-recorrencia'
,p_lov_query=>'.'||wwv_flow_imp.id(529897356643247038)||'.'
,p_location=>'STATIC'
,p_version_scn=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(529897767095247039)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('Esse problema ocorreu uma \00FAnica vez')
,p_lov_return_value=>'1'
,p_static_id=>'lov_data'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(529898101338247039)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('Esse problema \00E9 reincidente')
,p_lov_return_value=>'2'
,p_static_id=>'lov_data-2'
);
wwv_flow_imp.component_end;
end;
/
