prompt --application/shared_components/user_interface/lovs/d_imp_processoimportacao_numerario_detalhar_despesas
begin
--   Manifest
--     D_IMP_PROCESSOIMPORTACAO_NUMERARIO.DETALHAR_DESPESAS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(131548376126749929)
,p_lov_name=>'D_IMP_PROCESSOIMPORTACAO_NUMERARIO.DETALHAR_DESPESAS'
,p_static_id=>'d-imp-processoimportacao-numerario-detalhar-despesas'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select c.valor r, pkg_ui.retorna_dominio(c.id_dominio, c.valor) d',
'from mpd_dominio_valor c',
'where c.id_dominio = (select d.id from srv_dominio d where lower(d.nome) = lower(''imp_processoimportacao_numerario.detalhar_despesas''))'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'SH256:HQ8brUN-e_gBe9jIcQlMxrzi4Qot4c7D1mev2KfG-yA'
,p_created_on=>wwv_flow_imp.dz('20260917114331Z')
,p_updated_on=>wwv_flow_imp.dz('20260917115812Z')
,p_created_by=>'DEVJONATHAN'
,p_updated_by=>'DEVJONATHAN'
);
wwv_flow_imp.component_end;
end;
/
