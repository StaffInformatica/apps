prompt --application/shared_components/user_interface/lovs/d_ng_anexo_ind_situacao
begin
--   Manifest
--     D_NG_ANEXO.IND_SITUACAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(160012159965055906)
,p_lov_name=>'D_NG_ANEXO.IND_SITUACAO'
,p_static_id=>'d-ng-anexo-ind-situacao'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''ng_anexo'',''ind_situacao'') order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'45705772183926'
);
wwv_flow_imp.component_end;
end;
/
