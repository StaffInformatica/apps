prompt --application/shared_components/user_interface/lovs/r_ng_feriado_nome_feriado_id_pais
begin
--   Manifest
--     R_NG_FERIADO.NOME_FERIADO-ID_PAIS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(187115998116116320)
,p_lov_name=>'R_NG_FERIADO.NOME_FERIADO-ID_PAIS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select d, r from (',
'    select null d, null r, 0 ordem from dual',
'    union all',
'select ',
'    pkg_traducao.get_traducao(a.nome_feriado) || '' - '' || b.codigo_iso, ',
'    a.id, 1 ',
'from ng_feriado a ',
'join ng_pais b on b.id = a.id_pais)',
'order by ordem, d'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>46037634584623
);
wwv_flow_imp.component_end;
end;
/
