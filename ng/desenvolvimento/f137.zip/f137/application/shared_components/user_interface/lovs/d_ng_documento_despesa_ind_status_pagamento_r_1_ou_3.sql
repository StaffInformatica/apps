prompt --application/shared_components/user_interface/lovs/d_ng_documento_despesa_ind_status_pagamento_r_1_ou_3
begin
--   Manifest
--     D_NG_DOCUMENTO_DESPESA.IND_STATUS_PAGAMENTO_R_1_OU_3
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(227756041279360963)
,p_lov_name=>'D_NG_DOCUMENTO_DESPESA.IND_STATUS_PAGAMENTO_R_1_OU_3'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''ng_documento_despesa'',''ind_status_pagamento'') where r in (''1'',''3'') '
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>47289251089049
);
wwv_flow_imp.component_end;
end;
/
