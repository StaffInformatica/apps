prompt --application/shared_components/user_interface/lovs/r_ng_item_codigo_item
begin
--   Manifest
--     R_NG_ITEM.CODIGO_ITEM
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(41408565171290334)
,p_lov_name=>'R_NG_ITEM.CODIGO_ITEM'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.codigo_item as d,',
'    a.id as r',
'from ng_item a ',
'where a.data_fim_vigencia is null ',
'or to_date(a.data_fim_vigencia) >= to_date(current_date)',
'order by 1'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>44970825996442
);
wwv_flow_imp.component_end;
end;
/
