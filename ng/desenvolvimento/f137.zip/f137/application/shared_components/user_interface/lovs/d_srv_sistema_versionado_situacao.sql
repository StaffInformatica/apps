prompt --application/shared_components/user_interface/lovs/d_srv_sistema_versionado_situacao
begin
--   Manifest
--     D_SRV_SISTEMA_VERSIONADO.SITUACAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(298297219158518107)
,p_lov_name=>'D_SRV_SISTEMA_VERSIONADO.SITUACAO'
,p_static_id=>'d-srv-sistema-versionado-situacao'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''srv_sistema_versionado'',''situacao'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'50487053529364'
,p_created_on=>wwv_flow_imp.dz('20260904111007Z')
,p_updated_on=>wwv_flow_imp.dz('20260904111007Z')
,p_created_by=>'DEVNORTHONN'
,p_updated_by=>'DEVNORTHONN'
);
wwv_flow_imp.component_end;
end;
/
