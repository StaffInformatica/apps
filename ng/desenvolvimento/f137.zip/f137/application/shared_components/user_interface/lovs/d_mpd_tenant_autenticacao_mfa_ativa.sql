prompt --application/shared_components/user_interface/lovs/d_mpd_tenant_autenticacao_mfa_ativa
begin
--   Manifest
--     D_MPD_TENANT.AUTENTICACAO_MFA_ATIVA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(228653760507076673)
,p_lov_name=>'D_MPD_TENANT.AUTENTICACAO_MFA_ATIVA'
,p_static_id=>'d-mpd-tenant-autenticacao-mfa-ativa'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''mpd_tenant'',''autenticacao_mfa_ativa'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'41985122600415'
);
wwv_flow_imp.component_end;
end;
/
