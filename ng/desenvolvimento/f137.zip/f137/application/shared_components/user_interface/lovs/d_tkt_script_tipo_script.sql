prompt --application/shared_components/user_interface/lovs/d_tkt_script_tipo_script
begin
--   Manifest
--     D_TKT_SCRIPT.TIPO_SCRIPT
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(288529439499907264)
,p_lov_name=>'D_TKT_SCRIPT.TIPO_SCRIPT'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''tkt_script'',''tipo_script'') order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>50342380505877
);
wwv_flow_imp.component_end;
end;
/
