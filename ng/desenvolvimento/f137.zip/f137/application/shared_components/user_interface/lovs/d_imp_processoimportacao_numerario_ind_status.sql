prompt --application/shared_components/user_interface/lovs/d_imp_processoimportacao_numerario_ind_status
begin
--   Manifest
--     D_IMP_PROCESSOIMPORTACAO_NUMERARIO.IND_STATUS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(53697747758951977)
,p_lov_name=>'D_IMP_PROCESSOIMPORTACAO_NUMERARIO.IND_STATUS'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''IMP_PROCESSOIMPORTACAO_NUMERARIO'',''ind_status'') order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>46311709570142
);
wwv_flow_imp.component_end;
end;
/
