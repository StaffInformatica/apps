prompt --application/shared_components/user_interface/lovs/r_imp_pedidoimportacao_numero_pedido_importacao
begin
--   Manifest
--     R_IMP_PEDIDOIMPORTACAO.NUMERO_PEDIDO_IMPORTACAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(226927478788840158)
,p_lov_name=>'R_IMP_PEDIDOIMPORTACAO.NUMERO_PEDIDO_IMPORTACAO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    numero_pedido_importacao d, a.id r',
'from imp_pedidoimportacao a ',
'order by d'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>47280711669875
);
wwv_flow_imp.component_end;
end;
/
