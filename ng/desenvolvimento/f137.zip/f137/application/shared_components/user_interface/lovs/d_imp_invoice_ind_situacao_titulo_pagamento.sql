prompt --application/shared_components/user_interface/lovs/d_imp_invoice_ind_situacao_titulo_pagamento
begin
--   Manifest
--     D_IMP_INVOICE.IND_SITUACAO_TITULO_PAGAMENTO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(30422172715676735)
,p_lov_name=>'D_IMP_INVOICE.IND_SITUACAO_TITULO_PAGAMENTO'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''imp_invoice'',''ind_situacao_titulo_pagamento'') order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>45858730382975
);
wwv_flow_imp.component_end;
end;
/
