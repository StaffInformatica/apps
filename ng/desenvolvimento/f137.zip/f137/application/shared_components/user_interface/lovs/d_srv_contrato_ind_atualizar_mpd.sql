prompt --application/shared_components/user_interface/lovs/d_srv_contrato_ind_atualizar_mpd
begin
--   Manifest
--     D_SRV_CONTRATO.IND_ATUALIZAR_MPD
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(118362560136106344)
,p_lov_name=>'D_SRV_CONTRATO.IND_ATUALIZAR_MPD'
,p_static_id=>'d-srv-contrato-ind-atualizar-mpd'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''srv_contrato'',''ind_atualizar_mpd'') order by r desc'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>'SH256:svy1JkDe_1WLjbB3iGW2Q40GC6-DhmVjW6cXxKQg414'
);
wwv_flow_imp.component_end;
end;
/
