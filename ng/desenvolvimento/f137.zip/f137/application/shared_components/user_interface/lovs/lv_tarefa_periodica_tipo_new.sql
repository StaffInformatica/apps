prompt --application/shared_components/user_interface/lovs/lv_tarefa_periodica_tipo_new
begin
--   Manifest
--     LV_TAREFA_PERIODICA_TIPO_NEW
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(501920085429801056)
,p_lov_name=>'LV_TAREFA_PERIODICA_TIPO_NEW'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'ADM_FUNCAO_PERIODICA'
,p_return_column_name=>'ID'
,p_display_column_name=>'NOME'
,p_default_sort_column_name=>'NOME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
