prompt --application/shared_components/user_interface/lovs/r_mpd_tenant_nome_fantasia
begin
--   Manifest
--     R_MPD_TENANT.NOME_FANTASIA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(168528895013908813)
,p_lov_name=>'R_MPD_TENANT.NOME_FANTASIA'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'MPD_TENANT'
,p_return_column_name=>'ID'
,p_display_column_name=>'NOME_FANTASIA'
,p_default_sort_column_name=>'NOME_FANTASIA'
,p_default_sort_direction=>'ASC'
,p_version_scn=>44344941167947
);
wwv_flow_imp.component_end;
end;
/
