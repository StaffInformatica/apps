prompt --application/shared_components/user_interface/lovs/lv_all_scheduler_programs
begin
--   Manifest
--     LV_ALL_SCHEDULER_PROGRAMS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(357658348860314832)
,p_lov_name=>'LV_ALL_SCHEDULER_PROGRAMS'
,p_lov_query=>'Select PROGRAM_NAME, COMMENTS from ALL_SCHEDULER_PROGRAMS'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'PROGRAM_NAME'
,p_display_column_name=>'COMMENTS'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
