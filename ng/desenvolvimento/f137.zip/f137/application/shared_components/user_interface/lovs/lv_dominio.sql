prompt --application/shared_components/user_interface/lovs/lv_dominio
begin
--   Manifest
--     LV_DOMINIO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(284257225378802539)
,p_lov_name=>'LV_DOMINIO'
,p_static_id=>'lv-dominio'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'METADATA_DOMINIO'
,p_return_column_name=>'ID'
,p_display_column_name=>'NOME'
,p_default_sort_column_name=>'NOME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'1'
);
wwv_flow_imp.component_end;
end;
/
