prompt --application/shared_components/user_interface/lovs/aplicacao_apex_applications
begin
--   Manifest
--     APLICACAO_APEX_APPLICATIONS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(53781160971862590)
,p_lov_name=>'APLICACAO_APEX_APPLICATIONS'
,p_static_id=>'aplicacao-apex-applications'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''(''||application_id||'') ''||application_name as d, application_id as r',
'from apex_applications'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'D'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'R'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'42151104097977'
);
wwv_flow_imp.component_end;
end;
/
