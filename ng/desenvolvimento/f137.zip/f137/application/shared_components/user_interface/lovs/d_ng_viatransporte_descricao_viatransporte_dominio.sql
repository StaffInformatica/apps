prompt --application/shared_components/user_interface/lovs/d_ng_viatransporte_descricao_viatransporte_dominio
begin
--   Manifest
--     D_NG_VIATRANSPORTE.DESCRICAO_VIATRANSPORTE_(DOMINIO)
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(177167903734729127)
,p_lov_name=>'D_NG_VIATRANSPORTE.DESCRICAO_VIATRANSPORTE_(DOMINIO)'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''ng_viatransporte'',''descricao_viatransporte'') order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>45868076756906
);
wwv_flow_imp.component_end;
end;
/
