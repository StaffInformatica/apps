prompt --application/shared_components/user_interface/lovs/d_ng_viatransporte_icone_viatransporte
begin
--   Manifest
--     D_NG_VIATRANSPORTE.ICONE_VIATRANSPORTE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.16'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(352226008132815)
,p_lov_name=>'D_NG_VIATRANSPORTE.ICONE_VIATRANSPORTE'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    ''<i class=''''fa '' || d || ''''''></i>'' AS D,',
'    r AS R',
'FROM pkg_util.dominio_retorna_lista(''ng_viatransporte'', ''icone_viatransporte'')',
'ORDER BY r',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>45532807370357
);
wwv_flow_imp.component_end;
end;
/
