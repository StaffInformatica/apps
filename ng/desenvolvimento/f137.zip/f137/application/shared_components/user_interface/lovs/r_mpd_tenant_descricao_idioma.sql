prompt --application/shared_components/user_interface/lovs/r_mpd_tenant_descricao_idioma
begin
--   Manifest
--     R_MPD_TENANT.DESCRICAO_IDIOMA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(42253440162886204)
,p_lov_name=>'R_MPD_TENANT.DESCRICAO_IDIOMA'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    pkg_traducao.get_traducao(b.descricao_idioma) d,',
'    a.id r',
'from mpd_tenant a',
'left join srv_idioma b on b.id = a.id_idioma'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>46037555182733
);
wwv_flow_imp.component_end;
end;
/
