prompt --application/shared_components/user_interface/lovs/r_mpd_tenant_descricao_idioma
begin
--   Manifest
--     R_MPD_TENANT.DESCRICAO_IDIOMA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(187959841391674686)
,p_lov_name=>'R_MPD_TENANT.DESCRICAO_IDIOMA'
,p_static_id=>'r-mpd-tenant-descricao-idioma'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    pkg_traducao.get_traducao(b.descricao_idioma) d,',
'    a.id r',
'from mpd_tenant a',
'left join srv_idioma b on b.id = a.id_idioma'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'46037555182733'
);
wwv_flow_imp.component_end;
end;
/
