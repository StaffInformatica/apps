prompt --application/shared_components/user_interface/lovs/lv_srv_idioma
begin
--   Manifest
--     LV_SRV_IDIOMA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(323908124531729836)
,p_lov_name=>'LV_SRV_IDIOMA'
,p_static_id=>'lv-srv-idioma'
,p_lov_query=>'select * from SRV_IDIOMA'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_table=>'SRV_IDIOMA'
,p_query_where=>'ESTA_ATIVO = ''S'''
,p_return_column_name=>'ID'
,p_display_column_name=>'NOME'
,p_default_sort_column_name=>'NOME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'1'
);
wwv_flow_imp.component_end;
end;
/
