prompt --application/shared_components/user_interface/lovs/r_ng_incoterm_descricao_incoterm
begin
--   Manifest
--     R_NG_INCOTERM.DESCRICAO_INCOTERM
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(38701956932595486)
,p_lov_name=>'R_NG_INCOTERM.DESCRICAO_INCOTERM'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    pkg_traducao.get_traducao(a.descricao_incoterm) d, ',
'    a.id r ',
'from ng_incoterm a ',
'where a.data_fim_vigencia is null ',
'or to_date(a.data_fim_vigencia, ''dd/mm/yyyy'') >= to_date(current_date, ''dd/mm/yyyy'')',
'order by 1'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>46037645283050
);
wwv_flow_imp.component_end;
end;
/
