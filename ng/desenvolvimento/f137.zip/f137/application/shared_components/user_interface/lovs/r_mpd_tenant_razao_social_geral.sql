prompt --application/shared_components/user_interface/lovs/r_mpd_tenant_razao_social_geral
begin
--   Manifest
--     R_MPD_TENANT.RAZAO_SOCIAL(GERAL)
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(236915542106575271)
,p_lov_name=>'R_MPD_TENANT.RAZAO_SOCIAL(GERAL)'
,p_lov_query=>'select * from MPD_TENANT '
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'ID'
,p_display_column_name=>'RAZAO_SOCIAL'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'RAZAO_SOCIAL'
,p_default_sort_direction=>'ASC'
,p_version_scn=>41746634976702
);
wwv_flow_imp.component_end;
end;
/
