prompt --application/shared_components/user_interface/lovs/d_mae_sched_cfg_ind_sincronizar
begin
--   Manifest
--     D_MAE_SCHED_CFG.IND_SINCRONIZAR
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(146340875681821499)
,p_lov_name=>'D_MAE_SCHED_CFG.IND_SINCRONIZAR'
,p_static_id=>'d-mae-sched-cfg-ind-sincronizar'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''mae_sched_cfg'',''ind_sincronizar'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'50362806615379'
);
wwv_flow_imp.component_end;
end;
/
