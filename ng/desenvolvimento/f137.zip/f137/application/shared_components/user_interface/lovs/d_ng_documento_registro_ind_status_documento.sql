prompt --application/shared_components/user_interface/lovs/d_ng_documento_registro_ind_status_documento
begin
--   Manifest
--     D_NG_DOCUMENTO_REGISTRO.IND_STATUS_DOCUMENTO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(60572351182086458)
,p_lov_name=>'D_NG_DOCUMENTO_REGISTRO.IND_STATUS_DOCUMENTO'
,p_static_id=>'d-ng-documento-registro-ind-status-documento'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''ng_documento_registro'',''ind_status_documento'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'47120400274293'
,p_created_on=>wwv_flow_imp.dz('20260528160950Z')
,p_updated_on=>wwv_flow_imp.dz('20260528160950Z')
,p_created_by=>'DEVLEONARDO'
,p_updated_by=>'DEVLEONARDO'
);
wwv_flow_imp.component_end;
end;
/
