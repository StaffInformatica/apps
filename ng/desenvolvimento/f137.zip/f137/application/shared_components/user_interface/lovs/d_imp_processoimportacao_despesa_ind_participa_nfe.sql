prompt --application/shared_components/user_interface/lovs/d_imp_processoimportacao_despesa_ind_participa_nfe
begin
--   Manifest
--     D_IMP_PROCESSOIMPORTACAO_DESPESA.IND_PARTICIPA_NFE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(94778429636395566)
,p_lov_name=>'D_IMP_PROCESSOIMPORTACAO_DESPESA.IND_PARTICIPA_NFE'
,p_static_id=>'d-imp-processoimportacao-despesa-ind-participa-nfe'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''imp_processoimportacao_despesa'',''ind_participa_nfe'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'49874283058805'
);
wwv_flow_imp.component_end;
end;
/
