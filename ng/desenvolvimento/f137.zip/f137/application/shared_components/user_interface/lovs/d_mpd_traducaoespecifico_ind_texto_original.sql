prompt --application/shared_components/user_interface/lovs/d_mpd_traducaoespecifico_ind_texto_original
begin
--   Manifest
--     D_MPD_TRADUCAOESPECIFICO.IND_TEXTO_ORIGINAL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(48116099828585757)
,p_lov_name=>'D_MPD_TRADUCAOESPECIFICO.IND_TEXTO_ORIGINAL'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''mpd_traducaotextoespecifico'',''ind_texto_original'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>46142781492574
);
wwv_flow_imp.component_end;
end;
/
