prompt --application/shared_components/user_interface/lovs/d_imp_dashboard_importacao_configuracao_ind_alerta_processoimportacao
begin
--   Manifest
--     D_IMP_DASHBOARD_IMPORTACAO_CONFIGURACAO.IND_ALERTA_PROCESSOIMPORTACAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(124568024441463430)
,p_lov_name=>'D_IMP_DASHBOARD_IMPORTACAO_CONFIGURACAO.IND_ALERTA_PROCESSOIMPORTACAO'
,p_static_id=>'d-imp-dashboard-importacao-configuracao-ind-alerta-processoimportacao'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''imp_dashboard_importacao_configuracao'',''ind_alerta_processoimportacao'') order by d desc'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>'SH256:YD4dS2LsYji0HwWZYh92hOCYEKbsbK4pLXR2924Icfk'
);
wwv_flow_imp.component_end;
end;
/
