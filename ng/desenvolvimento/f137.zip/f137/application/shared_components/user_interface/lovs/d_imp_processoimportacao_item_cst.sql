prompt --application/shared_components/user_interface/lovs/d_imp_processoimportacao_item_cst
begin
--   Manifest
--     D_IMP_PROCESSOIMPORTACAO_ITEM.CST
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(240745599201307929)
,p_lov_name=>'D_IMP_PROCESSOIMPORTACAO_ITEM.CST'
,p_static_id=>'d-imp-processoimportacao-item-cst'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''imp_processoimportacao_item'',''cst'') order by to_number(r)'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>'49886312971541'
,p_created_on=>wwv_flow_imp.dz('20260703153335Z')
,p_updated_on=>wwv_flow_imp.dz('20260703153335Z')
,p_created_by=>'DEVLEONARDO'
,p_updated_by=>'DEVLEONARDO'
);
wwv_flow_imp.component_end;
end;
/
