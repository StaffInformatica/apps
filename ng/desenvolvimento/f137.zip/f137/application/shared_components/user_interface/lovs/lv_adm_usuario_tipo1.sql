prompt --application/shared_components/user_interface/lovs/lv_adm_usuario_tipo1
begin
--   Manifest
--     LV_ADM_USUARIO_TIPO1
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(468592317782138893)
,p_lov_name=>'LV_ADM_USUARIO_TIPO1'
,p_static_id=>'lv-adm-usuario-tipo-2'
,p_lov_query=>'.'||wwv_flow_imp.id(468592317782138893)||'.'
,p_location=>'STATIC'
,p_version_scn=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(468592721237138897)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Administrador'
,p_lov_return_value=>'ADMIN:CREATE:DATA_LOADER:EDIT:HELP:MONITOR:SQL'
,p_static_id=>'admin-create-data-loader-edit-help-monitor-sql'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(468593127825138898)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Desenvolvedor'
,p_lov_return_value=>'CREATE:DATA_LOADER:EDIT:HELP:MONITOR:SQL'
,p_static_id=>'create-data-loader-edit-help-monitor-sql'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(468593513508138898)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>unistr('Usu\00E1rio final')
,p_lov_return_value=>'NULL'
,p_static_id=>'null'
);
wwv_flow_imp.component_end;
end;
/
