prompt --application/shared_components/user_interface/lovs/lv_mpd_usuario_situacao_cadastral
begin
--   Manifest
--     LV_MPD_USUARIO_SITUACAO_CADASTRAL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.16'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(300968232308404074)
,p_lov_name=>'LV_MPD_USUARIO_SITUACAO_CADASTRAL'
,p_lov_query=>'.'||wwv_flow_imp.id(300968232308404074)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(300968537458404075)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Ativo'
,p_lov_return_value=>'S'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(300968973264404077)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Inativo'
,p_lov_return_value=>'N'
);
wwv_flow_imp.component_end;
end;
/
