prompt --application/shared_components/user_interface/lovs/lv_mpd_usuario_situacao_cadastral
begin
--   Manifest
--     LV_MPD_USUARIO_SITUACAO_CADASTRAL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(155261831079615592)
,p_lov_name=>'LV_MPD_USUARIO_SITUACAO_CADASTRAL'
,p_static_id=>'lv-mpd-usuario-situacao-cadastral'
,p_lov_query=>'.'||wwv_flow_imp.id(155261831079615592)||'.'
,p_location=>'STATIC'
,p_version_scn=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(155262572035615595)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Inativo'
,p_lov_return_value=>'N'
,p_static_id=>'n'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(155262136229615593)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Ativo'
,p_lov_return_value=>'S'
,p_static_id=>'s'
);
wwv_flow_imp.component_end;
end;
/
