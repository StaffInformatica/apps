prompt --application/shared_components/user_interface/lovs/lv_tipo_validacao
begin
--   Manifest
--     LV_TIPO_VALIDACAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.16'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(430151522141968238)
,p_lov_name=>'LV_TIPO_VALIDACAO'
,p_lov_query=>'.'||wwv_flow_imp.id(430151522141968238)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(430151810527968252)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('Chave prim\00E1ria')
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(430152208130968252)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('Valor obrigat\00F3rio')
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(430152633481968252)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>unistr('Valor \00FAnico')
,p_lov_return_value=>'3'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(430153059907968253)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>unistr('Verfica\00E7\00E3o de valores')
,p_lov_return_value=>'4'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(432098802504915130)
,p_lov_disp_sequence=>5
,p_lov_disp_value=>unistr('Verfica\00E7\00E3o de exclus\00E3o')
,p_lov_return_value=>'5'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(432223138152980619)
,p_lov_disp_sequence=>6
,p_lov_disp_value=>'Livre'
,p_lov_return_value=>'6'
);
wwv_flow_imp.component_end;
end;
/
