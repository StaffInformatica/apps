prompt --application/shared_components/user_interface/lovs/lv_tipo_validacao
begin
--   Manifest
--     LV_TIPO_VALIDACAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(284445120913179756)
,p_lov_name=>'LV_TIPO_VALIDACAO'
,p_lov_query=>'.'||wwv_flow_imp.id(284445120913179756)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(284445409299179770)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('Chave prim\00E1ria')
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(284445806902179770)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('Valor obrigat\00F3rio')
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(284446232253179770)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>unistr('Valor \00FAnico')
,p_lov_return_value=>'3'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(284446658679179771)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>unistr('Verfica\00E7\00E3o de valores')
,p_lov_return_value=>'4'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(286392401276126648)
,p_lov_disp_sequence=>5
,p_lov_disp_value=>unistr('Verfica\00E7\00E3o de exclus\00E3o')
,p_lov_return_value=>'5'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(286516736924192137)
,p_lov_disp_sequence=>6
,p_lov_disp_value=>'Livre'
,p_lov_return_value=>'6'
);
wwv_flow_imp.component_end;
end;
/
