prompt --application/shared_components/user_interface/lovs/lv_sup_status
begin
--   Manifest
--     LV_SUP_STATUS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(529780827432106555)
,p_lov_name=>'LV_SUP_STATUS'
,p_lov_query=>'.'||wwv_flow_imp.id(529780827432106555)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(529781207744106556)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Aberto'
,p_lov_return_value=>'A'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(529781675504106556)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('Em an\00E1lise')
,p_lov_return_value=>'B'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(529782002503106556)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Aguardando retorno'
,p_lov_return_value=>'C'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(529782446442106556)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Cancelado'
,p_lov_return_value=>'D'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(529782807568106557)
,p_lov_disp_sequence=>5
,p_lov_disp_value=>'Encerrado'
,p_lov_return_value=>'E'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(529783234288106557)
,p_lov_disp_sequence=>6
,p_lov_disp_value=>'Finalizado'
,p_lov_return_value=>'F'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(529783676663106557)
,p_lov_disp_sequence=>7
,p_lov_disp_value=>unistr('Em digita\00E7\00E3o')
,p_lov_return_value=>'G'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(498535145151989581)
,p_lov_disp_sequence=>8
,p_lov_disp_value=>'Qualidade'
,p_lov_return_value=>'H'
);
wwv_flow_imp.component_end;
end;
/
