prompt --application/shared_components/user_interface/lovs/lv_artefato_aplicativo
begin
--   Manifest
--     LV_ARTEFATO_APLICATIVO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(253826855801276560)
,p_lov_name=>'LV_ARTEFATO_APLICATIVO'
,p_lov_query=>'Select ID, NOME from ADM_ARTEFATO WHERE TIPO = 22'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'ID'
,p_display_column_name=>'NOME'
,p_default_sort_column_name=>'NOME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
