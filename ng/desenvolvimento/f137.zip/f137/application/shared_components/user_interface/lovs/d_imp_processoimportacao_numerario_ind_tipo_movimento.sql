prompt --application/shared_components/user_interface/lovs/d_imp_processoimportacao_numerario_ind_tipo_movimento
begin
--   Manifest
--     D_IMP_PROCESSOIMPORTACAO_NUMERARIO.IND_TIPO_MOVIMENTO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(199007136438819935)
,p_lov_name=>'D_IMP_PROCESSOIMPORTACAO_NUMERARIO.IND_TIPO_MOVIMENTO'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''imp_processoimportacao_numerario'',''ind_tipo_movimento'') order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>46230543705577
);
wwv_flow_imp.component_end;
end;
/
