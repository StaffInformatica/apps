prompt --application/shared_components/user_interface/lovs/r_ng_depara_id_ng
begin
--   Manifest
--     R_NG_DEPARA.ID_NG
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(192947951786306104)
,p_lov_name=>'R_NG_DEPARA.ID_NG'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select rtrim(d,'' - '') d, r from bo_ng_depara.consulta_dinamica_id_ng(',
'   (select id from srv_entidade ',
'    where lower(nome_leitura) = (',
'        select lower(c002) ',
'        from apex_collections ',
'        where collection_name = apex_util.get_session_state(''P9010_CODIGO_ARTEFATO'') || ''_'' || apex_custom_auth.get_session_id ',
'        and upper(c001) = upper(''f06_0000'')) ',
'    and rownum = 1',
'    and lower(nome_entidade) like ''ng_%'')) ',
'order by 1 nulls first'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>44863076988573
);
wwv_flow_imp.component_end;
end;
/
