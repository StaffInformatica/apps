prompt --application/shared_components/user_interface/lovs/mpd_tenant_razao_social
begin
--   Manifest
--     MPD_TENANT.RAZAO_SOCIAL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(133557176112984160)
,p_lov_name=>'MPD_TENANT.RAZAO_SOCIAL'
,p_static_id=>'mpd-tenant-razao-social'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'MPD_TENANT'
,p_return_column_name=>'ID'
,p_display_column_name=>'RAZAO_SOCIAL'
,p_default_sort_column_name=>'RAZAO_SOCIAL'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'SH256:EWUh-KEbG8QcDIbiNxMsjDNDtjcgofTccW97msKFw6k'
,p_created_on=>wwv_flow_imp.dz('20260911185749Z')
,p_updated_on=>wwv_flow_imp.dz('20260911185749Z')
,p_created_by=>'DEVNORTHONN'
,p_updated_by=>'DEVNORTHONN'
);
wwv_flow_imp.component_end;
end;
/
