prompt --application/shared_components/user_interface/lovs/r_ng_item_embalagem_descricao_ncm
begin
--   Manifest
--     R_NG_ITEM_EMBALAGEM.DESCRICAO_NCM
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.16'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(47389396552583513)
,p_lov_name=>'R_NG_ITEM_EMBALAGEM.DESCRICAO_NCM'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    pkg_traducao.get_traducao(a.descricao_ncm) d, ',
'    a.id r ',
'from ng_ncm a',
'where a.data_fim_vigencia is null ',
'or to_date(a.data_fim_vigencia) >= to_date(current_date)',
'order by 1'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>46042202742015
);
wwv_flow_imp.component_end;
end;
/
