prompt --application/shared_components/user_interface/lovs/d_geral_sim_nao
begin
--   Manifest
--     D_GERAL.SIM_NAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(340672464799880398)
,p_lov_name=>'D_GERAL.SIM_NAO'
,p_static_id=>'d-geral-sim-nao'
,p_lov_query=>'select * from pkg_ui.retorna_lista_dominio(197)'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'41840868914599'
);
wwv_flow_imp.component_end;
end;
/
