prompt --application/shared_components/user_interface/lovs/r_ng_entrega_processoimportacao
begin
--   Manifest
--     R_NG_ENTREGA.PROCESSOIMPORTACAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(148003796909589800)
,p_lov_name=>'R_NG_ENTREGA.PROCESSOIMPORTACAO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    a.num_processoimportacao d,',
'    a.id r',
'FROM ',
'    imp_processoimportacao a',
'    JOIN imp_entrega b ',
'        ON b.id_exportador = a.id_embarcador',
'       AND b.id_importador = a.id_importador',
'       AND b.id = :P9012_ID',
'WHERE ',
'    a.ind_status IN (1,2,3,4)',
'ORDER BY ',
'    d;',
'',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>46809028033763
);
wwv_flow_imp.component_end;
end;
/
