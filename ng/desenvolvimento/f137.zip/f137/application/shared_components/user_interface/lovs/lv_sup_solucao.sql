prompt --application/shared_components/user_interface/lovs/lv_sup_solucao
begin
--   Manifest
--     LV_SUP_SOLUCAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(384193734882458558)
,p_lov_name=>'LV_SUP_SOLUCAO'
,p_lov_query=>'.'||wwv_flow_imp.id(384193734882458558)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(384194095718458558)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('Temos solu\00E7\00E3o de contorno para o problema reportado')
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(384194511786458559)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('N\00E3o temos uma solu\00E7\00E3o de contorno para esse problema')
,p_lov_return_value=>'2'
);
wwv_flow_imp.component_end;
end;
/
