prompt --application/shared_components/user_interface/lovs/d_imp_naturezaoperacao_tributo_ind_modalidade_drawback
begin
--   Manifest
--     D_IMP_NATUREZAOPERACAO_TRIBUTO.IND_MODALIDADE_DRAWBACK
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(15065525597136600)
,p_lov_name=>'D_IMP_NATUREZAOPERACAO_TRIBUTO.IND_MODALIDADE_DRAWBACK'
,p_static_id=>'d-imp-naturezaoperacao-tributo-ind-modalidade-drawback'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''imp_naturezaoperacao_tributo'',''ind_modalidade_drawback'') order by r'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>'SH256:XMFAuyiIoNOo1p1xmYoE-4r2VyYgXgxJq29_xUC9nRU'
);
wwv_flow_imp.component_end;
end;
/
