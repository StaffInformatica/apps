prompt --application/shared_components/user_interface/lovs/d_imp_naturezaoperacao_tributo_ind_modalidade_drawback
begin
--   Manifest
--     D_IMP_NATUREZAOPERACAO_TRIBUTO.IND_MODALIDADE_DRAWBACK
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(160771926825925082)
,p_lov_name=>'D_IMP_NATUREZAOPERACAO_TRIBUTO.IND_MODALIDADE_DRAWBACK'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''imp_naturezaoperacao_tributo'',''ind_modalidade_drawback'') order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>45295295374263
);
wwv_flow_imp.component_end;
end;
/
