prompt --application/shared_components/user_interface/lovs/lv_sup_criticidade
begin
--   Manifest
--     LV_SUP_CRITICIDADE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(384189118861458555)
,p_lov_name=>'LV_SUP_CRITICIDADE'
,p_static_id=>'lv-sup-criticidade'
,p_lov_query=>'.'||wwv_flow_imp.id(384189118861458555)||'.'
,p_location=>'STATIC'
,p_version_scn=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(384189514251458555)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('N\00E3o \00E9 cr\00EDtico')
,p_lov_return_value=>'1'
,p_static_id=>'lov_data'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(384189971868458556)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('Est\00E1 impedindo uma funcionalidade imprescind\00EDvel')
,p_lov_return_value=>'2'
,p_static_id=>'lov_data-2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(384190378096458556)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>unistr('Est\00E1 impedindo o uso do NG de forma geral')
,p_lov_return_value=>'3'
,p_static_id=>'lov_data-3'
);
wwv_flow_imp.component_end;
end;
/
