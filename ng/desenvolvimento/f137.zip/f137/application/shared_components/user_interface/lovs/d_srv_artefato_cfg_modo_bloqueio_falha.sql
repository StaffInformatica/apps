prompt --application/shared_components/user_interface/lovs/d_srv_artefato_cfg_modo_bloqueio_falha
begin
--   Manifest
--     D_SRV_ARTEFATO_CFG.MODO_BLOQUEIO_FALHA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(67299018211256316)
,p_lov_name=>'D_SRV_ARTEFATO_CFG.MODO_BLOQUEIO_FALHA'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''srv_artefato_cfg'',''modo_bloqueio_falha'') order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>46488582477364
);
wwv_flow_imp.component_end;
end;
/
