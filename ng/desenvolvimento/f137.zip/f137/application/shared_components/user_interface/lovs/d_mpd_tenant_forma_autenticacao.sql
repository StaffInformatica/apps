prompt --application/shared_components/user_interface/lovs/d_mpd_tenant_forma_autenticacao
begin
--   Manifest
--     D_MPD_TENANT.FORMA_AUTENTICACAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.16'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(301728450578217956)
,p_lov_name=>'D_MPD_TENANT.FORMA_AUTENTICACAO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from pkg_util.dominio_retorna_lista(''MPD_TENANT'',''FORMA_AUTENTICACAO'')',
'',
'',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>41985116548647
);
wwv_flow_imp.component_end;
end;
/
