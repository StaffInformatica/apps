prompt --application/shared_components/user_interface/lovs/r_imp_minutanotafiscal_entrada_despesa_id_despesa
begin
--   Manifest
--     R_ IMP_MINUTANOTAFISCAL_ENTRADA_DESPESA.ID_DESPESA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(148270927265825546)
,p_lov_name=>'R_ IMP_MINUTANOTAFISCAL_ENTRADA_DESPESA.ID_DESPESA'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pkg_traducao.get_traducao(e.descricao_despesa) d,',
'       d.id r     ',
'from imp_minutanotafiscal_entrada_item a ',
'join imp_processoimportacao_item c ',
'    on c.id_minutanotafiscal = a.id_minuta',
'join imp_processoimportacao_despesa d ',
'    on d.id_processoimportacao = c.id_processoimportacao',
'join ng_despesa e ',
'    on e.id = d.id_despesa',
'where c.id_minutanotafiscal = :P9010_PARAMETRO'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>46730741014890
);
wwv_flow_imp.component_end;
end;
/
