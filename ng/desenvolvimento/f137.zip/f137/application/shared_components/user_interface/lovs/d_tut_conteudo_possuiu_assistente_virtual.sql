prompt --application/shared_components/user_interface/lovs/d_tut_conteudo_possuiu_assistente_virtual
begin
--   Manifest
--     D_TUT_CONTEUDO.POSSUIU_ASSISTENTE_VIRTUAL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(131380793901814876)
,p_lov_name=>'D_TUT_CONTEUDO.POSSUIU_ASSISTENTE_VIRTUAL'
,p_static_id=>'d-tut-conteudo-possuiu-assistente-virtual'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''tut_conteudo'',''possuiu_assistente_virtual'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'SH256:XtI0CxUq9B1Q_QIyu5eypQ4p127WYozlbwMh_a3dTfQ'
,p_created_on=>wwv_flow_imp.dz('20260917195242Z')
,p_updated_on=>wwv_flow_imp.dz('20260917195242Z')
,p_created_by=>'DEVNORTHONN'
,p_updated_by=>'DEVNORTHONN'
);
wwv_flow_imp.component_end;
end;
/
