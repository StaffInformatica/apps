prompt --application/shared_components/user_interface/lovs/d_ng_incoterm_ind_responsavel_despesa_destino
begin
--   Manifest
--     D_NG_INCOTERM.IND_RESPONSAVEL_DESPESA_DESTINO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(146103970862751398)
,p_lov_name=>'D_NG_INCOTERM.IND_RESPONSAVEL_DESPESA_DESTINO'
,p_static_id=>'d-ng-incoterm-ind-responsavel-despesa-destino'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''ng_incoterm'',''ind_responsavel_despesa_destino'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'44569480323789'
);
wwv_flow_imp.component_end;
end;
/
