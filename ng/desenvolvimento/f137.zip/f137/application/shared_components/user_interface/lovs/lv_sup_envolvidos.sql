prompt --application/shared_components/user_interface/lovs/lv_sup_envolvidos
begin
--   Manifest
--     LV_SUP_ENVOLVIDOS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(529778077799106548)
,p_lov_name=>'LV_SUP_ENVOLVIDOS'
,p_lov_query=>'.'||wwv_flow_imp.id(529778077799106548)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(529778806306106551)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Meus chamados'
,p_lov_return_value=>'S'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(529778447079106551)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Chamados como convidado'
,p_lov_return_value=>'N'
);
wwv_flow_imp.component_end;
end;
/
