prompt --application/shared_components/user_interface/lovs/d_ng_representante_comissao_ind_quando_pagar
begin
--   Manifest
--     D_NG_REPRESENTANTE_COMISSAO.IND_QUANDO_PAGAR
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(39642908764930468)
,p_lov_name=>'D_NG_REPRESENTANTE_COMISSAO.IND_QUANDO_PAGAR'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''ng_representante_comissao'',''ind_quando_pagar'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>44589198136177
);
wwv_flow_imp.component_end;
end;
/
