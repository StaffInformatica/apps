prompt --application/shared_components/user_interface/lovs/d_ng_documento_despesa_referencia_processoimportacao
begin
--   Manifest
--     D_NG_DOCUMENTO_DESPESA_REFERENCIA.PROCESSOIMPORTACAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(92096977431031438)
,p_lov_name=>'D_NG_DOCUMENTO_DESPESA_REFERENCIA.PROCESSOIMPORTACAO'
,p_static_id=>'d-ng-documento-despesa-referencia-processoimportacao'
,p_lov_query=>'select a.num_processoimportacao as d, a.id as r from imp_processoimportacao a order by d'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'49855682854062'
);
wwv_flow_imp.component_end;
end;
/
