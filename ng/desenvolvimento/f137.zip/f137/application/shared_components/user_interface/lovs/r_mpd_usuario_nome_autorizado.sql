prompt --application/shared_components/user_interface/lovs/r_mpd_usuario_nome_autorizado
begin
--   Manifest
--     R_MPD_USUARIO.NOME(AUTORIZADO)
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.16'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(208985908700579677)
,p_lov_name=>'R_MPD_USUARIO.NOME(AUTORIZADO)'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct a.nome, a.login, a.id',
'from mpd_usuario a',
'join mpd_usuario_tenant b',
'on a.id <> b.id_usuario',
'and b.id_tenant <> :P156_ID_TENANT_2',
'where a.id not in (select case when id_usuario in (select id_usuario from mpd_usuario_tenant where id = :P156_ID) then ',
'                   null else id_usuario end from mpd_usuario_tenant where id_tenant = :P156_ID_TENANT_2)',
'',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_table=>'MPD_USUARIO'
,p_query_where=>'id not in (select case when id_usuario in (select id_usuario from mpd_usuario_tenant where id_tenant = :P156_ID) then null else id_usuario end from mpd_usuario_tenant where id_tenant = :P156_ID_TENANT_2)'
,p_return_column_name=>'ID'
,p_display_column_name=>'NOME'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'NOME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>41734470622441
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(208986123407579695)
,p_query_column_name=>'ID'
,p_display_sequence=>10
,p_data_type=>'NUMBER'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(208986538336579696)
,p_query_column_name=>'NOME'
,p_heading=>'Nome'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(208986962448579697)
,p_query_column_name=>'LOGIN'
,p_heading=>'Login'
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp.component_end;
end;
/
