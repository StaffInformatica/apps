prompt --application/shared_components/user_interface/lovs/grupo_funcionalidade_pasta_nome
begin
--   Manifest
--     GRUPO_FUNCIONALIDADE_PASTA.NOME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(411891201897598831)
,p_lov_name=>'GRUPO_FUNCIONALIDADE_PASTA.NOME'
,p_static_id=>'grupo-funcionalidade-pasta-nome'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'GRUPO_FUNCIONALIDADE_PASTA'
,p_return_column_name=>'ID'
,p_display_column_name=>'NOME'
,p_default_sort_column_name=>'NOME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'1'
);
wwv_flow_imp.component_end;
end;
/
