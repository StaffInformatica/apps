prompt --application/shared_components/user_interface/lovs/r_mpd_grupo_nome_grupo
begin
--   Manifest
--     R_MPD_GRUPO.NOME_GRUPO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(291267840270534974)
,p_lov_name=>'R_MPD_GRUPO.NOME_GRUPO'
,p_static_id=>'r-mpd-grupo-nome-grupo'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'MPD_GRUPO'
,p_return_column_name=>'ID'
,p_display_column_name=>'NOME_GRUPO'
,p_default_sort_column_name=>'NOME_GRUPO'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'50352710286304'
,p_created_on=>wwv_flow_imp.dz('20260821141339Z')
,p_updated_on=>wwv_flow_imp.dz('20260821141339Z')
,p_created_by=>'DEVNORTHONN'
,p_updated_by=>'DEVNORTHONN'
);
wwv_flow_imp.component_end;
end;
/
