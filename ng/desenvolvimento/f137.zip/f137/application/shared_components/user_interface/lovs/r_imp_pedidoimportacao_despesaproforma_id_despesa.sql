prompt --application/shared_components/user_interface/lovs/r_imp_pedidoimportacao_despesaproforma_id_despesa
begin
--   Manifest
--     R_IMP_PEDIDOIMPORTACAO_DESPESAPROFORMA.ID_DESPESA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(7172508046147593)
,p_lov_name=>'R_IMP_PEDIDOIMPORTACAO_DESPESAPROFORMA.ID_DESPESA'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    pkg_traducao.get_traducao(a.descricao_despesa) d,',
'    a.id r ',
'from ng_despesa a',
'where (',
'    data_fim_vigencia is null',
'        or to_date(to_char(a.data_fim_vigencia, ''dd/mm/yyyy''), ''dd/mm/yyyy'') >= to_date(to_char(current_date, ''dd/mm/yyyy''), ''dd/mm/yyyy'')',
'    )',
'and ind_origem_despesa = 2 ',
'order by 1'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>46037554290354
);
wwv_flow_imp.component_end;
end;
/
