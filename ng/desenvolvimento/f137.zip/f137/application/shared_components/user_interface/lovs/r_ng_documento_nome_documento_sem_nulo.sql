prompt --application/shared_components/user_interface/lovs/r_ng_documento_nome_documento_sem_nulo
begin
--   Manifest
--     R_NG_DOCUMENTO.NOME_DOCUMENTO_-_SEM_NULO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(18728353331870498)
,p_lov_name=>'R_NG_DOCUMENTO.NOME_DOCUMENTO_-_SEM_NULO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select     ',
'    a.nome_documento, a.id',
'from ng_documento a ',
'where (a.data_fim_vigencia is null or to_date(a.data_fim_vigencia) >= to_date(current_date))',
'and a.id_entidade = (select sepa.id from srv_entidade_ng_permite_anexo sepa where sepa.id_entidade = to_number(apex_util.get_session_state(''P9011_PARAMETRO2''))) order by 1'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'ID'
,p_display_column_name=>'NOME_DOCUMENTO'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>45944716359464
);
wwv_flow_imp.component_end;
end;
/
