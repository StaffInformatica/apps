prompt --application/shared_components/user_interface/lovs/d_srv_entidade_nome_leitura
begin
--   Manifest
--     D_SRV_ENTIDADE.NOME_LEITURA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(128313660810933095)
,p_lov_name=>'D_SRV_ENTIDADE.NOME_LEITURA'
,p_static_id=>'d-srv-entidade-nome-leitura'
,p_lov_query=>'select nome_leitura d, id r from srv_entidade'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'SH256:Vtl309kzdERkObxyV6F4t_9OnTT1MBMHTP8KHdHV3Pk'
);
wwv_flow_imp.component_end;
end;
/
