prompt --application/shared_components/user_interface/lovs/d_imp_invoice_pagamento_periodo_multa
begin
--   Manifest
--     D_IMP_INVOICE_PAGAMENTO.PERIODO_MULTA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(177180284074388696)
,p_lov_name=>'D_IMP_INVOICE_PAGAMENTO.PERIODO_MULTA'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''imp_invoice_pagamento'',''periodo_multa'') order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>45865451165636
);
wwv_flow_imp.component_end;
end;
/
