prompt --application/shared_components/user_interface/lovs/d_ng_listapreco_item_id_importador
begin
--   Manifest
--     D_NG_LISTAPRECO_ITEM.ID_IMPORTADOR
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.16'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(191297770399666550)
,p_lov_name=>'D_NG_LISTAPRECO_ITEM.ID_IMPORTADOR'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select d, r',
'from (',
'    select null d, null r, 0 ordem from dual',
'    union all',
'    select ',
'        a.nome_fantasia || '' - '' ||a.razao_social,',
'        b.id,',
'        1',
'    from ng_pessoa_juridica a ',
'    join ng_pessoa b on b.id = a.id_pessoa',
'    where (',
'            b.data_fim_vigencia is null ',
'            or to_date(b.data_fim_vigencia) >= to_date(current_date)',
'        )',
'        and '':'' || a.ind_perfil || '':'' like ''%:I:%''',
') order by ordem, d',
'',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>45087619193466
);
wwv_flow_imp.component_end;
end;
/
