prompt --application/shared_components/user_interface/lovs/projeto_situacao
begin
--   Manifest
--     PROJETO_SITUACAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(268517347869534312)
,p_lov_name=>'PROJETO_SITUACAO'
,p_static_id=>'projeto-situacao'
,p_lov_query=>'.'||wwv_flow_imp.id(268517347869534312)||'.'
,p_location=>'STATIC'
,p_version_scn=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(268518402512534315)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>unistr('Conclu\00EDdo')
,p_lov_return_value=>'C'
,p_static_id=>'c'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(268518044595534315)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Em progresso'
,p_lov_return_value=>'E'
,p_static_id=>'e'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(268517592116534313)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Pendente'
,p_lov_return_value=>'P'
,p_static_id=>'p'
);
wwv_flow_imp.component_end;
end;
/
