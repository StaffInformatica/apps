prompt --application/shared_components/user_interface/lovs/d_mpd_configuracao_ind_grupo_funcionalidade
begin
--   Manifest
--     D_MPD_CONFIGURACAO.IND_GRUPO_FUNCIONALIDADE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(117795764963616855)
,p_lov_name=>'D_MPD_CONFIGURACAO.IND_GRUPO_FUNCIONALIDADE'
,p_static_id=>'d-mpd-configuracao-ind-grupo-funcionalidade'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''mpd_configuracao_ng'',''ind_grupo_funcionalidade'') order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>'SH256:VmuD_GK282r0YFJ8-tgC-tbJEtki_JMrjNrO388Xs_A'
);
wwv_flow_imp.component_end;
end;
/
