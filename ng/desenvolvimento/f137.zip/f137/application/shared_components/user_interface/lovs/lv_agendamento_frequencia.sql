prompt --application/shared_components/user_interface/lovs/lv_agendamento_frequencia
begin
--   Manifest
--     LV_AGENDAMENTO_FREQUENCIA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(356270299305025505)
,p_lov_name=>'LV_AGENDAMENTO_FREQUENCIA'
,p_lov_query=>'.'||wwv_flow_imp.id(356270299305025505)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(356270725510025505)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Diariamente'
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(356271119028025505)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Semanalmente'
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(356271505476025506)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Mensalmente'
,p_lov_return_value=>'3'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(356271891867025506)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Anualmente'
,p_lov_return_value=>'4'
);
wwv_flow_imp.component_end;
end;
/
