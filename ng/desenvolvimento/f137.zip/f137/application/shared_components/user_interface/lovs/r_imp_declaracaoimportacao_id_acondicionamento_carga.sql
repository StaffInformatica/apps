prompt --application/shared_components/user_interface/lovs/r_imp_declaracaoimportacao_id_acondicionamento_carga
begin
--   Manifest
--     R_IMP_DECLARACAOIMPORTACAO.ID_ACONDICIONAMENTO_CARGA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(197387774110335491)
,p_lov_name=>'R_IMP_DECLARACAOIMPORTACAO.ID_ACONDICIONAMENTO_CARGA'
,p_static_id=>'r-imp-declaracaoimportacao-id-acondicionamento-carga'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    pkg_traducao.get_traducao(a.descricao_acondicionamento_carga) d,',
'    a.id r ',
'from ng_acondicionamentocarga a',
'where (a.data_fim_vigencia is null',
'or to_date(a.data_fim_vigencia) >= to_date(current_date)) ',
'order by 1'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>'47058504369348'
,p_created_on=>wwv_flow_imp.dz('20260521170450Z')
,p_updated_on=>wwv_flow_imp.dz('20260521170450Z')
,p_created_by=>'DEVJONICLEI'
,p_updated_by=>'DEVJONICLEI'
);
wwv_flow_imp.component_end;
end;
/
