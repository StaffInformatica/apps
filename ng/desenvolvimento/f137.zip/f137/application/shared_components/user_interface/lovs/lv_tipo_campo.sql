prompt --application/shared_components/user_interface/lovs/lv_tipo_campo
begin
--   Manifest
--     LV_TIPO_CAMPO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(429950428053492887)
,p_lov_name=>'LV_TIPO_CAMPO'
,p_lov_query=>'.'||wwv_flow_imp.id(429950428053492887)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(429950702330492889)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Texto'
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(429951181788492889)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('N\00FAmero inteiro')
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(429951512925492890)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>unistr('N\00FAmero decimal')
,p_lov_return_value=>'3'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(429951897285492890)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Data'
,p_lov_return_value=>'4'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(429952351983492891)
,p_lov_disp_sequence=>5
,p_lov_disp_value=>'Data e hora'
,p_lov_return_value=>'5'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(429952747329492891)
,p_lov_disp_sequence=>6
,p_lov_disp_value=>'Arquivo'
,p_lov_return_value=>'6'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(429953116109492891)
,p_lov_disp_sequence=>7
,p_lov_disp_value=>unistr('Domin\00EDo')
,p_lov_return_value=>'7'
);
wwv_flow_imp.component_end;
end;
/
