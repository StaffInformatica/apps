prompt --application/shared_components/user_interface/lovs/lv_tipo_campo
begin
--   Manifest
--     LV_TIPO_CAMPO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(284244026824704405)
,p_lov_name=>'LV_TIPO_CAMPO'
,p_static_id=>'lv-tipo-campo'
,p_lov_query=>'.'||wwv_flow_imp.id(284244026824704405)||'.'
,p_location=>'STATIC'
,p_version_scn=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(284244301101704407)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Texto'
,p_lov_return_value=>'1'
,p_static_id=>'lov_data'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(284244780559704407)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('N\00FAmero inteiro')
,p_lov_return_value=>'2'
,p_static_id=>'lov_data-2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(284245111696704408)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>unistr('N\00FAmero decimal')
,p_lov_return_value=>'3'
,p_static_id=>'lov_data-3'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(284245496056704408)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Data'
,p_lov_return_value=>'4'
,p_static_id=>'lov_data-4'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(284245950754704409)
,p_lov_disp_sequence=>5
,p_lov_disp_value=>'Data e hora'
,p_lov_return_value=>'5'
,p_static_id=>'lov_data-5'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(284246346100704409)
,p_lov_disp_sequence=>6
,p_lov_disp_value=>'Arquivo'
,p_lov_return_value=>'6'
,p_static_id=>'lov_data-6'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(284246714880704409)
,p_lov_disp_sequence=>7
,p_lov_disp_value=>unistr('Domin\00EDo')
,p_lov_return_value=>'7'
,p_static_id=>'lov_data-7'
);
wwv_flow_imp.component_end;
end;
/
