prompt --application/shared_components/user_interface/lovs/d_imp_ncm_fiscal_ind_licenca_importacao
begin
--   Manifest
--     D_IMP_NCM_FISCAL.IND_LICENCA_IMPORTACAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(63048501607754699)
,p_lov_name=>'D_IMP_NCM_FISCAL.IND_LICENCA_IMPORTACAO'
,p_static_id=>'d-imp-ncm-fiscal-ind-licenca-importacao'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Sim'' d, ''S'' r from dual',
'union all',
unistr('select ''N\00E3o'' d, ''N'' r from dual')))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'46410614462121'
);
wwv_flow_imp.component_end;
end;
/
