prompt --application/shared_components/user_interface/lovs/r_ng_configuracao_id_entidade
begin
--   Manifest
--     R_NG_CONFIGURACAO.ID_ENTIDADE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(155434787721291708)
,p_lov_name=>'R_NG_CONFIGURACAO.ID_ENTIDADE'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    e.nome_leitura d, ',
'    e.id r',
'from srv_entidade e',
'where lower(e.nome_entidade) like ''ng_%''',
'   or lower(e.nome_entidade) like ''imp_%''',
'   or lower(e.nome_entidade) like ''exp_%''',
'   or lower(e.nome_entidade) like ''drb_%''',
'order by d;',
'',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>45834988785998
);
wwv_flow_imp.component_end;
end;
/
