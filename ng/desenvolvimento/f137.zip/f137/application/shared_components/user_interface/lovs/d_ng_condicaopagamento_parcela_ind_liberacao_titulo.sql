prompt --application/shared_components/user_interface/lovs/d_ng_condicaopagamento_parcela_ind_liberacao_titulo
begin
--   Manifest
--     D_NG_CONDICAOPAGAMENTO_PARCELA.IND_LIBERACAO_TITULO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(5072961970603672)
,p_lov_name=>'D_NG_CONDICAOPAGAMENTO_PARCELA.IND_LIBERACAO_TITULO'
,p_static_id=>'d-ng-condicaopagamento-parcela-ind-liberacao-titulo'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''ng_condicaopagamento_parcela'',''ind_liberacao_titulo'') order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'45630367972113'
);
wwv_flow_imp.component_end;
end;
/
