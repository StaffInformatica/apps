prompt --application/shared_components/user_interface/lovs/r_mpd_papel_nome_papel_autorizado
begin
--   Manifest
--     R_MPD_PAPEL.NOME_PAPEL(AUTORIZADO)
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(235705874230593334)
,p_lov_name=>'R_MPD_PAPEL.NOME_PAPEL(AUTORIZADO)'
,p_static_id=>'r-mpd-papel-nome-papel-autorizado'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT a.nome_papel, a.id',
'FROM mpd_papel a',
'JOIN mpd_usuario_papel b',
'ON a.id = b.id_papel_usuario',
'AND (b.id_usuario <> :P270_ID_USUARIO OR :ID_USUARIO_LOGADO = :P270_ID_USUARIO)',
'WHERE a.id NOT IN (',
'    SELECT CASE ',
'        WHEN id_papel_usuario IN (',
'            SELECT id_papel_usuario ',
'            FROM mpd_usuario_papel ',
'            WHERE id = :P270_ID',
'        ) THEN NULL ',
'        ELSE id_papel_usuario',
'    END ',
'    FROM mpd_usuario_papel ',
'    WHERE id_usuario = :P270_ID_USUARIO',
')',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'ID'
,p_display_column_name=>'NOME_PAPEL'
,p_default_sort_column_name=>'NOME_PAPEL'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'41760928640283'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(236683878438516557)
,p_query_column_name=>'ID'
,p_display_sequence=>10
,p_data_type=>'NUMBER'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(236684188933516558)
,p_query_column_name=>'NOME_PAPEL'
,p_heading=>'Nome Papel'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp.component_end;
end;
/
