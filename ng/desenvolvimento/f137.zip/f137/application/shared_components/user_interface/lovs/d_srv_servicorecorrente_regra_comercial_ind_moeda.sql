prompt --application/shared_components/user_interface/lovs/d_srv_servicorecorrente_regra_comercial_ind_moeda
begin
--   Manifest
--     D_SRV_SERVICORECORRENTE_REGRA_COMERCIAL.IND_MOEDA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(101648039179082184)
,p_lov_name=>'D_SRV_SERVICORECORRENTE_REGRA_COMERCIAL.IND_MOEDA'
,p_static_id=>'d-srv-servicorecorrente-regra-comercial-ind-moeda'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''srv_servicorecorrente_regra_comercial'',''ind_moeda'') order by to_number(r)'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>'SH256:k1fT6TIW5ZF6x6ZeRldkdsVgOV5GdquLGE5RM3WW8j8'
);
wwv_flow_imp.component_end;
end;
/
