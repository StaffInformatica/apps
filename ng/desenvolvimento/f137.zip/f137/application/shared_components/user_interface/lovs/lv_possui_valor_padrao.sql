prompt --application/shared_components/user_interface/lovs/lv_possui_valor_padrao
begin
--   Manifest
--     LV_POSSUI_VALOR_PADRAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(429953428516513843)
,p_lov_name=>'LV_POSSUI_VALOR_PADRAO'
,p_static_id=>'lv-possui-valor-padrao'
,p_lov_query=>'.'||wwv_flow_imp.id(429953428516513843)||'.'
,p_location=>'STATIC'
,p_version_scn=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(429953773041513843)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('N\00E3o')
,p_lov_return_value=>'1'
,p_static_id=>'lov_data'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(429954162817513844)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Sequencial'
,p_lov_return_value=>'2'
,p_static_id=>'lov_data-2'
,p_lov_disp_cond_type=>'EXPRESSION'
,p_lov_disp_cond=>':P434_TIPO = 2'
,p_lov_disp_cond2=>'PLSQL'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(429954539469513844)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>unistr('Dom\00EDnio')
,p_lov_return_value=>'3'
,p_static_id=>'lov_data-3'
,p_lov_disp_cond_type=>'EXPRESSION'
,p_lov_disp_cond=>':P434_TIPO = 7'
,p_lov_disp_cond2=>'PLSQL'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(429954889386513845)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Outro'
,p_lov_return_value=>'4'
,p_static_id=>'lov_data-4'
);
wwv_flow_imp.component_end;
end;
/
