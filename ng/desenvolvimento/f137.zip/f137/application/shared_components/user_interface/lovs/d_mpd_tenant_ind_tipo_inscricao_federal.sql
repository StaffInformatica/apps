prompt --application/shared_components/user_interface/lovs/d_mpd_tenant_ind_tipo_inscricao_federal
begin
--   Manifest
--     D_MPD_TENANT.IND_TIPO_INSCRICAO_FEDERAL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(102145500549525066)
,p_lov_name=>'D_MPD_TENANT.IND_TIPO_INSCRICAO_FEDERAL'
,p_static_id=>'d-mpd-tenant-ind-tipo-inscricao-federal'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from pkg_util.dominio_retorna_lista(''mpd_tenant'',''ind_tipo_inscricao_federal'') order by 1',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>'SH256:u1LWokqJXGrNx9gerPHBy_Ijp1-m2vTlBaGf0g1ipRc'
);
wwv_flow_imp.component_end;
end;
/
