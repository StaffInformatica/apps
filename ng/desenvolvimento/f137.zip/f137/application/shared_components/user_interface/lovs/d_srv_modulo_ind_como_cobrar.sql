prompt --application/shared_components/user_interface/lovs/d_srv_modulo_ind_como_cobrar
begin
--   Manifest
--     D_SRV_MODULO.IND_COMO_COBRAR
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(104628697737246760)
,p_lov_name=>'D_SRV_MODULO.IND_COMO_COBRAR'
,p_static_id=>'d-srv-modulo-ind-como-cobrar'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''srv_modulo'',''ind_como_cobrar'') order by d'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>'SH256:PXkU8Le_9oBa57uF5n9sNhltBrN6x7OB9W7dlI2oBtQ'
);
wwv_flow_imp.component_end;
end;
/
