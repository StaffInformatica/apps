prompt --application/shared_components/user_interface/lovs/lv_sup_analista
begin
--   Manifest
--     LV_SUP_ANALISTA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(487595780442290535)
,p_lov_name=>'LV_SUP_ANALISTA'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT A.ID, NOME||'' ''||SOBRENOME AS NOME FROM ADM_USUARIO A ',
'JOIN ADM_CHAMADO_FUNCIONARIO B ON B.ID_USUARIO = A.ID      ',
'WHERE B.ANALISTA = ''S'''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'ID'
,p_display_column_name=>'NOME'
,p_default_sort_column_name=>'NOME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
