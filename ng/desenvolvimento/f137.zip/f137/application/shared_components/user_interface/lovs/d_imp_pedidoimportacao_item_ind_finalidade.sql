prompt --application/shared_components/user_interface/lovs/d_imp_pedidoimportacao_item_ind_finalidade
begin
--   Manifest
--     D_IMP_PEDIDOIMPORTACAO_ITEM.IND_FINALIDADE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(85071172793905331)
,p_lov_name=>'D_IMP_PEDIDOIMPORTACAO_ITEM.IND_FINALIDADE'
,p_static_id=>'d-imp-pedidoimportacao-item-ind-finalidade'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''imp_pedidoimportacao_item'',''ind_finalidade'') order by 2'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>'47349602417040'
);
wwv_flow_imp.component_end;
end;
/
