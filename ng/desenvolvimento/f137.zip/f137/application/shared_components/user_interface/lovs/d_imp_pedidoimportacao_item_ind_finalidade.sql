prompt --application/shared_components/user_interface/lovs/d_imp_pedidoimportacao_item_ind_finalidade
begin
--   Manifest
--     D_IMP_PEDIDOIMPORTACAO_ITEM.IND_FINALIDADE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(230777574022693813)
,p_lov_name=>'D_IMP_PEDIDOIMPORTACAO_ITEM.IND_FINALIDADE'
,p_static_id=>'d-imp-pedidoimportacao-item-ind-finalidade'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''imp_pedidoimportacao_item'',''ind_finalidade'') order by 2'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>'47349602417040'
,p_created_on=>wwv_flow_imp.dz('20260623132801Z')
,p_updated_on=>wwv_flow_imp.dz('20260623132801Z')
,p_created_by=>'DEVLEONARDO'
,p_updated_by=>'DEVLEONARDO'
);
wwv_flow_imp.component_end;
end;
/
