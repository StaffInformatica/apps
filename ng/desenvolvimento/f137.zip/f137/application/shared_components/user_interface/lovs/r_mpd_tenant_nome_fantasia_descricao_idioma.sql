prompt --application/shared_components/user_interface/lovs/r_mpd_tenant_nome_fantasia_descricao_idioma
begin
--   Manifest
--     R_MPD_TENANT.NOME_FANTASIA(DESCRICAO_IDIOMA)
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(182278982133559143)
,p_lov_name=>'R_MPD_TENANT.NOME_FANTASIA(DESCRICAO_IDIOMA)'
,p_lov_query=>'select nome_fantasia||'' (''||descricao_idioma||'')'' d, a.id r from mpd_tenant a join srv_idioma b on b.id = a.id_idioma'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>44538195853940
);
wwv_flow_imp.component_end;
end;
/
