prompt --application/shared_components/user_interface/lovs/d_imp_pedidoimportacao_ind_status_conclusao
begin
--   Manifest
--     D_IMP_PEDIDOIMPORTACAO.IND_STATUS_CONCLUSAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(34137349899709299)
,p_lov_name=>'D_IMP_PEDIDOIMPORTACAO.IND_STATUS_CONCLUSAO'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''imp_pedidoimportacao'',''ind_status_pedido_importacao'') where r in (2,3) order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>45143215930738
);
wwv_flow_imp.component_end;
end;
/
