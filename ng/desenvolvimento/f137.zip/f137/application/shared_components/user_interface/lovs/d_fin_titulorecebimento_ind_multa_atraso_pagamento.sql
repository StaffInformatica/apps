prompt --application/shared_components/user_interface/lovs/d_fin_titulorecebimento_ind_multa_atraso_pagamento
begin
--   Manifest
--     D_FIN_TITULORECEBIMENTO.IND_MULTA_ATRASO_PAGAMENTO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(208426554715941067)
,p_lov_name=>'D_FIN_TITULORECEBIMENTO.IND_MULTA_ATRASO_PAGAMENTO'
,p_static_id=>'d-fin-titulorecebimento-ind-multa-atraso-pagamento'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''fin_titulorecebimento'',''ind_multa_atraso_pagamento'') order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'46390665041932'
);
wwv_flow_imp.component_end;
end;
/
