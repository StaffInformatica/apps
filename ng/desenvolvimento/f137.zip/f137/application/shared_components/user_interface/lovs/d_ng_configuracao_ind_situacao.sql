prompt --application/shared_components/user_interface/lovs/d_ng_configuracao_ind_situacao
begin
--   Manifest
--     D_NG_CONFIGURACAO.IND_SITUACAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(4892926869103676)
,p_lov_name=>'D_NG_CONFIGURACAO.IND_SITUACAO'
,p_static_id=>'d-ng-configuracao-ind-situacao'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''ng_configuracao'',''ind_situacao'') order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>'45626079240937'
);
wwv_flow_imp.component_end;
end;
/
