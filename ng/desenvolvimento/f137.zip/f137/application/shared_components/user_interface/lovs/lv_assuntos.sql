prompt --application/shared_components/user_interface/lovs/lv_assuntos
begin
--   Manifest
--     LV_ASSUNTOS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(254449575020819096)
,p_lov_name=>'LV_ASSUNTOS'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'TUTORIAL_ASSUNTO'
,p_return_column_name=>'ID'
,p_display_column_name=>'ASSUNTO'
,p_default_sort_column_name=>'ASSUNTO'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
