prompt --application/shared_components/user_interface/lovs/d_imp_minutanotafiscal_entrada_item_cst
begin
--   Manifest
--     D_ IMP_MINUTANOTAFISCAL_ENTRADA_ITEM.CST
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(148218456502898880)
,p_lov_name=>'D_ IMP_MINUTANOTAFISCAL_ENTRADA_ITEM.CST'
,p_static_id=>'d-imp-minutanotafiscal-entrada-item-cst'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''imp_minutanotafiscal_entrada_item'',''cst'') order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>'46728785796064'
,p_created_on=>wwv_flow_imp.dz('20260413145031Z')
,p_updated_on=>wwv_flow_imp.dz('20260413145031Z')
,p_created_by=>'DEVJONICLEI'
,p_updated_by=>'DEVJONICLEI'
);
wwv_flow_imp.component_end;
end;
/
