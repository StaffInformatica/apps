prompt --application/shared_components/user_interface/lovs/d_imp_entrega_ind_modalidade_importacao
begin
--   Manifest
--     D_IMP_ENTREGA.IND_MODALIDADE_IMPORTACAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(15202298506915529)
,p_lov_name=>'D_IMP_ENTREGA.IND_MODALIDADE_IMPORTACAO'
,p_static_id=>'d-imp-entrega-ind-modalidade-importacao'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''imp_entrega'',''ind_modalidade_importacao'') order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>'45294923543231'
);
wwv_flow_imp.component_end;
end;
/
