prompt --application/shared_components/user_interface/lovs/d_srv_aplicacao_texto_tipo_texto
begin
--   Manifest
--     D_SRV_APLICACAO_TEXTO.TIPO_TEXTO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.16'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(196359054272365460)
,p_lov_name=>'D_SRV_APLICACAO_TEXTO.TIPO_TEXTO'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''srv_aplicacao_texto'',''tipo_texto'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>42134531653687
);
wwv_flow_imp.component_end;
end;
/
