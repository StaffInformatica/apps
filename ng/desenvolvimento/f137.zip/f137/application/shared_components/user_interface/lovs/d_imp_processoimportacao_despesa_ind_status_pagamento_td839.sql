prompt --application/shared_components/user_interface/lovs/d_imp_processoimportacao_despesa_ind_status_pagamento_td839
begin
--   Manifest
--     D_IMP_PROCESSOIMPORTACAO_DESPESA.IND_STATUS_PAGAMENTO.TD839
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(36277790874774536)
,p_lov_name=>'D_IMP_PROCESSOIMPORTACAO_DESPESA.IND_STATUS_PAGAMENTO.TD839'
,p_static_id=>'d-imp-processoimportacao-despesa-ind-status-pagamento-td'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''IMP_PROCESSOIMPORTACAO_DESPESA'',''IND_STATUS_PAGAMENTO'') where r in (''1'',''3'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'46972887525082'
,p_created_on=>wwv_flow_imp.dz('20260512150514Z')
,p_updated_on=>wwv_flow_imp.dz('20260512150514Z')
,p_created_by=>'DEVLEONARDO'
,p_updated_by=>'DEVLEONARDO'
);
wwv_flow_imp.component_end;
end;
/
