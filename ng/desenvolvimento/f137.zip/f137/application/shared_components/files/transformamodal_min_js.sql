prompt --application/shared_components/files/transformamodal_min_js
begin
--   Manifest
--     APP STATIC FILES: 137
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '66756E6374696F6E20706167696E615F6D6F64616C28612C692C6E297B72657475726E20617065782E6E617669676174696F6E2E6469616C6F672E636C6F73652821302C2866756E6374696F6E2865297B617065782E6E617669676174696F6E2E646961';
wwv_flow_imp.g_varchar2_table(2) := '6C6F6728692C7B7469746C653A612C77696474683A22393638222C6D6F64616C3A21302C6469616C6F673A652C726573697A61626C653A21307D2C22742D4472617765722D706167652D2D7374616E6461726420742D4472617765722D2D70756C6C4F75';
wwv_flow_imp.g_varchar2_table(3) := '74456E64206573636F6E646572222C24286E29297D29292C317D';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(33763797720596464)
,p_file_name=>'TransformaModal.min.js'
,p_mime_type=>'text/javascript'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
