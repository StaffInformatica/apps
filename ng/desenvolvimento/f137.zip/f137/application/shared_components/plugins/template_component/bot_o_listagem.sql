prompt --application/shared_components/plugins/template_component/bot_o_listagem
begin
--   Manifest
--     PLUGIN: BOT_O_LISTAGEM
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_plugin(
 p_id=>wwv_flow_imp.id(54835313684096547)
,p_plugin_type=>'TEMPLATE COMPONENT'
,p_theme_id=>nvl(wwv_flow_application_install.get_theme_id, '')
,p_name=>'BOT_O_LISTAGEM'
,p_display_name=>unistr('Bot\00E3o Listagem')
,p_apexlang_name=>'botoListagem'
,p_supported_component_types=>'PARTIAL'
,p_image_prefix=>nvl(wwv_flow_application_install.get_static_plugin_file_prefix('TEMPLATE COMPONENT','BOT_O_LISTAGEM'),'')
,p_partial_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{if APEX$IS_LAZY_LOADING/}',
'  <div></div>',
'{else/}',
'  {if APEX$HAS_ACTION_BUTTONS/}',
'  #OPCAO#',
'  {endif/}',
'{endif/}'))
,p_default_escape_mode=>'HTML'
,p_translate_this_template=>false
,p_api_version=>2
,p_standard_attributes=>'REGION_TEMPLATE'
,p_substitute_attributes=>true
,p_reference_id=>wwv_imp_util.get_subscription_id(147615099398182056,2700,wwv_flow_t_varchar2(),null)
,p_subscribe_plugin_settings=>true
,p_version_identifier=>'1.0'
,p_files_version=>1
);
wwv_flow_imp_shared.create_plugin_act_template(
 p_id=>wwv_flow_imp.id(202451019101281877)
,p_plugin_id=>wwv_flow_imp.id(54835313684096547)
,p_name=>'opcao'
,p_apexlang_name=>'opcao'
,p_static_id=>'opcao'
,p_type=>'BUTTON'
,p_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<a class="rw-Button{if IS_HOT/} is-hot{endif/} {if ICON_CLASSES/}rw-Button--iconText{else/}rw-Button--text{endif/} #CSS_CLASSES#" href="#LINK_URL#" title="#LABEL!ATTR#" #LINK_ATTR# {if IS_DISABLED/}disabled{endif/}>',
'  <span class="rw-Button-label">',
'    <span class="rw-Button-icon #ICON_CLASSES#" aria-hidden="true"></span>',
'  </span>',
'</a>'))
);
wwv_flow_imp_shared.create_plugin_act_position(
 p_id=>wwv_flow_imp.id(202451330428284162)
,p_plugin_id=>wwv_flow_imp.id(54835313684096547)
,p_name=>'opcao'
,p_static_id=>'OPCAO'
,p_apexlang_name=>'opcao'
,p_display_sequence=>10
,p_type=>'TEMPLATE'
,p_template_id=>wwv_flow_imp.id(202451019101281877)
);
end;
/
begin
wwv_flow_imp.component_end;
end;
/
