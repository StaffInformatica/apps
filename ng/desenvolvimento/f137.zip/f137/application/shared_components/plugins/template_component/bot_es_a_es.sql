prompt --application/shared_components/plugins/template_component/bot_es_a_es
begin
--   Manifest
--     PLUGIN: BOT_ES_A__ES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_plugin(
 p_id=>wwv_flow_imp.id(178069393373412252)
,p_plugin_type=>'TEMPLATE COMPONENT'
,p_theme_id=>nvl(wwv_flow_application_install.get_theme_id, '')
,p_name=>'BOT_ES_A__ES'
,p_display_name=>unistr('Bot\00F5es a\00E7\00F5es')
,p_apexlang_name=>'botesAes'
,p_supported_component_types=>'REPORT'
,p_image_prefix=>nvl(wwv_flow_application_install.get_static_plugin_file_prefix('TEMPLATE COMPONENT','BOT_ES_A__ES'),'')
,p_partial_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{if APEX$IS_LAZY_LOADING/}',
'  <div></div>',
'  {if MY_SECOND_PLACEHOLDER%assigned/}<div></div>{endif/}',
'{else/}',
'    <a href="#LINK#" #RECURSO#>',
'        <button class="t-Button t-Button--noLabel t-Button--icon js-ignoreChange st-border-radius-100  lto70204071365924982_0" style="height: 48px; width: 48px;" type="button" id="B70204071365924982" title="#LABEL#" aria-label="#HELP#">',
'            <span class="t-Icon fa #ICON#" aria-hidden="true"></span>',
'        </button> ',
'    </a>',
'{endif/}'))
,p_default_escape_mode=>'HTML'
,p_translate_this_template=>false
,p_api_version=>1
,p_report_body_template=>'<ul style="display: flex; justify-content: center;">#APEX$ROWS#</ul>'
,p_report_row_template=>'<div style="margin-right:4px;" #APEX$ROW_IDENTIFICATION#>#APEX$PARTIAL#</div>'
,p_report_placeholder_count=>3
,p_standard_attributes=>'REGION_TEMPLATE'
,p_substitute_attributes=>true
,p_version_scn=>'46143111874284'
,p_subscribe_plugin_settings=>false
,p_version_identifier=>'1.0'
,p_files_version=>1
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(48118389243242614)
,p_plugin_id=>wwv_flow_imp.id(178069393373412252)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>5
,p_display_sequence=>50
,p_static_id=>'HELP'
,p_prompt=>'Help'
,p_apexlang_name=>'help'
,p_attribute_type=>'SESSION STATE VALUE'
,p_is_required=>false
,p_escape_mode=>'HTML'
,p_column_data_types=>'VARCHAR2'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(192720018427290150)
,p_plugin_id=>wwv_flow_imp.id(178069393373412252)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>1
,p_display_sequence=>10
,p_static_id=>'ICON'
,p_prompt=>'Icon'
,p_apexlang_name=>'icon'
,p_attribute_type=>'SESSION STATE VALUE'
,p_is_required=>false
,p_escape_mode=>'HTML'
,p_column_data_types=>'VARCHAR2'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(192720432172290153)
,p_plugin_id=>wwv_flow_imp.id(178069393373412252)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>2
,p_display_sequence=>20
,p_static_id=>'LABEL'
,p_prompt=>'Label'
,p_apexlang_name=>'label'
,p_attribute_type=>'SESSION STATE VALUE'
,p_is_required=>false
,p_escape_mode=>'HTML'
,p_column_data_types=>'VARCHAR2'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(192720854610290154)
,p_plugin_id=>wwv_flow_imp.id(178069393373412252)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>3
,p_display_sequence=>30
,p_static_id=>'LINK'
,p_prompt=>'Link'
,p_apexlang_name=>'link'
,p_attribute_type=>'SESSION STATE VALUE'
,p_is_required=>false
,p_escape_mode=>'HTML'
,p_column_data_types=>'VARCHAR2'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(192721214315290157)
,p_plugin_id=>wwv_flow_imp.id(178069393373412252)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>4
,p_display_sequence=>40
,p_static_id=>'MY_SECOND_PLACEHOLDER'
,p_prompt=>'My Second Placeholder'
,p_apexlang_name=>'mySecondPlaceholder'
,p_attribute_type=>'SESSION STATE VALUE'
,p_is_required=>false
,p_escape_mode=>'HTML'
,p_column_data_types=>'VARCHAR2'
,p_is_translatable=>false
);
wwv_flow_imp_shared.create_plugin_attribute(
 p_id=>wwv_flow_imp.id(48124689252210619)
,p_plugin_id=>wwv_flow_imp.id(178069393373412252)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>6
,p_display_sequence=>60
,p_static_id=>'RECURSO'
,p_prompt=>'Recurso'
,p_apexlang_name=>'recurso'
,p_attribute_type=>'SESSION STATE VALUE'
,p_is_required=>false
,p_escape_mode=>'HTML'
,p_column_data_types=>'VARCHAR2'
,p_is_translatable=>false
);
end;
/
begin
wwv_flow_imp.component_end;
end;
/
