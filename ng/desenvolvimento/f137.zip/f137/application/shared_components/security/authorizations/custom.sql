prompt --application/shared_components/security/authorizations/custom
begin
--   Manifest
--     SECURITY SCHEME: Custom
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(268417739962853942)
,p_name=>'Custom'
,p_scheme_type=>'NATIVE_FUNCTION_BODY'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return pkg_controle_acesso.verifica_permissao(',
'     :APP_USER,',
'     :P0_CODIGO_ARTEFATO',
');',
''))
,p_error_message=>unistr('Controle de acesso: Voc\00EA n\00E3o possuiu permiss\00E3o para acessar essa funcionalidade. Entre em contato como administrador do sistema para conceder acesso.')
,p_version_scn=>1
,p_caching=>'BY_USER_BY_PAGE_VIEW'
);
wwv_flow_imp.component_end;
end;
/
