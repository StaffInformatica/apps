prompt --application/shared_components/security/authorizations/custom
begin
--   Manifest
--     SECURITY SCHEME: Custom
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(268417739962853942)
,p_name=>'Custom'
,p_static_id=>'custom'
,p_scheme_type=>'NATIVE_FUNCTION_BODY'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'plsql_function_body', wwv_flow_string.join(wwv_flow_t_varchar2(
    'begin',
    '',
    'select replace(pkg_ui.retorna_label_botao(''erro-controle-acesso''),''#CODIGO_ARTEFATO#'',:P0_CODIGO_ARTEFATO) into :P0_LABEL_CONTROLE_ACESSO from dual;',
    '',
    'return pkg_controle_acesso.verifica_permissao(',
    '     :APP_USER,',
    '     :P0_CODIGO_ARTEFATO',
    ');',
    'end;')))).to_clob
,p_error_message=>'&P0_LABEL_CONTROLE_ACESSO.'
,p_version_scn=>'50537663369200'
,p_caching=>'BY_USER_BY_PAGE_VIEW'
,p_updated_on=>wwv_flow_imp.dz('20260909210545Z')
,p_updated_by=>'DEVNORTHONN'
);
wwv_flow_imp.component_end;
end;
/
