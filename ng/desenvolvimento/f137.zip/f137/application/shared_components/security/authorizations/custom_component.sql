prompt --application/shared_components/security/authorizations/custom_component
begin
--   Manifest
--     SECURITY SCHEME: Custom component
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(268493976712237802)
,p_name=>'Custom component'
,p_static_id=>'custom-component'
,p_scheme_type=>'NATIVE_FUNCTION_BODY'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'plsql_function_body', wwv_flow_string.join(wwv_flow_t_varchar2(
    'return true;',
    '')))).to_clob
,p_error_message=>unistr('Voc\00EA n\00E3o tem permiss\00E3o para alterar a foto')
,p_version_scn=>'1'
,p_caching=>'BY_COMPONENT'
);
wwv_flow_imp.component_end;
end;
/
