prompt --application/shared_components/logic/application_items/g_fos_tooltip_attr_1
begin
--   Manifest
--     APPLICATION ITEM: G_FOS_TOOLTIP_ATTR_1
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(126181355613312157)
,p_name=>'G_FOS_TOOLTIP_ATTR_1'
,p_protection_level=>'I'
,p_item_comment=>'This item is used for the FOS - Tooltip Plug-in'
,p_version_scn=>'SH256:tuC8zoAWqzYdMl61KOLWWc-PLrUB2bG2gBxrpuJ2LvI'
);
wwv_flow_imp.component_end;
end;
/
