prompt --application/shared_components/logic/application_items/a_reset_breadcrumb1
begin
--   Manifest
--     APPLICATION ITEM: A_RESET_BREADCRUMB1
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(159562852074309458)
,p_name=>'A_RESET_BREADCRUMB1'
,p_protection_level=>'S'
,p_version_scn=>44351908749030
);
wwv_flow_imp.component_end;
end;
/
