prompt --application/shared_components/logic/application_items/g_fos_tooltip_attr_2
begin
--   Manifest
--     APPLICATION ITEM: G_FOS_TOOLTIP_ATTR_2
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(126181178275312141)
,p_name=>'G_FOS_TOOLTIP_ATTR_2'
,p_protection_level=>'I'
,p_item_comment=>'This item is used for the FOS - Tooltip Plug-in'
,p_version_scn=>'SH256:FBiSiHN62lD0NpUwe6Szq0ZmBeYMNzCf_MyO9zS6q4Y'
);
wwv_flow_imp.component_end;
end;
/
