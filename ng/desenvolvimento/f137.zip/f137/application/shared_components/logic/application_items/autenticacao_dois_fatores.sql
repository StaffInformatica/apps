prompt --application/shared_components/logic/application_items/autenticacao_dois_fatores
begin
--   Manifest
--     APPLICATION ITEM: AUTENTICACAO_DOIS_FATORES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(469620565056539849)
,p_name=>'AUTENTICACAO_DOIS_FATORES'
,p_protection_level=>'I'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
