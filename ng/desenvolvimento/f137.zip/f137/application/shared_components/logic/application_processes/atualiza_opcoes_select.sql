prompt --application/shared_components/logic/application_processes/atualiza_opcoes_select
begin
--   Manifest
--     APPLICATION PROCESS: ATUALIZA_OPCOES_SELECT
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(122625447239266523)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_name=>'ATUALIZA_OPCOES_SELECT'
,p_static_id=>'atualiza-opcoes-select'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_html varchar2(32767);',
'begin',
'',
'    l_html :=',
'        PKG_FORMULARIO_DINAMICO.gerar_opcoes_select_lov(',
'            p_lov_name    => apex_application.g_x01,',
'            p_contador    => to_number(apex_application.g_x02),',
'            p_valor_atual => apex_application.g_x03,',
'            p_null_text   => apex_application.g_x04',
'        );',
'',
'    htp.prn(l_html);',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>'SH256:101RSRiM2UR6iSFYrqfwmpD0phh5WTd7SjWLSxHrgf8'
);
wwv_flow_imp.component_end;
end;
/
