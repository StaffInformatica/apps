prompt --application/shared_components/logic/application_processes/get_url_maisdetalhes
begin
--   Manifest
--     APPLICATION PROCESS: GET_URL_MAISDETALHES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.16'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(2370691985822767)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_URL_MAISDETALHES'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_url VARCHAR2(2000);',
'BEGIN',
unistr('    -- apex_application.g_x01 \00E9 como o APEX recebe o primeiro par\00E2metro via AJAX'),
'    l_url := pkg_ui.url_mais_detalhes_antiga(apex_application.g_x01,apex_application.g_x02,apex_application.g_x03,apex_application.g_x04);',
'',
'    -- Retornamos a URL em formato JSON',
'    apex_json.open_object;',
'    apex_json.write(''url'', l_url);',
'    apex_json.close_object;',
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        -- Em caso de erro, retorne um status de erro',
'        htp.p(''{"error":"'' || SQLERRM || ''"}'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>45500972089562
);
wwv_flow_imp.component_end;
end;
/
