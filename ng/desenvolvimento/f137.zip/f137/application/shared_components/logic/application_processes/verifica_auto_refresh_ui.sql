prompt --application/shared_components/logic/application_processes/verifica_auto_refresh_ui
begin
--   Manifest
--     APPLICATION PROCESS: VERIFICA_AUTO_REFRESH_UI
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(211845315831123118)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'VERIFICA_AUTO_REFRESH_UI'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_package      varchar2(200);',
'    l_sql          clob;',
'    l_atualizar    varchar2(1);',
'    l_modo_refresh  varchar2(30);',
'begin',
'    l_package := ''UI_MPD_'' || apex_application.g_x01;',
'',
'    if not pkg_ui.existe_funcao_package(',
'        p_package_name  => l_package,',
'        p_function_name => ''SQL_AUTO_REFRESH''',
'    ) then',
'        apex_json.open_object;',
'        apex_json.write(''ativo'', false);',
'        apex_json.write(''atualizar'', false);',
'        apex_json.close_object;',
'        return;',
'    end if;',
'',
'    execute immediate',
'        ''begin :ret := '' || dbms_assert.simple_sql_name(l_package) ||',
'        ''.sql_auto_refresh(:p_modo_refresh, :p1, :p2, :p3, :p4); end;''',
'        using out l_sql,',
'              in apex_application.g_x02,',
'              in apex_application.g_x03,',
'              in apex_application.g_x04,',
'              in apex_application.g_x05,',
'              in apex_application.g_x06;',
'',
'    execute immediate',
'        ''select atualizar, modo_refresh from ('' || l_sql || '') where rownum = 1''',
'        into l_atualizar, l_modo_refresh;',
'',
'    apex_json.open_object;',
'    apex_json.write(''ativo'', true);',
'    apex_json.write(''atualizar'', case when l_atualizar = ''S'' then true else false end);',
'    apex_json.write(''modoRefresh'', nvl(l_modo_refresh, ''ONCE''));',
'    apex_json.close_object;',
'',
'exception',
'    when others then',
'        apex_json.open_object;',
'        apex_json.write(''ativo'', false);',
'        apex_json.write(''atualizar'', false);',
'        apex_json.write(''erro'', sqlerrm);',
'        apex_json.close_object;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>47156773028642
);
wwv_flow_imp.component_end;
end;
/
