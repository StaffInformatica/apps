prompt --application/shared_components/logic/application_processes/set_tenant_global
begin
--   Manifest
--     APPLICATION PROCESS: SET_TENANT_GLOBAL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(147605278906596043)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_name=>'SET_TENANT_GLOBAL'
,p_static_id=>'set-tenant-global'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_tenant VARCHAR2(100);',
'BEGIN',
'    l_tenant := apex_application.g_x01;',
'',
unistr('    -- Atualiza o item de sess\00E3o'),
'    apex_util.set_session_state(''P0_TENANT_INFORMADO'', l_tenant);',
'',
'    -- Retorna o valor para o JavaScript',
'    htp.p(l_tenant);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>'45783077691214'
);
wwv_flow_imp.component_end;
end;
/
