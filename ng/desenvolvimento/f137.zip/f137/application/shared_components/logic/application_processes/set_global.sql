prompt --application/shared_components/logic/application_processes/set_global
begin
--   Manifest
--     APPLICATION PROCESS: SET_GLOBAL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(4901095523835540)
,p_process_sequence=>1
,p_process_point=>'AFTER_LOGIN'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SET_GLOBAL'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_conta_tenant number;',
'begin',
'   ',
'    Select ID into :ID_USUARIO_LOGADO FROM MPD_USUARIO WHERE UPPER(LOGIN) = UPPER(:APP_USER);',
'',
unistr('    --Se o usu\00E1rio logado possuir apenas um tenant, ent\00E3o deve alimentar a variavel global para sugerir tenant nas telas de formul\00E1rio'),
'    select count(1) into l_conta_tenant',
'                from mpd_usuario_tenant',
'                where id_usuario = (select id from mpd_usuario where lower(login) = lower(APEX_CUSTOM_AUTH.GET_USER));',
'    if l_conta_tenant = 1 then',
'        select id_tenant into :P0_TENANT_SUGERIDO',
'                    from mpd_usuario_tenant',
'                    where rownum = 1 and id_usuario = (select id from mpd_usuario where lower(login) = lower(APEX_CUSTOM_AUTH.GET_USER));',
'    end if;',
'',
'    select pkg_ui.retorna_label_tela(''filtrar-por''),',
'           pkg_ui.retorna_label_botao(''opcao''),',
'           pkg_ui.retorna_label_botao(''maisdetalhes''),',
'           pkg_ui.retorna_label_botao(''adicionar-favorito''),',
'           pkg_ui.retorna_label_botao(''remover-favorito''),',
'           pkg_ui.retorna_label_botao(''fixar-desfixar''),',
'           pkg_ui.retorna_label_botao(''visao-card''),',
'           pkg_ui.retorna_label_botao(''visao-lista''),',
'           pkg_ui.retorna_label_botao(''mostra-esconde-filtro''),',
'           pkg_ui.retorna_label_botao(''historico-exclusao''),',
'           pkg_ui.retorna_label_botao(''novo''),',
'           pkg_ui.retorna_label_botao(''voltar''),',
'           pkg_ui.retorna_label_botao(''configuracao-lista''),',
'           pkg_ui.retorna_label_botao(''gravar''),',
'           pkg_ui.retorna_label_botao(''alterar-idioma''),',
'           pkg_ui.retorna_label_botao(''prefiltro''),',
'           pkg_ui.retorna_label_tela(''ordenar''),',
'           pkg_ui.retorna_label_botao(''proximo''),',
'           pkg_ui.retorna_label_botao(''concluir''),',
'           pkg_ui.retorna_label_botao(''selecionar''),',
'           pkg_ui.retorna_label_botao(''acessar-cadastro''),',
'           pkg_ui.retorna_label_botao(''exibir-todos''),',
'           pkg_ui.retorna_label_coluna(''mpd_usuario.ind_log_execucao'') ',
'    into :P0_LABEL_FILTRAR, :P0_LABEL_OPCAO, :P0_LABEL_MAIS_DETALHES,:P0_LABEL_ADICIONAR_FAV,:P0_LABEL_REMOVER_FAV,:P0_LABEL_FIXAR,:P0_LABEL_VISAO_CARD,',
'    :P0_LABEL_VISAO_LISTA,:P0_LABEL_ESCONDER_MOSTRAR_PESQUISA,:P0_LABEL_HISTORICO_EXCLUSAO,:P0_LABEL_NOVO,:P0_LABEL_VOLTAR, :P0_LABEL_CONFIGURACAO_LISTA,:P0_LABEL_SALVAR,',
'    :P0_LABEL_SELECIONAR_IDIOMA, :P0_LABEL_PREFILTRO, :P0_LABEL_ORDENAR, :P0_LABEL_PROXIMO, :P0_LABEL_CONCLUIR, :P0_LABEL_SELECIONAR, :P0_LABEL_ACESSAR_CADASTRO, :P0_LABEL_EXIBIR_TODOS, :P0_LABEL_ATIVAR_RASTREAMENTO from dual;    ',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_version_scn=>46526060013380
);
wwv_flow_imp.component_end;
end;
/
