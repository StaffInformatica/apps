prompt --application/shared_components/logic/application_processes/limpar_reset_breadcrumb
begin
--   Manifest
--     APPLICATION PROCESS: LIMPAR_RESET_BREADCRUMB
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(211560625957066295)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_name=>'LIMPAR_RESET_BREADCRUMB'
,p_static_id=>'limpar-reset-breadcrumb'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    apex_util.set_session_state(''P0_RESET_BREADCRUMB'', null);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>'47150258162616'
,p_created_on=>wwv_flow_imp.dz('20260601011503Z')
,p_updated_on=>wwv_flow_imp.dz('20260601011503Z')
,p_created_by=>'DEVNORTHONN'
,p_updated_by=>'DEVNORTHONN'
);
wwv_flow_imp.component_end;
end;
/
