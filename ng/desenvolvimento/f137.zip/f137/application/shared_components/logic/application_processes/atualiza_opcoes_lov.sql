prompt --application/shared_components/logic/application_processes/atualiza_opcoes_lov
begin
--   Manifest
--     APPLICATION PROCESS: ATUALIZA_OPCOES_LOV
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(122896166685517758)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_name=>'ATUALIZA_OPCOES_LOV'
,p_static_id=>'atualiza-opcoes-lov'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_html varchar2(32767);',
'',
'    l_tipo        varchar2(10);',
'    l_coluna      varchar2(4000);',
'    l_lov_name    varchar2(4000);',
'    l_contador    number;',
'    l_valor_atual varchar2(4000);',
'',
'begin',
'',
'    l_tipo        := apex_application.g_x01;',
'    l_coluna      := apex_application.g_x02;',
'    l_lov_name    := apex_application.g_x03;',
'    l_contador    := to_number(apex_application.g_x04);',
'    l_valor_atual := apex_application.g_x05;',
'',
'    l_html := PKG_FORMULARIO_DINAMICO.gerar_opcao_lov(',
'        p_tipo        => l_tipo,',
'        p_coluna      => l_coluna,',
'        p_lov_name    => l_lov_name,',
'        p_contador    => l_contador,',
'        p_valor_atual => l_valor_atual,',
'        p_ajax        => true',
'    );',
'',
'    htp.prn(l_html);',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>'SH256:_f9APRcqJ0YqBeOmGwq3tsU05TpO4-m5sZiElUE7M4Q'
);
wwv_flow_imp.component_end;
end;
/
