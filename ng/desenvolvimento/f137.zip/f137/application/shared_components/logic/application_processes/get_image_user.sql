prompt --application/shared_components/logic/application_processes/get_image_user
begin
--   Manifest
--     APPLICATION PROCESS: GET_IMAGE_USER
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(403804847432071609)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_IMAGE_USER'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    for c1 in (select *',
'               from   MPD_USUARIO',
'               where  Upper(login) = Upper(:IMAGE_USER_ID)) loop',
'        sys.htp.init;',
'        sys.owa_util.Mime_header(c1.foto_mimetype, false);',
'        sys.htp.P(''Content-length: ''|| sys.dbms_lob.Getlength(c1.foto));',
'        sys.htp.P(''Content-Disposition: attachment; filename="''|| c1.foto_name|| ''"'');',
'        sys.htp.P(''Cache-Control: max-age=3600'');',
'        sys.owa_util.http_header_close;',
'        sys.wpg_docload.Download_file(c1.foto);',
'        apex_application.stop_apex_engine;',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>41595924327038
);
wwv_flow_imp.component_end;
end;
/
