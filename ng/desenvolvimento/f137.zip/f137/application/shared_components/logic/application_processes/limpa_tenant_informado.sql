prompt --application/shared_components/logic/application_processes/limpa_tenant_informado
begin
--   Manifest
--     APPLICATION PROCESS: Limpa tenant informado
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(122993572422477936)
,p_process_sequence=>1
,p_process_point=>'BEFORE_HEADER'
,p_process_name=>'Limpa tenant informado'
,p_static_id=>'limpa-tenant-informado'
,p_process_sql_clob=>':P0_TENANT_INFORMADO := null;'
,p_process_clob_language=>'PLSQL'
,p_process_when=>'9004'
,p_process_when_type=>'CURRENT_PAGE_NOT_EQUAL_CONDITION'
,p_version_scn=>'SH256:urpAG_1mknrVGoByxeXNbZ_4ORD4d55SM4ogchn7ARw'
);
wwv_flow_imp.component_end;
end;
/
