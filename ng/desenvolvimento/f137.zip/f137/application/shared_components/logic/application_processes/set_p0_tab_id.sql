prompt --application/shared_components/logic/application_processes/set_p0_tab_id
begin
--   Manifest
--     APPLICATION PROCESS: SET_P0_TAB_ID
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(37207881060691494)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SET_P0_TAB_ID'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    if apex_application.G_X01 is not null then',
'      APEX_UTIL.SET_SESSION_STATE(''P0_TAB_ID'',APEX_APPLICATION.G_X01);',
'    end if;',
'',
'    apex_json.open_object;  ',
'    apex_json.write(''success'', true);  ',
'    apex_json.close_object; ',
'    exception',
'        when others then',
'            apex_json.open_object;',
'            apex_json.write(''success'', false);',
'            apex_json.write(''message'', sqlerrm);',
'            apex_json.close_object;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>45626524209838
);
wwv_flow_imp.component_end;
end;
/
