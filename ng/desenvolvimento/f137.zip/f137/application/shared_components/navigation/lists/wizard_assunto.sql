prompt --application/shared_components/navigation/lists/wizard_assunto
begin
--   Manifest
--     LIST: Wizard assunto
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(400581708731675935)
,p_name=>'Wizard assunto'
,p_static_id=>'wizard-assunto'
,p_version_scn=>'1'
);
wwv_flow_imp.component_end;
end;
/
