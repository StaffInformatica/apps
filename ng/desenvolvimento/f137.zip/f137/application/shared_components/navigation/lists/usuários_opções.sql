prompt --application/shared_components/navigation/lists/usuários_opções
begin
--   Manifest
--     LIST: Usuários Opções
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(155397908192876361)
,p_name=>unistr('Usu\00E1rios Op\00E7\00F5es')
,p_static_id=>unistr('usu\00E1rios-op\00E7\00F5es')
,p_version_scn=>'42176084411222'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(157887714683127553)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Funcionalidades'
,p_static_id=>'funcionalidades'
,p_list_item_link_target=>'f?p=&APP_ID.:276:&SESSION.::&DEBUG.:276:P276_ID:&P112_ID.:'
,p_list_item_icon=>'fa-tasks-alt'
,p_list_text_01=>unistr('Permite atribuir, alterar ou excluir funcionalidades do usu\00E1rio')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(157744928191966021)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>unistr('Papel do usu\00E1rio')
,p_static_id=>unistr('papel-do-usu\00E1rio')
,p_list_item_link_target=>'f?p=&APP_ID.:269:&SESSION.::&DEBUG.:269:P269_ID:&P112_ID.:'
,p_list_item_icon=>'fa-address-card-o'
,p_list_text_01=>unistr('Permite atribuir, alterar ou excluir o pap\00E9l do usu\00E1rio')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
