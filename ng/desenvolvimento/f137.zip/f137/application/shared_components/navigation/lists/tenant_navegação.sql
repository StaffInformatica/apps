prompt --application/shared_components/navigation/lists/tenant_navegação
begin
--   Manifest
--     LIST: Tenant navegação
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.16'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(152760404201442644)
,p_name=>unistr('Tenant navega\00E7\00E3o')
,p_list_status=>'PUBLIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(152760970470442652)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('Conceder acesso a usu\00E1rios')
,p_list_item_link_target=>'f?p=&APP_ID.:155:&SESSION.::&DEBUG.::P155_ID_TENANT:&P101_ID.:'
,p_list_item_icon=>'fa-user-lock'
,p_list_text_01=>unistr('Usu\00E1rios que possuem acesso ao tenant')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
