prompt --application/shared_components/navigation/lists/menu_teste
begin
--   Manifest
--     LIST: Menu teste
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.16'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(43519232309076784)
,p_name=>'Menu teste'
,p_list_status=>'PUBLIC'
,p_version_scn=>42064134667673
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(43519439436076783)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'teste'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
