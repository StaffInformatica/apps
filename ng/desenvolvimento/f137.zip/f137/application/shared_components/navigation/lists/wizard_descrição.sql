prompt --application/shared_components/navigation/lists/wizard_descrição
begin
--   Manifest
--     LIST: Wizard Descrição
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(278146711236856156)
,p_name=>unistr('Wizard Descri\00E7\00E3o')
,p_static_id=>unistr('wizard-descri\00E7\00E3o')
,p_version_scn=>'1'
);
wwv_flow_imp.component_end;
end;
/
