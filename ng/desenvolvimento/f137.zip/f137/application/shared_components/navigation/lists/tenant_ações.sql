prompt --application/shared_components/navigation/lists/tenant_ações
begin
--   Manifest
--     LIST: Tenant Ações
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(155403814217910704)
,p_name=>unistr('Tenant A\00E7\00F5es')
,p_list_status=>'PUBLIC'
,p_version_scn=>42176084410539
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(155405098206917088)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Excluir'
,p_list_item_link_target=>'f?p=&APP_ID.:104:&SESSION.::&DEBUG.:104:P104_ID:&P101_ID.:'
,p_list_item_icon=>'fa-trash'
,p_list_text_06=>'u-danger'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
