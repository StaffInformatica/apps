prompt --application/shared_components/navigation/lists/usuários_ações
begin
--   Manifest
--     LIST: Usuários Ações
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(255413956147887059)
,p_name=>unistr('Usu\00E1rios A\00E7\00F5es')
,p_static_id=>unistr('usu\00E1rios-a\00E7\00F5es')
,p_version_scn=>'42176084410894'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(155397587111868883)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Excluir'
,p_static_id=>'excluir'
,p_list_item_link_target=>'f?p=&APP_ID.:108:&SESSION.::&DEBUG.:108:P108_ID:&P112_ID.:'
,p_list_item_icon=>'fa-trash'
,p_list_text_06=>'u-danger'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
