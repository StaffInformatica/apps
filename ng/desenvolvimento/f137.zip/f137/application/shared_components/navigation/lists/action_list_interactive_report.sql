prompt --application/shared_components/navigation/lists/action_list_interactive_report
begin
--   Manifest
--     LIST: Action list interactive report
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(265143456876865031)
,p_name=>'Action list interactive report'
,p_static_id=>'action-list-interactive-report'
,p_version_scn=>'SH256:y-mOjG56cuoA_GPXRfq_Vxb4WkPYB2aFsEaBiqqsEaQ'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(265143631614865031)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Colunas'
,p_static_id=>'colunas'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-columns'
,p_list_text_01=>'Permitir ocultar, mostrar e mover colunas'
,p_list_text_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'onclick="apex.theme.openRegion(''COLUNAS'');"',
''))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(265157099845139737)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Destacar'
,p_static_id=>'destacar'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-star-o'
,p_list_text_01=>unistr('Permite aplicar destaque as linhas de acordo com defini\00E7\00F5es realizadas pelo usu\00E1rio')
,p_list_text_03=>unistr('data-id="irHighlight" title="Permite aplicar destaque as linhas de acordo com defini\00E7\00F5es realizadas pelo usu\00E1rio"')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(265150687340969472)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Salvar dados'
,p_static_id=>'salvar-dados'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-download'
,p_list_text_01=>unistr('Permite salvar o relat\00F3rio em diversos formatos')
,p_list_text_03=>unistr('data-id="irDownload" title="Permite salvar o relat\00F3rio em diversos formatos"')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
