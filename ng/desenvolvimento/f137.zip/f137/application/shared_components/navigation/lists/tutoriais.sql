prompt --application/shared_components/navigation/lists/tutoriais
begin
--   Manifest
--     LIST: Tutoriais
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(255163867117481585)
,p_name=>'Tutoriais'
,p_static_id=>'tutoriais'
,p_version_scn=>'1'
);
wwv_flow_imp.component_end;
end;
/
