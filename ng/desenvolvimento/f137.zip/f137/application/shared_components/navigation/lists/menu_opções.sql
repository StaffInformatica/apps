prompt --application/shared_components/navigation/lists/menu_opções
begin
--   Manifest
--     LIST: Menu Opções
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(302319969142671044)
,p_name=>unistr('Menu Op\00E7\00F5es')
,p_static_id=>unistr('menu-op\00E7\00F5es')
,p_version_scn=>'1'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(302320589583671047)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('A\00E7\00F5es')
,p_static_id=>unistr('a\00E7\00F5es')
,p_list_item_link_target=>'f?p=&APP_ID.:261:&SESSION.::&DEBUG.:261:P261_ID:&P260_ID.:'
,p_list_item_icon=>'fa-bolt'
,p_list_text_01=>unistr('Permite realizar a cria\00E7\00E3o e altera\00E7\00E3o das a\00E7\00F5es do menu.')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
