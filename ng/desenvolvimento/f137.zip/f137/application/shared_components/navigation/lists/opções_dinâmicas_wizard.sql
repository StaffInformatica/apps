prompt --application/shared_components/navigation/lists/opções_dinâmicas_wizard
begin
--   Manifest
--     LIST: Opções dinâmicas wizard
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(18239831529276586)
,p_name=>unistr('Op\00E7\00F5es din\00E2micas wizard')
,p_static_id=>unistr('op\00E7\00F5es-din\00E2micas-wizard')
,p_list_type=>'SQL_QUERY'
,p_list_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null, ',
'       label label, ',
'       ''javascript:void(0);'' target,',
'       null image',
'from srv_texto_traduzido a',
'left join srv_texto b on b.id = a.id_texto',
'where b.tag in (''botao.alterar'',''botao.maisdetalhes'',''botao.excluir'')',
'and a.id_idioma = :IDIOMA_LOGADO',
'order by case tag when ''botao.alterar'' then 1 when ''botao.maisdetalhes'' then 2 when ''botao.excluir'' then 3 end'))
,p_version_scn=>'44299043927923'
);
wwv_flow_imp.component_end;
end;
/
