prompt --application/shared_components/navigation/lists/menu_dinamico_drawback
begin
--   Manifest
--     LIST: Menu dinamico drawback
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(16670953530801572)
,p_name=>'Menu dinamico drawback'
,p_list_type=>'SQL_QUERY'
,p_list_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    1 "level",',
'    pkg_ui.retorna_titulo_menu(a.id) || case when c.codigo_artefato is not null then '' (''||c.codigo_artefato||'')'' else '' (Em desenvolvimento)'' end "label",',
'    case when a.id = b.id_menu then ''f?p=&APP_ID.:''||case when c.tipo = ''CD'' then e.codigo_artefato else c.codigo_artefato end||'':&SESSION.::NO:''||case when c.tipo = ''CD'' then e.codigo_artefato else c.codigo_artefato end||'':P0_CODIGO_ARTEFATO,P''||cas'
||'e when c.tipo = ''CD'' then e.codigo_artefato else c.codigo_artefato end||''_CODIGO_ARTEFATO:''||c.codigo_artefato||'',''||c.codigo_artefato else '''' end as target,',
'    case when :P0_CODIGO_ARTEFATO = c.codigo_artefato then ''YES'' else ''NO'' end as is_current,',
'    case when PKG_CONTROLE_ACESSO.retorno_verifica_permissao(:APP_USER,c.codigo_artefato) = ''true'' then a.icone else case when c.codigo_artefato is null then a.icone else ''fa-lock'' end end as image',
'    from mpd_menu a',
'left join mpd_menu_acao b on b.id_menu = a.id',
'left join mpd_funcionalidade c on c.id = b.id_funcionalidade',
'left join mpd_funcionalidade_tela_dinamica d on d.id_funcionalidade = c.id',
'left join mpd_funcionalidade e on e.id = d.id_funcionalidade_base',
'left join srv_menu a1 on a1.id = a.id            ',
'left join srv_sistema_versionado b1 on b1.id = a1.id_sistema_versionado            ',
'left join srv_sistema c1 on c1.id = b1.id_sistema',
'where /*a.id = b.id_menu and */a.id_nivel_pai in (select id from mpd_menu where titulo = ''Drawback'')',
'and upper(c1.codigo_sistema) = upper(:app_name)',
'start with',
'    id_nivel_pai is null',
'connect by',
'    prior a.id = a.id_nivel_pai ',
'    order by a.ordenacao'))
,p_list_status=>'PUBLIC'
,p_version_scn=>44275904512142
);
wwv_flow_imp.component_end;
end;
/
