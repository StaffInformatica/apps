prompt --application/shared_components/navigation/lists/teste
begin
--   Manifest
--     LIST: teste
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(185396566385915369)
,p_name=>'teste'
,p_list_type=>'SQL_QUERY'
,p_list_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    pkg_ui.retorna_titulo_menu(a.id) || case when c.codigo_artefato is not null then '' (''||c.codigo_artefato||'')'' else '''' end text, ',
'    case when a.id = b.id_menu then ''f?p=&APP_ID.:''||case when c.tipo = ''CD'' then e.codigo_artefato else c.codigo_artefato end||'':&SESSION.::NO:''||:APP_PAGE_ID||'':A_RESET_BREADCRUMB1,P0_CODIGO_ARTEFATO,P''||case when c.tipo = ''CD'' then e.codigo_artefa'
||'to else c.codigo_artefato end||''_CODIGO_ARTEFATO:Y,''||c.codigo_artefato||'',''||c.codigo_artefato else '''' end as link,',
'    case when PKG_CONTROLE_ACESSO.retorno_verifica_permissao(:APP_USER,c.codigo_artefato) = ''true'' then /*a.icone*/'''' else case when c.codigo_artefato is null then a.icone else ''fa-lock'' end end as image',
'    from mpd_menu a',
'left join mpd_menu_acao b on b.id_menu = a.id',
'left join mpd_funcionalidade c on c.id = b.id_funcionalidade',
'left join mpd_funcionalidade_tela_dinamica d on d.id_funcionalidade = c.id',
'left join mpd_funcionalidade e on e.id = d.id_funcionalidade_base            ',
'left join srv_menu a1 on a1.id = a.id            ',
'left join srv_sistema_versionado b1 on b1.id = a1.id_sistema_versionado            ',
'left join srv_sistema c1 on c1.id = b1.id_sistema            ',
'where upper(c1.codigo_sistema) = upper(:app_name)',
'and a.id_nivel_pai is null',
'    order  by ',
'        case when a.ordenacao < 7 then a.ordenacao end, 2'))
,p_list_status=>'PUBLIC'
,p_version_scn=>44591015961695
);
wwv_flow_imp.component_end;
end;
/
