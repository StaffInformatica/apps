prompt --application/shared_components/navigation/lists/wizard_incluir_papel_e_funcionalidades
begin
--   Manifest
--     LIST: Wizard incluir papel e funcionalidades
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(197502429407966736)
,p_name=>'Wizard incluir papel e funcionalidades'
,p_static_id=>'wizard-incluir-papel-e-funcionalidades'
,p_version_scn=>'42176084412351'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(197503029310966738)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Funcionalidades'
,p_static_id=>'funcionalidades'
,p_list_item_link_target=>'f?p=&APP_ID.:273:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
