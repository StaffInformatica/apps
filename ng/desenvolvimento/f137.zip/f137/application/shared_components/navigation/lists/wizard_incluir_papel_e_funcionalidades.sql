prompt --application/shared_components/navigation/lists/wizard_incluir_papel_e_funcionalidades
begin
--   Manifest
--     LIST: Wizard incluir papel e funcionalidades
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.16'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(343208830636755218)
,p_name=>'Wizard incluir papel e funcionalidades'
,p_list_status=>'PUBLIC'
,p_version_scn=>42176084412351
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(343209430539755220)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Funcionalidades'
,p_list_item_link_target=>'f?p=&APP_ID.:273:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
