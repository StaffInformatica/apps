prompt --application/shared_components/navigation/lists/perfil_de_usuário
begin
--   Manifest
--     LIST: Perfil de usuário
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(202792140941785973)
,p_name=>unistr('Perfil de usu\00E1rio')
,p_static_id=>unistr('perfil-de-usu\00E1rio')
,p_version_scn=>'1'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(202792385385785983)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Meu Perfil'
,p_static_id=>'meu-perfil'
,p_list_item_link_target=>'f?p=&APP_ID.:133:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(202792799076786006)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Sair'
,p_static_id=>'sair'
,p_list_item_link_target=>'&LOGOUT_URL.'
,p_list_item_current_type=>'NEVER'
);
wwv_flow_imp.component_end;
end;
/
