prompt --application/shared_components/navigation/lists/tenant_opções
begin
--   Manifest
--     LIST: Tenant Opções
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(155400844548892894)
,p_name=>unistr('Tenant Op\00E7\00F5es')
,p_list_status=>'PUBLIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(155403322570907097)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>unistr('Alterar informa\00E7\00F5es')
,p_list_item_link_target=>'f?p=&APP_ID.:103:&SESSION.::&DEBUG.:103:P103_ID:&P101_ID.:'
,p_list_item_icon=>'fa-user'
,p_list_text_01=>unistr('Permite realizar a altera\00E7\00E3o das informa\00E7\00F5es do tenant, como raz\00E3o social, inscri\00E7\00E3o estadual, forma de autentica\00E7\00E3o,numero de licen\00E7as de uso etc .')
,p_list_text_06=>'u-hot'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
