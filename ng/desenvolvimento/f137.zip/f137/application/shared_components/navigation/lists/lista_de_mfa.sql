prompt --application/shared_components/navigation/lists/lista_de_mfa
begin
--   Manifest
--     LIST: Lista de MFA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(314248722088745554)
,p_name=>'Lista de MFA'
,p_list_status=>'PUBLIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(314249011639745555)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>unistr('Aplicativo de Autentica\00E7\00E3o')
,p_list_item_icon=>'fa-mobile'
,p_list_text_01=>unistr('Utiliza aplicativo no celular para gera\00E7\00E3o do c\00F3digo de verifica\00E7\00E3o minuto a minuto')
,p_list_text_03=>'data-id="1"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(314249423025745556)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'E-mail'
,p_list_item_icon=>'fa-envelope-lock'
,p_list_text_01=>unistr('Envia um e-mail com o c\00F3digo de verifica\00E7\00E3o ')
,p_list_text_03=>'data-id="2"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(314249761824745556)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'SMS'
,p_list_item_icon=>'fa-comments-o'
,p_list_item_disp_cond_type=>'NEVER'
,p_list_text_01=>unistr('Envia um SMS com o c\00F3digo de verifica\00E7\00E3o')
,p_list_text_03=>'data-id="3"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
