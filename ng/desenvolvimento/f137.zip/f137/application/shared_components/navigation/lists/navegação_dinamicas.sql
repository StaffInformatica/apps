prompt --application/shared_components/navigation/lists/navegação_dinamicas
begin
--   Manifest
--     LIST: Navegação dinamicas
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(245766554276448469)
,p_name=>unistr('Navega\00E7\00E3o dinamicas')
,p_static_id=>unistr('navega\00E7\00E3o-dinamicas')
,p_list_type=>'FUNCTION_RETURNING_SQL_QUERY'
,p_list_language=>'PLSQL'
,p_list_query=>'return PKG_UI.buscar_acoes(:P9000_ID,:P9000_PAGINA,''N'',false,:P9000_PARAMETRO);'
,p_version_scn=>'45188026599076'
);
wwv_flow_imp.component_end;
end;
/
