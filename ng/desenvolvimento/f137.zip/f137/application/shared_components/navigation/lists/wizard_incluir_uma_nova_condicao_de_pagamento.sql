prompt --application/shared_components/navigation/lists/wizard_incluir_uma_nova_condicao_de_pagamento
begin
--   Manifest
--     LIST: Wizard - Incluir uma nova condicao de pagamento
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(162927087974252752)
,p_name=>'Wizard - Incluir uma nova condicao de pagamento'
,p_static_id=>'wizard-incluir-uma-nova-condicao-de-pagamento'
,p_version_scn=>'45347183884476'
);
wwv_flow_imp.component_end;
end;
/
