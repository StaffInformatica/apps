prompt --application/shared_components/navigation/lists/wizard_incluir_uma_nova_condicao_de_pagamento
begin
--   Manifest
--     LIST: Wizard - Incluir uma nova condicao de pagamento
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(17220686745464270)
,p_name=>'Wizard - Incluir uma nova condicao de pagamento'
,p_list_status=>'PUBLIC'
,p_version_scn=>45347183884476
);
wwv_flow_imp.component_end;
end;
/
