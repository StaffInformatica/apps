prompt --application/shared_components/navigation/lists/wizard_ambiente_de_trabalho
begin
--   Manifest
--     LIST: Wizard ambiente de trabalho
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(399510610402047850)
,p_name=>'Wizard ambiente de trabalho'
,p_static_id=>'wizard-ambiente-de-trabalho'
,p_version_scn=>'1'
);
wwv_flow_imp.component_end;
end;
/
