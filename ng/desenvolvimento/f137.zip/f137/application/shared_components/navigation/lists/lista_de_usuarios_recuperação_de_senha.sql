prompt --application/shared_components/navigation/lists/lista_de_usuarios_recuperação_de_senha
begin
--   Manifest
--     LIST: Lista de usuarios recuperação de senha
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(235728346674089646)
,p_name=>unistr('Lista de usuarios recupera\00E7\00E3o de senha')
,p_list_type=>'SQL_QUERY'
,p_list_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT level_value, label_value, target_value, is_current, image_value, image_attr_value, image_alt_value',
'FROM (',
'select null as level_value ',
'       , "NOME" as label_value ',
'       , "LOGIN" as target_value',
'       , null as is_current ',
'       , "FOTO" as image_value ',
'       , null as image_attr_value ',
'       , null as image_alt_value,',
'       COUNT(*) OVER () AS total_count ',
'from "MPD_USUARIO"',
'where lower(login) = lower(:P9998_USERNAME) or lower(email) = lower(:P9998_USERNAME)',
') sub',
'WHERE total_count > 1;',
'',
''))
,p_list_status=>'PUBLIC'
,p_version_scn=>41743700730286
);
wwv_flow_imp.component_end;
end;
/
