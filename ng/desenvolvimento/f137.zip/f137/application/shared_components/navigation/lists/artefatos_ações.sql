prompt --application/shared_components/navigation/lists/artefatos_ações
begin
--   Manifest
--     LIST: Artefatos Ações
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.16'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(358933243034190159)
,p_name=>unistr('Artefatos A\00E7\00F5es')
,p_list_status=>'PUBLIC'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
