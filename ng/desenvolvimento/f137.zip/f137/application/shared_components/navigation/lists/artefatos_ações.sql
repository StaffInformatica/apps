prompt --application/shared_components/navigation/lists/artefatos_ações
begin
--   Manifest
--     LIST: Artefatos Ações
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(504639644262978641)
,p_name=>unistr('Artefatos A\00E7\00F5es')
,p_static_id=>unistr('artefatos-a\00E7\00F5es')
,p_version_scn=>'1'
);
wwv_flow_imp.component_end;
end;
/
