prompt --application/shared_components/navigation/lists/agendamento_repetir_dias_da_semana
begin
--   Manifest
--     LIST: Agendamento repetir dias da semana
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(356272558044025506)
,p_name=>'Agendamento repetir dias da semana'
,p_list_status=>'PUBLIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(356272822208025507)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Dias da Semana'
,p_list_text_03=>'data-id="1"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
