prompt --application/shared_components/navigation/lists/menu_aplicação
begin
--   Manifest
--     LIST: Menu Aplicação
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(224049059830402036)
,p_name=>unistr('Menu Aplica\00E7\00E3o')
,p_list_type=>'FUNCTION_RETURNING_SQL_QUERY'
,p_list_language=>'PLSQL'
,p_list_query=>'return pkg_menu_dinamico.retorna_sql_menu;'
,p_list_status=>'PUBLIC'
,p_version_scn=>50449599923619
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(189639921163461874)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'teste'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-table'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'4,5'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(185358548458266137)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'menu'
,p_list_item_link_target=>'f?p=&APP_ID.:7:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-search'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'7'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(225896787466177390)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>unistr('Importa\00E7\00E3o de invoice via PDF')
,p_list_item_link_target=>'f?p=&APP_ID.:429:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'429'
);
wwv_flow_imp.component_end;
end;
/
