prompt --application/shared_components/navigation/lists/menu_aplicação
begin
--   Manifest
--     LIST: Menu Aplicação
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.16'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(78342658601613554)
,p_name=>unistr('Menu Aplica\00E7\00E3o')
,p_list_type=>'SQL_QUERY'
,p_list_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    level,',
'    a.label,',
'    a.link as target,',
'    a.is_current,',
'    null image',
'from (',
'    select',
'        0 as id,',
'        null as id_nivel_pai,',
'        pkg_ui.retorna_label_botao(''favoritos'') as label,',
'        null as link,',
'        null is_current,',
'        ''fa-star'' image,',
'        0 ordenacao',
'    from dual',
'    where exists(select 1 from mpd_usuario_artefato_favorito a where upper(login) = upper(apex_custom_auth.get_username) and a.aplicacao = v(''APP_ID'')) ',
'',
'    union all',
'',
'    select',
'        a.id,',
'        0 as id_nivel_pai,',
'        pkg_ui.retorna_titulo_tela(c.codigo_artefato) || case when c.codigo_artefato is not null then '' (''||c.codigo_artefato||'')'' else '''' end "label",                 ',
'        ''f?p=&APP_ID.:''||case when c.tipo = ''CD'' then e.codigo_artefato else c.codigo_artefato end||'':&SESSION.::NO:''||:APP_PAGE_ID||'':P0_RESET_BREADCRUMB,P0_CODIGO_ARTEFATO,P''||case when c.tipo = ''CD'' then e.codigo_artefato else c.codigo_artefato en'
||'d||''_CODIGO_ARTEFATO:S,''||c.codigo_artefato||'',''||c.codigo_artefato as target,',
'        case when :P0_CODIGO_ARTEFATO = c.codigo_artefato then ''YES'' else ''NO'' end as is_current,',
'        null image,',
'        1 ordenacao',
'    from mpd_usuario_artefato_favorito a',
'    left join mpd_funcionalidade c on c.codigo_artefato = a.codigo_artefato',
'    left join mpd_funcionalidade_tela_dinamica d on d.id_funcionalidade = c.id',
'    left join mpd_funcionalidade e on e.id = d.id_funcionalidade_base',
'    where upper(login) = upper(apex_custom_auth.get_username)',
'    and a.aplicacao = v(''APP_ID'')',
'',
'    union all',
'',
'    select',
'        a.id,',
'        a.id_nivel_pai,',
'        pkg_ui.retorna_titulo_menu(a.id) || case when c.codigo_artefato is not null then '' (''||c.codigo_artefato||'')'' else '''' end "label", ',
'        case when a.id = b.id_menu then ''f?p=&APP_ID.:''||case when c.tipo = ''CD'' then e.codigo_artefato else c.codigo_artefato end||'':&SESSION.::NO:''||:APP_PAGE_ID||'':P0_RESET_BREADCRUMB,P0_CODIGO_ARTEFATO,P''||case when c.tipo = ''CD'' then e.codigo_ar'
||'tefato else c.codigo_artefato end||''_CODIGO_ARTEFATO:S,''||c.codigo_artefato||'',''||c.codigo_artefato else '''' end as target,',
'        case when :P0_CODIGO_ARTEFATO = c.codigo_artefato then ''YES'' else ''NO'' end as is_current,    ',
'        case when PKG_CONTROLE_ACESSO.retorno_verifica_permissao(:APP_USER,c.codigo_artefato) = ''true'' or a.id_nivel_pai is not null then /*a.icone*/'''' else case when c.codigo_artefato is null then a.icone else ''fa-lock'' end end as image,',
'        a.ordenacao',
'        from mpd_menu a',
'    left join mpd_menu_acao b on b.id_menu = a.id',
'    left join mpd_funcionalidade c on c.id = b.id_funcionalidade',
'    left join mpd_funcionalidade_tela_dinamica d on d.id_funcionalidade = c.id',
'    left join mpd_funcionalidade e on e.id = d.id_funcionalidade_base            ',
'    left join srv_menu a1 on a1.id = a.id            ',
'    left join srv_sistema_versionado b1 on b1.id = a1.id_sistema_versionado            ',
'    left join srv_sistema c1 on c1.id = b1.id_sistema            ',
'    where upper(c1.codigo_sistema) = upper(:app_name)',
'',
') a',
'start with',
'    id_nivel_pai is null',
'connect by',
'    prior a.id = a.id_nivel_pai ',
'order siblings by a.ordenacao, a.label'))
,p_list_status=>'PUBLIC'
,p_version_scn=>47150290434290
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(43933519934673392)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'teste'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-table'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'4,5'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39652147229477655)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'menu'
,p_list_item_link_target=>'f?p=&APP_ID.:7:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-search'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'7'
);
wwv_flow_imp.component_end;
end;
/
