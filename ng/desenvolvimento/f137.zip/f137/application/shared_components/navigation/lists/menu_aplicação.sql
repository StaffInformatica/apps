prompt --application/shared_components/navigation/lists/menu_aplicação
begin
--   Manifest
--     LIST: Menu Aplicação
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(78342658601613554)
,p_name=>unistr('Menu Aplica\00E7\00E3o')
,p_static_id=>unistr('menu-aplica\00E7\00E3o')
,p_list_type=>'FUNCTION_RETURNING_SQL_QUERY'
,p_list_language=>'PLSQL'
,p_list_query=>'return pkg_menu_dinamico.retorna_sql_menu;'
,p_version_scn=>'50449599923619'
);
wwv_flow_imp.component_end;
end;
/
