prompt --application/shared_components/navigation/lists/cadastro_compartilhado_navegação
begin
--   Manifest
--     LIST: Cadastro Compartilhado navegação
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.16'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(298911657406829014)
,p_name=>unistr('Cadastro Compartilhado navega\00E7\00E3o')
,p_list_status=>'PUBLIC'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
