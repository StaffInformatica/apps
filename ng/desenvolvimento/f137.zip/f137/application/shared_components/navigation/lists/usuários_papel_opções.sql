prompt --application/shared_components/navigation/lists/usuários_papel_opções
begin
--   Manifest
--     LIST: Usuários Papel Opções
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(157794734341415120)
,p_name=>unistr('Usu\00E1rios Papel Op\00E7\00F5es')
,p_static_id=>unistr('usu\00E1rios-papel-op\00E7\00F5es')
,p_version_scn=>'1'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(157794985620415126)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Funcionalidades'
,p_static_id=>'funcionalidades'
,p_list_item_link_target=>'f?p=&APP_ID.:273:&SESSION.::&DEBUG.:273:P273_ID:&P271_ID.:'
,p_list_item_icon=>'fa-tasks-alt'
,p_list_text_01=>'Permite atribuir, alterar ou excluir funcionalidades ao papel'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
