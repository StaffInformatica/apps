prompt --application/shared_components/navigation/lists/opções_wizard
begin
--   Manifest
--     LIST: Opções wizard
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(163918115734678064)
,p_name=>unistr('Op\00E7\00F5es wizard')
,p_list_status=>'PUBLIC'
,p_version_scn=>44299017506572
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(163918295321678077)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'botao.alterar.l'
,p_list_item_icon=>'fa-edit'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(163918710579678080)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'botao.maisdetalhes.l'
,p_list_item_icon=>'fa-info'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(163919065433678082)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'botao.excluir.l'
,p_list_item_icon=>'fa-trash'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
