prompt --application/shared_components/navigation/lists/agendamento_repetir_static
begin
--   Manifest
--     LIST: Agendamento repetir Static
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(501928851756809671)
,p_name=>'Agendamento repetir Static'
,p_static_id=>'agendamento-repetir-static'
,p_version_scn=>'1'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(501930371404809674)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'A Cada 2 Semanas'
,p_static_id=>'a-cada-2-semanas'
,p_list_text_03=>'data-id="4"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(501931087030809674)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'A Cada Ano'
,p_static_id=>'a-cada-ano'
,p_list_text_03=>'data-id="6"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(501930783348809674)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>unistr('A Cada M\00EAs')
,p_static_id=>unistr('a-cada-m\00EAs')
,p_list_text_03=>'data-id="5"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(501929887208809673)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'A Cada Semana'
,p_static_id=>'a-cada-semana'
,p_list_text_03=>'data-id="3"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(501929127197809673)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Nunca'
,p_static_id=>'nunca'
,p_list_text_03=>'data-id="1"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(501929566602809673)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Todos os Dias'
,p_static_id=>'todos-os-dias'
,p_list_text_03=>'data-id="2"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
