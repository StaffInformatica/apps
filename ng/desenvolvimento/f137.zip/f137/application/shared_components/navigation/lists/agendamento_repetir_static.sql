prompt --application/shared_components/navigation/lists/agendamento_repetir_static
begin
--   Manifest
--     LIST: Agendamento repetir Static
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(356222450528021189)
,p_name=>'Agendamento repetir Static'
,p_list_status=>'PUBLIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(356222725969021191)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Nunca'
,p_list_text_03=>'data-id="1"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(356223165374021191)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Todos os Dias'
,p_list_text_03=>'data-id="2"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(356223485980021191)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'A Cada Semana'
,p_list_text_03=>'data-id="3"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(356223970176021192)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'A Cada 2 Semanas'
,p_list_text_03=>'data-id="4"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(356224382120021192)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>unistr('A Cada M\00EAs')
,p_list_text_03=>'data-id="5"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(356224685802021192)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'A Cada Ano'
,p_list_text_03=>'data-id="6"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
