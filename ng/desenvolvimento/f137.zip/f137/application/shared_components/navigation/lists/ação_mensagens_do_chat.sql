prompt --application/shared_components/navigation/lists/ação_mensagens_do_chat
begin
--   Manifest
--     LIST: Ação mensagens do chat
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(321747177241291571)
,p_name=>unistr('A\00E7\00E3o mensagens do chat')
,p_static_id=>unistr('a\00E7\00E3o-mensagens-do-chat')
,p_version_scn=>'1'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(321754838927442546)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('Op\00E7\00E3o 2')
,p_static_id=>unistr('op\00E7\00E3o')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(321755171863442547)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>unistr('Op\00E7\00E3o 3')
,p_static_id=>unistr('op\00E7\00E3o-2')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(321747375154291579)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Responder'
,p_static_id=>'responder'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
