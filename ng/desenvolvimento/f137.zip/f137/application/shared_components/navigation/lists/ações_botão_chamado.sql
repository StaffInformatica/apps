prompt --application/shared_components/navigation/lists/ações_botão_chamado
begin
--   Manifest
--     LIST: Ações botão chamado
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.4'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(384077864665318076)
,p_name=>unistr('A\00E7\00F5es bot\00E3o chamado')
,p_static_id=>unistr('a\00E7\00F5es-bot\00E3o-chamado')
,p_version_scn=>'1'
);
wwv_flow_imp.component_end;
end;
/
