prompt --application/shared_components/navigation/tabs/standard
begin
--   Manifest
--     TABS: 137
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.16'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
null;
wwv_flow_imp.component_end;
end;
/
