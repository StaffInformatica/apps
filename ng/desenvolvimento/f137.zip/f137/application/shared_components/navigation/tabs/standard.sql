prompt --application/shared_components/navigation/tabs/standard
begin
--   Manifest
--     TABS: 137
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_TESTE'
);
null;
wwv_flow_imp.component_end;
end;
/
