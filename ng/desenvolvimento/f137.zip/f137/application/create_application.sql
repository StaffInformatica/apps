prompt --application/create_application
begin
--   Manifest
--     FLOW: 137
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.17'
,p_default_workspace_id=>145690023972863206
,p_default_application_id=>137
,p_default_id_offset=>145706401228788482
,p_default_owner=>'WKSP_DESENVOLVIMENTO'
);
wwv_imp_workspace.create_flow(
 p_id=>wwv_flow.g_flow_id
,p_owner=>nvl(wwv_flow_application_install.get_schema,'WKSP_DESENVOLVIMENTO')
,p_name=>nvl(wwv_flow_application_install.get_application_name,'NG')
,p_alias=>nvl(wwv_flow_application_install.get_application_alias,'NG')
,p_page_view_logging=>'YES'
,p_page_protection_enabled_y_n=>'Y'
,p_checksum_salt=>'0A9084DFC1996BCBFC0567E276020B2BB0F5DBB39F52DD547AA809D7B11F98C8'
,p_bookmark_checksum_function=>'SH512'
,p_compatibility_mode=>'21.2'
,p_accessible_read_only=>'N'
,p_session_state_commits=>'IMMEDIATE'
,p_flow_language=>'pt-br'
,p_flow_language_derived_from=>'ITEM_PREFERENCE'
,p_allow_feedback_yn=>'Y'
,p_date_format=>'dd/mm/yyyy'
,p_timestamp_format=>'DS'
,p_timestamp_tz_format=>'DD-MON-YYYY HH24:MI TZR'
,p_direction_right_to_left=>'N'
,p_flow_image_prefix => nvl(wwv_flow_application_install.get_image_prefix,'')
,p_authentication_id=>wwv_flow_imp.id(468780342541661722)
,p_application_tab_set=>1
,p_logo_type=>'IT'
,p_logo=>'#APP_FILES#icons/app-icon-256-rounded.png'
,p_logo_text=>'NG'
,p_public_user=>'APEX_PUBLIC_USER'
,p_proxy_server=>nvl(wwv_flow_application_install.get_proxy,'')
,p_no_proxy_domains=>nvl(wwv_flow_application_install.get_no_proxy_domains,'')
,p_flow_version=>'Release 1.0'
,p_flow_status=>'AVAILABLE_W_EDIT_LINK'
,p_flow_unavailable_text=>'This application is currently unavailable at this time.'
,p_exact_substitutions_only=>'Y'
,p_browser_cache=>'N'
,p_browser_frame=>'S'
,p_vpd=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_login varchar2(256);',
'    l_tz    varchar2(6);   -- ex: +00:00 / -03:00',
'begin',
unistr('    -- Usu\00E1rio logado no APEX'),
'    l_login := nvl(v(''APP_USER''), :APP_USER);',
'',
unistr('    -- Busca o fuso do usu\00E1rio; se n\00E3o achar, usa Brasil (-03:00)'),
'    begin',
'        select u.fuso_horario',
'          into l_tz',
'          from mpd_usuario u',
'         where upper(u.login) = upper(l_login);',
'    exception',
'        when no_data_found then',
'            l_tz := ''-03:00'';',
'    end;',
'',
unistr('    -- Se veio nulo, aplica padr\00E3o'),
'    l_tz := nvl(l_tz, ''-03:00'');',
'',
unistr('    -- Valida\00E7\00E3o r\00EDgida (evita lixo/injection): somente \00B1HH:MM'),
'    if regexp_like(l_tz, ''^[\+\-](0[0-9]|1[0-4]):[0-5][0-9]$'') then',
'        execute immediate ''alter session set time_zone = '''''' || l_tz || '''''''';',
'    else',
'        execute immediate ''alter session set time_zone = ''''-03:00'''''';',
'    end if;',
'end;'))
,p_runtime_api_usage=>'T:O:W'
,p_pass_ecid=>'N'
,p_rejoin_existing_sessions=>'N'
,p_csv_encoding=>'Y'
,p_auto_time_zone=>'Y'
,p_substitution_string_01=>'APP_NAME'
,p_substitution_value_01=>'NG'
,p_substitution_string_02=>'ON_CLOSE'
,p_substitution_value_02=>'close: function() { customEvent(''customDialogClose'', {modalPageId: ''MODAL_CLOSE_FIXED''});}'
,p_substitution_string_03=>'ON_DISABLE_CLOSE'
,p_substitution_value_03=>'var button = parent.$(''.ui-dialog-titlebar-close''); button.unbind(); button.on(''click'', function() {});'
,p_file_prefix => nvl(wwv_flow_application_install.get_static_app_file_prefix,'')
,p_files_version=>3164
,p_version_scn=>49885421932221
,p_print_server_type=>'NATIVE'
,p_file_storage=>'DB'
,p_is_pwa=>'Y'
,p_pwa_is_installable=>'N'
,p_pwa_is_push_enabled=>'N'
,p_copyright_banner=>unistr('Uma aplica\00E7\00E3o para abertura de chamados de corre\00E7\00E3o e melhorias seria uma ferramenta usada por uma empresa ou organiza\00E7\00E3o para gerenciar solicita\00E7\00F5es de corre\00E7\00F5es ou melhorias em seus sistemas, produtos ou servi\00E7os.')
);
wwv_flow_imp.component_end;
end;
/
