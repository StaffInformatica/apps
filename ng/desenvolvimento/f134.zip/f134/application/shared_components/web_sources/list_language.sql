prompt --application/shared_components/web_sources/list_language
begin
--   Manifest
--     WEB SOURCE: list-language
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>60010874338124056
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(279823478165112726)
,p_name=>'list-language'
,p_static_id=>'list_language'
,p_web_source_type=>'NATIVE_ORDS'
,p_data_profile_id=>wwv_flow_imp.id(279822609994112719)
,p_remote_server_id=>wwv_flow_imp.id(107553653157433019)
,p_url_path_prefix=>'/languages/create-language'
,p_attribute_01=>'N'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(279823618185112727)
,p_web_src_module_id=>wwv_flow_imp.id(279823478165112726)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(279824042918112729)
,p_web_src_module_id=>wwv_flow_imp.id(279823478165112726)
,p_operation=>'POST'
,p_database_operation=>'INSERT'
,p_url_pattern=>'.'
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
