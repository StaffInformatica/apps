prompt --application/shared_components/logic/application_items/a_reset_breadcrumb1
begin
--   Manifest
--     APPLICATION ITEM: A_RESET_BREADCRUMB1
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>60010874338124056
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(13856450845520976)
,p_name=>'A_RESET_BREADCRUMB1'
,p_protection_level=>'S'
,p_version_scn=>44351908749030
);
wwv_flow_imp.component_end;
end;
/
