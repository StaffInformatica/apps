prompt --application/shared_components/logic/application_processes/set_breadcrumb
begin
--   Manifest
--     APPLICATION PROCESS: SET_BREADCRUMB
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>60010874338124056
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(13817954548262491)
,p_process_sequence=>1
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SET_BREADCRUMB'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_codigo_artefato varchar2(256);',
'    -- v_inicio timestamp;',
'    -- v_fim    timestamp;',
'    -- v_tempo_ms number;',
'begin',
unistr('    -- in\00EDcio'),
'    -- v_inicio := systimestamp;',
'',
'    if apex_page.get_page_mode(:APP_ID,:APP_PAGE_ID) = ''NORMAL'' then',
'        v_codigo_artefato := apex_util.get_session_state(''P''||:APP_PAGE_ID||''_CODIGO_ARTEFATO'');',
'        ',
unistr('        -- valida\00E7\00E3o'),
'        if v_codigo_artefato is null then',
'            -- dispara erro do tipo "Application Error"',
'            apex_error.add_error (',
unistr('                p_message          => ''O c\00F3digo do artefato n\00E3o pode ser nulo.'','),
'                p_display_location => apex_error.c_inline_in_notification',
'            );',
unistr('            return; -- para n\00E3o executar o resto'),
'        end if;',
'',
'        breadcrumb_pkg.add_entry(',
'            ''BREADCRUMB''||:APP_ID,',
'            v_codigo_artefato,',
'            :APP_PAGE_ID,',
'            :A_RESET_BREADCRUMB1,',
'            :P0_TITULO_TELA,',
'            :P0_HELP_TELA||'' (''||:P0_CODIGO_ARTEFATO||'')'',',
'            OWA_UTIL.GET_CGI_ENV(''SCRIPT_NAME'') ||  ',
'            OWA_UTIL.GET_CGI_ENV(''PATH_INFO'') ||''?''||  ',
'            OWA_UTIL.GET_CGI_ENV(''QUERY_STRING'')',
'        );',
'    end if;',
'',
'    if(:A_RESET_BREADCRUMB1 = ''Y'') then',
'        :A_RESET_BREADCRUMB1 :=''N'';',
'    end if;',
'',
'    -- fim',
'    -- v_fim := systimestamp;',
'',
unistr('    -- Calcula a diferen\00E7a de tempo em segundos'),
'    -- v_tempo_ms := ',
'    --     (EXTRACT(HOUR FROM (v_fim - v_inicio)) * 3600) +',
'    --     (EXTRACT(MINUTE FROM (v_fim - v_inicio)) * 60) +',
'    --      EXTRACT(SECOND FROM (v_fim - v_inicio));',
'                ',
'',
'    -- -- grava na tabela de log',
'    -- insert into log_execucao (app_id, page_id, tempo_execucao_s, funcao)',
'    -- values (:APP_ID, :APP_PAGE_ID, v_tempo_ms, ''SET_BREADCRUMB'');',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'apex_page.get_page_mode(:APP_ID,:APP_PAGE_ID) = ''NORMAL'' '
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_version_scn=>46149926586597
);
wwv_flow_imp.component_end;
end;
/
