prompt --application/shared_components/user_interface/lovs/lv_carga
begin
--   Manifest
--     LV_CARGA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>60010874338124056
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(284210659567541707)
,p_lov_name=>'LV_CARGA'
,p_lov_query=>'.'||wwv_flow_imp.id(284210659567541707)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(284210889385541707)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('N\00E3o h\00E1')
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(284211340743541708)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Iniciada pela staff'
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(284211774455541708)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Iniciada pelo cliente'
,p_lov_return_value=>'3'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(284212183576541708)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Iniciada por outra fonte'
,p_lov_return_value=>'4'
);
wwv_flow_imp.component_end;
end;
/
