prompt --application/shared_components/user_interface/lovs/lv_adm_webservice_tipo_autenticacao
begin
--   Manifest
--     LV_ADM_WEBSERVICE_TIPO_AUTENTICACAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>60010874338124056
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(360625909090075459)
,p_lov_name=>'LV_ADM_WEBSERVICE_TIPO_AUTENTICACAO'
,p_lov_query=>'.'||wwv_flow_imp.id(360625909090075459)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(360626344813075463)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('Sem autentica\00E7\00E3o')
,p_lov_return_value=>'0'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(360626733753075464)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('Autentica\00E7\00E3o b\00E1sica')
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(360627164519075464)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>unistr('Autentica\00E7\00E3o Oauth 2.0')
,p_lov_return_value=>'2'
);
wwv_flow_imp.component_end;
end;
/
