prompt --application/shared_components/user_interface/lovs/r_ng_pessoa_endereco_id_pessoa_titulo_endereco
begin
--   Manifest
--     R_NG_PESSOA_ENDERECO.ID_PESSOA-TITULO_ENDERECO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>60010874338124056
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(45400790249481593)
,p_lov_name=>'R_NG_PESSOA_ENDERECO.ID_PESSOA-TITULO_ENDERECO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select d, r from (',
'    select null d, null r, 0 ordem from dual',
'    union all',
'select ',
'    case',
'        when nome_abreviado is not null then nome_abreviado',
'        when nome_fantasia is not null then nome_fantasia',
'    end || '' - '' ||',
'    to_char(nvl(pkg_traducao.get_traducao(a.titulo_endereco), pkg_ui.retorna_label_tela(''sem_titulo''))) d, a.id, 1 ',
'from ng_pessoa_endereco a',
'join ng_pessoa b on b.id = a.id_pessoa ',
'left join ng_pessoa_fisica c on c.id_pessoa = b.id',
'left join ng_pessoa_juridica d on d.id_pessoa = b.id',
'where b.data_fim_vigencia is null ',
'or to_date(b.data_fim_vigencia) >= to_date(current_date))',
'order by ordem, d'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>46042322678107
);
wwv_flow_imp.component_end;
end;
/
