prompt --application/shared_components/user_interface/lovs/lv_possui_valor_padrao
begin
--   Manifest
--     LV_POSSUI_VALOR_PADRAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>60010874338124056
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(284247027287725361)
,p_lov_name=>'LV_POSSUI_VALOR_PADRAO'
,p_lov_query=>'.'||wwv_flow_imp.id(284247027287725361)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(284247371812725361)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('N\00E3o')
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(284247761588725362)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Sequencial'
,p_lov_return_value=>'2'
,p_lov_disp_cond_type=>'EXPRESSION'
,p_lov_disp_cond=>':P434_TIPO = 2'
,p_lov_disp_cond2=>'PLSQL'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(284248138240725362)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>unistr('Dom\00EDnio')
,p_lov_return_value=>'3'
,p_lov_disp_cond_type=>'EXPRESSION'
,p_lov_disp_cond=>':P434_TIPO = 7'
,p_lov_disp_cond2=>'PLSQL'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(284248488157725363)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Outro'
,p_lov_return_value=>'4'
);
wwv_flow_imp.component_end;
end;
/
