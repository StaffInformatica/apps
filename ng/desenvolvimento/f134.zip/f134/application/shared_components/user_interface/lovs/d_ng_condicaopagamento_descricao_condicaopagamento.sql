prompt --application/shared_components/user_interface/lovs/d_ng_condicaopagamento_descricao_condicaopagamento
begin
--   Manifest
--     D_NG_CONDICAOPAGAMENTO.DESCRICAO_CONDICAOPAGAMENTO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>60010874338124056
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(38700885382558649)
,p_lov_name=>'D_NG_CONDICAOPAGAMENTO.DESCRICAO_CONDICAOPAGAMENTO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    pkg_traducao.get_traducao(a.descricao_condicaopagamento) d, ',
'    a.id r ',
'from ng_condicaopagamento a ',
'order by 1'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>46037546301516
);
wwv_flow_imp.component_end;
end;
/
