prompt --application/shared_components/user_interface/lovs/d_fin_titulopagamento_ind_status_pagamento
begin
--   Manifest
--     D_FIN_TITULOPAGAMENTO.IND_STATUS_PAGAMENTO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>60010874338124056
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(36395584156282686)
,p_lov_name=>'D_FIN_TITULOPAGAMENTO.IND_STATUS_PAGAMENTO'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''fin_titulopagamento'',''ind_status_pagamento'') order by 1'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>45909237624156
);
wwv_flow_imp.component_end;
end;
/
