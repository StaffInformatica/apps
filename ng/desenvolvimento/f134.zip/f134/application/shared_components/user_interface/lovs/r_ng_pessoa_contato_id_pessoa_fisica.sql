prompt --application/shared_components/user_interface/lovs/r_ng_pessoa_contato_id_pessoa_fisica
begin
--   Manifest
--     R_NG_PESSOA_CONTATO.ID_PESSOA_FISICA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>60010874338124056
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(48784141386288704)
,p_lov_name=>'R_NG_PESSOA_CONTATO.ID_PESSOA_FISICA'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct ',
'    a.nome_abreviado||'' - ''||a.nome d, ',
'    a.id_pessoa r ',
'from ng_pessoa_fisica a',
'join ng_pessoa_contato b on b.id_pessoa_fisica = a.id_pessoa',
'join ng_pessoa c on c.id = a.id_pessoa',
'where c.data_fim_vigencia is null',
'or to_date(c.data_fim_vigencia, ''dd/mm/yyyy'') >= to_date(current_date, ''dd/mm/yyyy'')',
'order by 1'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>44955390451392
);
wwv_flow_imp.component_end;
end;
/
