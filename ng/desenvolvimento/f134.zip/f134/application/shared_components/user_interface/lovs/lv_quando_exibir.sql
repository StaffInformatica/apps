prompt --application/shared_components/user_interface/lovs/lv_quando_exibir
begin
--   Manifest
--     LV_QUANDO_EXIBIR
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>60010874338124056
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(254362768875528035)
,p_lov_name=>'LV_QUANDO_EXIBIR'
,p_lov_query=>'.'||wwv_flow_imp.id(254362768875528035)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(254362997202528035)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Ao iniciar o sistema'
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(254363399839528036)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Ao fechar o sistema'
,p_lov_return_value=>'2'
);
wwv_flow_imp.component_end;
end;
/
