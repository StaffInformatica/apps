prompt --application/shared_components/user_interface/lovs/lv_sup_empresas
begin
--   Manifest
--     LV_SUP_EMPRESAS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>60010874338124056
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(374760938917436746)
,p_lov_name=>'LV_SUP_EMPRESAS'
,p_lov_query=>'select ID AS DONUT_ID, NOME from ADM_EMPRESAS'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_table=>'ADM_EMPRESAS'
,p_return_column_name=>'DONUT_ID'
,p_display_column_name=>'NOME'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'NOME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
