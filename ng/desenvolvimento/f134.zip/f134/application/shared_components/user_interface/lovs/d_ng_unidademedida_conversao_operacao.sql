prompt --application/shared_components/user_interface/lovs/d_ng_unidademedida_conversao_operacao
begin
--   Manifest
--     D_NG_UNIDADEMEDIDA_CONVERSAO.OPERACAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>60010874338124056
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(44255419559816269)
,p_lov_name=>'D_NG_UNIDADEMEDIDA_CONVERSAO.OPERACAO'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''ng_unidademedida_conversao'',''operacao'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>44648607493772
);
wwv_flow_imp.component_end;
end;
/
