prompt --application/shared_components/user_interface/lovs/lv_sup_notificacao
begin
--   Manifest
--     LV_SUP_NOTIFICACAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>60010874338124056
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(384073071607318072)
,p_lov_name=>'LV_SUP_NOTIFICACAO'
,p_lov_query=>'.'||wwv_flow_imp.id(384073071607318072)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(384073828995318073)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Nova mensagem'
,p_lov_return_value=>'S'
,p_lov_disp_cond_type=>'EXISTS'
,p_lov_disp_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT A.ID FROM ADM_CHAMADO_CHAT A',
'JOIN ADM_USUARIO B ON B.ID=A.ID_USUARIO',
'JOIN ADM_CHAMADO_ENVOLVIDOS C ON C.ID_CHAMADO = A.ID_CHAMADO',
'WHERE UPPER(USERNAME)!=UPPER(V(''APP_USER'')) AND A.NOTIFICACAO=''S'' AND C.ID_CHAMADO IN (SELECT ID_CHAMADO FROM ADM_USUARIO A',
'JOIN ADM_CHAMADO_ENVOLVIDOS B ON B.ID_USUARIO = A.ID',
'WHERE UPPER(A.USERNAME)=UPPER(V(''APP_USER''))); '))
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(384073461875318073)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Mensagens lidas'
,p_lov_return_value=>'N'
,p_lov_disp_cond_type=>'NEVER'
);
wwv_flow_imp.component_end;
end;
/
