prompt --application/shared_components/user_interface/lovs/r_ng_pessoa_agenciabancaria_nome_fantasia
begin
--   Manifest
--     R_NG_PESSOA_AGENCIABANCARIA.NOME_FANTASIA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>60010874338124056
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(46323153103384306)
,p_lov_name=>'R_NG_PESSOA_AGENCIABANCARIA.NOME_FANTASIA'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    nome_fantasia d,',
'    a.id r',
'from ng_pessoa_agenciabancaria a',
'join ng_pessoa b on b.id = a.id_pessoa',
'join ng_pessoa_juridica c on c.id_pessoa = b.id',
'where lower(c.ind_perfil) like ''%a%''',
'and (b.data_fim_vigencia is null ',
'or to_date(b.data_fim_vigencia) >= to_date(current_date))',
'order by 1'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>46084962210567
);
wwv_flow_imp.component_end;
end;
/
