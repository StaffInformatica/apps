prompt --application/shared_components/user_interface/lovs/d_srv_entidade_foreign_key_situacao
begin
--   Manifest
--     D_SRV_ENTIDADE_FOREIGN_KEY.SITUACAO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>60010874338124056
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(31842942072580263)
,p_lov_name=>'D_SRV_ENTIDADE_FOREIGN_KEY.SITUACAO'
,p_lov_query=>'select * from pkg_util.dominio_retorna_lista(''srv_entidade_foreign_key'',''situacao'') order by d'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>44452228488555
);
wwv_flow_imp.component_end;
end;
/
