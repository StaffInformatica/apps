prompt --application/shared_components/user_interface/lovs/lv_sup_usuario_historico
begin
--   Manifest
--     LV_SUP_USUARIO_HISTORICO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>42869539604646409
,p_default_application_id=>124
,p_default_id_offset=>60010874338124056
,p_default_owner=>'WKSP_TESTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(362781990471496200)
,p_lov_name=>'LV_SUP_USUARIO_HISTORICO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ID, ',
'CASE  ',
'WHEN UPPER(V(''APP_USER'')) IN (SELECT UPPER(USERNAME) FROM ADM_USUARIO WHERE UPPER(USERNAME) = UPPER(V(''APP_USER'')) AND TIPO = ''ADMIN:CREATE:DATA_LOADER:EDIT:HELP:MONITOR:SQL'')',
'THEN NOME',
'WHEN ID IN (SELECT ID_USUARIO FROM ADM_CHAMADO_ENVOLVIDOS WHERE ID_CHAMADO = :P159_ID_CHAMADO) ',
'THEN NOME',
'ELSE ''Help Desk'' END AS USUARIO',
'FROM ADM_USUARIO'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'ID'
,p_display_column_name=>'USUARIO'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'USUARIO'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
